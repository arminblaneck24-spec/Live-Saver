package com.lifesave.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.lifesave.MainActivity
import com.lifesave.core.*
import com.lifesave.training.ExerciseDb
import com.lifesave.training.Training
import com.lifesave.widget.WidgetUpdater

fun openApp(c: Context) {
    c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
}

/** Ist gerade etwas offen, für das sich das automatische Öffnen lohnt? */
fun somethingOpen(s: AppState = Store.state): Boolean =
    s.active != null || Training.dueToday(s) != null || Tasks.dueToday(s).isNotEmpty() ||
        s.habits.any { Habits.dueToday(it) && !Habits.doneToday(it) }

/**
 * Hintergrunddienst: öffnet die App nach dem Entsperren, erinnert an fällige Aufgaben,
 * meldet das Ende der Satzpause und hält das Widget aktuell.
 */
class UnlockService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_USER_PRESENT) return
            val lock = Locks.pending() != null
            // Tagesplan: ist ein Block vorbei, öffnet sich die App mit der Frage „Erledigt?“
            val ask = Schedule.pendingAsk() != null
            if (lock || ask || Locks.shouldOpen(Store.state, somethingOpen())) {
                Locks.markShown()
                openApp(c)
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            runCatching { onTick() }
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        ExerciseDb.init(this)
        WidgetUpdater.attach(this)
        CalendarSync.attach(this)
        val nm = getSystemService(NotificationManager::class.java)
        PlanNotifier.channels(nm)
        nm.createNotificationChannel(NotificationChannel("service", "Hintergrunddienst", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("due", "Erinnerungen", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("rest", "Satzpause", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("workout", "Laufendes Workout", NotificationManager.IMPORTANCE_LOW).apply {
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        val n = Notification.Builder(this, "service")
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setContentTitle("$APP_NAME ist aktiv")
            .setContentText("Öffnet sich nach dem Entsperren")
            .setContentIntent(openIntent())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        registerReceiver(receiver, IntentFilter(Intent.ACTION_USER_PRESENT))
        handler.post(tick)
    }

    private fun openIntent() = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun onTick() {
        ticks++
        checkRest()
        workoutNotification()
        runCatching { PlanNotifier.tick(this) }
        if (ticks % 360 == 0) com.lifesave.system.Health.autoSync(this) // alle 30 Minuten
        if (ticks % 12 == 0) { checkDue(); checkFood(); runCatching { PlanNotifier.reminders(this) } } // jede Minute
        if (ticks % 60 == 1) runCatching {                                  // alle 5 Minuten: Kalender & Aufgaben-Blöcke
            val t = startOfDay(now())
            CalendarSync.ensure(this, t, startOfDay(addDays(t, 2)))
            Schedule.ensureAuto(listOf(t))
        }
        if (ticks % 180 == 0) WidgetUpdater.update(this) // alle 15 Minuten
    }

    private var lastWorkoutKey = ""

    /** Gym-Modus: laufende Benachrichtigung mit Pausen-Countdown und nächstem Satz */
    private fun workoutNotification() {
        val s = Store.state
        val w = s.active
        val nm = getSystemService(NotificationManager::class.java)
        if (w == null || !s.settings.gymMode || !s.settings.gymNotify) {
            if (lastWorkoutKey.isNotEmpty()) { nm.cancel(3); lastWorkoutKey = "" }
            return
        }
        val resting = s.restUntil > now()
        val next = w.exercises.withIndex().firstOrNull { (_, e) -> e.sets.any { !it.done } }
        val nextText = next?.let { (_, e) ->
            val si = e.sets.indexOfFirst { !it.done }
            "${ExerciseDb.name(e.exId)} · Satz ${si + 1}/${e.sets.size}"
        } ?: "Alle Sätze erledigt – speichern nicht vergessen"
        val key = "${w.id}|${w.doneSets()}|${s.restUntil}|$resting"
        if (key == lastWorkoutKey) return
        lastWorkoutKey = key
        val b = Notification.Builder(this, "workout")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(openIntent())
            .setContentTitle(if (resting) "Pause · danach: $nextText" else "${w.name} · ${w.doneSets()}/${w.exercises.sumOf { it.sets.size }} Sätze")
            .setContentText(if (resting) "Nächster Satz gleich" else "Weiter: $nextText")
            .setUsesChronometer(true)
            .setShowWhen(true)
        if (resting) b.setWhen(s.restUntil).setChronometerCountDown(true) else b.setWhen(w.start)
        nm.notify(3, b.build())
    }

    private fun checkRest() {
        val r = Store.state.restUntil
        if (r == 0L || r == Store.restAlerted || now() < r) return
        Store.restAlerted = r
        val v = getSystemService(Vibrator::class.java)
        runCatching { v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)) }
        getSystemService(NotificationManager::class.java).notify(2, Notification.Builder(this, "rest")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Pause vorbei")
            .setContentText("Weiter mit dem nächsten Satz 💪")
            .setContentIntent(openIntent()).setAutoCancel(true).setTimeoutAfter(60_000).build())
    }

    /** Erinnerungen: 14 Uhr ohne Eintrag, 20 Uhr ohne Abendessen, Supplements ab 9 Uhr */
    private fun checkFood() {
        val s = Store.state
        if (!s.settings.mealReminders) return
        val h = hourNow(); val d = startOfDay(now())
        val last = s.lastFoodReminder
        fun notify(id: Int, title: String, text: String) {
            getSystemService(NotificationManager::class.java).notify(id, Notification.Builder(this, "due")
                .setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle(title).setContentText(text)
                .setContentIntent(openIntent()).setAutoCancel(true).build())
        }
        // Bits im Tagesmarker: 1 = Mittag, 2 = Abend, 4 = Supplements
        val flags = if (startOfDay(last) == d) (last - d).toInt() and 7 else 0
        var nf = flags
        if (h >= 14 && flags and 1 == 0 && (0..1).none { Nutrition.mealDone(d, it, s) }) {
            notify(10, "Noch nichts eingetragen 🍽", "Was gab's heute zum Frühstück und Mittag?"); nf = nf or 1
        }
        if (h >= 20 && flags and 2 == 0 && !Nutrition.mealDone(d, 2, s)) {
            notify(11, "Abendessen eintragen 🥗", "Damit dein Tagesabschluss schneller geht."); nf = nf or 2
        }
        val supps = s.nutritionGoals.supplements.filter { !Nutrition.suppTaken(it, s) }
        if (h >= 9 && flags and 4 == 0 && supps.isNotEmpty()) {
            notify(12, "Supplements 💊", supps.joinToString { SUPPLEMENTS[it] ?: it } + " nicht vergessen"); nf = nf or 4
        }
        if (nf != flags) Store.update { it.copy(lastFoodReminder = d + nf) }
    }

    private fun checkDue() {
        val n = now()
        val due = Store.state.tasks.filter { it.doneAt == null && !it.archived && !it.notified && it.due != null && it.due <= n }
        if (due.isEmpty()) return
        val nm = getSystemService(NotificationManager::class.java)
        due.forEach { t ->
            nm.notify((t.id % Int.MAX_VALUE).toInt(), Notification.Builder(this, "due")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Fällig: ${t.title}")
                .setContentText(t.note.ifBlank { "Jetzt erledigen" })
                .setContentIntent(openIntent()).setAutoCancel(true).build())
        }
        val ids = due.map { it.id }.toSet()
        Store.update { s -> s.copy(tasks = s.tasks.map { if (it.id in ids) it.copy(notified = true) else it }) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        handler.removeCallbacks(tick)
        Store.flush()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) runCatching { c.startForegroundService(Intent(c, UnlockService::class.java)) }
    }
}
