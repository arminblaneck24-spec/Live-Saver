package com.lifesave.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** „Rückgängig“-Leiste: nach Löschen/Verschieben ein paar Sekunden lang die letzte Aktion zurücknehmen */
object Undo {
    var text by mutableStateOf("")
        private set
    var until by mutableLongStateOf(0L)
        private set
    private var action: (() -> Unit)? = null

    fun offer(text: String, seconds: Int = 6, undo: () -> Unit) {
        this.text = text; action = undo; until = now() + seconds * 1000L
    }

    fun run() { val a = action; clear(); a?.invoke() }
    fun clear() { action = null; until = 0L }
}
