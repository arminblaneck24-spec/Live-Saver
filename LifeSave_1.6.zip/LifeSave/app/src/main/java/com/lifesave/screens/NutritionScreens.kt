package com.lifesave.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lifesave.core.*
import com.lifesave.system.FoodApi
import com.lifesave.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

val MACRO_COLORS = mapOf("protein" to Color(0xFFE57373), "fat" to Color(0xFFE0B83A), "carbs" to Color(0xFF4FA3E0), "fiber" to Color(0xFFB98B5E))

private fun r(v: Double?) = (v ?: 0.0).roundToInt()
private fun n1(v: Double) = if (v >= 100 || v == Math.floor(v)) v.roundToInt().toString() else String.format(java.util.Locale.GERMAN, "%.1f", v)

/** gewählter Tag im Ernährungstagebuch (bleibt beim Hin- und Herwechseln erhalten) */
object NutritionDay { var day by mutableLongStateOf(startOfDay(now())) }

// ================= Tagebuch =================
/** Eintrag, der gerade gezogen wird (Positionen in Bildschirm-Koordinaten) */
private class FoodDrag(val log: FoodLog, val p0: Offset, val s0: Int) {
    var pointer by mutableStateOf(p0)
}

@Composable
fun NutritionScreen() {
    val st = Store.state
    val p = pal
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val day = NutritionDay.day
    val today = startOfDay(now())
    val isToday = day == today
    val t = Nutrition.totals(day, st)
    val goalK = Nutrition.goal("kcal", st)
    val eaten = t["kcal"] ?: 0.0
    var editLog by remember { mutableStateOf<FoodLog?>(null) }
    var showMicros by remember { mutableStateOf(false) }
    editLog?.let { l -> LogEditDialog(l) { editLog = null } }

    // ---------- Ziehen & Ablegen ----------
    val scroll = rememberScrollState()
    var drag by remember { mutableStateOf<FoodDrag?>(null) }
    val mealRects = remember { mutableStateMapOf<Int, Rect>() }
    val dayRects = remember { mutableStateMapOf<Long, Rect>() }
    var boxRect by remember { mutableStateOf(Rect.Zero) }
    val stripDays = (-3..3).map { startOfDay(addDays(day, it)) }
    fun hoverDay(d: FoodDrag) = dayRects.entries.firstOrNull { it.value.contains(d.pointer) }?.key
    fun hoverMeal(d: FoodDrag) = if (hoverDay(d) != null) null else mealRects.entries.firstOrNull { it.value.contains(d.pointer) }?.key
    fun drop(d: FoodDrag) {
        val td = hoverDay(d)
        if (td != null) { if (td != d.log.day) Nutrition.moveLog(d.log, td, d.log.meal) }
        else hoverMeal(d)?.let { m -> if (m != d.log.meal) Nutrition.moveLog(d.log, d.log.day, m) }
    }
    // am Rand automatisch scrollen
    LaunchedEffect(drag != null) {
        while (drag != null) {
            val d = drag ?: break
            val edge = with(density) { 70.dp.toPx() }
            val y = d.pointer.y
            val v = when {
                y < boxRect.top + edge -> -(boxRect.top + edge - y) / 6f
                y > boxRect.bottom - edge -> (y - (boxRect.bottom - edge)) / 6f
                else -> 0f
            }
            if (v != 0f) scroll.scrollBy(v.coerceIn(-25f, 25f))
            delay(16)
        }
    }
    val logRow: @Composable (FoodLog) -> Unit = { l ->
        FoodLogRow(l, drag?.log?.id == l.id, onTap = { editLog = l }, onDelete = { Nutrition.deleteLogUndo(l) },
            onDragStart = { start -> haptic.performHapticFeedback(HapticFeedbackType.LongPress); drag = FoodDrag(l, start, scroll.value) },
            onDrag = { acc -> drag?.let { d -> d.pointer = d.p0 + acc - Offset(0f, (scroll.value - d.s0).toFloat()) } },
            onDragEnd = { drag?.let { drop(it) }; drag = null },
            onCancel = { drag = null })
    }

    Box(Modifier.fillMaxSize().onGloballyPositioned { boxRect = it.boundsInRoot() }) {
        Column(
            Modifier.fillMaxSize().verticalScroll(scroll, enabled = drag == null).padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ---------- Kopf: Gegessen · übrig · Ziel ----------
            Panel {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        BigNumber("${r(eaten)}", size = 24.sp); Muted("Gegessen")
                    }
                    Ring((eaten / goalK.coerceAtLeast(1.0)).toFloat(), if (eaten > goalK * 1.1) p.secondary else p.primary, 128.dp, 12.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            BigNumber("${r((goalK - eaten).coerceAtLeast(0.0))}", size = 28.sp)
                            Muted(if (eaten > goalK) "kcal drüber" else "kcal übrig", size = 12.sp)
                        }
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        BigNumber("${r(goalK)}", size = 24.sp); Muted("Ziel")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    MACROS.forEach { k ->
                        val g = Nutrition.goal(k, st); val v = t[k] ?: 0.0
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Ring((v / g.coerceAtLeast(1.0)).toFloat(), MACRO_COLORS[k] ?: p.primary, 64.dp, 7.dp) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("${r(v)}", fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = p.ink)
                                    Text("/${r(g)}g", fontSize = 10.sp, color = p.inkSoft)
                                }
                            }
                            Muted(NUTRIENT_BY_KEY[k]?.label?.take(12) ?: k, size = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
            // ---------- Tag wählen ----------
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBtn("‹", color = p.primary) { NutritionDay.day = startOfDay(addDays(day, -1)) }
                Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(p.panel).clickable { NutritionDay.day = today }.padding(10.dp),
                    contentAlignment = Alignment.Center) {
                    Body(if (isToday) "📅  Heute" else "📅  " + fmtDay(day), bold = true)
                }
                IconBtn("›", color = if (isToday) p.line else p.primary) { if (!isToday) NutritionDay.day = startOfDay(addDays(day, 1)) }
            }
            // ---------- Mahlzeiten ----------
            MEALS.indices.forEach { m ->
                val logs = Nutrition.logs(day, st).filter { it.meal == m }
                val mk = logs.sumOf { it.values["kcal"] ?: 0.0 }
                val planned = if (st.settings.nutritionPlanOn) Nutrition.planFor(dow(day), m, st) else null
                val hover = drag?.let { hoverMeal(it) == m && it.log.meal != m } == true
                Panel(Modifier.onGloballyPositioned { mealRects[m] = it.boundsInRoot() }, accent = if (hover) p.gold else null, padding = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(50.dp).clip(CircleShape).background(p.bg), contentAlignment = Alignment.Center) { Text(MEAL_ICONS[m], fontSize = 24.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Body(MEALS[m], bold = true, size = 17.sp)
                            Muted("${r(mk)} / ${r(Nutrition.mealGoal(m, st))} kcal" + if (m in (st.mealSkips[day] ?: emptySet())) " · ausgelassen" else "")
                        }
                        Box(Modifier.size(44.dp).clip(CircleShape).background(p.header).clickable { Nav.go("food_add", "$m|$day") }, contentAlignment = Alignment.Center) {
                            Text("+", color = p.onHeader, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (hover) Muted("Hier ablegen → ${MEALS[m]}", Modifier.padding(top = 6.dp), color = p.gold)
                    if (planned != null && logs.isEmpty()) {
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).background(p.soft).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Body("Geplant: ${planned.name}", Modifier.weight(1f), size = 14.sp)
                            Btn("Gegessen ✓", small = true) { Nutrition.logMeal(planned, m, day) }
                        }
                    }
                    logs.forEach { l -> key(l.id) { logRow(l) } }
                }
            }
            if (Nutrition.logs(day, st).isNotEmpty()) Muted("Tipp: Eintrag lange drücken und ziehen – in eine andere Mahlzeit oder oben auf einen anderen Tag.", size = 12.sp)
            // ---------- Supplements ----------
            if (isToday && st.nutritionGoals.supplements.isNotEmpty()) Panel {
                Heading("Supplements heute")
                st.nutritionGoals.supplements.forEach { k ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Body(SUPPLEMENTS[k] ?: k, Modifier.weight(1f))
                        Check(Nutrition.suppTaken(k, st), p.good) { Nutrition.toggleSupp(k) }
                    }
                }
            }
            // ---------- Was fehlt noch? ----------
            if (isToday) {
                val sug = Nutrition.suggestions(day, st)
                val needP = Nutrition.goal("protein", st) - (t["protein"] ?: 0.0)
                val needK = goalK - eaten
                Panel(accent = p.gold) {
                    Heading("Was fehlt noch?")
                    if (sug.isEmpty()) Body(if (eaten > 0) "Du hast deine Ziele für heute erreicht 🎉" else "Trag dein erstes Essen ein, dann kommen hier Vorschläge.")
                    else {
                        Body("Noch ${r(needK.coerceAtLeast(0.0))} kcal und ${r(needP.coerceAtLeast(0.0))} g Eiweiß – zum Beispiel:", size = 14.sp)
                        sug.forEach { s ->
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Body(s.label, bold = true, size = 14.sp, maxLines = 2)
                                    Muted("+${r(s.values["protein"])} g Eiweiß · ${r(s.values["kcal"])} kcal", size = 12.sp)
                                }
                                Btn("+", small = true, kind = BtnKind.SECONDARY) {
                                    val meal = if (hourNow() < 11) 0 else if (hourNow() < 16) 1 else if (hourNow() < 21) 2 else 3
                                    Nutrition.log(s.food, s.grams, meal, day)
                                }
                            }
                        }
                    }
                }
            }
            // ---------- Mikronährstoffe ----------
            Panel(onClick = { showMicros = !showMicros }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Heading("Alle Nährstoffe", Modifier.weight(1f))
                    Muted(if (showMicros) "▲" else "▼")
                }
                if (showMicros) NUTRIENTS.drop(1).forEach { n ->
                    val g = Nutrition.goal(n.key, st); val v = t[n.key] ?: 0.0
                    val over = n.isMax && v > g
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Row {
                            Body(n.label, Modifier.weight(1f), size = 14.sp)
                            Body("${n1(v)} / ${n1(g)} ${n.unit}" + if (n.isMax) " max." else "", size = 13.sp, color = if (over) p.secondary else p.ink)
                        }
                        Bar((v / g.coerceAtLeast(0.001)).toFloat(), if (over) p.secondary else if (v >= g) p.good else p.primary, height = 6.dp)
                    }
                }
                if (showMicros) Muted("Mikronährstoffe nur so genau wie die Daten der Lebensmittel – gescannte Produkte haben oft keine Angaben dazu.", Modifier.padding(top = 4.dp))
            }
            // ---------- Werkzeuge ----------
            Row {
                Btn("Mahlzeiten & Plan", Modifier.weight(1f), BtnKind.GHOST, small = true) { Nav.go("meals") }
                Spacer(Modifier.width(8.dp))
                Btn("Wochenbericht", Modifier.weight(1f), BtnKind.GHOST, small = true) { Nav.go("report") }
            }
            ClaudeImportPanel(subtitle = "Ziele, Pläne, Lebensmittel – Essen am besten über das ＋ der Mahlzeit")
            val g = st.nutritionGoals
            Muted("Ziele: ${g.source}" + (if (g.setAt > 0) " · Stand ${fmtDate(g.setAt)}" else "") + " · ${g.note}")
        }

        // ---------- beim Ziehen: Tage zum Ablegen + Vorschau ----------
        drag?.let { d ->
            val hd = hoverDay(d)
            Column(Modifier.fillMaxWidth().padding(10.dp).shadow(8.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(p.header).padding(8.dp)) {
                Text("Auf einen Tag ziehen", color = p.onHeader.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    stripDays.forEach { sd ->
                        val sel = sd == hd
                        val cur = sd == d.log.day
                        Column(
                            Modifier.weight(1f).onGloballyPositioned { dayRects[sd] = it.boundsInRoot() }.clip(RoundedCornerShape(10.dp))
                                .background(if (sel) p.gold else if (cur) p.onHeader.copy(alpha = 0.18f) else p.onHeader.copy(alpha = 0.08f))
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val fc = if (sel) Color(0xFF12161C) else p.onHeader
                            Text(WEEKDAYS.find { it.first == dow(sd) }?.second ?: "", color = fc, fontSize = 11.sp)
                            Text(if (sd == today) "heute" else fmtShort(sd).dropLast(1), color = fc, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
            val ghostX = with(density) { (d.pointer.x - boxRect.left).toDp() } - 120.dp
            val ghostY = with(density) { (d.pointer.y - boxRect.top).toDp() } - 64.dp
            Row(
                Modifier.offset(x = ghostX.coerceAtLeast(8.dp), y = ghostY.coerceAtLeast(0.dp)).width(240.dp).shadow(10.dp, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp)).background(p.panel).border(2.dp, p.gold, RoundedCornerShape(12.dp)).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Body(d.log.name, Modifier.weight(1f), bold = true, size = 14.sp, maxLines = 1)
                Body("${r(d.log.values["kcal"])} kcal", size = 13.sp)
            }
        }
        // Positionen der Tage nur während des Ziehens gültig
        if (drag == null && dayRects.isNotEmpty()) SideEffect { dayRects.clear() }
    }
}

/** Zeile eines Eintrags: antippen = bearbeiten · ✕ = löschen · lange drücken = ziehen */
@Composable
private fun FoodLogRow(
    l: FoodLog, dragging: Boolean, onTap: () -> Unit, onDelete: () -> Unit,
    onDragStart: (Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onCancel: () -> Unit
) {
    val p = pal
    var origin by remember { mutableStateOf(Offset.Zero) }
    var acc by remember { mutableStateOf(Offset.Zero) }
    val dStart by rememberUpdatedState(onDragStart)
    val dMove by rememberUpdatedState(onDrag)
    val dEnd by rememberUpdatedState(onDragEnd)
    val dCancel by rememberUpdatedState(onCancel)
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).alpha(if (dragging) 0.35f else 1f)
            .onGloballyPositioned { origin = it.boundsInRoot().topLeft }
            .pointerInput(l.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { o -> acc = Offset.Zero; dStart(origin + o) },
                    onDrag = { ch, a -> ch.consume(); acc += a; dMove(acc) },
                    onDragEnd = { dEnd() },
                    onDragCancel = { dCancel() }
                )
            }
            .clip(RoundedCornerShape(8.dp)).clickable { onTap() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Body(l.name, size = 14.sp, maxLines = 1)
            Muted("${n1(l.grams)} g · E ${r(l.values["protein"])} g · K ${r(l.values["carbs"])} g · F ${r(l.values["fat"])} g", size = 11.sp)
        }
        Body("${r(l.values["kcal"])} kcal", size = 14.sp, bold = true)
        IconBtn("✕", color = p.inkSoft, size = 34.dp) { onDelete() }
    }
}

@Composable
private fun LogEditDialog(l: FoodLog, onClose: () -> Unit) {
    var g by remember { mutableStateOf(n1(l.grams)) }
    var meal by remember { mutableIntStateOf(l.meal) }
    var day by remember { mutableLongStateOf(l.day) }
    val today = startOfDay(now())
    Dialog(onDismissRequest = onClose) {
        Panel {
            Heading(l.name)
            Field(g, { g = it }, "Menge in g", decimal = true)
            Muted("${r(l.values["kcal"])} kcal", Modifier.padding(top = 4.dp))
            Heading("Mahlzeit", Modifier.padding(top = 8.dp))
            ChipRow { MEALS.forEachIndexed { i, n -> Pick(n, meal == i) { meal = i } } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBtn("‹", color = pal.primary) { day = startOfDay(addDays(day, -1)) }
                Body(if (day == today) "Heute" else fmtDay(day), Modifier.weight(1f), bold = true)
                IconBtn("›", color = pal.primary) { day = startOfDay(addDays(day, 1)) }
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Btn("Löschen", Modifier.weight(1f), BtnKind.GHOST) { Nutrition.deleteLogUndo(l); onClose() }
                Spacer(Modifier.width(8.dp))
                Btn("Speichern", Modifier.weight(1f), enabled = (parseNum(g) ?: 0.0) > 0) {
                    val ng = parseNum(g)!!
                    if (ng != l.grams) Nutrition.updateGrams(l, ng)
                    if (meal != l.meal || day != l.day) Store.state.foodLogs.find { it.id == l.id }?.let { Nutrition.moveLog(it, day, meal) }
                    onClose()
                }
            }
        }
    }
}

// ================= Lebensmittel hinzufügen =================
@Composable
fun AddFoodScreen(arg: String) {
    val ctx = LocalContext.current
    val p = pal
    val st = Store.state
    val meal = arg.substringBefore("|").toIntOrNull() ?: 0
    val day = arg.substringAfter("|").toLongOrNull() ?: startOfDay(now())
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var online by remember { mutableStateOf<List<Food>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf<Food?>(null) }
    val scope = rememberCoroutineScope()

    fun lookup(code: String) {
        loading = true; msg = "Suche Barcode $code …"
        scope.launch {
            val f = runCatching { withContext(Dispatchers.IO) { FoodApi.byBarcode(code) } }
            loading = false
            f.onSuccess { food ->
                if (food == null) { msg = "Produkt nicht gefunden – bitte selbst anlegen oder Nährwerttabelle an Claude schicken."; Nav.go("food_edit", "barcode:$code") }
                else { Nutrition.upsertFood(food); msg = ""; pick = food }
            }.onFailure { msg = "Keine Verbindung: ${it.message}" }
        }
    }
    pick?.let { f -> AmountDialog(f, meal, day) { pick = null; if (it) Nav.back() } }

    val list: List<Food> = when {
        q.isNotBlank() && tab != 4 -> Nutrition.search(q, st)
        tab == 0 -> Nutrition.recent(st)
        tab == 1 -> Nutrition.allFoods(st).filter { it.fav }
        tab == 2 -> Nutrition.allFoods(st).filter { it.id in FoodDb.HOME || it.source != "builtin" }.filter { !it.excluded }
        tab == 4 -> online
        else -> emptyList()
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp)) {
            Body("${MEAL_ICONS[meal]} ${MEALS[meal]} · " + if (day == startOfDay(now())) "heute" else fmtShort(day), bold = true)
            Spacer(Modifier.height(6.dp))
            // Import von Claude direkt hier – alles landet in genau dieser Mahlzeit
            ClaudeImportPanel(meal = meal, day = day, subtitle = "Landet komplett bei ${MEALS[meal]}", onDone = { Nav.back() })
            Spacer(Modifier.height(8.dp))
            Field(q, { q = it }, "Lebensmittel suchen")
            Row(Modifier.padding(top = 8.dp)) {
                Btn("📷 Barcode", Modifier.weight(1f), small = true) {
                    FoodApi.scan(ctx, { code -> lookup(code) }, { e -> msg = e })
                }
                Spacer(Modifier.width(6.dp))
                Btn("＋ Eigenes", Modifier.weight(1f), BtnKind.SECONDARY, small = true) { Nav.go("food_edit", "new") }
            }
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("Zuletzt", "★ Favor.", "Zuhause", "Gerichte", "🌐 Online"), tab) { i ->
                tab = i
                if (i == 4 && q.length >= 3) { loading = true; scope.launch { online = runCatching { withContext(Dispatchers.IO) { FoodApi.search(q) } }.getOrDefault(emptyList()); loading = false } }
            }
            if (loading) Muted("Lädt …")
            if (msg.isNotBlank()) Muted(msg, color = p.secondary)
            if (tab == 4 && q.length < 3) Muted("Mindestens 3 Buchstaben eingeben, dann erneut auf „Online“ tippen.")
        }
        Box(Modifier.weight(1f)) {
            Screen {
                if (tab == 3 && q.isBlank()) {
                    if (st.savedMeals.isEmpty()) item { Empty("Noch keine gespeicherten Mahlzeiten – unter „Mahlzeiten & Plan“ anlegen.") }
                    items(st.savedMeals, key = { "m" + it.id }) { m ->
                        val v = Nutrition.total(m.items.mapNotNull { i -> Nutrition.food(i.foodId)?.let { FoodLog(day = day, meal = meal, name = it.name, grams = i.grams, values = Nutrition.values(it, i.grams)) } })
                        Panel(padding = 10.dp, onClick = { Nutrition.logMeal(m, meal, day); Nav.back() }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Body(m.name, bold = true)
                                    Muted("${m.items.size} Zutaten · E ${r(v["protein"])} g")
                                }
                                Body("${r(v["kcal"])} kcal", bold = true)
                            }
                        }
                    }
                } else {
                    if (list.isEmpty()) item { Empty(if (tab == 0 && q.isBlank()) "Noch nichts gegessen – such ein Lebensmittel oder scanne einen Barcode." else "Keine Treffer.") }
                    items(list.take(80), key = { it.id }) { f -> FoodRow(f) { pick = f } }
                }
            }
        }
    }
}

@Composable
fun FoodRow(f: Food, onClick: () -> Unit) {
    val p = pal
    Panel(padding = 10.dp, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Body(f.name, bold = true, maxLines = 2)
                Muted(listOfNotNull(f.brand.ifBlank { null }, "${f.portionName} (${n1(f.portionG)} g)").joinToString(" · "), size = 12.sp, maxLines = 1)
                Muted("pro 100 g: ${r(f.per100["kcal"])} kcal · E ${n1(f.per100["protein"] ?: 0.0)} g", size = 12.sp)
            }
            Text(if (f.fav) "★" else "☆", Modifier.clickable { Nutrition.toggleFav(f) }.padding(8.dp), fontSize = 22.sp, color = if (f.fav) p.gold else p.inkSoft)
        }
    }
}

@Composable
private fun AmountDialog(f: Food, meal: Int, day: Long, onClose: (Boolean) -> Unit) {
    val p = pal
    var g by remember { mutableStateOf(n1(f.portionG)) }
    var m by remember { mutableIntStateOf(meal) }
    val grams = parseNum(g) ?: 0.0
    val v = Nutrition.values(f, grams)
    Dialog(onDismissRequest = { onClose(false) }) {
        Panel {
            Heading(f.name)
            if (f.brand.isNotBlank()) Muted(f.brand)
            Field(g, { g = it }, "Menge in g", decimal = true)
            ChipRow {
                Pick("1× ${f.portionName.take(18)}", grams == f.portionG) { g = n1(f.portionG) }
                Pick("2×", grams == f.portionG * 2) { g = n1(f.portionG * 2) }
                Pick("100 g", grams == 100.0) { g = "100" }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                listOf("kcal" to "kcal", "protein" to "E", "carbs" to "K", "fat" to "F").forEach { (k, l) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        BigNumber("${r(v[k])}", size = 20.sp, color = MACRO_COLORS[k] ?: p.ink); Muted(l, size = 11.sp)
                    }
                }
            }
            ChipRow { MEALS.forEachIndexed { i, name -> Pick(name, m == i) { m = i } } }
            Spacer(Modifier.height(8.dp))
            Row {
                Btn("Bearbeiten", Modifier.weight(1f), BtnKind.GHOST, small = true) { onClose(false); Nav.go("food_edit", f.id) }
                Spacer(Modifier.width(8.dp))
                Btn("Hinzufügen", Modifier.weight(1.4f), enabled = grams > 0) { Nutrition.log(f, grams, m, day); onClose(true) }
            }
        }
    }
}

// ================= Lebensmittel bearbeiten / anlegen =================
@Composable
fun FoodEditor(arg: String) {
    val st = Store.state
    val existing = if (arg == "new" || arg.startsWith("barcode:")) null else Nutrition.food(arg, st)
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var brand by remember { mutableStateOf(existing?.brand ?: "") }
    var portion by remember { mutableStateOf(n1(existing?.portionG ?: 100.0)) }
    var portionName by remember { mutableStateOf(existing?.portionName ?: "Portion") }
    val vals = remember { mutableStateMapOf<String, String>().apply { NUTRIENTS.forEach { n -> put(n.key, existing?.per100?.get(n.key)?.let { n1(it) } ?: "") } } }
    var excluded by remember { mutableStateOf(existing?.excluded ?: false) }
    Screen {
        item {
            Panel {
                if (arg.startsWith("barcode:")) Muted("Barcode ${arg.removePrefix("barcode:")} nicht gefunden – Werte von der Verpackung abtippen oder ein Foto der Nährwerttabelle an Claude schicken.")
                Field(name, { name = it }, "Name")
                Spacer(Modifier.height(6.dp))
                Field(brand, { brand = it }, "Marke (optional)")
                Spacer(Modifier.height(6.dp))
                Row {
                    Field(portion, { portion = it }, "Portion (g)", Modifier.weight(1f), decimal = true)
                    Spacer(Modifier.width(8.dp))
                    Field(portionName, { portionName = it }, "Portionsname", Modifier.weight(1.4f))
                }
            }
        }
        item {
            Panel {
                Heading("Nährwerte pro 100 g")
                NUTRIENTS.chunked(2).forEach { row ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        row.forEach { n ->
                            Field(vals[n.key] ?: "", { vals[n.key] = it }, "${n.label} (${n.unit})", Modifier.weight(1f).padding(end = 6.dp), decimal = true)
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                ToggleRow("Nie vorschlagen", excluded, "z. B. bei Unverträglichkeit") { excluded = it }
            }
        }
        item {
            Btn("Speichern", Modifier.fillMaxWidth(), enabled = name.isNotBlank() && (parseNum(vals["kcal"] ?: "") ?: -1.0) >= 0) {
                val per = NUTRIENTS.associate { it.key to (parseNum(vals[it.key] ?: "") ?: 0.0) }
                val id = existing?.id?.takeIf { !it.startsWith("b_") } ?: existing?.id ?: ("c_" + newId())
                Nutrition.upsertFood(Food(id, name.trim(), brand.trim(), per, parseNum(portion) ?: 100.0, portionName.ifBlank { "Portion" },
                    barcode = existing?.barcode ?: arg.removePrefix("barcode:").takeIf { arg.startsWith("barcode:") } ?: "",
                    source = existing?.source ?: "manual", fav = existing?.fav ?: true, excluded = excluded))
                Nav.back()
            }
        }
        if (existing != null && existing.source != "builtin") item {
            Btn("Lebensmittel löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { Nutrition.deleteFood(existing.id); Nav.back() }
        }
    }
}

// ================= Mahlzeiten & Wochenplan =================
@Composable
fun MealsScreen() {
    val st = Store.state
    val p = pal
    var name by remember { mutableStateOf("") }
    var fromMeal by remember { mutableIntStateOf(0) }
    var planPick by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    planPick?.let { (wd, m) ->
        Dialog(onDismissRequest = { planPick = null }) {
            Panel {
                Heading("${WEEKDAY_LONG[wd]} · ${MEALS[m]}")
                if (st.savedMeals.isEmpty()) Empty("Erst eine Mahlzeit speichern.")
                st.savedMeals.forEach { sm -> Body(sm.name, Modifier.fillMaxWidth().clickable { Nutrition.setPlan(wd, m, sm.id); planPick = null }.padding(vertical = 10.dp)) }
                Btn("Leeren", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) { Nutrition.setPlan(wd, m, null); planPick = null }
            }
        }
    }
    Screen {
        item {
            Panel {
                Heading("Mahlzeit speichern")
                Muted("Speichert alles, was du heute bei einer Mahlzeit eingetragen hast – danach mit einem Tipp wieder eintragen.")
                ChipRow { MEALS.forEachIndexed { i, n -> Pick(n, fromMeal == i) { fromMeal = i } } }
                Field(name, { name = it }, "Name, z. B. „Rührei mit Toast“")
                val items = Nutrition.logs(startOfDay(now()), st).filter { it.meal == fromMeal && it.foodId.isNotBlank() }
                Muted("${items.size} Einträge von heute", Modifier.padding(top = 4.dp))
                Btn("Speichern", Modifier.fillMaxWidth().padding(top = 6.dp), enabled = name.isNotBlank() && items.isNotEmpty()) {
                    Nutrition.upsertMeal(SavedMeal(name = name.trim(), meal = fromMeal, items = items.map { MealItem(it.foodId, it.grams) })); name = ""
                }
            }
        }
        item { Heading("Gespeicherte Mahlzeiten") }
        if (st.savedMeals.isEmpty()) item { Empty("Noch keine") }
        items(st.savedMeals, key = { it.id }) { m ->
            Panel(padding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Body(m.name, bold = true)
                        Muted(m.items.joinToString(", ") { i -> (Nutrition.food(i.foodId)?.name ?: "?") + " ${n1(i.grams)} g" }, maxLines = 2)
                    }
                    IconBtn("✕", color = p.secondary) { Nutrition.deleteMeal(m.id) }
                }
            }
        }
        item {
            Panel {
                ToggleRow("Wochenplan nutzen", st.settings.nutritionPlanOn, "Optional: feste Mahlzeiten je Wochentag, im Tagebuch mit einem Tipp abhaken") { v ->
                    Store.setSettings { it.copy(nutritionPlanOn = v) }
                }
            }
        }
        if (st.settings.nutritionPlanOn) items(WEEKDAYS, key = { "wd" + it.first }) { (wd, short) ->
            Panel(padding = 10.dp) {
                Body(WEEKDAY_LONG[wd] ?: short, bold = true)
                MEALS.forEachIndexed { m, mn ->
                    Row(Modifier.fillMaxWidth().clickable { planPick = wd to m }.padding(vertical = 4.dp)) {
                        Muted(mn, Modifier.width(110.dp))
                        Body(Nutrition.planFor(wd, m, st)?.name ?: "–", size = 14.sp)
                    }
                }
            }
        }
    }
}

// ================= Import von Claude =================
/**
 * [meal]/[day] gesetzt (über das ＋ einer Mahlzeit): alle Essens-Einträge landen genau dort.
 * Das Textfeld bleibt immer gleich groß (innen scrollbar), damit „Hinzufügen“ ohne Scrollen sichtbar ist.
 */
@Composable
fun ClaudeImportPanel(meal: Int? = null, day: Long? = null, subtitle: String = "Essen per Foto, Nährwerttabellen, Ziele, Pläne", onDone: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val p = pal
    val forMeal = meal != null
    var open by remember { mutableStateOf(if (forMeal) Store.state.settings.foodImportOpen else false) }
    var text by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    fun run(t: String) {
        msg = runCatching { ClaudeImport.run(t, meal, day) }.getOrElse { "Ungültiger Text – bitte den JSON-Text von Claude komplett einfügen." }
        if (msg.startsWith("✓")) {
            text = ""
            if (onDone != null) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show(); onDone() }
            if (onDone == null) open = false
        }
    }
    fun toggle() {
        open = !open
        if (forMeal) Store.setSettings { it.copy(foodImportOpen = open) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() } }
            .onSuccess { run(it) }.onFailure { msg = "Datei konnte nicht gelesen werden." }
    }
    Panel(padding = 12.dp, accent = if (forMeal) p.gold else null) {
        Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
            Text("✨", fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Body("Von Claude importieren", bold = true)
                Muted(subtitle, size = 12.sp, maxLines = 1)
            }
            Muted(if (open) "▲" else "▼")
        }
        if (msg.isNotBlank()) Muted(msg, Modifier.padding(top = 6.dp), color = if (msg.startsWith("✓")) p.good else p.secondary)
        if (open) {
            Spacer(Modifier.height(8.dp))
            // feste Höhe: langer Text scrollt im Feld, die Knöpfe bleiben direkt darunter
            Field(text, { text = it }, "Text von Claude hier einfügen", singleLine = false, minLines = 4, maxLines = 4)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Btn("Datei", Modifier.weight(1f), BtnKind.GHOST, small = true) { launcher.launch(arrayOf("application/json", "text/plain", "*/*")) }
                Spacer(Modifier.width(8.dp))
                Btn("Hinzufügen", Modifier.weight(2f), small = true, enabled = text.isNotBlank()) { run(text) }
            }
        }
    }
}

// ================= Wochenbericht =================
@Composable
fun ReportScreen() {
    val ctx = LocalContext.current
    val report = remember { Nutrition.weeklyReport() }
    Screen {
        item {
            Panel {
                Heading("Wochenbericht für Claude")
                Muted("Kopieren oder teilen und bei Claude einfügen. Du bekommst eine Ziel-Datei zurück, die du unter „Von Claude importieren“ lädst.")
                Spacer(Modifier.height(8.dp))
                Row {
                    Btn("Kopieren", Modifier.weight(1f)) {
                        ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Life Save Wochenbericht", report))
                        Toast.makeText(ctx, "Kopiert", Toast.LENGTH_SHORT).show()
                    }
                    Spacer(Modifier.width(8.dp))
                    Btn("Teilen", Modifier.weight(1f), BtnKind.SECONDARY) {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report), "Teilen")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }
        item { Panel { Text(report, fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, color = pal.ink) } }
    }
}
