package com.lifesave.core

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Ein Import für alles, was von Claude kommt (Datei oder eingefügter Text).
 * Erkannte Teile (alle optional):
 *  - "plans":  Trainingspläne
 *  - "goals":  Ernährungsziele {targets:{kcal, protein, …}, mealSplit:[4], supplements:[…], note}
 *  - "foods":  Lebensmittel {id?, name, brand?, per100:{…}, portionG, portionName}
 *  - "logs":   Einträge {day:"today"|"yesterday"|"JJJJ-MM-TT", meal:0–3|"Frühstück", name, grams, values:{…} oder per100:{…}}
 *  - "meals":  gespeicherte Mahlzeiten {name, meal, items:[{foodId|food:{…}, grams}]}
 *  - "exclude": Namen von Lebensmitteln, die nie vorgeschlagen werden
 * Bestehende Daten bleiben erhalten (Ziele werden ersetzt).
 */
object ClaudeImport {
    /**
     * [forceMeal]/[forceDay]: Import über das Plus einer Mahlzeit → alle Einträge landen genau dort,
     * egal was im Text steht.
     */
    fun run(text: String, forceMeal: Int? = null, forceDay: Long? = null): String {
        val t = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val root: JSONObject = if (t.startsWith("[")) JSONObject().put("plans", JSONArray(t)) else JSONObject(t)
        val out = mutableListOf<String>()

        // ---- Trainingspläne ----
        if (root.has("plans") || root.has("days")) {
            val l = com.lifesave.training.Training.importPlans(if (root.has("plans")) root.toString() else t)
            if (l.isNotEmpty()) out += "${l.size} Trainingsplan/-pläne"
        }
        // ---- Ziele ----
        root.optJSONObject("goals")?.let { g ->
            val ng = Json.goalsFrom(g).copy(setAt = now(), source = "Claude")
            Store.update { it.copy(nutritionGoals = ng) }
            out += "Ernährungsziele (${ng.targets["kcal"]?.toInt()} kcal, ${ng.targets["protein"]?.toInt()} g Eiweiß)"
        }
        // ---- Lebensmittel ----
        val idMap = mutableMapOf<String, String>()
        root.optJSONArray("foods")?.let { a ->
            var n = 0
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val f = foodFrom(o)
                idMap[o.optString("id", f.name)] = f.id
                Nutrition.upsertFood(f); n++
            }
            if (n > 0) out += "$n Lebensmittel"
        }
        // ---- Einträge ----
        root.optJSONArray("logs")?.let { a ->
            var n = 0
            val newLogs = mutableListOf<FoodLog>()
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val day = forceDay ?: parseDay(o.optString("day", "today"))
                val meal = forceMeal ?: parseMeal(o.opt("meal"))
                val grams = o.optDouble("grams", 100.0)
                val fid = o.optString("foodId").let { idMap[it] ?: it }
                val known = Nutrition.food(fid)
                val values: Map<String, Double> = when {
                    o.has("values") -> Json.numMap(o.optJSONObject("values"))
                    o.has("per100") -> Json.numMap(o.optJSONObject("per100")).mapValues { it.value * grams / 100 }
                    known != null -> Nutrition.values(known, grams)
                    else -> emptyMap()
                }
                if (values.isEmpty()) continue
                val e = FoodLog(day = day, meal = meal, foodId = known?.id ?: "", name = o.optString("name", known?.name ?: "Mahlzeit"), grams = grams, values = values)
                newLogs += e
                if (o.optBoolean("saveFood") && o.has("per100")) Nutrition.upsertFood(Food("c_" + newId(), e.name, "", Json.numMap(o.optJSONObject("per100")), grams, "Portion", source = "claude"))
                n++
            }
            Nutrition.addLogs(newLogs)
            if (n > 0) out += "$n Essens-Einträge" + (forceMeal?.let { " → ${MEALS[it]}" } ?: "")
        }
        // ---- Mahlzeiten ----
        root.optJSONArray("meals")?.let { a ->
            var n = 0
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val items = mutableListOf<MealItem>()
                o.optJSONArray("items")?.let { ia ->
                    for (j in 0 until ia.length()) {
                        val it = ia.optJSONObject(j) ?: continue
                        val fid = it.optJSONObject("food")?.let { fo -> foodFrom(fo).also { f -> Nutrition.upsertFood(f) }.id }
                            ?: it.optString("foodId").let { x -> idMap[x] ?: x }
                        items += MealItem(fid, it.optDouble("grams", 100.0))
                    }
                }
                if (items.isNotEmpty()) { Nutrition.upsertMeal(SavedMeal(name = o.optString("name", "Mahlzeit"), meal = parseMeal(o.opt("meal")), items = items)); n++ }
            }
            if (n > 0) out += "$n Mahlzeiten"
        }
        // ---- Ausschlüsse ----
        root.optJSONArray("exclude")?.let { a ->
            val names = (0 until a.length()).map { a.optString(it).lowercase() }
            Nutrition.allFoods().filter { f -> names.any { f.name.lowercase().contains(it) } }.forEach { Nutrition.upsertFood(it.copy(excluded = true)) }
            if (names.isNotEmpty()) out += "${names.size} Ausschlüsse"
        }
        return if (out.isEmpty()) "Nichts Passendes in der Datei gefunden." else "✓ Importiert: " + out.joinToString(", ")
    }

    private fun foodFrom(o: JSONObject): Food {
        val base = Json.foodFrom(o)
        val id = if (o.optString("id").isBlank() || !o.optString("id").startsWith("c_") && !o.optString("id").startsWith("b_")) "c_" + base.name.lowercase().filter { it.isLetterOrDigit() }.take(30) else base.id
        return base.copy(id = id, source = if (base.source == "manual") "claude" else base.source)
    }

    fun parseDay(s: String): Long = when (s.lowercase()) {
        "", "today", "heute" -> startOfDay(now())
        "yesterday", "gestern" -> startOfDay(addDays(now(), -1))
        else -> runCatching { startOfDay(SimpleDateFormat("yyyy-MM-dd", Locale.GERMAN).parse(s)!!.time) }.getOrDefault(startOfDay(now()))
    }

    fun parseMeal(v: Any?): Int = when (v) {
        is Number -> v.toInt().coerceIn(0, 3)
        is String -> v.toIntOrNull()?.coerceIn(0, 3) ?: MEALS.indexOfFirst { it.lowercase().startsWith(v.lowercase().take(4)) }.let { if (it < 0) 3 else it }
        else -> if (hourNow() < 11) 0 else if (hourNow() < 16) 1 else if (hourNow() < 21) 2 else 3
    }
}
