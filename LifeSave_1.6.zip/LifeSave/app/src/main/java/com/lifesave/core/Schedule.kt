package com.lifesave.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.lifesave.training.Training
import kotlin.math.ceil
import kotlin.math.roundToInt

// ================= Tagesplan (Stundenplan im UNTIS-Stil) =================

/** Kategorie mit eigener Farbe, wie die Fächer bei UNTIS */
data class SchedCat(val id: String, val name: String, val color: String)

const val SRC_OWN = "own"            // selbst eingetragen
const val SRC_TASK = "task"          // aus einer Aufgabe mit Uhrzeit (ref = "t:<id>")
const val SRC_TRAINING = "training"  // Training laut Plan

const val BLOCK_OPEN = 0
const val BLOCK_DONE = 1
const val BLOCK_SKIPPED = 2          // ausgefallen

/** Ein Block im Tagesplan. Zeiten in Minuten ab Mitternacht. */
data class Block(
    val id: Long = newId(),
    val day: Long,
    val start: Int,
    val dur: Int,
    val title: String,
    val cat: String = "",
    val note: String = "",
    val source: String = SRC_OWN,
    val ref: String = "",
    val status: Int = BLOCK_OPEN,
    val extended: Int = 0,           // Minuten, um die schon verlängert wurde
    val reminded: Long = 0L,         // Startzeitpunkt, für den schon erinnert wurde
    val calEventId: Long = 0L,       // Termin im Google-Kalender (0 = noch keiner)
    val calSig: String = ""          // Stand, der zuletzt in den Kalender geschrieben wurde
) {
    val end: Int get() = start + dur
}

val DEFAULT_SCHED_CATS = listOf(
    SchedCat("uni", "Uni", "#1F4E79"),
    SchedCat("training", "Training", "#C8102E"),
    SchedCat("stream", "Stream", "#7E57C2"),
    SchedCat("essen", "Essen", "#2E7D46"),
    SchedCat("aufgabe", "Aufgabe", "#E07A1F"),
    SchedCat("freizeit", "Freizeit", "#C9A227"),
    SchedCat("haushalt", "Haushalt", "#54606E")
)

// ---------- Google-Kalender (wird von system/CalendarSync gefüllt) ----------
data class CalInfo(val id: Long, val name: String, val account: String, val color: Int, val writable: Boolean)

/** Ein Termin aus dem Kalender. Ganztägige: begin/end = lokale Tagesanfänge (end exklusiv). */
data class CalEvent(
    val key: String, val eventId: Long, val calId: Long, val title: String,
    val begin: Long, val end: Long, val allDay: Boolean, val color: Int, val location: String
)

object CalCache {
    var events by mutableStateOf<List<CalEvent>>(emptyList())
    var calendars by mutableStateOf<List<CalInfo>>(emptyList())
    var from by mutableLongStateOf(0L)
    var to by mutableLongStateOf(0L)
    var loadedAt by mutableLongStateOf(0L)
}

/** Ein Eintrag im Raster: eigener Block oder Kalendertermin */
data class PlanItem(
    val key: String, val day: Long, val start: Int, val dur: Int, val title: String,
    val color: String, val catName: String, val block: Block? = null, val cal: CalEvent? = null
) {
    val end: Int get() = start + dur
    val done: Boolean get() = block?.status == BLOCK_DONE
    val skipped: Boolean get() = block?.status == BLOCK_SKIPPED
}

data class SchedSuggestion(
    val title: String, val cat: String, val dur: Int,
    val source: String = SRC_OWN, val ref: String = "", val hint: String = ""
)

object Schedule {
    const val GRID_FROM = 5 * 60
    const val GRID_TO = 24 * 60
    const val SNAP = 10

    /** wird nach jeder Änderung aufgerufen (Kalender-Abgleich) */
    var onChange: (() -> Unit)? = null
    private fun changed() { onChange?.invoke() }

    fun snap(m: Int): Int = (m / SNAP.toDouble()).roundToInt() * SNAP
    fun snapUp(m: Int): Int = ceil(m / SNAP.toDouble()).toInt() * SNAP
    fun snapDown(m: Int, step: Int = SNAP): Int = Math.floorDiv(m, step) * step
    fun clampStart(start: Int, dur: Int): Int = start.coerceIn(GRID_FROM, (GRID_TO - dur).coerceAtLeast(GRID_FROM))

    // ---------- Kategorien ----------
    fun cat(id: String, s: AppState = Store.state) = s.schedCats.find { it.id == id }
    fun colorOf(b: Block, s: AppState = Store.state): String = cat(b.cat, s)?.color ?: when (b.source) {
        SRC_TRAINING -> "#C8102E"; SRC_TASK -> "#E07A1F"; else -> "#1F4E79"
    }
    fun upsertCat(c: SchedCat) = Store.update { s ->
        if (s.schedCats.any { it.id == c.id }) s.copy(schedCats = s.schedCats.map { if (it.id == c.id) c else it }) else s.copy(schedCats = s.schedCats + c)
    }
    fun deleteCat(id: String) = Store.update { s -> s.copy(schedCats = s.schedCats.filterNot { it.id == id }) }

    // ---------- Einträge eines Tages ----------
    fun blocks(day: Long, s: AppState = Store.state) = s.blocks.filter { it.day == day }.sortedBy { it.start }

    private fun hexOf(argb: Int) = String.format("#%06X", 0xFFFFFF and argb)

    fun calTimed(day: Long, s: AppState = Store.state): List<PlanItem> {
        if (!s.settings.calRead) return emptyList()
        val hidden = s.settings.calHidden.toSet()
        return CalCache.events.filter { !it.allDay && it.calId !in hidden && startOfDay(it.begin) == day }.map { e ->
            val shift = s.calShifts[e.key] ?: 0
            val st = minuteOf(e.begin) + shift
            val endM = if (startOfDay(e.end) == day) minuteOf(e.end) + shift else GRID_TO
            val start = st.coerceIn(0, GRID_TO - SNAP)
            PlanItem("c" + e.key, day, start, (endM - start).coerceIn(SNAP, GRID_TO - start), e.title.ifBlank { "Termin" },
                hexOf(e.color), "Kalender", cal = e)
        }
    }

    fun calAllDay(day: Long, s: AppState = Store.state): List<CalEvent> {
        if (!s.settings.calRead) return emptyList()
        val hidden = s.settings.calHidden.toSet()
        return CalCache.events.filter { it.allDay && it.calId !in hidden && it.begin <= day && day < it.end }
    }

    fun itemOf(b: Block, s: AppState = Store.state) =
        PlanItem("b${b.id}", b.day, b.start, b.dur, b.title, colorOf(b, s), cat(b.cat, s)?.name ?: "", block = b)

    fun items(day: Long, s: AppState = Store.state): List<PlanItem> =
        (blocks(day, s).map { itemOf(it, s) } + calTimed(day, s)).sortedWith(compareBy({ it.start }, { -it.dur }))

    /** Spalten für überlappende Einträge: Eintrag → (Spur, Anzahl Spuren in seiner Gruppe) */
    fun layout(list: List<PlanItem>): List<Triple<PlanItem, Int, Int>> {
        val out = mutableListOf<Triple<PlanItem, Int, Int>>()
        val sorted = list.sortedWith(compareBy({ it.start }, { -it.dur }))
        var group = mutableListOf<Pair<PlanItem, Int>>()
        var groupEnd = -1
        val laneEnds = mutableListOf<Int>()
        fun flush() {
            val lanes = (group.maxOfOrNull { it.second } ?: 0) + 1
            group.forEach { (item, lane) -> out += Triple(item, lane, lanes) }
            group = mutableListOf(); laneEnds.clear()
        }
        for (item in sorted) {
            if (item.start >= groupEnd && group.isNotEmpty()) flush()
            var lane = laneEnds.indexOfFirst { e -> e <= item.start }
            if (lane < 0) { lane = laneEnds.size; laneEnds += item.end } else laneEnds[lane] = item.end
            group.add(item to lane)
            groupEnd = maxOf(groupEnd, item.end)
        }
        if (group.isNotEmpty()) flush()
        return out
    }

    /** nächster freier 10-Minuten-Start (heute ab jetzt, sonst 9 Uhr) */
    fun nextSlot(day: Long): Int =
        if (day == startOfDay(now())) clampStart(snapUp(minuteOf(now())), 60) else 9 * 60

    // ---------- Ändern ----------
    fun upsert(b: Block) {
        val fixed = b.copy(start = clampStart(b.start, b.dur.coerceAtLeast(SNAP)), dur = b.dur.coerceIn(SNAP, GRID_TO - GRID_FROM))
        val f2 = fixed.copy(dur = fixed.dur.coerceAtMost(GRID_TO - fixed.start))
        Store.update { s ->
            if (s.blocks.any { it.id == f2.id }) s.copy(blocks = s.blocks.map { if (it.id == f2.id) f2 else it }) else s.copy(blocks = s.blocks + f2)
        }
        changed()
    }

    private fun edit(id: Long, f: (Block) -> Block) {
        Store.update { s -> s.copy(blocks = s.blocks.map { if (it.id == id) f(it) else it }) }
        changed()
    }

    fun move(id: Long, day: Long, start: Int) = edit(id) { b ->
        val ns = clampStart(start, b.dur)
        // Erinnerung neu, wenn sich die Startzeit ändert; Erledigt-Frage neu, wenn der Block in die Zukunft rückt
        b.copy(day = day, start = ns, dur = b.dur.coerceAtMost(GRID_TO - ns), reminded = 0L)
    }

    fun resize(id: Long, dur: Int) = edit(id) { b -> b.copy(dur = dur.coerceIn(SNAP, GRID_TO - b.start)) }

    fun setStatus(id: Long, status: Int) = edit(id) { it.copy(status = status) }

    fun delete(id: Long) {
        val s = Store.state
        val b = s.blocks.find { it.id == id } ?: return
        Store.update { st ->
            st.copy(
                blocks = st.blocks.filterNot { it.id == id },
                calDeleted = if (b.calEventId != 0L) st.calDeleted + b.calEventId else st.calDeleted,
                // automatisch angelegte Aufgaben-Blöcke nicht wieder anlegen
                schedHidden = if (b.source == SRC_TASK) st.schedHidden + "${b.ref}@${b.day}" else st.schedHidden
            )
        }
        changed()
        Undo.offer("„${b.title}“ gelöscht") {
            Store.update { st ->
                st.copy(blocks = st.blocks + b, calDeleted = st.calDeleted - b.calEventId, schedHidden = st.schedHidden - "${b.ref}@${b.day}")
            }
            changed()
        }
    }

    /** Kalendertermin nur in der App verschieben (der echte Termin bleibt unverändert) */
    fun shiftCal(key: String, delta: Int) {
        if (delta == 0) return
        Store.update { s -> s.copy(calShifts = s.calShifts + (key to ((s.calShifts[key] ?: 0) + delta))) }
    }
    fun resetCal(key: String) = Store.update { s -> s.copy(calShifts = s.calShifts - key) }

    // ---------- Erledigt? ----------
    /** Block, der vorbei ist und noch beantwortet werden muss (der früheste zuerst) */
    fun pendingAsk(s: AppState = Store.state, at: Long = now()): Block? {
        if (!s.settings.schedAskDone) return null
        val today = startOfDay(at)
        val m = minuteOf(at)
        return s.blocks.filter { b ->
            b.day == today && b.status == BLOCK_OPEN && b.end <= m &&
                // nachträglich eingetragene Blöcke (nach ihrem Ende angelegt) nicht abfragen
                b.id < atMinute(b.day, b.end)
        }.minByOrNull { it.end }
    }

    fun markDone(id: Long) {
        val b = Store.state.blocks.find { it.id == id } ?: return
        setStatus(id, BLOCK_DONE)
        if (b.source == SRC_TASK) Store.state.tasks.find { "t:${it.id}" == b.ref && it.doneAt == null }?.let { Tasks.complete(it) }
    }

    fun skip(id: Long) = setStatus(id, BLOCK_SKIPPED)

    /**
     * Nicht fertig: Block um [minutes] verlängern (ab jetzt, falls schon später) und alles,
     * was danach an diesem Tag geplant ist – auch Kalendertermine mit Uhrzeit –, nach hinten schieben.
     */
    fun extend(id: Long, minutes: Int = Store.state.settings.schedExtend) {
        val s = Store.state
        val b = s.blocks.find { it.id == id } ?: return
        val nowMin = if (b.day == startOfDay(now())) minuteOf(now()) else b.end
        val newEnd = snapUp(maxOf(b.end, nowMin) + minutes).coerceAtMost(GRID_TO)
        val delta = newEnd - b.end
        if (delta <= 0) { setStatus(id, BLOCK_DONE); return }
        val laterCal = calTimed(b.day, s).filter { it.start > b.start }.mapNotNull { it.cal?.key }
        Store.update { st ->
            st.copy(
                blocks = st.blocks.map { x ->
                    when {
                        x.id == b.id -> x.copy(dur = x.dur + delta, extended = x.extended + delta)
                        x.day == b.day && x.start > b.start -> {
                            val ns = (x.start + delta).coerceAtMost(GRID_TO - SNAP)
                            x.copy(start = ns, dur = x.dur.coerceAtMost(GRID_TO - ns), reminded = 0L)
                        }
                        else -> x
                    }
                },
                calShifts = st.calShifts + laterCal.associateWith { (st.calShifts[it] ?: 0) + delta }
            )
        }
        changed()
    }

    /** Aufgabe abgehakt → ihr Block heute gilt als erledigt (und umgekehrt) */
    fun syncTask(taskId: Long, done: Boolean) {
        val ref = "t:$taskId"
        val today = startOfDay(now())
        if (Store.state.blocks.none { it.ref == ref && it.day == today }) return
        Store.update { s ->
            s.copy(blocks = s.blocks.map { if (it.ref == ref && it.day == today) it.copy(status = if (done) BLOCK_DONE else BLOCK_OPEN) else it })
        }
        changed()
    }

    // ---------- Automatisch: Aufgaben mit Uhrzeit, Training ----------
    /** legt für Aufgaben mit Uhrzeit an diesen Tagen Blöcke an und räumt Blöcke gelöschter Aufgaben weg */
    fun ensureAuto(days: Collection<Long>) {
        val s = Store.state
        val add = mutableListOf<Block>()
        for (d in days.toSet()) {
            s.tasks.filter { t -> t.doneAt == null && !t.archived && t.due != null && startOfDay(t.due) == d }.forEach { t ->
                val ref = "t:${t.id}"
                if (s.blocks.none { it.ref == ref && it.day == d } && "$ref@$d" !in s.schedHidden) {
                    add += Block(day = d, start = clampStart(snapDown(minuteOf(t.due!!)), 30), dur = 30, title = t.title,
                        cat = if (cat("aufgabe", s) != null) "aufgabe" else "", source = SRC_TASK, ref = ref)
                }
            }
        }
        val taskRefs = s.tasks.map { "t:${it.id}" }.toSet()
        val orphans = s.blocks.filter { it.source == SRC_TASK && it.ref !in taskRefs }
        // Training erledigt → Training-Block abhaken
        val trainedDays = (s.workouts.map { startOfDay(it.start) } + s.cardio.map { startOfDay(it.at) }).toSet()
        val trainDone = s.blocks.filter { it.source == SRC_TRAINING && it.status == BLOCK_OPEN && it.day in trainedDays }.map { it.id }.toSet()
        if (add.isEmpty() && orphans.isEmpty() && trainDone.isEmpty()) return
        val orphanIds = orphans.map { it.id }.toSet()
        Store.update { st ->
            st.copy(
                blocks = st.blocks.filterNot { it.id in orphanIds }.map { if (it.id in trainDone) it.copy(status = BLOCK_DONE) else it } + add,
                calDeleted = st.calDeleted + orphans.filter { it.calEventId != 0L }.map { it.calEventId }
            )
        }
        changed()
    }

    /** Name des Trainingstags, der an [day] laut aktivem Plan dran ist */
    fun trainingOn(day: Long, s: AppState = Store.state): String? {
        val today = startOfDay(now())
        if (day < today) return s.workouts.firstOrNull { startOfDay(it.start) == day }?.name
        val p = Training.activePlan(s) ?: return null
        if (p.days.isEmpty()) return null
        if (p.mode == PLAN_ROTATION) {
            if (dow(day) !in p.trainDays) return null
            val trainedToday = s.workouts.any { it.planId == p.id && startOfDay(it.start) == today }
            if (day == today && trainedToday) return s.workouts.lastOrNull { startOfDay(it.start) == today }?.name
            var n = 0; var d = today; var g = 0
            while (d < day && g < 400) {
                if (dow(d) in p.trainDays && !(d == today && trainedToday)) n++
                d = startOfDay(addDays(d, 1)); g++
            }
            return p.days[Math.floorMod(p.nextIndex + n, p.days.size)].name
        }
        val w = Training.cycleWeek(p, day)
        return p.days.find { it.week == w && dow(day) in it.weekdays }?.name
    }

    /** Training, das an diesem Tag noch keinen Block hat */
    fun unplannedTraining(day: Long, s: AppState = Store.state): String? {
        if (day < startOfDay(now())) return null
        val name = trainingOn(day, s) ?: return null
        if (s.blocks.any { it.day == day && it.source == SRC_TRAINING }) return null
        if (day == startOfDay(now()) && Training.trainedToday(s)) return null
        return name
    }

    // ---------- Vorschläge beim Anlegen ----------
    fun suggestions(q: String, day: Long, s: AppState = Store.state): List<SchedSuggestion> {
        val ql = q.trim().lowercase()
        // frühere Einträge: häufigste zuerst, gleiche Namen zusammengefasst
        val hist = s.blocks.filter { it.source == SRC_OWN && it.title.isNotBlank() }
            .groupBy { it.title.trim().lowercase() }
            .map { (_, l) -> l.maxByOrNull { it.id }!! to l.size }
            .sortedWith(compareByDescending<Pair<Block, Int>> { it.second }.thenByDescending { it.first.id })
            .map { (b, n) ->
                SchedSuggestion(b.title.trim(), b.cat, b.dur, hint = listOfNotNull(cat(b.cat, s)?.name, fmtDur(b.dur), if (n > 1) "${n}×" else null).joinToString(" · "))
            }
        val special = mutableListOf<SchedSuggestion>()
        trainingOn(day, s)?.let { special += SchedSuggestion("🏋 $it", "training", 90, SRC_TRAINING, "tr", "Training laut Plan") }
        Tasks.open(s).sortedByDescending { it.priority }.take(40).forEach {
            special += SchedSuggestion(it.title, if (cat("aufgabe", s) != null) "aufgabe" else "", 30, SRC_TASK, "t:${it.id}",
                "Aufgabe" + (it.due?.let { d -> " · fällig " + fmtShort(d) } ?: ""))
        }
        val all = (hist + special).distinctBy { it.title.lowercase() + it.source }
        if (ql.isEmpty()) return (special.take(3) + hist).distinctBy { it.title.lowercase() + it.source }.take(14)
        return all.filter { it.title.lowercase().contains(ql) }
            .sortedBy { if (it.title.lowercase().startsWith(ql)) 0 else 1 }.take(14)
    }

    // ---------- Jetzt & als Nächstes ----------
    fun nowNext(s: AppState = Store.state, at: Long = now()): Pair<PlanItem?, PlanItem?> {
        val today = startOfDay(at)
        val m = minuteOf(at)
        val list = items(today, s).filter { !it.skipped }
        val cur = list.filter { it.start <= m && m < it.end }.sortedWith(compareBy({ it.block == null }, { -it.start })).firstOrNull()
        val next = list.filter { it.start > m && it.key != cur?.key }.minByOrNull { it.start }
        return cur to next
    }

    /** Blöcke, an die jetzt erinnert werden soll */
    fun dueReminders(s: AppState = Store.state, at: Long = now()): List<Block> {
        val lead = s.settings.schedRemind
        if (lead <= 0) return emptyList()
        val today = startOfDay(at)
        val m = minuteOf(at)
        return s.blocks.filter { b ->
            b.day == today && b.status == BLOCK_OPEN && b.start - lead <= m && m < b.start && b.reminded != atMinute(b.day, b.start)
        }
    }
    fun markReminded(ids: Collection<Long>) = Store.update { s ->
        s.copy(blocks = s.blocks.map { if (it.id in ids) it.copy(reminded = atMinute(it.day, it.start)) else it })
    }

    // ---------- Morgens planen ----------
    /** nach dem Wiegen einmal am Tag zum Tagesplan führen */
    fun shouldPrompt(s: AppState = Store.state): Boolean {
        if (!s.settings.schedPlanPrompt || s.active != null) return false
        val today = startOfDay(now())
        if (s.planPromptDay == today) return false
        val h = hourNow()
        if (h < s.settings.weighDailyHour || h >= 14) return false
        val weighed = s.weights.any { startOfDay(it.at) == today }
        return weighed || !s.settings.locksOn || !s.settings.weighDaily
    }
    fun markPrompted() = Store.update { it.copy(planPromptDay = startOfDay(now())) }
}
