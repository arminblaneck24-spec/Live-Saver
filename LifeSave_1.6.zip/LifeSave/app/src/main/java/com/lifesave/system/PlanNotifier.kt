package com.lifesave.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lifesave.MainActivity
import com.lifesave.core.*

/**
 * Benachrichtigungen des Tagesplans:
 *  - dauerhafte Zeile „Jetzt: … bis …“ mit dem nächsten Block (kommt nach dem Wegwischen sofort wieder)
 *  - Erinnerung X Minuten vor Beginn
 *  - nach dem Ende: „Erledigt?“ mit Knöpfen direkt in der Benachrichtigung
 */
object PlanNotifier {
    private const val ID_NOW = 20
    private const val ID_REMIND_BASE = 30_000
    private var lastKey = ""

    fun channels(nm: NotificationManager) {
        nm.createNotificationChannel(NotificationChannel("plan_now", "Tagesplan: jetzt dran", NotificationManager.IMPORTANCE_LOW).apply {
            setShowBadge(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        nm.createNotificationChannel(NotificationChannel("plan_remind", "Tagesplan: Erinnerungen", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openIntent(c: Context) = PendingIntent.getActivity(
        c, 7, Intent(c, MainActivity::class.java).putExtra("open", "plan").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun action(c: Context, act: String, id: Long, code: Int) = PendingIntent.getBroadcast(
        c, code, Intent(c, PlanActionReceiver::class.java).setAction(act).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** alle 5 Sekunden aus dem Hintergrunddienst */
    fun tick(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        val s = Store.state
        if (!s.settings.schedNowNotif) {
            if (lastKey.isNotEmpty()) { nm.cancel(ID_NOW); lastKey = "" }
            return
        }
        val ask = Schedule.pendingAsk(s)
        val (cur, next) = Schedule.nowNext(s)
        val title: String
        val text: String
        val b = Notification.Builder(c, "plan_now")
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(openIntent(c))
        when {
            ask != null -> {
                title = "${ask.title} ist vorbei – erledigt?"
                text = "Seit ${fmtMin(ask.end)} · nicht fertig = +${s.settings.schedExtend} Min., alles danach rutscht nach hinten"
                b.addAction(Notification.Action.Builder(null, "✓ Erledigt", action(c, PlanActionReceiver.DONE, ask.id, 1)).build())
                b.addAction(Notification.Action.Builder(null, "+${s.settings.schedExtend} Min.", action(c, PlanActionReceiver.EXTEND, ask.id, 2)).build())
            }
            cur != null -> {
                title = "Jetzt: ${cur.title} · bis ${fmtMin(cur.end)}"
                text = next?.let { "Danach: ${it.title} um ${fmtMin(it.start)}" } ?: "Danach ist nichts mehr geplant"
            }
            next != null -> {
                title = "Als Nächstes: ${next.title} um ${fmtMin(next.start)}"
                text = "Bis dahin frei"
            }
            else -> {
                if (lastKey.isNotEmpty()) { nm.cancel(ID_NOW); lastKey = "" }
                return
            }
        }
        val key = "$title|$text"
        // nach dem Wegwischen gleich wieder anzeigen
        val visible = runCatching { nm.activeNotifications.any { it.id == ID_NOW } }.getOrDefault(true)
        if (key == lastKey && visible) return
        lastKey = key
        nm.notify(ID_NOW, b.setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).build())
    }

    /** jede Minute: Erinnerung vor Beginn */
    fun reminders(c: Context) {
        val due = Schedule.dueReminders()
        if (due.isEmpty()) return
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        due.forEach { b ->
            val inMin = (b.start - minuteOf(now())).coerceAtLeast(0)
            nm.notify(ID_REMIND_BASE + (b.id % 10_000).toInt(), Notification.Builder(c, "plan_remind")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(if (inMin <= 0) "Jetzt: ${b.title}" else "In $inMin Min.: ${b.title}")
                .setContentText("${fmtMin(b.start)}–${fmtMin(b.end)}" + (Schedule.cat(b.cat)?.name?.let { " · $it" } ?: ""))
                .setContentIntent(openIntent(c)).setAutoCancel(true).setTimeoutAfter(30 * 60_000L).build())
        }
        Schedule.markReminded(due.map { it.id })
    }
}

/** Knöpfe „Erledigt“ / „+30 Min.“ in der Benachrichtigung */
class PlanActionReceiver : BroadcastReceiver() {
    companion object {
        const val DONE = "com.lifesave.PLAN_DONE"
        const val EXTEND = "com.lifesave.PLAN_EXTEND"
    }

    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        val id = i.getLongExtra("id", 0L)
        when (i.action) {
            DONE -> Schedule.markDone(id)
            EXTEND -> Schedule.extend(id)
        }
        Store.flush()
        runCatching { PlanNotifier.tick(c) }
    }
}
