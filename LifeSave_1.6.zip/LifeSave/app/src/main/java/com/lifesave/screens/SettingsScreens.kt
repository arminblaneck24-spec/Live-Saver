package com.lifesave.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.Pw
import com.lifesave.ui.*
import com.lifesave.widget.WidgetRenderer
import com.lifesave.widget.WidgetUpdater
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Menüpunkte der Einstellungen. Neue Bereiche: hier eintragen und unten im `when` ergänzen. */
val SETTINGS_SECTIONS = listOf(
    Triple("general", "Allgemein", "Startseite"),
    Triple("design", "Design & Farben", "Farbschema wählen oder eigene Farben"),
    Triple("navigation", "Navigation", "Welche Bereiche unten in der Leiste stehen"),
    Triple("dashboard", "Startseite anpassen", "Kacheln anordnen und ausblenden"),
    Triple("widget", "Widget", "Homescreen-Widget gestalten"),
    Triple("training", "Training", "Satzpause, Wochenziel, Gym-Modus"),
    Triple("photos", "Fortschrittsfotos", "Foto-Kategorien wie Front, Seite, Rücken"),
    Triple("vitals", "Schlaf, Wasser & Schritte", "Tagesziele"),
    Triple("health", "Health Connect", "Schritte, Schlaf und Gewicht automatisch übernehmen"),
    Triple("nutrition", "Ernährung", "Ziele (von Claude), Erinnerungen, Supplements"),
    Triple("plan", "Tagesplan & Kalender", "Kategorien, Erinnerungen, Google-Kalender"),
    Triple("locks", "Sperren & Automatik 🔒", "Wiegen, Tagesabschluss, automatisches Öffnen"),
    Triple("setup", "Einrichtung", "Berechtigungen prüfen"),
    Triple("data", "Daten & Backup", "Sichern, wiederherstellen"),
    Triple("update", "App-Update", "Neue Version direkt in der App installieren"),
    Triple("about", "Über Life Save", "Version und Neuerungen")
)

/** Gruppen der Einstellungs-Übersicht (Schlüssel aus SETTINGS_SECTIONS) */
val SETTINGS_GROUPS = listOf(
    "Darstellung" to listOf("general", "design", "navigation", "dashboard", "widget"),
    "Training & Körper" to listOf("training", "photos", "vitals", "health"),
    "Ernährung & Alltag" to listOf("nutrition", "plan"),
    "System" to listOf("locks", "setup", "data", "update", "about")
)
val SETTINGS_ICONS = mapOf(
    "general" to "⌂", "design" to "🎨", "navigation" to "☰", "dashboard" to "▦", "widget" to "▣",
    "training" to "🏋", "photos" to "📷", "vitals" to "💧", "health" to "❤", "nutrition" to "🥗", "plan" to "📅",
    "locks" to "🔒", "setup" to "✔", "data" to "💾", "update" to "⬆", "about" to "ℹ"
)

@Composable
fun SettingsScreen() {
    val byKey = SETTINGS_SECTIONS.associateBy { it.first }
    Screen {
        SETTINGS_GROUPS.forEach { (title, keys) ->
            val rows = keys.mapNotNull { byKey[it] }
            item(key = title) {
                MenuGroup(title, rows.map { (k, t, d) -> Triple(SETTINGS_ICONS[k] ?: "•", t, d) }) { i -> Nav.go("settings_x", rows[i].first) }
            }
        }
        item { Muted("$APP_NAME · Version $VERSION", Modifier.fillMaxWidth().padding(top = 4.dp), size = 12.sp) }
    }
}

@Composable
fun SettingsSection(k: String) {
    when (k) {
        "general" -> GeneralSettings()
        "training" -> TrainingSettings()
        "vitals" -> VitalsSettings()
        "health" -> HealthSettings()
        "nutrition" -> NutritionSettings()
        "plan" -> PlanSettings()
        "photos" -> PhotoSettings()
        "design" -> DesignSettings()
        "navigation" -> NavigationSettings()
        "dashboard" -> DashboardSettings()
        "widget" -> WidgetEditor()
        "locks" -> LockSettings()
        "setup" -> Screen { item { SetupPanel(always = true) } }
        "data" -> DataSettings()
        "about" -> AboutScreen()
        "update" -> UpdateScreen()
        else -> SettingsScreen()
    }
}

// ---------- Allgemein ----------
@Composable
fun GeneralSettings() {
    val s = Store.state.settings
    Screen {
        item {
            Panel {
                Heading("Startseite beim Öffnen")
                ChipRow { SECTIONS.filterKeys { it != "settings" }.forEach { (k, v) -> Pick(v, s.startPage == k) { Store.setSettings { it.copy(startPage = k) } } } }
            }
        }
    }
}

// ---------- Training ----------
@Composable
fun TrainingSettings() {
    val s = Store.state.settings
    val p = pal
    Screen {
        item {
            Panel {
                Heading("Satzpause")
                ToggleRow("Pause je Übung (empfohlen)", s.restAuto,
                    "Schwere Grundübungen 3 Min., andere Mehrgelenksübungen 2 Min., Isolation 75 Sek., Bauch/Waden 60 Sek.") { v -> Store.setSettings { it.copy(restAuto = v) } }
                Spacer(Modifier.height(6.dp))
                Muted(if (s.restAuto) "Feste Zeit (gilt für unbekannte und eigene Übungen):" else "Feste Zeit für alle Übungen:")
                Stepper(fmtDuration(s.restSec * 1000L),
                    { Store.setSettings { it.copy(restSec = (it.restSec - 15).coerceAtLeast(15)) } },
                    { Store.setSettings { it.copy(restSec = (it.restSec + 15).coerceAtMost(600)) } })
                Muted("Grundlage: Studien zeigen mehr Muskelaufbau mit längeren Pausen (2–3 Min.) bei schweren Übungen; bei kleinen Muskeln reichen 60–90 Sek.", Modifier.padding(top = 6.dp))
            }
        }
        item {
            Panel {
                Heading("Wochenziel")
                Stepper("${s.weeklyGoal} Workouts", { Store.setSettings { it.copy(weeklyGoal = (it.weeklyGoal - 1).coerceAtLeast(1)) } },
                    { Store.setSettings { it.copy(weeklyGoal = (it.weeklyGoal + 1).coerceAtMost(14)) } }, "Pro Woche")
            }
        }
        item {
            Panel {
                Heading("Gym-Modus")
                ToggleRow("Gym-Modus", s.gymMode, "Hilfen, während ein Workout läuft") { v -> Store.setSettings { it.copy(gymMode = v) } }
                if (s.gymMode) {
                    ToggleRow("Bildschirm bleibt an", s.gymKeepScreen) { v -> Store.setSettings { it.copy(gymKeepScreen = v) } }
                    ToggleRow("Benachrichtigung mit Pause & nächstem Satz", s.gymNotify, "auch auf dem Sperrbildschirm") { v -> Store.setSettings { it.copy(gymNotify = v) } }
                    ToggleRow("Über dem Sperrbildschirm anzeigen", s.gymLockScreen, "Workout sehen, ohne zu entsperren") { v -> Store.setSettings { it.copy(gymLockScreen = v) } }
                }
            }
        }
    }
}

@Composable
fun VitalsSettings() {
    val s = Store.state.settings
    Screen {
        item {
            Panel {
                Heading("Tagesziele")
                Stepper("${s.waterGoal} Gläser", { Store.setSettings { it.copy(waterGoal = (it.waterGoal - 1).coerceAtLeast(1)) } },
                    { Store.setSettings { it.copy(waterGoal = (it.waterGoal + 1).coerceAtMost(20)) } }, "Wasser")
                Muted("1 Glas = 250 ml · ${String.format(java.util.Locale.GERMAN, "%.2f", s.waterGoal * 0.25)} Liter")
                Spacer(Modifier.height(8.dp))
                Stepper(Vitals.fmtHours(s.sleepGoal), { Store.setSettings { it.copy(sleepGoal = (it.sleepGoal - 0.5).coerceAtLeast(5.0)) } },
                    { Store.setSettings { it.copy(sleepGoal = (it.sleepGoal + 0.5).coerceAtMost(11.0)) } }, "Schlaf")
                Spacer(Modifier.height(8.dp))
                Stepper("${s.stepGoal}", { Store.setSettings { it.copy(stepGoal = (it.stepGoal - 1000).coerceAtLeast(1000)) } },
                    { Store.setSettings { it.copy(stepGoal = (it.stepGoal + 1000).coerceAtMost(30000)) } }, "Schritte")
            }
        }
    }
}

@Composable
fun HealthSettings() {
    val ctx = LocalContext.current
    val p = pal
    val s = Store.state.settings
    val h = com.lifesave.system.Health
    val available = remember { h.available(ctx) }
    val launcher = rememberLauncherForActivityResult(h.permissionContract()) { granted ->
        h.refreshGranted(ctx)
        if (granted.isNotEmpty()) { Store.setSettings { it.copy(hcEnabled = true) }; h.sync(ctx) }
    }
    LaunchedEffect(Unit) { h.refreshGranted(ctx) }
    Screen {
        item {
            Panel(accent = p.primary) {
                Heading("Health Connect")
                Body("Übernimmt automatisch Schritte, Schlaf und Gewicht aus Samsung Health, Google Fit oder deiner Waage. Life Save liest nur, es schreibt nichts zurück.")
                Spacer(Modifier.height(8.dp))
                if (!available) {
                    Muted("Health Connect ist auf diesem Handy nicht verfügbar oder muss aktualisiert werden (Play Store → „Health Connect“).", color = p.secondary)
                } else {
                    val ok = h.granted.isNotEmpty()
                    Pill(if (ok) "Verbunden (${h.granted.size}/3 Berechtigungen)" else "Nicht verbunden", if (ok) p.good else p.secondary)
                    Spacer(Modifier.height(8.dp))
                    Btn(if (ok) "Berechtigungen ändern" else "Verbinden", Modifier.fillMaxWidth()) { runCatching { launcher.launch(h.PERMISSIONS) } }
                    if (ok) {
                        Spacer(Modifier.height(6.dp))
                        ToggleRow("Synchronisierung aktiv", s.hcEnabled) { v -> Store.setSettings { it.copy(hcEnabled = v) } }
                        ToggleRow("Schritte", s.hcSteps) { v -> Store.setSettings { it.copy(hcSteps = v) } }
                        ToggleRow("Schlaf", s.hcSleep, "eigene Einträge haben Vorrang") { v -> Store.setSettings { it.copy(hcSleep = v) } }
                        ToggleRow("Gewicht", s.hcWeight, "zählt auch fürs Wiegen am Samstag") { v -> Store.setSettings { it.copy(hcWeight = v) } }
                        Btn("Jetzt synchronisieren", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY) { h.sync(ctx) }
                    }
                }
                if (h.status.isNotBlank()) Muted(h.status, Modifier.padding(top = 6.dp))
            }
        }
    }
}

// ---------- Ernährung ----------
@Composable
fun NutritionSettings() {
    val st = Store.state
    val p = pal
    val g = st.nutritionGoals
    val admin = Store.adminActive()
    val edit = remember(admin) { mutableStateMapOf<String, String>().apply { NUTRIENTS.forEach { put(it.key, fmtKg(Math.round(Nutrition.goal(it.key, st) * 10) / 10.0)) } } }
    Screen {
        item {
            Panel(accent = p.gold) {
                Heading("Deine Ziele")
                Muted("Quelle: ${g.source}" + (if (g.setAt > 0) " · Stand ${fmtDate(g.setAt)}" else "") + "\n${g.note}")
                Spacer(Modifier.height(6.dp))
                NUTRIENTS.forEach { n ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Body(n.label + if (n.isMax) " (max.)" else "", Modifier.weight(1f), size = 14.sp)
                        if (admin) Field(edit[n.key] ?: "", { edit[n.key] = it }, n.unit, Modifier.width(110.dp), decimal = true)
                        else Body("${fmtKg(Math.round(Nutrition.goal(n.key, st) * 10) / 10.0)} ${n.unit}", bold = true, size = 14.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                if (admin) Btn("Ziele speichern", Modifier.fillMaxWidth()) {
                    val t = NUTRIENTS.associate { it.key to (parseNum(edit[it.key] ?: "") ?: Nutrition.goal(it.key)) }
                    Store.update { s -> s.copy(nutritionGoals = s.nutritionGoals.copy(targets = t, setAt = now(), source = "Eigene Anpassung")) }
                } else Muted("Die Ziele kommen von Claude: Wochenbericht schicken → Ziel-Datei importieren. Ändern von Hand nur mit Passwort (Sperren & Automatik).")
            }
        }
        item {
            Panel {
                Heading("Aufteilung auf Mahlzeiten")
                Body(MEALS.indices.joinToString(" · ") { "${MEALS[it]} ${(g.mealSplit.getOrElse(it) { 0.25 } * 100).toInt()} %" }, size = 14.sp)
                Heading("Supplements")
                if (g.supplements.isEmpty()) Muted("Keine – sag Claude Bescheid, sobald du Kreatin oder Proteinpulver hast, dann kommt es per Import mit Erinnerung dazu.")
                g.supplements.forEach { Body("• ${SUPPLEMENTS[it] ?: it}") }
            }
        }
        item {
            Panel {
                ToggleRow("Erinnerungen fürs Essen", st.settings.mealReminders, "14 Uhr ohne Eintrag, 20 Uhr ohne Abendessen, Supplements morgens") { v ->
                    Store.setSettings { it.copy(mealReminders = v) }
                }
            }
        }
        item { ClaudeImportPanel() }
    }
}

// ---------- Foto-Kategorien ----------
@Composable
fun PhotoSettings() {
    val cats = Store.state.settings.photoCats
    val p = pal
    var newCat by remember { mutableStateOf("") }
    Screen {
        item {
            Panel {
                Heading("Foto-Kategorien")
                Muted("Pro Tag ein Foto je Kategorie. Beim Vergleichen stehen gleiche Kategorien nebeneinander.")
                cats.forEachIndexed { i, c ->
                    var name by remember(c) { mutableStateOf(c) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Field(name, { name = it }, "Kategorie ${i + 1}", Modifier.weight(1f))
                        IconBtn("✓", color = if (name != c && name.isNotBlank()) p.primary else p.line) {
                            if (name.isNotBlank() && name != c) Store.update { s ->
                                s.copy(settings = s.settings.copy(photoCats = s.settings.photoCats.map { if (it == c) name.trim() else it }),
                                    photos = s.photos.map { if (it.category == c) it.copy(category = name.trim()) else it })
                            }
                        }
                        IconBtn("▲", color = if (i > 0) p.primary else p.line) { if (i > 0) Store.setSettings { it.copy(photoCats = it.photoCats.moved(i, i - 1)) } }
                        IconBtn("✕", color = p.secondary) { Store.setSettings { it.copy(photoCats = it.photoCats - c) } }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(newCat, { newCat = it }, "Neue Kategorie", Modifier.weight(1f))
                    IconBtn("＋", color = p.primary) {
                        val n = newCat.trim()
                        if (n.isNotEmpty() && n !in cats) { Store.setSettings { it.copy(photoCats = it.photoCats + n) }; newCat = "" }
                    }
                }
            }
        }
    }
}

// ---------- Design ----------
@Composable
fun DesignSettings() {
    val s = Store.state.settings
    val p = pal
    Screen {
        item { Heading("Farbschema") }
        THEMES.forEach { t ->
            item {
                val sel = s.themeId == t.id
                Panel(accent = if (sel) t.p.primary else null, onClick = { Store.setSettings { it.copy(themeId = t.id, customColors = emptyMap()) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Body(t.name + if (sel) "  ✓" else "", bold = true)
                            Muted(t.desc)
                        }
                        listOf(t.p.header, t.p.bg, t.p.primary, t.p.secondary, t.p.gold).forEach { c ->
                            Box(Modifier.padding(start = 3.dp).size(20.dp).clip(CircleShape).background(c).border(1.dp, p.line, CircleShape))
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("Eigene Farben")
                Muted("Überschreibt einzelne Farben des gewählten Schemas.")
                val base = paletteFor(s)
                CUSTOM_KEYS.forEach { (k, label) ->
                    val cur = s.customColors[k] ?: toHex(when (k) {
                        "primary" -> base.primary; "secondary" -> base.secondary; "gold" -> base.gold
                        "header" -> base.header; "bg" -> base.bg; else -> base.panel
                    })
                    ColorRow(label, cur) { hx -> Store.setSettings { it.copy(customColors = it.customColors + (k to hx)) } }
                }
                if (s.customColors.isNotEmpty()) Btn("Eigene Farben zurücksetzen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) {
                    Store.setSettings { it.copy(customColors = emptyMap()) }
                }
            }
        }
    }
}

// ---------- Navigation ----------
@Composable
fun NavigationSettings() {
    val s = Store.state.settings
    val p = pal
    Screen {
        item { Muted("Bis zu 5 Bereiche unten in der Leiste. Alle Bereiche findest du immer im Menü ☰ oben links.") }
        item {
            Panel {
                Heading("Unten in der Leiste")
                s.tabs.forEachIndexed { i, k ->
                    OrderRow(SECTIONS[k] ?: k, true, { if (s.tabs.size > 1) Store.setSettings { st -> st.copy(tabs = st.tabs - k) } },
                        if (i > 0) ({ Store.setSettings { st -> st.copy(tabs = st.tabs.moved(i, i - 1)) } }) else null,
                        if (i < s.tabs.size - 1) ({ Store.setSettings { st -> st.copy(tabs = st.tabs.moved(i, i + 1)) } }) else null)
                }
                Heading("Weitere Bereiche")
                SECTIONS.keys.filter { it !in s.tabs }.forEach { k ->
                    OrderRow(SECTIONS[k] ?: k, false, { if (s.tabs.size < 5) Store.setSettings { st -> st.copy(tabs = st.tabs + k) } }, null, null)
                }
                if (s.tabs.size >= 5) Muted("Maximal 5 – erst einen entfernen.", color = p.secondary)
            }
        }
    }
}

// ---------- Startseite ----------
@Composable
fun DashboardSettings() {
    val s = Store.state.settings
    Screen {
        item {
            Panel {
                Heading("Kacheln der Startseite")
                s.tiles.forEachIndexed { i, t ->
                    OrderRow(TILE_NAMES[t.id] ?: t.id, t.visible,
                        { v -> Store.setSettings { st -> st.copy(tiles = st.tiles.map { if (it.id == t.id) it.copy(visible = v) else it }) } },
                        if (i > 0) ({ Store.setSettings { st -> st.copy(tiles = st.tiles.moved(i, i - 1)) } }) else null,
                        if (i < s.tiles.size - 1) ({ Store.setSettings { st -> st.copy(tiles = st.tiles.moved(i, i + 1)) } }) else null)
                }
                Btn("Standard wiederherstellen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) {
                    Store.setSettings { it.copy(tiles = DEFAULT_TILES) }
                }
            }
        }
        item {
            Panel {
                Heading("Mannequin zeigt standardmäßig")
                RadioRow("Zuletzt trainiert (verblasst über 7 Tage)", s.mannequinMode == 0) { Store.setSettings { it.copy(mannequinMode = 0) } }
                RadioRow("Wochenvolumen (Sätze der letzten 7 Tage)", s.mannequinMode == 1) { Store.setSettings { it.copy(mannequinMode = 1) } }
            }
        }
    }
}

// ---------- Widget ----------
@Composable
fun WidgetEditor() {
    val ctx = LocalContext.current
    val st = Store.state
    val w = st.settings.widget
    val density = LocalDensity.current.density
    fun set(f: (WidgetCfg) -> WidgetCfg) { Store.setSettings { it.copy(widget = f(it.widget)) } }
    val preview = remember(w, st) { WidgetRenderer.render(w, st, (340 * density).toInt(), (200 * density).toInt(), density).asImageBitmap() }
    Screen {
        item {
            Panel {
                Heading("Vorschau")
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.header.copy(alpha = 0.25f)).padding(10.dp)) {
                    Image(preview, null, Modifier.fillMaxWidth().aspectRatio(1.7f))
                }
                Spacer(Modifier.height(8.dp))
                Btn("Widget zum Startbildschirm hinzufügen", Modifier.fillMaxWidth(), small = true) {
                    if (!WidgetUpdater.requestPin(ctx)) Toast.makeText(ctx, "Lange auf den Startbildschirm drücken → Widgets → Life Save", Toast.LENGTH_LONG).show()
                }
                Muted("Größe änderst du direkt auf dem Startbildschirm (lange drücken). Änderungen hier erscheinen sofort.", Modifier.padding(top = 6.dp))
            }
        }
        item {
            Panel {
                Heading("Vorlagen")
                ChipRow {
                    WIDGET_TEMPLATES.forEach { (k, list) ->
                        Pick(k.replaceFirstChar { it.uppercase() }, w.template == k) {
                            set { c -> c.copy(template = k, blocks = list.map { Tile(it, true) } + WIDGET_BLOCKS.keys.filter { it !in list }.map { Tile(it, false) }) }
                        }
                    }
                }
                Heading("Bausteine")
                w.blocks.forEachIndexed { i, b ->
                    OrderRow(WIDGET_BLOCKS[b.id] ?: b.id, b.visible,
                        { v -> set { c -> c.copy(template = "eigene", blocks = c.blocks.map { if (it.id == b.id) it.copy(visible = v) else it }) } },
                        if (i > 0) ({ set { c -> c.copy(template = "eigene", blocks = c.blocks.moved(i, i - 1)) } }) else null,
                        if (i < w.blocks.size - 1) ({ set { c -> c.copy(template = "eigene", blocks = c.blocks.moved(i, i + 1)) } }) else null)
                }
                Muted("Tipp: Das Mannequin erscheint bei breiten Widgets rechts neben dem Text.")
            }
        }
        item {
            Panel {
                Heading("Farben")
                ColorRow("Hintergrund", w.bg) { hx -> set { it.copy(bg = hx) } }
                ColorRow("Text", w.fg) { hx -> set { it.copy(fg = hx) } }
                ColorRow("Akzent", w.accent) { hx -> set { it.copy(accent = hx) } }
                Muted("Deckkraft: ${w.alpha * 100 / 255} %")
                Slider(w.alpha / 255f, { v -> set { it.copy(alpha = (v * 255).toInt()) } })
                Muted("Ecken: ${w.radius} dp")
                Slider(w.radius / 32f, { v -> set { it.copy(radius = (v * 32).toInt()) } })
                Btn("Farben wie App-Design", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) {
                    val pp = paletteFor(st.settings)
                    set { it.copy(bg = toHex(pp.header), fg = toHex(pp.onHeader), accent = toHex(pp.gold)) }
                }
            }
        }
    }
}

// ---------- Sperren (Passwort) ----------
@Composable
fun LockSettings() {
    val s = Store.state.settings
    val p = pal
    val admin = Store.adminActive()
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Screen {
        item {
            Panel(accent = p.gold) {
                Heading("Aktuell")
                Body(if (s.weighDaily) "⚖ Wiegen: jeden Morgen ab ${s.weighDailyHour}:00 Uhr · Fotos ${WEEKDAY_LONG[s.weighDay]}"
                    else "⚖ Wiegen: ${WEEKDAY_LONG[s.weighDay]} ab ${s.weighHour}:00 Uhr")
                Body("🌙 Tagesabschluss: täglich ab ${s.reviewHour}:00 Uhr")
                Body("📲 Öffnen nach dem Entsperren: " + OPEN_MODES[s.openMode.coerceIn(0, OPEN_MODES.size - 1)] + if (s.openMode == 1) " (${s.openInterval} Min.)" else "")
                Body("Sperren: " + if (s.locksOn) "an" else "aus")
                Muted("Während einer Sperre bleiben Telefon, Notruf und Uhr frei. Läuft ein Workout, wartet die Sperre.", Modifier.padding(top = 4.dp))
            }
        }
        if (!admin) item {
            Panel {
                Heading("🔒 Geschützt")
                Muted("Diese Einstellungen sind mit dem Passwort geschützt, das sich alle 5 Minuten ändert. Frag Claude nach dem aktuellen Passwort.")
                Spacer(Modifier.height(6.dp))
                Field(pw, { pw = it.uppercase().trim(); wrong = false }, "Passwort", caps = true)
                if (wrong) Muted("Falsches oder abgelaufenes Passwort", color = p.secondary)
                Btn("Entsperren", Modifier.fillMaxWidth().padding(top = 6.dp)) { if (Pw.check(pw)) { Store.unlockAdmin(); pw = "" } else wrong = true }
            }
        } else item {
            Panel(accent = p.primary) {
                Heading("🔓 Entsperrt bis ${fmtTime(Store.adminUntil)}")
                ToggleRow("Sperren aktiv (Wiegen & Tagesabschluss)", s.locksOn) { v -> Store.setSettings { it.copy(locksOn = v) } }
                ToggleRow("Einstellungen schützen", s.protect, "verhindert Ausschalten/Deinstallieren ohne Passwort") { v -> Store.setSettings { it.copy(protect = v) } }
                Sep()
                Heading("Wiegen")
                ToggleRow("Jeden Morgen wiegen (Pflicht)", s.weighDaily, "sonst nur am Wiege-Tag") { v -> Store.setSettings { it.copy(weighDaily = v) } }
                if (s.weighDaily) Stepper("${s.weighDailyHour}:00", { Store.setSettings { it.copy(weighDailyHour = (it.weighDailyHour + 23) % 24) } },
                    { Store.setSettings { it.copy(weighDailyHour = (it.weighDailyHour + 1) % 24) } }, "Morgens ab")
                Muted(if (s.weighDaily) "Foto-Tag (Fortschrittsfotos beim Wiegen):" else "Wiege-Tag:")
                ChipRow { WEEKDAYS.forEach { (d, l) -> Pick(l, s.weighDay == d) { Store.setSettings { it.copy(weighDay = d) } } } }
                if (!s.weighDaily) Stepper("${s.weighHour}:00", { Store.setSettings { it.copy(weighHour = (it.weighHour + 23) % 24) } }, { Store.setSettings { it.copy(weighHour = (it.weighHour + 1) % 24) } }, "Ab")
                Sep()
                Heading("Tagesabschluss")
                Stepper("${s.reviewHour}:00", { Store.setSettings { it.copy(reviewHour = (it.reviewHour + 23) % 24) } }, { Store.setSettings { it.copy(reviewHour = (it.reviewHour + 1) % 24) } }, "Ab")
                Sep()
                Heading("Nach dem Entsperren öffnen")
                OPEN_MODES.forEachIndexed { i, l -> RadioRow(l, s.openMode == i) { Store.setSettings { it.copy(openMode = i) } } }
                if (s.openMode == 1) Stepper("${s.openInterval} Min.",
                    { Store.setSettings { it.copy(openInterval = (it.openInterval - 15).coerceAtLeast(15)) } },
                    { Store.setSettings { it.copy(openInterval = (it.openInterval + 15).coerceAtMost(600)) } })
                Spacer(Modifier.height(8.dp))
                Btn("Wieder sperren", Modifier.fillMaxWidth(), BtnKind.DANGER) { Store.lockAdmin() }
            }
        }
    }
}

val OPEN_MODES = listOf("Bei jedem Entsperren", "Höchstens alle X Minuten", "Einmal pro Tag", "Nur wenn etwas offen ist (Training, Aufgaben, Gewohnheiten)", "Aus")

// ---------- Daten ----------
@Composable
fun DataSettings() {
    val ctx = LocalContext.current
    var confirmImport by remember { mutableStateOf<AppState?>(null) }
    var importPhotos by remember { mutableStateOf<Map<String, ByteArray>>(emptyMap()) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching {
            Store.flush()
            ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                ZipOutputStream(os).use { z ->
                    z.putNextEntry(ZipEntry("data.json")); z.write(Json.encode(Store.state).toByteArray()); z.closeEntry()
                    Store.photoDir.listFiles()?.forEach { f -> z.putNextEntry(ZipEntry("photos/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
                }
            }
        }.onSuccess { Toast.makeText(ctx, "Backup gespeichert", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(ctx, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show() }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                var json: String? = null
                val photos = mutableMapOf<String, ByteArray>()
                ZipInputStream(bytes.inputStream()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (e.name == "data.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (e.name.startsWith("photos/") && !e.isDirectory) photos[e.name.removePrefix("photos/").substringAfterLast('/')] = z.readBytes()
                        e = z.nextEntry
                    }
                }
                confirmImport = Json.decode(json!!); importPhotos = photos
            } else { confirmImport = Json.decode(bytes.toString(Charsets.UTF_8)); importPhotos = emptyMap() }
        }.onFailure { Toast.makeText(ctx, "Datei ungültig", Toast.LENGTH_SHORT).show() }
    }
    confirmImport?.let { imp ->
        ConfirmDialog("Backup laden?", "Deine aktuellen Daten werden durch das Backup ersetzt (${imp.workouts.size} Workouts, ${imp.weights.size} Gewichte, ${imp.photos.size} Fotos).", "Laden",
            { confirmImport = null }) {
            importPhotos.forEach { (n, b) -> runCatching { File(Store.photoDir, n).writeBytes(b) } }
            // Sperr-Einstellungen nur mit Passwort per Backup überschreibbar
            val cur = Store.state.settings
            Store.replace(if (Store.adminActive()) imp else imp.copy(settings = imp.settings.copy(
                openMode = cur.openMode, openInterval = cur.openInterval, reviewHour = cur.reviewHour,
                weighDay = cur.weighDay, weighHour = cur.weighHour, locksOn = cur.locksOn, protect = cur.protect)))
            Toast.makeText(ctx, "Backup geladen", Toast.LENGTH_SHORT).show()
        }
    }
    Screen {
        item {
            Panel {
                Heading("Automatische Sicherung")
                Body("Deine Daten werden automatisch über die Android-Sicherung in deinem Google-Konto gesichert und beim Neuinstallieren wiederhergestellt.")
                Muted("Voraussetzung: In den Android-Einstellungen unter »Google → Sicherung« ist die Sicherung eingeschaltet. Fotos sind wegen der Größe nur im manuellen Backup enthalten.", Modifier.padding(top = 4.dp))
            }
        }
        item {
            Panel {
                Heading("Manuelles Backup")
                Muted("Eine ZIP-Datei mit allen Daten und Fotos, z. B. für Google Drive oder ein neues Handy.")
                Spacer(Modifier.height(8.dp))
                Btn("Backup exportieren", Modifier.fillMaxWidth()) {
                    exportL.launch("lifesave-backup-" + java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMAN).format(java.util.Date()) + ".zip")
                }
                Spacer(Modifier.height(8.dp))
                Btn("Backup importieren", Modifier.fillMaxWidth(), BtnKind.GHOST) { importL.launch(arrayOf("application/zip", "application/json", "*/*")) }
            }
        }
    }
}

// ---------- Update ----------
@Composable
fun UpdateScreen() {
    val ctx = LocalContext.current
    val p = pal
    val s = Store.state.settings
    val u = com.lifesave.system.Updater
    var repo by remember { mutableStateOf(s.updateRepo) }
    var perm by remember { mutableIntStateOf(0) }
    val canInstall = remember(perm, u.status) { u.canInstall(ctx) }
    Screen {
        item {
            Panel(accent = p.primary) {
                Heading("Installiert")
                BigNumber("Version $VERSION")
                Spacer(Modifier.height(8.dp))
                val a = u.available
                if (a != null) {
                    Pill("Neu: Version ${a.version}", p.good)
                    if (a.notes.isNotBlank()) Muted(a.notes, Modifier.padding(top = 6.dp), maxLines = 12)
                    Spacer(Modifier.height(8.dp))
                    if (!canInstall) {
                        Muted("Einmalig nötig: Life Save erlauben, Apps zu installieren.", color = p.secondary)
                        Btn("Erlaubnis öffnen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY) { u.openInstallPermission(ctx); perm++ }
                        Btn("Erledigt – neu prüfen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) { perm++ }
                    } else Btn("Jetzt installieren", Modifier.fillMaxWidth(), BtnKind.GOLD, enabled = !u.busy) { u.downloadAndInstall(ctx) }
                }
                Btn("Nach Update suchen", Modifier.fillMaxWidth().padding(top = 8.dp), BtnKind.SECONDARY, enabled = !u.busy) { u.check() }
                if (u.status.isNotBlank()) Muted(u.status, Modifier.padding(top = 6.dp))
                Muted("Deine Daten bleiben beim Update erhalten.", Modifier.padding(top = 6.dp))
            }
        }
        item {
            Panel {
                Heading("GitHub-Repo")
                Muted("Von hier holt sich die App neue Versionen. Das Repo muss öffentlich sein.")
                Field(repo, { repo = it.trim(); Store.setSettings { st -> st.copy(updateRepo = repo) } }, "Benutzername/Repo")
            }
        }
    }
}

// ---------- Über ----------
val PATCH_NOTES = listOf(
    "1.6" to listOf(
        "Neu: Tagesplan im Stundenplan-Stil (Alltag → Plan) mit Wochen-, Tages- und Monatsansicht",
        "Blöcke mit Kategorien und eigenen Farben; lange drücken & ziehen verschiebt (10-Minuten-Raster, 5–24 Uhr), unten ziehen ändert die Länge",
        "Beim Anlegen: Vorschläge aus früheren Einträgen, Aufgaben und dem heutigen Training – durchsuchbar",
        "Aufgaben mit Uhrzeit erscheinen automatisch im Plan, Training laut Plan zum Einplanen",
        "Google-Kalender: Termine mit Uhrzeit im Raster, ganztägige (z. B. Geburtstage) als Info-Zeile; eigene Blöcke landen im Kalender",
        "„Jetzt dran“ dauerhaft in der Benachrichtigungsleiste, Erinnerung vor Beginn",
        "Nach dem Ende: „Erledigt?“ – nicht fertig verlängert um 30 Min. (einstellbar) und schiebt alles danach nach hinten",
        "Morgens nach dem Wiegen öffnet sich der heutige Plan",
        "Startseiten-Kachel und Widget-Baustein „Tagesplan“",
        "Ernährung: „Von Claude importieren“ direkt im ＋ der Mahlzeit – alles landet in genau dieser Mahlzeit",
        "Import-Textfeld bleibt gleich groß (innen scrollen), „Hinzufügen“ sofort sichtbar",
        "Einträge löschen per ✕ mit „Rückgängig“; per Ziehen in andere Mahlzeit oder auf einen anderen Tag verschieben",
        "Fehler behoben: Import gab keine XP, leeres Workout schob die Plan-Reihenfolge weiter, beschädigte Daten wurden überschrieben"
    ),
    "1.5" to listOf(
        "Neues Mannequin: anatomische Linienzeichnung wie auf den Geräteschildern – trainierte Muskeln farbig, hinten links, vorne rechts",
        "Aufgeräumtes Design: abgerundete Karten mit leichtem Schatten, mehr Luft, klare Trennungen",
        "Segment-Schalter statt loser Knöpfe (Alltag, Fortschritt, Statistik, Essen suchen, Verläufe)",
        "Einstellungen in Gruppen: Darstellung, Training & Körper, Ernährung, System – mit Symbolen",
        "Seitenmenü gegliedert (Hauptbereiche, Mehr, System) mit Level-Fortschritt",
        "Untere Leiste und Hinweise als abgerundete Elemente"
    ),
    "1.4" to listOf("App-Updates lassen sich jetzt trotz Einstellungsschutz installieren – nur Deinstallieren bleibt geschützt"),
    "1.3" to listOf(
        "Ernährung: Tagebuch mit kcal-Ring, Makros und allen wichtigen Mikronährstoffen",
        "„Was fehlt noch?“ – Vorschläge aus deinen eigenen Lebensmitteln",
        "Barcode-Scanner mit Open Food Facts, eigene Lebensmittel, gespeicherte Mahlzeiten, optionaler Wochenplan",
        "Import von Claude: Essen per Foto, Nährwerttabellen, Ziele, Supplements – Ziele sind nur so änderbar",
        "Wochenbericht zum Kopieren für Claude",
        "Fünf gleichwertige Bereiche: Start, Training, Ernährung, Alltag, Fortschritt",
        "Fortschritt: Diagramme für alles – je Trainingstag, Übung, Gewicht (mit 7-Tage-Schnitt), Kalorien, Schlaf …",
        "Fortschrittsfotos pro Tag mit eigenen Kategorien, Vergleich Tag gegen Tag",
        "Wiegen jeden Morgen (Pflicht), Fotos am Foto-Tag",
        "Tagesabschluss fragt die Mahlzeiten ab, Erinnerungen fürs Essen"
    ),
    "1.2" to listOf(
        "Pause je Übung nach Studienlage: schwere Grundübungen 3 Min., Mehrgelenk 2 Min., Isolation 75 Sek.",
        "Wochenziel mit Ring, Tagesübersicht und Wochen-Serie (+ Abzeichen)",
        "Jahresrückblick mit ausführlichen Zahlen und Story-Karten zum Teilen",
        "Schlaf & Wasser tracken, Auswertung „Schlaf & Kraft“",
        "Health Connect: Schritte, Schlaf und Gewicht automatisch",
        "Gym-Modus (abschaltbar): Bildschirm bleibt an, Benachrichtigung mit Pause, Anzeige über dem Sperrbildschirm"
    ),
    "1.1" to listOf(
        "Workout-Ansicht neu: alle Übungen untereinander mit Satz · Vorherige · kg · Wdh. und Speichern-Knopf unten",
        "Steigerungsvorschläge nach Doppelprogression: erst Wiederholungen, dann ca. 5 % mehr Gewicht",
        "Graue Vorschläge in leeren Feldern – Haken übernimmt sie, Antippen und direkt Neues tippen",
        "Wiederholungsbereiche (z. B. 8–12) im Trainingsplan",
        "Pläne als JSON importieren (z. B. von Claude), ohne andere Daten zu ersetzen",
        "App-Update direkt in der App (über GitHub Releases)"
    ),
    "1.0" to listOf(
        "Neu: Life Save ersetzt Unlock To-do – cleanes Design im Stil der MEL-Liga, 4 Farbschemata + eigene Farben",
        "Training: Pläne als Wochenplan (Zyklus 1–12 Wochen) oder feste Reihenfolge, Vorlagen, laufendes Workout mit Satzpause",
        "Übungsdatenbank mit 876 Übungen, Bildern, Mannequin, YouTube-Link und eigenen Übungen",
        "Automatische Rekorde mit Feier, 37 Abzeichen, XP & Level",
        "Cardio, Statistik je Muskel, Volumen pro Woche",
        "Gewicht mit Verlauf, private Fortschrittsfotos mit Vorher/Nachher-Vergleich",
        "Wiege-Sperre (Sa 11 Uhr) und Tagesabschluss-Sperre (22 Uhr), Notfall-Passwort",
        "Aufgaben mit Training als eigener Kategorie, Gewohnheiten täglich / Wochentage / X-mal pro Woche",
        "Einstellbare Startseite, Leiste unten, Seitenmenü und gestaltbares Widget",
        "Automatische Sicherung + Backup als ZIP"
    )
)

@Composable
fun AboutScreen() {
    val p = pal
    Screen {
        item {
            Panel(accent = p.primary) {
                Title(APP_NAME)
                Muted("Version $VERSION")
                Spacer(Modifier.height(6.dp))
                Body("Training, Aufgaben, Gewohnheiten und Körper an einem Ort. Ernährung folgt in Version 1.1.")
                Muted("Übungsdaten & Bilder: free-exercise-db (Public Domain). Schrift: Barlow Condensed (OFL).", Modifier.padding(top = 6.dp))
            }
        }
        PATCH_NOTES.forEach { (v, notes) ->
            item {
                Panel {
                    Heading("Neu in $v")
                    notes.forEach { Body("• $it", Modifier.padding(vertical = 2.dp), size = 14.sp) }
                }
            }
        }
    }
}
