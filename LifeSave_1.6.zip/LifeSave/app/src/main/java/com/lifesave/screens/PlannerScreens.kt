package com.lifesave.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lifesave.core.*
import com.lifesave.system.CalendarSync
import com.lifesave.ui.*
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Zustand der Plan-Ansicht (bleibt beim Hin- und Herwechseln erhalten) */
object PlanUi {
    var view by mutableIntStateOf(1)                          // 0 Tag, 1 Woche, 2 Monat
    var anchor by mutableLongStateOf(startOfDay(now()))
    var prompt by mutableStateOf(false)                       // „Plan deinen Tag“-Hinweis
    var calOpen by mutableStateOf<CalEvent?>(null)

    /** direkt zum heutigen Tag im Plan */
    fun showToday(prompt: Boolean = false) {
        view = 0; anchor = startOfDay(now()); this.prompt = prompt
        SubTabs.daily = 0
        Nav.root("daily")
    }
}

private fun monthGrid(anchor: Long): List<Long> {
    val first = startOfMonth(anchor)
    val gs = startOfWeek(first)
    val last = startOfDay(addDays(addMonths(first, 1), -1))
    val weeks = (daysBetween(gs, last) / 7) + 1
    return (0 until weeks * 7).map { startOfDay(addDays(gs, it)) }
}

private fun stepAnchor(view: Int, anchor: Long, dir: Int): Long = when (view) {
    0 -> startOfDay(addDays(anchor, dir))
    1 -> startOfDay(addDays(anchor, 7 * dir))
    else -> startOfMonth(addMonths(startOfMonth(anchor), dir))
}

private fun wd(d: Long) = WEEKDAYS.find { it.first == dow(d) }?.second ?: ""

// ================= Plan (Alltag → Plan) =================
@Composable
fun PlannerScreen() {
    val st = Store.state
    val p = pal
    val ctx = LocalContext.current
    val today = startOfDay(now())
    val view = PlanUi.view
    val anchor = PlanUi.anchor
    val weekStart = startOfWeek(anchor)
    val days: List<Long> = when (view) {
        0 -> listOf(anchor)
        1 -> (0..6).map { startOfDay(addDays(weekStart, it)) }
        else -> monthGrid(anchor)
    }
    val from = days.first()
    val to = startOfDay(addDays(days.last(), 1))
    // Kalender laden und alle 2 Minuten auffrischen
    LaunchedEffect(from, to, st.settings.calRead) {
        CalendarSync.ensure(ctx, from, to)
        while (true) { delay(120_000); CalendarSync.ensure(ctx, from, to) }
    }
    // Aufgaben mit Uhrzeit als Blöcke anlegen
    LaunchedEffect(from, to, st.tasks, st.workouts.size) { Schedule.ensureAuto(days.filter { it >= today }) }

    val (title, sub) = when (view) {
        0 -> (if (anchor == today) "Heute" else fmtDay(anchor)) to (if (anchor == today) fmtDay(anchor) else "KW ${weekOfYear(anchor)}")
        1 -> "KW ${weekOfYear(weekStart)}" to "${fmtShort(weekStart)} – ${fmtShort(addDays(weekStart, 6))}"
        else -> fmtMonth(anchor).replaceFirstChar { it.uppercase() } to ""
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn("‹", color = p.primary) { PlanUi.anchor = stepAnchor(view, anchor, -1) }
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { PlanUi.anchor = today }.padding(vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(title.uppercase(), color = p.ink, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
                        if (sub.isNotBlank()) Muted(sub, size = 12.sp, maxLines = 1)
                    }
                    IconBtn("›", color = p.primary) { PlanUi.anchor = stepAnchor(view, anchor, 1) }
                }
                Segmented(listOf("Tag", "Woche", "Monat"), view) { PlanUi.view = it }
            }
            if (!st.settings.calRead) Text("📅 Google-Kalender verbinden ›",
                Modifier.padding(start = 18.dp, top = 6.dp).clickable { Nav.go("settings_x", "plan") }, color = p.primary, fontSize = 12.sp)
            if (PlanUi.prompt && view == 0 && anchor == today) PromptBanner()
            else if (st.blocks.isEmpty() && view != 2) Muted(
                "Tippe auf eine freie Zeit oder auf ＋. Lange drücken und ziehen verschiebt einen Block, unten am Block ziehen ändert die Länge.",
                Modifier.padding(start = 18.dp, end = 18.dp, top = 6.dp), size = 12.sp
            )
            Box(Modifier.weight(1f)) {
                when (view) {
                    0 -> DayPlan(anchor)
                    1 -> TimeGrid(days, 46.dp)
                    else -> MonthPlan(anchor, days)
                }
            }
        }
        // ---------- ＋ ----------
        Box(
            Modifier.align(Alignment.BottomEnd).padding(16.dp).size(56.dp).shadow(6.dp, CircleShape).clip(CircleShape)
                .background(p.primary).clickable {
                    val d = when {
                        view == 0 -> anchor
                        today in days && (view == 1 || startOfMonth(today) == startOfMonth(anchor)) -> today
                        view == 2 -> startOfMonth(anchor)
                        else -> days.first()
                    }
                    Nav.go("block", "new|$d|${Schedule.nextSlot(d)}|")
                },
            contentAlignment = Alignment.Center
        ) { Text("+", color = p.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        PlanUi.calOpen?.let { CalEventDialog(it) { PlanUi.calOpen = null } }
    }
}

@Composable
private fun PromptBanner() {
    val p = pal
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 8.dp).clip(RoundedCornerShape(14.dp))
            .background(p.gold.copy(alpha = 0.2f)).padding(start = 12.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("☀", fontSize = 24.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Body("Guten Morgen! Plan deinen Tag", bold = true)
            Muted("Tippe auf eine freie Zeit oder auf ＋. Lange drücken & ziehen verschiebt, unten am Block ziehen ändert die Länge.", size = 12.sp)
        }
        IconBtn("✕", color = p.inkSoft) { PlanUi.prompt = false }
    }
}

// ================= Tag =================
@Composable
private fun DayPlan(day: Long) {
    val st = Store.state
    val p = pal
    Column(Modifier.fillMaxSize()) {
        Schedule.unplannedTraining(day, st)?.let { name ->
            val start = if (day == startOfDay(now())) Schedule.nextSlot(day) else 17 * 60
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 8.dp).clip(RoundedCornerShape(12.dp))
                    .background(p.secondary.copy(alpha = 0.12f)).clickable { Nav.go("block", "new|$day|$start|tr") }
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🏋", fontSize = 18.sp)
                Spacer(Modifier.width(8.dp))
                Body("Training: $name – noch einplanen", Modifier.weight(1f), color = p.secondary, bold = true, size = 14.sp, maxLines = 1)
                Text("＋", color = p.secondary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        TimeGrid(listOf(day), 72.dp, Modifier.fillMaxWidth().weight(1f))
    }
}

// ================= Raster (Tag & Woche) =================
private data class GridDrag(val key: String, val resize: Boolean, val local: Offset, val dx: Float, val dy: Float, val scrollAt: Int)

@Composable
fun TimeGrid(days: List<Long>, hourDp: Dp, modifier: Modifier = Modifier.fillMaxSize()) {
    val st = Store.state
    val p = pal
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scroll = rememberScrollState()
    var drag by remember { mutableStateOf<GridDrag?>(null) }
    var viewportH by remember { mutableIntStateOf(0) }
    var tick by remember { mutableLongStateOf(now()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); tick = now() } }
    val today = startOfDay(tick)
    val ppm = with(density) { hourDp.toPx() } / 60f
    val from = Schedule.GRID_FROM
    val gridMin = Schedule.GRID_TO - from
    val totalH = hourDp * (gridMin / 60f)
    val axisW = 34.dp
    val axisPx = with(density) { axisW.toPx() }
    val compact = days.size > 1
    // beim Öffnen zur aktuellen Uhrzeit scrollen
    LaunchedEffect(days.size) {
        val m = (minuteOf(now()) - 90 - from).coerceAtLeast(0)
        scroll.scrollTo((m * ppm).toInt())
    }
    val layouts = remember(st, days, CalCache.events) { days.map { d -> Schedule.layout(Schedule.items(d, st)) } }
    val allDay = days.map { Schedule.calAllDay(it, st) }

    BoxWithConstraints(modifier) {
        val colW = (maxWidth - axisW) / days.size
        val colPx = with(density) { colW.toPx() }

        fun find(key: String): Pair<Int, PlanItem>? {
            layouts.forEachIndexed { di, l -> l.firstOrNull { it.first.key == key }?.let { return di to it.first } }
            return null
        }

        /** neue Lage während des Ziehens: (Tag-Index, Beginn, Dauer) */
        fun preview(item: PlanItem, di: Int, g: GridDrag): Triple<Int, Int, Int> {
            val dMin = ((g.dy + (scroll.value - g.scrollAt)) / ppm).roundToInt()
            return if (g.resize) Triple(di, item.start, Schedule.snap(item.dur + dMin).coerceIn(Schedule.SNAP, Schedule.GRID_TO - item.start))
            else {
                val ns = Schedule.clampStart(Schedule.snap(item.start + dMin), item.dur)
                val nd = if (item.cal != null) di else (di + (g.dx / colPx).roundToInt()).coerceIn(0, days.size - 1)
                Triple(nd, ns, item.dur)
            }
        }

        fun commit(item: PlanItem, di: Int, g: GridDrag) {
            val (nd, ns, ndur) = preview(item, di, g)
            val b = item.block
            if (b != null) {
                if (g.resize) { if (ndur != b.dur) Schedule.resize(b.id, ndur) }
                else if (ns != b.start || days[nd] != b.day) Schedule.move(b.id, days[nd], ns)
            } else item.cal?.let { Schedule.shiftCal(it.key, ns - item.start) }
        }

        // am oberen/unteren Rand automatisch weiterscrollen
        LaunchedEffect(drag != null) {
            while (drag != null) {
                val g = drag ?: break
                val hit = find(g.key)
                if (hit != null && viewportH > 0) {
                    val item = hit.second
                    val top = (item.start.coerceAtLeast(from) - from) * ppm
                    val py = top + g.local.y + g.dy + (scroll.value - g.scrollAt) - scroll.value
                    val edge = with(density) { 56.dp.toPx() }
                    val v = when {
                        py < edge -> -(edge - py) / 5f
                        py > viewportH - edge -> (py - (viewportH - edge)) / 5f
                        else -> 0f
                    }
                    if (v != 0f) scroll.scrollBy(v.coerceIn(-28f, 28f))
                }
                delay(16)
            }
        }

        Column(Modifier.fillMaxSize()) {
            // ---------- Kopf: Wochentage ----------
            if (compact) Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp)) {
                Spacer(Modifier.width(axisW))
                days.forEach { d -> DayHead(d, d == today, Modifier.width(colW)) { PlanUi.anchor = d; PlanUi.view = 0 } }
            }
            // ---------- ganztägige Termine (Geburtstage usw.) ----------
            if (allDay.any { it.isNotEmpty() }) Row(Modifier.fillMaxWidth().padding(top = if (compact) 0.dp else 6.dp, bottom = 3.dp)) {
                Box(Modifier.width(axisW).padding(top = 2.dp), contentAlignment = Alignment.TopCenter) { Text("☀", fontSize = 12.sp, color = p.inkSoft) }
                val max = if (compact) 2 else 4
                allDay.forEach { list ->
                    Column(Modifier.width(colW).padding(horizontal = 1.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        list.take(max).forEach { e -> AllDayChip(e, compact) }
                        if (list.size > max) Text("+${list.size - max}", fontSize = 9.sp, color = p.inkSoft)
                    }
                }
            }
            // ---------- Raster ----------
            Box(
                Modifier.weight(1f).fillMaxWidth().onSizeChanged { viewportH = it.height }
                    .verticalScroll(scroll, enabled = drag == null)
            ) {
                Box(Modifier.fillMaxWidth().height(totalH)) {
                    GridBackground(days, today, axisW, colW, hourDp, compact)
                    // freie Fläche antippen → neuer Block (auf halbe Stunden abgerundet)
                    Box(Modifier.fillMaxSize().padding(start = axisW).pointerInput(days, colPx, ppm) {
                        detectTapGestures { o ->
                            val di = (o.x / colPx).toInt().coerceIn(0, days.size - 1)
                            val m = Schedule.snapDown((o.y / ppm).toInt() + from, 30)
                            Nav.go("block", "new|${days[di]}|${Schedule.clampStart(m, 60)}|")
                        }
                    })
                    // ---------- Blöcke ----------
                    days.forEachIndexed { di, _ ->
                        layouts[di].forEach { (item, lane, lanes) ->
                            key(item.key) {
                                val top = (item.start.coerceAtLeast(from) - from) * ppm
                                val hgt = (minOf(item.end, Schedule.GRID_TO) - maxOf(item.start, from)).coerceAtLeast(Schedule.SNAP) * ppm
                                val x = axisPx + di * colPx + lane * colPx / lanes
                                val w = colPx / lanes
                                PlanBlock(
                                    item, compact, dragging = drag?.key == item.key,
                                    modifier = Modifier.offset { IntOffset(x.roundToInt(), top.roundToInt()) }
                                        .size(with(density) { w.toDp() }, with(density) { hgt.toDp() }).padding(1.dp),
                                    onTap = {
                                        val b = item.block
                                        if (b != null) Nav.go("block", b.id.toString())
                                        if (b == null) PlanUi.calOpen = item.cal
                                    },
                                    onDragStart = { o, resize ->
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        drag = GridDrag(item.key, resize, o, 0f, 0f, scroll.value)
                                    },
                                    onDrag = { a -> drag = drag?.let { it.copy(dx = it.dx + a.x, dy = it.dy + a.y, scrollAt = scroll.value) } },
                                    onDragEnd = { drag?.let { commit(item, di, it) }; drag = null },
                                    onCancel = { drag = null }
                                )
                            }
                        }
                    }
                    // ---------- Jetzt-Linie ----------
                    val ti = days.indexOf(today)
                    val nm = minuteOf(tick)
                    if (ti >= 0 && nm in from..Schedule.GRID_TO) {
                        val y = (nm - from) * ppm
                        val x0 = axisPx + ti * colPx
                        Box(Modifier.offset { IntOffset(x0.roundToInt(), y.roundToInt() - 1) }.width(colW).height(2.dp).background(p.secondary))
                        Box(Modifier.offset { IntOffset((x0 - with(density) { 4.dp.toPx() }).roundToInt(), y.roundToInt() - with(density) { 4.dp.toPx() }.roundToInt()) }
                            .size(8.dp).clip(CircleShape).background(p.secondary))
                    }
                    // ---------- Vorschau beim Ziehen ----------
                    drag?.let { g ->
                        val hit = find(g.key)
                        if (hit != null) {
                            val (di, item) = hit
                            val (nd, ns, ndur) = preview(item, di, g)
                            val top = (ns - from) * ppm
                            val base = hex(item.color) ?: p.primary
                            val fg = if (base.lum() > 0.6f) Color(0xFF12161C) else Color.White
                            Column(
                                Modifier.offset { IntOffset((axisPx + nd * colPx).roundToInt(), top.roundToInt()) }
                                    .size(colW, with(density) { (ndur * ppm).toDp() }).padding(1.dp)
                                    .shadow(10.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))
                                    .background(base).border(2.dp, p.gold, RoundedCornerShape(8.dp)).padding(3.dp)
                            ) {
                                Text("${fmtMin(ns)}–${fmtMin(ns + ndur)}", color = fg, fontSize = if (compact) 9.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(item.title, color = fg, fontSize = if (compact) 9.sp else 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridBackground(days: List<Long>, today: Long, axisW: Dp, colW: Dp, hourDp: Dp, compact: Boolean) {
    val p = pal
    val hours = (Schedule.GRID_TO - Schedule.GRID_FROM) / 60
    val ti = days.indexOf(today)
    val weekend = days.map { dow(it) == java.util.Calendar.SATURDAY || dow(it) == java.util.Calendar.SUNDAY }
    Canvas(Modifier.fillMaxSize()) {
        val ax = axisW.toPx()
        val cw = colW.toPx()
        val hp = hourDp.toPx()
        if (compact) weekend.forEachIndexed { i, we -> if (we) drawRect(p.inkSoft.copy(alpha = 0.04f), Offset(ax + i * cw, 0f), Size(cw, size.height)) }
        if (compact && ti >= 0) drawRect(p.primary.copy(alpha = 0.06f), Offset(ax + ti * cw, 0f), Size(cw, size.height))
        val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        for (i in 0 until hours) {
            val y = i * hp
            drawLine(p.line, Offset(ax - 4f, y), Offset(size.width, y), 1.2f)
            drawLine(p.line.copy(alpha = 0.5f), Offset(ax, y + hp / 2), Offset(size.width, y + hp / 2), 1f, pathEffect = dash)
        }
        if (compact) for (i in 0..days.size) {
            val x = ax + i * cw
            drawLine(p.line, Offset(x, 0f), Offset(x, size.height), 1f)
        }
    }
    for (i in 0 until hours) {
        Text(
            "%02d:00".format(Schedule.GRID_FROM / 60 + i),
            Modifier.offset(y = hourDp * i + 2.dp).width(axisW).padding(end = 4.dp),
            fontSize = 9.sp, color = p.inkSoft, textAlign = TextAlign.End, maxLines = 1
        )
    }
}

@Composable
private fun DayHead(d: Long, isToday: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = pal
    Column(modifier.clip(RoundedCornerShape(8.dp)).clickable { onClick() }.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(wd(d), fontSize = 11.sp, color = if (isToday) p.primary else p.inkSoft, fontWeight = FontWeight.SemiBold)
        Box(Modifier.size(26.dp).clip(CircleShape).background(if (isToday) p.primary else Color.Transparent), contentAlignment = Alignment.Center) {
            Text("${dayOfMonth(d)}", fontSize = 14.sp, color = if (isToday) p.onPrimary else p.ink, fontWeight = FontWeight.Bold, fontFamily = Barlow)
        }
    }
}

@Composable
private fun AllDayChip(e: CalEvent, compact: Boolean) {
    val p = pal
    val c = Color(e.color).copy(alpha = 1f)
    Text(
        e.title.ifBlank { "Termin" },
        Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).background(c.copy(alpha = 0.2f)).clickable { PlanUi.calOpen = e }
            .padding(horizontal = 4.dp, vertical = 2.dp),
        fontSize = if (compact) 9.sp else 12.sp, color = p.ink, maxLines = 1, overflow = TextOverflow.Ellipsis
    )
}

/** Ein Block im Raster. Antippen = bearbeiten · lange drücken & ziehen = verschieben · unten ziehen = Länge */
@Composable
private fun PlanBlock(
    item: PlanItem, compact: Boolean, dragging: Boolean, modifier: Modifier,
    onTap: () -> Unit, onDragStart: (Offset, Boolean) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onCancel: () -> Unit
) {
    val p = pal
    val tap by rememberUpdatedState(onTap)
    val dStart by rememberUpdatedState(onDragStart)
    val dMove by rememberUpdatedState(onDrag)
    val dEnd by rememberUpdatedState(onDragEnd)
    val dCancel by rememberUpdatedState(onCancel)
    val canResize = item.block != null
    val isCal = item.cal != null
    val faded = item.done || item.skipped
    val base = hex(item.color) ?: p.primary
    val shape = RoundedCornerShape(if (compact) 6.dp else 10.dp)
    val bg = when { isCal -> base.copy(alpha = 0.18f); faded -> base.copy(alpha = 0.38f); else -> base }
    val fg = when {
        isCal || (faded && !p.dark) -> p.ink
        base.lum() > 0.6f -> Color(0xFF12161C)
        else -> Color.White
    }
    Box(
        modifier.alpha(if (dragging) 0.35f else 1f).clip(shape).background(p.panel).background(bg)
            .then(if (isCal) Modifier.border(1.dp, base.copy(alpha = 0.55f), shape) else Modifier)
            .pointerInput(item.key) { detectTapGestures(onTap = { tap() }) }
            .pointerInput(item.key) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { o ->
                        val zone = minOf(18.dp.toPx(), size.height * 0.4f)
                        dStart(o, canResize && o.y > size.height - zone)
                    },
                    onDrag = { ch, a -> ch.consume(); dMove(a) },
                    onDragEnd = { dEnd() },
                    onDragCancel = { dCancel() }
                )
            }
    ) {
        if (isCal) Box(Modifier.fillMaxHeight().width(3.dp).background(base))
        Column(Modifier.fillMaxSize().padding(start = if (isCal) 6.dp else 4.dp, end = 3.dp, top = 2.dp)) {
            val deco = if (item.skipped) TextDecoration.LineThrough else null
            if (compact) {
                Text((if (item.done) "✓ " else "") + item.title, fontSize = 10.sp, lineHeight = 11.sp, color = fg,
                    fontWeight = FontWeight.SemiBold, overflow = TextOverflow.Ellipsis, textDecoration = deco)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.title, Modifier.weight(1f), fontSize = 14.sp, color = fg, fontWeight = FontWeight.Bold, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textDecoration = deco)
                    if (item.done) Text("✓", color = fg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                if (item.dur >= 20) Text(
                    "${fmtMin(item.start)}–${fmtMin(item.end)}" + listOfNotNull(item.catName.ifBlank { null }, if (item.skipped) "ausgefallen" else null)
                        .joinToString("") { " · $it" },
                    fontSize = 11.sp, color = fg.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val note = item.block?.note ?: item.cal?.location ?: ""
                if (note.isNotBlank() && item.dur >= 40) Text(note, fontSize = 11.sp, color = fg.copy(alpha = 0.8f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        // Griff zum Ziehen der Länge
        if (canResize && item.dur >= 20) Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp).width(if (compact) 12.dp else 24.dp).height(3.dp)
                .clip(RoundedCornerShape(50)).background(fg.copy(alpha = 0.55f))
        )
    }
}

// ================= Monat =================
@Composable
private fun MonthPlan(anchor: Long, days: List<Long>) {
    val st = Store.state
    val p = pal
    val today = startOfDay(now())
    val month = startOfMonth(anchor)
    val next = startOfMonth(addMonths(month, 1))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 90.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
            WEEKDAYS.forEach { (_, l) -> Text(l, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = p.inkSoft, fontWeight = FontWeight.SemiBold) }
        }
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth().height(98.dp)) {
                week.forEach { d ->
                    MonthCell(d, d >= month && d < next, d == today, Schedule.items(d, st), Schedule.calAllDay(d, st), Modifier.weight(1f).fillMaxHeight()) {
                        PlanUi.anchor = d; PlanUi.view = 0
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthCell(d: Long, inMonth: Boolean, isToday: Boolean, items: List<PlanItem>, allDay: List<CalEvent>, modifier: Modifier, onClick: () -> Unit) {
    val p = pal
    Column(
        modifier.padding(1.dp).clip(RoundedCornerShape(6.dp)).background(if (isToday) p.primary.copy(alpha = 0.08f) else p.panel)
            .border(1.dp, if (isToday) p.primary else p.line.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
            .clickable { onClick() }.padding(2.dp).alpha(if (inMonth) 1f else 0.45f),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Text("${dayOfMonth(d)}", fontSize = 12.sp, fontFamily = Barlow, fontWeight = FontWeight.Bold, color = if (isToday) p.primary else p.ink)
        val entries = allDay.map { it.title.ifBlank { "Termin" } to Color(it.color).copy(alpha = 1f) } +
            items.map { it.title to (hex(it.color) ?: p.primary) }
        entries.take(4).forEach { (t, c) ->
            Text(t, Modifier.fillMaxWidth().clip(RoundedCornerShape(3.dp)).background(c.copy(alpha = 0.85f)).padding(horizontal = 2.dp),
                fontSize = 8.sp, lineHeight = 10.sp, color = if (c.lum() > 0.6f) Color(0xFF12161C) else Color.White, maxLines = 1, overflow = TextOverflow.Clip)
        }
        if (entries.size > 4) Text("+${entries.size - 4}", fontSize = 8.sp, color = p.inkSoft)
    }
}

// ================= Kalendertermin =================
@Composable
private fun CalEventDialog(e: CalEvent, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val st = Store.state
    val shift = st.calShifts[e.key] ?: 0
    val calName = CalCache.calendars.find { it.id == e.calId }?.name ?: "Kalender"
    Dialog(onDismissRequest = onClose) {
        Panel(accent = Color(e.color).copy(alpha = 1f)) {
            Heading("📅 $calName")
            Title(e.title.ifBlank { "Termin" }, size = 22.sp)
            Body(if (e.allDay) "Ganztägig · ${fmtDay(e.begin)}" else "${fmtDay(e.begin)} · ${fmtTime(e.begin)}–${fmtTime(e.end)}")
            if (e.location.isNotBlank()) Muted("📍 ${e.location}")
            if (shift != 0) {
                Muted("In deinem Plan um ${if (shift > 0) "+" else ""}$shift Min. verschoben (der Termin im Kalender bleibt, wie er ist).", Modifier.padding(top = 6.dp))
                Btn("Verschiebung zurücksetzen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY, small = true) { Schedule.resetCal(e.key); onClose() }
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Btn("Im Kalender öffnen", Modifier.weight(1.4f), BtnKind.GHOST, small = true) { CalendarSync.openEvent(ctx, e); onClose() }
                Spacer(Modifier.width(8.dp))
                Btn("OK", Modifier.weight(1f), small = true) { onClose() }
            }
        }
    }
}

// ================= „Erledigt?“ nach dem Ende eines Blocks =================
@Composable
fun BlockAskDialog(b: Block) {
    val st = Store.state
    val p = pal
    val ext = st.settings.schedExtend
    val color = hex(Schedule.colorOf(b, st)) ?: p.primary
    Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
        Panel(accent = color) {
            Muted("Vorbei seit ${fmtMin(b.end)} · geplant ${fmtMin(b.start)}–${fmtMin(b.end)}")
            Title(b.title, Modifier.padding(vertical = 4.dp), size = 24.sp)
            Body("Hast du es erledigt?")
            Spacer(Modifier.height(12.dp))
            Btn("✓ Erledigt", Modifier.fillMaxWidth()) { Schedule.markDone(b.id) }
            Spacer(Modifier.height(8.dp))
            Btn("Noch nicht fertig · +$ext Min.", Modifier.fillMaxWidth(), BtnKind.SECONDARY) { Schedule.extend(b.id) }
            Muted("Alles, was danach geplant ist, rutscht mit nach hinten.", Modifier.padding(top = 4.dp), size = 12.sp)
            Spacer(Modifier.height(6.dp))
            Btn("Ist ausgefallen", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) { Schedule.skip(b.id) }
        }
    }
}

// ================= Kachel für die Startseite =================
@Composable
fun PlanTile(st: AppState) {
    val p = pal
    var tick by remember { mutableLongStateOf(now()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); tick = now() } }
    val (cur, next) = Schedule.nowNext(st, tick)
    val left = Schedule.items(startOfDay(tick), st).count { it.block != null && it.block.status == BLOCK_OPEN && it.start > minuteOf(tick) }
    Panel(accent = cur?.let { hex(it.color) } ?: p.primary, onClick = { PlanUi.showToday() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Heading("Tagesplan", Modifier.weight(1f))
            Muted(if (left > 0) "noch $left heute" else "")
        }
        if (cur == null && next == null) {
            Body("Für heute ist noch nichts geplant.")
            Btn("Tag planen", Modifier.fillMaxWidth().padding(top = 8.dp), small = true) { PlanUi.showToday() }
        }
        cur?.let { PlanLine("JETZT", it, true) }
        next?.let { PlanLine("DANACH", it, false) }
    }
}

@Composable
private fun PlanLine(label: String, item: PlanItem, strong: Boolean) {
    val p = pal
    val c = hex(item.color) ?: p.primary
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(36.dp).clip(RoundedCornerShape(50)).background(c))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Muted(label + " · " + "${fmtMin(item.start)}–${fmtMin(item.end)}", size = 11.sp)
            Body(item.title, bold = strong, size = if (strong) 17.sp else 15.sp, maxLines = 1)
        }
    }
}
