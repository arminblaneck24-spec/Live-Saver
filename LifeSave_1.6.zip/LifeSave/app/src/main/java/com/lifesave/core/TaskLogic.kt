package com.lifesave.core

import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

// ================= Aufgaben =================
object Tasks {
    fun isRepeating(t: Task) = t.weekdays.isNotEmpty() || t.repeatDays > 0

    fun nextOcc(t: Task, from: Long): Long {
        if (t.weekdays.isNotEmpty()) {
            var n = from; var g = 0
            do { n = addDays(n, 1); g++ } while (dow(n) !in t.weekdays && g < 8)
            return n
        }
        return addDays(from, t.repeatDays.coerceAtLeast(1))
    }

    fun nextDue(t: Task, at: Long): Long {
        var n = t.due ?: at
        val today = startOfDay(at)
        var g = 0
        do { n = nextOcc(t, n); g++ } while (startOfDay(n) <= today && g < 5000)
        return n
    }

    fun firstWeekday(days: List<Int>): Long {
        var c = atHour(now(), 9); var g = 0
        while (dow(c) !in days && g < 8) { c = addDays(c, 1); g++ }
        return c
    }

    fun repeatText(t: Task): String? = when {
        t.weekdays.isNotEmpty() -> "↻ " + WEEKDAYS.filter { it.first in t.weekdays }.joinToString(" ") { it.second }
        t.repeatDays == 1 -> "↻ täglich"
        t.repeatDays > 1 -> "↻ alle ${t.repeatDays} Tage"
        else -> null
    }

    fun open(s: AppState = Store.state) = s.tasks.filter { it.doneAt == null && !it.archived }
    /** fällig bis heute Abend oder ohne Datum */
    fun dueToday(s: AppState = Store.state): List<Task> {
        val end = addDays(startOfDay(now()), 1)
        return open(s).filter { it.due == null || it.due < end }
            .sortedWith(compareByDescending<Task> { it.priority }.thenBy { it.due ?: Long.MAX_VALUE })
    }
    fun doneToday(s: AppState = Store.state) = s.tasks.filter { it.doneAt != null && !it.archived }

    fun upsert(t: Task) = Store.update { s ->
        if (s.tasks.any { it.id == t.id }) s.copy(tasks = s.tasks.map { if (it.id == t.id) t else it }) else s.copy(tasks = s.tasks + t)
    }
    fun delete(id: Long) = Store.update { s -> s.copy(tasks = s.tasks.filterNot { it.id == id }) }
    fun addCategory(n: String) = Store.update { if (n in it.categories) it else it.copy(categories = it.categories + n) }
    fun removeCategory(n: String) = Store.update { it.copy(categories = it.categories - n) }

    fun toggleSub(id: Long, i: Int) = Store.update { s ->
        s.copy(tasks = s.tasks.map { t ->
            if (t.id != id) t else t.copy(subtasks = t.subtasks.mapIndexed { j, st -> if (j == i) st.copy(done = !st.done) else st })
        })
    }

    fun complete(t: Task) {
        val n = now()
        Store.update { s ->
            val nt = if (isRepeating(t)) t.copy(due = nextDue(t, n), subtasks = t.subtasks.map { it.copy(done = false) }, notified = false)
            else t.copy(doneAt = n)
            s.copy(tasks = s.tasks.map { if (it.id == t.id) nt else it })
        }
        Rewards.addXp(t.id, t.title, "task", t.xp, n)
        Schedule.syncTask(t.id, true)
    }

    fun uncomplete(t: Task) {
        Store.update { s -> s.copy(tasks = s.tasks.map { if (it.id == t.id) it.copy(doneAt = null) else it }) }
        Rewards.removeXp { it.refId == t.id && it.kind == "task" && it.at == t.doneAt }
        Schedule.syncTask(t.id, false)
    }

    /** auf morgen verschieben (Tagesabschluss) */
    fun postpone(t: Task) {
        val base = t.due ?: atHour(now(), 9)
        val d = addDays(atHour(now(), 0), 1) + (base - startOfDay(base))
        upsert(t.copy(due = d, notified = false))
    }

    /** Erledigtes von gestern ins Archiv, verpasste Wiederholungen auf den nächsten Termin */
    fun archiveOld() {
        val sod = startOfDay(now())
        val s = Store.state
        if (s.tasks.none { (it.doneAt != null && it.doneAt < sod && !it.archived) || (it.doneAt == null && !it.archived && isRepeating(it) && it.due != null && startOfDay(it.due) < sod) }) return
        Store.update { st ->
            st.copy(tasks = st.tasks.map { t ->
                if (t.doneAt != null && t.doneAt < sod && !t.archived) t.copy(archived = true)
                else if (t.doneAt == null && !t.archived && isRepeating(t) && t.due != null && startOfDay(t.due) < sod) {
                    var d: Long = t.due; var g = 0
                    while (startOfDay(d) < sod && g < 5000) { d = nextOcc(t, d); g++ }
                    t.copy(due = d, notified = false)
                } else t
            })
        }
    }
}

// ================= Gewohnheiten =================
object Habits {
    fun progress(h: Habit) = if (h.progressDay == startOfDay(now())) h.progress else 0
    fun doneToday(h: Habit) = startOfDay(now()) in h.doneDays

    fun countThisWeek(h: Habit): Int { val w = startOfWeek(now()); return h.doneDays.count { it >= w } }

    /** soll heute erledigt werden? */
    fun dueToday(h: Habit): Boolean = when (h.mode) {
        HABIT_WEEKDAYS -> dow(now()) in h.weekdays
        HABIT_PER_WEEK -> doneToday(h) || countThisWeek(h) < h.perWeek
        else -> true
    }

    fun modeText(h: Habit): String = when (h.mode) {
        HABIT_WEEKDAYS -> WEEKDAYS.filter { it.first in h.weekdays }.joinToString(" ") { it.second }.ifBlank { "keine Tage" }
        HABIT_PER_WEEK -> "${countThisWeek(h)}/${h.perWeek} diese Woche"
        else -> "täglich"
    }

    /** Streak: Tage (täglich), geplante Tage (Wochentage) oder Wochen (X-mal pro Woche) in Folge */
    fun streak(h: Habit, before: Boolean = false): Int {
        val days = h.doneDays.toSet()
        val today = startOfDay(now())
        return when (h.mode) {
            HABIT_WEEKDAYS -> {
                if (h.weekdays.isEmpty()) return 0
                var d = today; var n = 0; var g = 0
                if (before || today !in days) d = startOfDay(addDays(d, -1))
                while (g < 800) {
                    if (dow(d) in h.weekdays) { if (d in days) n++ else break }
                    d = startOfDay(addDays(d, -1)); g++
                }
                n
            }
            HABIT_PER_WEEK -> {
                var w = startOfWeek(today); var n = 0; var g = 0
                fun met(ws: Long) = days.count { it >= ws && it < addDays(ws, 7) } >= h.perWeek
                if (before || !met(w)) w = addDays(w, -7)
                while (g < 200 && met(w)) { n++; w = addDays(w, -7); g++ }
                n
            }
            else -> {
                val from = if (before || today !in days) startOfDay(addDays(today, -1)) else today
                Rewards.dayChain(days, from)
            }
        }
    }

    /** +5 % pro Streak-Einheit, höchstens ×10 */
    fun mult(h: Habit): Double = min(10.0, 1.05.pow(streak(h, before = true)))
    fun nextXp(h: Habit): Int = (h.baseXp * mult(h)).roundToInt()

    fun upsert(h: Habit) = Store.update { s ->
        if (s.habits.any { it.id == h.id }) s.copy(habits = s.habits.map { if (it.id == h.id) h else it }) else s.copy(habits = s.habits + h)
    }
    fun delete(id: Long) = Store.update { s -> s.copy(habits = s.habits.filterNot { it.id == id }) }

    fun step(id: Long, delta: Int) {
        val today = startOfDay(now())
        val h = Store.state.habits.find { it.id == id } ?: return
        val cur = progress(h)
        val np = (cur + delta).coerceIn(0, h.target)
        val wasDone = today in h.doneDays
        val xp = nextXp(h)
        var days = h.doneDays
        if (np >= h.target && !wasDone) days = (days + today).takeLast(800)
        else if (np < h.target && wasDone) days = days - today
        Store.update { s -> s.copy(habits = s.habits.map { if (it.id == id) h.copy(progress = np, progressDay = today, doneDays = days) else it }) }
        if (np >= h.target && !wasDone) Rewards.addXp(h.id, h.title, "habit", xp)
        else if (np < h.target && wasDone) Rewards.removeXp { it.refId == h.id && it.kind == "habit" && startOfDay(it.at) == today }
    }

    fun setDone(h: Habit, done: Boolean) {
        val cur = progress(h)
        val delta = if (done) h.target - cur else -cur
        if (delta != 0) step(h.id, delta)
    }
}
