package com.lifesave.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.CalendarSync
import com.lifesave.training.Training
import com.lifesave.ui.*
import java.util.Calendar

/** Farben für neue Kategorien (der Reihe nach) */
val CAT_COLORS = listOf("#1F4E79", "#C8102E", "#7E57C2", "#2E7D46", "#E07A1F", "#C9A227", "#0F8F7E", "#D81B60", "#5D4037", "#546E7A")
private val DURATIONS = listOf(10, 20, 30, 40, 60, 90, 120, 180)

// ================= Block anlegen / bearbeiten =================
/** arg: Block-ID oder "new|<Tag>|<Beginn in Minuten>|<Vorlage>" (Vorlage "tr" = Training laut Plan) */
@Composable
fun BlockEditor(arg: String) {
    val ctx = LocalContext.current
    val st = Store.state
    val p = pal
    val parts = arg.split("|")
    val isNew = parts[0] == "new"
    val orig = if (isNew) null else parts[0].toLongOrNull()?.let { id -> st.blocks.find { it.id == id } }
    if (!isNew && orig == null) {
        Screen { item { Empty("Diesen Block gibt es nicht mehr.") } }
        return
    }
    val initDay = orig?.day ?: parts.getOrNull(1)?.toLongOrNull() ?: startOfDay(now())
    val trName = if (orig == null && parts.getOrNull(3) == "tr") Schedule.trainingOn(initDay, st) else null

    var title by remember { mutableStateOf(orig?.title ?: trName?.let { "🏋 $it" } ?: "") }
    var cat by remember { mutableStateOf(orig?.cat ?: if (trName != null && Schedule.cat("training", st) != null) "training" else "") }
    var day by remember { mutableLongStateOf(initDay) }
    var start by remember { mutableIntStateOf(orig?.start ?: parts.getOrNull(2)?.toIntOrNull() ?: Schedule.nextSlot(initDay)) }
    var dur by remember { mutableIntStateOf(orig?.dur ?: if (trName != null) 90 else st.settings.schedDefaultDur) }
    var note by remember { mutableStateOf(orig?.note ?: "") }
    var source by remember { mutableStateOf(orig?.source ?: if (trName != null) SRC_TRAINING else SRC_OWN) }
    var ref by remember { mutableStateOf(orig?.ref ?: if (trName != null) "tr" else "") }
    var status by remember { mutableIntStateOf(orig?.status ?: BLOCK_OPEN) }
    // Vorschläge zeigen, bis einer gewählt wurde (oder beim Tippen wieder)
    var picked by remember { mutableStateOf(orig != null || trName != null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (isNew && trName == null) runCatching { focus.requestFocus() } }
    val sugg = if (!picked) Schedule.suggestions(title, day, st) else emptyList()
    val end = (start + dur).coerceAtMost(Schedule.GRID_TO)

    fun save() {
        val d = dur.coerceIn(Schedule.SNAP, Schedule.GRID_TO - Schedule.GRID_FROM)
        val base = orig ?: Block(day = day, start = start, dur = d, title = "")
        val moved = orig != null && (orig.day != day || orig.start != start)
        Schedule.upsert(base.copy(
            day = day, start = start, dur = d, title = title.trim(), cat = cat, note = note.trim(), source = source, ref = ref,
            status = if (status == BLOCK_DONE) base.status else status,
            reminded = if (moved) 0L else base.reminded
        ))
        if (status == BLOCK_DONE && base.status != BLOCK_DONE) Schedule.markDone(base.id)
        Nav.back()
    }

    Screen {
        item {
            Panel {
                Field(title, { title = it; picked = false; if (source != SRC_OWN) { source = SRC_OWN; ref = "" } }, "Was steht an?",
                    Modifier.fillMaxWidth().focusRequester(focus))
                if (sugg.isNotEmpty()) {
                    Muted(if (title.isBlank()) "Vorschläge – zuletzt und häufig eingetragen" else "Passende Vorschläge", Modifier.padding(top = 8.dp, bottom = 2.dp), size = 12.sp)
                    sugg.forEach { s ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                title = s.title; cat = s.cat; dur = s.dur; source = s.source; ref = s.ref; picked = true
                                if (start + s.dur > Schedule.GRID_TO) start = Schedule.clampStart(start, s.dur)
                            }.padding(horizontal = 4.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(12.dp).clip(CircleShape).background(hex(Schedule.cat(s.cat, st)?.color ?: "") ?: p.line))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Body(s.title, maxLines = 1)
                                if (s.hint.isNotBlank()) Muted(s.hint, size = 12.sp, maxLines = 1)
                            }
                            Text("↖", color = p.inkSoft, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("Wann?")
                ChipRow {
                    Pick("📅 " + if (day == startOfDay(now())) "Heute" else fmtDay(day), true) {
                        val c = Calendar.getInstance().apply { timeInMillis = day }
                        DatePickerDialog(ctx, { _, y, m, d -> day = Calendar.getInstance().apply { clear(); set(y, m, d) }.timeInMillis },
                            c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Body("Beginn", Modifier.weight(1f))
                    TimeStep(fmtMin(start), { start = Schedule.clampStart(start - Schedule.SNAP, dur) }, { start = Schedule.clampStart(start + Schedule.SNAP, dur) }) {
                        TimePickerDialog(ctx, { _, h, m -> start = Schedule.clampStart(Schedule.snap(h * 60 + m), dur) }, start / 60, start % 60, true).show()
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Body("Dauer", Modifier.weight(1f))
                    TimeStep(fmtDur(dur), { dur = (dur - Schedule.SNAP).coerceAtLeast(Schedule.SNAP) }, { dur = (dur + Schedule.SNAP).coerceAtMost(Schedule.GRID_TO - start) }) {}
                }
                ChipRow { DURATIONS.forEach { m -> Pick(fmtDur(m), dur == m) { dur = m.coerceAtMost(Schedule.GRID_TO - start) } } }
                Muted("${fmtMin(start)} – ${fmtMin(end)} Uhr", Modifier.padding(top = 2.dp))
            }
        }
        item {
            Panel {
                Heading("Kategorie")
                ChipRow {
                    Pick("Keine", cat.isEmpty()) { cat = "" }
                    st.schedCats.forEach { c -> Pick(c.name, cat == c.id, color = hex(c.color) ?: p.primary) { cat = c.id } }
                }
                Text("Kategorien & Farben bearbeiten ›", Modifier.clickable { Nav.go("settings_x", "plan") }.padding(vertical = 4.dp), color = p.primary, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Field(note, { note = it }, "Notiz (optional)", singleLine = false, minLines = 2)
            }
        }
        if (orig != null) item {
            Panel {
                Heading("Status")
                ChipRow {
                    Pick("Offen", status == BLOCK_OPEN) { status = BLOCK_OPEN }
                    Pick("✓ Erledigt", status == BLOCK_DONE, color = p.good) { status = BLOCK_DONE }
                    Pick("Ausgefallen", status == BLOCK_SKIPPED, color = p.inkSoft) { status = BLOCK_SKIPPED }
                }
                if (orig.extended > 0) Muted("Schon um ${orig.extended} Min. verlängert", Modifier.padding(top = 4.dp))
                if (source == SRC_TRAINING && day == startOfDay(now())) Training.dueToday(st)?.let { s ->
                    Btn("🏋 Workout jetzt starten", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.DANGER, small = true) {
                        Training.start(s.plan, s.day); Nav.go("workout")
                    }
                }
            }
        }
        item { Btn("Speichern", Modifier.fillMaxWidth(), enabled = title.isNotBlank()) { save() } }
        if (orig != null) item {
            Row {
                Btn("Kopie für morgen", Modifier.weight(1f), BtnKind.SECONDARY, small = true) {
                    Schedule.upsert(orig.copy(id = newId(), day = startOfDay(addDays(orig.day, 1)), status = BLOCK_OPEN, extended = 0,
                        reminded = 0L, calEventId = 0L, calSig = "", source = if (orig.source == SRC_TASK) SRC_OWN else orig.source,
                        ref = if (orig.source == SRC_TASK) "" else orig.ref))
                    Nav.back()
                }
                Spacer(Modifier.width(8.dp))
                Btn("Löschen", Modifier.weight(1f), BtnKind.GHOST, small = true) { Schedule.delete(orig.id); Nav.back() }
            }
        }
    }
}

/** − Wert + ; Wert antippen öffnet z. B. die Uhrzeit-Auswahl */
@Composable
private fun TimeStep(value: String, onMinus: () -> Unit, onPlus: () -> Unit, onClick: () -> Unit) {
    val p = pal
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).clip(CircleShape).background(p.soft).clickable { onMinus() }, contentAlignment = Alignment.Center) {
            Text("−", color = p.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Text(value, Modifier.widthIn(min = 76.dp).clip(RoundedCornerShape(8.dp)).clickable { onClick() }.padding(horizontal = 6.dp, vertical = 4.dp),
            textAlign = TextAlign.Center, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = p.ink)
        Box(Modifier.size(36.dp).clip(CircleShape).background(p.soft).clickable { onPlus() }, contentAlignment = Alignment.Center) {
            Text("+", color = p.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

// ================= Einstellungen: Tagesplan & Kalender =================
private val REMIND_STEPS = listOf(0, 5, 10, 15, 30, 60)

@Composable
fun PlanSettings() {
    val ctx = LocalContext.current
    val st = Store.state
    val s = st.settings
    val p = pal
    var refresh by remember { mutableIntStateOf(0) }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refresh++
        if (CalendarSync.hasRead(ctx)) {
            Store.setSettings { it.copy(calRead = true) }
            CalendarSync.loadCalendars(ctx)
            CalendarSync.ensure(ctx, startOfDay(now()), startOfDay(addDays(now(), 1)), force = true)
        }
    }
    val hasRead = remember(refresh) { CalendarSync.hasRead(ctx) }
    val hasWrite = remember(refresh) { CalendarSync.hasWrite(ctx) }
    LaunchedEffect(hasRead) { if (hasRead) CalendarSync.loadCalendars(ctx) }
    var newCat by remember { mutableStateOf("") }
    var colorFor by remember { mutableStateOf<SchedCat?>(null) }
    colorFor?.let { c -> ColorPickerDialog("Farbe: ${c.name}", c.color, { colorFor = null }) { Schedule.upsertCat(c.copy(color = it)); colorFor = null } }

    Screen {
        item {
            Panel {
                Heading("Kategorien & Farben")
                Muted("Wie die Fächer bei UNTIS. Farbkreis antippen zum Ändern.")
                Spacer(Modifier.height(6.dp))
                st.schedCats.forEach { c ->
                    key(c.id) {
                        var name by remember { mutableStateOf(c.name) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(34.dp).clip(CircleShape).background(hex(c.color) ?: Color.Gray).border(1.dp, p.line, CircleShape).clickable { colorFor = c })
                            Spacer(Modifier.width(10.dp))
                            Field(name, { name = it; if (it.isNotBlank()) Schedule.upsertCat(c.copy(name = it.trim())) }, "Name", Modifier.weight(1f))
                            IconBtn("✕", color = p.secondary) { Schedule.deleteCat(c.id) }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(newCat, { newCat = it }, "Neue Kategorie", Modifier.weight(1f))
                    IconBtn("＋", color = p.primary) {
                        if (newCat.isNotBlank()) {
                            Schedule.upsertCat(SchedCat("k" + newId(), newCat.trim(), CAT_COLORS[st.schedCats.size % CAT_COLORS.size]))
                            newCat = ""
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("Ablauf")
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Body("Nicht fertig → verlängern um", Modifier.weight(1f))
                    Stepper("${s.schedExtend} Min.",
                        { Store.setSettings { it.copy(schedExtend = (it.schedExtend - 10).coerceAtLeast(10)) } },
                        { Store.setSettings { it.copy(schedExtend = (it.schedExtend + 10).coerceAtMost(180)) } })
                }
                ToggleRow("Nach dem Ende fragen, ob erledigt", s.schedAskDone, "Die App öffnet sich nach dem Entsperren mit der Frage") { v -> Store.setSettings { it.copy(schedAskDone = v) } }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Body("Erinnerung vor Beginn", Modifier.weight(1f))
                    val i = REMIND_STEPS.indexOf(s.schedRemind).let { if (it < 0) 1 else it }
                    Stepper(if (s.schedRemind == 0) "aus" else "${s.schedRemind} Min.",
                        { Store.setSettings { it.copy(schedRemind = REMIND_STEPS[(i - 1).coerceAtLeast(0)]) } },
                        { Store.setSettings { it.copy(schedRemind = REMIND_STEPS[(i + 1).coerceAtMost(REMIND_STEPS.size - 1)]) } })
                }
                ToggleRow("„Jetzt dran“ in der Benachrichtigungsleiste", s.schedNowNotif, "Zeigt den aktuellen und nächsten Block – kommt nach dem Wegwischen sofort wieder") { v ->
                    Store.setSettings { it.copy(schedNowNotif = v) }
                }
                ToggleRow("Morgens nach dem Wiegen Tag planen", s.schedPlanPrompt, "Öffnet einmal am Tag die Tagesansicht") { v -> Store.setSettings { it.copy(schedPlanPrompt = v) } }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Body("Standard-Dauer", Modifier.weight(1f))
                    Stepper(fmtDur(s.schedDefaultDur),
                        { Store.setSettings { it.copy(schedDefaultDur = (it.schedDefaultDur - 10).coerceAtLeast(10)) } },
                        { Store.setSettings { it.copy(schedDefaultDur = (it.schedDefaultDur + 10).coerceAtMost(240)) } })
                }
            }
        }
        item {
            Panel(accent = p.primary) {
                Heading("Google-Kalender")
                if (!hasRead || !hasWrite) {
                    Muted("Damit deine Termine im Plan erscheinen und deine Blöcke im Google-Kalender landen, braucht Life Save Zugriff auf den Kalender.")
                    Btn("Kalender-Zugriff erlauben", Modifier.fillMaxWidth().padding(top = 8.dp)) { permL.launch(CalendarSync.PERMISSIONS) }
                } else {
                    ToggleRow("Termine im Plan anzeigen", s.calRead, "Mit Uhrzeit im Raster, ganztägige (z. B. Geburtstage) oben als Info") { v ->
                        Store.setSettings { it.copy(calRead = v) }
                        if (v) CalendarSync.ensure(ctx, startOfDay(now()), startOfDay(addDays(now(), 1)), force = true)
                    }
                    if (s.calRead) {
                        Muted("Welche Kalender?", Modifier.padding(top = 4.dp))
                        if (CalCache.calendars.isEmpty()) Muted("Keine Kalender gefunden.")
                        CalCache.calendars.forEach { c ->
                            val on = c.id !in s.calHidden
                            Row(Modifier.fillMaxWidth().clickable {
                                Store.setSettings { it.copy(calHidden = if (on) it.calHidden + c.id else it.calHidden - c.id) }
                            }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                Check(on, Color(c.color).copy(alpha = 1f), 26.dp) {
                                    Store.setSettings { it.copy(calHidden = if (on) it.calHidden + c.id else it.calHidden - c.id) }
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Body(c.name, maxLines = 1)
                                    if (c.account.isNotBlank()) Muted(c.account, size = 12.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                    Sep()
                    ToggleRow("Eigene Blöcke in den Kalender eintragen", s.calWrite, "So siehst du deinen Plan auch im Google-Kalender") { v ->
                        Store.setSettings { it.copy(calWrite = v) }
                        if (v) CalendarSync.writeSoon()
                    }
                    if (s.calWrite) {
                        val writable = CalCache.calendars.filter { it.writable }
                        Muted("In welchen Kalender?", Modifier.padding(top = 4.dp))
                        writable.forEach { c ->
                            RadioRow(c.name + if (c.account.isNotBlank() && c.account != c.name) " · ${c.account}" else "", s.calTarget == c.id) {
                                Store.setSettings { it.copy(calTarget = c.id) }
                                CalendarSync.writeSoon()
                            }
                        }
                        if (s.calTarget < 0) Muted("Bitte einen Kalender wählen.", color = p.secondary)
                    }
                    Muted("Kalendertermine, die du im Plan verschiebst, bleiben im Kalender unverändert. Life-Save-Termine im Kalender werden beim nächsten Ändern in der App überschrieben.",
                        Modifier.padding(top = 8.dp), size = 12.sp)
                }
            }
        }
    }
}
