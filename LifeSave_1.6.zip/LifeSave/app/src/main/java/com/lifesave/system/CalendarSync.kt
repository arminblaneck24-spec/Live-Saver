package com.lifesave.system

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import com.lifesave.core.*
import java.util.Calendar
import java.util.TimeZone
import java.util.concurrent.Executors

/**
 * Abgleich mit dem Android-Kalender (Google-Kalender):
 *  - liest Termine (mit Uhrzeit → im Raster, ganztägig → Info-Zeile)
 *  - trägt eigene Blöcke in einen gewählten Kalender ein und hält sie aktuell (nur in diese Richtung)
 * Kalendertermine selbst werden nie verändert – Verschieben passiert nur in der App.
 */
object CalendarSync {
    /** Markierung in der Beschreibung der von Life Save angelegten Termine */
    const val MARK = "[Life Save]"
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private val syncTask = Runnable { val c = app ?: return@Runnable; io.execute { runCatching { writeNow(c) } } }

    fun attach(c: Context) {
        if (app != null) return
        app = c.applicationContext
        Schedule.onChange = { scheduleWrite() }
    }

    fun hasRead(c: Context) = c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
    fun hasWrite(c: Context) = c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
    val PERMISSIONS = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)

    // ================= Lesen =================
    fun loadCalendars(c: Context) {
        val ctx = c.applicationContext
        io.execute {
            val list = runCatching { queryCalendars(ctx) }.getOrDefault(emptyList())
            main.post { CalCache.calendars = list }
        }
    }

    private fun queryCalendars(c: Context): List<CalInfo> {
        if (!hasRead(c)) return emptyList()
        val proj = arrayOf(
            CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME, CalendarContract.Calendars.CALENDAR_COLOR,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
        )
        val out = mutableListOf<CalInfo>()
        c.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, proj, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                out += CalInfo(
                    id = cur.getLong(0), name = cur.getString(1) ?: "Kalender", account = cur.getString(2) ?: "",
                    color = cur.getInt(3), writable = cur.getInt(4) >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR
                )
            }
        }
        return out
    }

    /** Standard-Zeitraum, der immer geladen wird (für Benachrichtigungen, Woche und Monat) */
    private fun defaultRange(): Pair<Long, Long> {
        val t = startOfDay(now())
        return startOfDay(addDays(startOfMonth(t), -7)) to startOfDay(addDays(t, 70))
    }

    /** lädt neu, wenn [from]..[to] nicht abgedeckt ist oder die Daten älter als 2 Minuten sind */
    fun ensure(c: Context, from: Long, to: Long, force: Boolean = false) {
        if (!Store.state.settings.calRead || !hasRead(c)) return
        val fresh = now() - CalCache.loadedAt < 120_000L
        if (!force && fresh && from >= CalCache.from && to <= CalCache.to) return
        val (df, dt) = defaultRange()
        refresh(c, minOf(from, df), maxOf(to, dt))
    }

    private var loading = false
    fun refresh(c: Context, from: Long, to: Long) {
        if (loading) return
        loading = true
        val ctx = c.applicationContext
        io.execute {
            val list = runCatching { queryEvents(ctx, from, to) }.getOrNull()
            main.post {
                loading = false
                if (list != null) { CalCache.events = list; CalCache.from = from; CalCache.to = to; CalCache.loadedAt = now() }
            }
        }
    }

    private fun queryEvents(c: Context, from: Long, to: Long): List<CalEvent> {
        if (!hasRead(c)) return emptyList()
        val s = Store.state
        val own = (s.blocks.map { it.calEventId } + s.calDeleted).filter { it != 0L }.toSet()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, from)
        ContentUris.appendId(b, to)
        val proj = arrayOf(
            CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.DISPLAY_COLOR,
            CalendarContract.Instances.CALENDAR_ID, CalendarContract.Instances.DESCRIPTION, CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.SELF_ATTENDEE_STATUS
        )
        val out = mutableListOf<CalEvent>()
        c.contentResolver.query(b.build(), proj, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
            while (cur.moveToNext()) {
                val eid = cur.getLong(0)
                val desc = cur.getString(7) ?: ""
                if (eid in own || desc.contains(MARK)) continue
                if (cur.getInt(9) == CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED) continue
                val allDay = cur.getInt(4) == 1
                var begin = cur.getLong(2)
                var end = cur.getLong(3)
                if (allDay) {
                    begin = utcDayToLocal(begin)
                    end = utcDayToLocal(end).let { if (it <= begin) startOfDay(addDays(begin, 1)) else it }
                }
                out += CalEvent(
                    key = "$eid@${cur.getLong(2)}", eventId = eid, calId = cur.getLong(6), title = cur.getString(1) ?: "",
                    begin = begin, end = end, allDay = allDay, color = cur.getInt(5), location = cur.getString(8) ?: ""
                )
            }
        }
        return out
    }

    /** ganztägige Termine sind in UTC gespeichert → lokaler Tagesanfang desselben Datums */
    private fun utcDayToLocal(t: Long): Long {
        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = t }
        return Calendar.getInstance().apply {
            clear(); set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH))
        }.timeInMillis
    }

    /** Termin in der Kalender-App öffnen */
    fun openEvent(c: Context, e: CalEvent) {
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, e.eventId)
        runCatching {
            c.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, e.begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, e.end))
        }
    }

    // ================= Schreiben (eigene Blöcke → Kalender) =================
    private fun scheduleWrite() {
        main.removeCallbacks(syncTask)
        main.postDelayed(syncTask, 2500)
    }

    /** sofort abgleichen (z. B. nach dem Einschalten) */
    fun writeSoon() = scheduleWrite()

    private fun writeNow(c: Context) {
        val s = Store.state
        val st = s.settings
        if (!st.calWrite || st.calTarget < 0 || !hasWrite(c)) return
        val cr = c.contentResolver
        val deleted = mutableListOf<Long>()
        s.calDeleted.forEach { id ->
            runCatching { cr.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), null, null) }
            deleted += id
        }
        val written = mutableMapOf<Long, Pair<Long, String>>()
        val from = startOfDay(addDays(now(), -7))
        val tz = TimeZone.getDefault().id
        s.blocks.filter { it.day >= from && it.status != BLOCK_SKIPPED }.forEach { b ->
            val begin = atMinute(b.day, b.start)
            val end = atMinute(b.day, b.end)
            val title = b.title + if (b.status == BLOCK_DONE) " ✓" else ""
            val sig = "$begin|$end|$title|${b.note}"
            if (b.calEventId != 0L && b.calSig == sig) return@forEach
            val v = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, begin)
                put(CalendarContract.Events.DTEND, end)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, (b.note + "\n\n" + MARK).trim())
                put(CalendarContract.Events.EVENT_TIMEZONE, tz)
            }
            var id = b.calEventId
            if (id != 0L) {
                val n = runCatching { cr.update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), v, null, null) }.getOrDefault(0)
                if (n == 0) id = 0L
            }
            if (id == 0L) {
                v.put(CalendarContract.Events.CALENDAR_ID, st.calTarget)
                id = runCatching { cr.insert(CalendarContract.Events.CONTENT_URI, v)?.lastPathSegment?.toLongOrNull() }.getOrNull() ?: return@forEach
            }
            written[b.id] = id to sig
        }
        // ausgefallene Blöcke aus dem Kalender nehmen
        val skipped = s.blocks.filter { it.status == BLOCK_SKIPPED && it.calEventId != 0L }
        skipped.forEach { b -> runCatching { cr.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, b.calEventId), null, null) } }
        if (written.isEmpty() && deleted.isEmpty() && skipped.isEmpty()) return
        val skippedIds = skipped.map { it.id }.toSet()
        main.post {
            Store.update { cur ->
                cur.copy(
                    blocks = cur.blocks.map { b ->
                        when {
                            b.id in skippedIds -> b.copy(calEventId = 0L, calSig = "")
                            else -> written[b.id]?.let { (id, sig) -> b.copy(calEventId = id, calSig = sig) } ?: b
                        }
                    },
                    calDeleted = cur.calDeleted - deleted.toSet()
                )
            }
        }
    }
}
