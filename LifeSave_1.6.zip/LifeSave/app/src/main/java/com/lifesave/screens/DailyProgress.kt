package com.lifesave.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*

/** gemerkte Unter-Tabs (bleiben beim Wechseln erhalten) */
object SubTabs {
    var daily by mutableIntStateOf(0)
    var progress by mutableIntStateOf(0)
}

// ================= Alltag: Plan + Aufgaben + Gewohnheiten =================
@Composable
fun DailyScreen() {
    Column(Modifier.fillMaxSize()) {
        Segmented(listOf("📅 Plan", "✓ Aufgaben", "🔥 Gewohnh."), SubTabs.daily, Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp)) { SubTabs.daily = it }
        Box(Modifier.weight(1f)) {
            when (SubTabs.daily) {
                0 -> PlannerScreen()
                1 -> TasksScreen()
                else -> HabitsScreen()
            }
        }
    }
}

// ================= Fortschritt: alles mit Diagrammen =================
val PROGRESS_TABS = listOf("Übersicht", "Diagramme", "Körper", "Muskeln", "Rekorde", "Abzeichen")

@Composable
fun ProgressScreen() {
    Column(Modifier.fillMaxSize()) {
        // zwei Reihen à drei Segmente → alles auf einen Blick, nichts versteckt
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Segmented(PROGRESS_TABS.take(3), if (SubTabs.progress < 3) SubTabs.progress else -1) { SubTabs.progress = it }
            Segmented(PROGRESS_TABS.drop(3), if (SubTabs.progress >= 3) SubTabs.progress - 3 else -1) { SubTabs.progress = it + 3 }
        }
        Box(Modifier.weight(1f)) {
            when (SubTabs.progress) {
                0 -> StatsScreen(0)
                1 -> ChartsScreen()
                2 -> BodyScreen()
                3 -> StatsScreen(1)
                4 -> StatsScreen(2)
                else -> StatsScreen(3)
            }
        }
    }
}

// ---------- Diagramm-Baukasten ----------
private val METRICS = linkedMapOf(
    "volume" to "Gesamtvolumen (kg)",
    "avgw" to "Ø Gewicht pro Satz (kg)",
    "sets" to "Sätze",
    "reps" to "Wiederholungen",
    "dur" to "Dauer (Min.)",
    "e1rm" to "Ø Kraft (1RM-Index)"
)
private val OTHER = linkedMapOf(
    "weight" to "Körpergewicht",
    "kcal" to "Kalorien",
    "protein" to "Eiweiß",
    "sleep" to "Schlaf",
    "steps" to "Schritte",
    "water" to "Wasser"
)

object ChartSel {
    var source by mutableStateOf("all")       // "all", "day:<Name>", "ex:<id>" oder Körper-/Alltagswert
    var metric by mutableStateOf("volume")
    var range by mutableIntStateOf(1)         // 0 = 1 Monat, 1 = 3 Monate, 2 = 1 Jahr, 3 = alles
    var weekly by mutableStateOf(false)
}

@Composable
fun ChartsScreen() {
    val st = Store.state
    val p = pal
    val from = when (ChartSel.range) { 0 -> addDays(now(), -30); 1 -> addDays(now(), -90); 2 -> addDays(now(), -365); else -> 0L }
    // Trainingstage aus allen Plänen (nach Name, damit „Oberkörper A" über Planwechsel hinweg zusammenbleibt)
    val dayNames = (st.plans.flatMap { pl -> pl.days.map { it.name } } + st.workouts.map { it.name }).distinct()
    val exIds = st.workouts.flatMap { w -> w.exercises.map { it.exId } }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key }.take(25)
    val src = ChartSel.source
    val isTraining = src == "all" || src.startsWith("day:")
    val isExercise = src.startsWith("ex:")

    val points: List<Pair<Long, Double>> = remember(st, src, ChartSel.metric, ChartSel.weekly, ChartSel.range) {
        when {
            isTraining -> {
                val ws = st.workouts.filter { it.start >= from && (src == "all" || it.name == src.removePrefix("day:")) }.sortedBy { it.start }
                fun value(l: List<Workout>): Double = when (ChartSel.metric) {
                    "volume" -> l.sumOf { it.volume() }
                    "avgw" -> l.flatMap { w -> w.exercises.flatMap { e -> e.sets.filter { it.done && it.weight > 0 } } }.map { it.weight }.average().let { if (it.isNaN()) 0.0 else it }
                    "sets" -> l.sumOf { it.doneSets() }.toDouble()
                    "reps" -> l.sumOf { w -> w.exercises.sumOf { e -> e.sets.filter { it.done }.sumOf { it.reps } } }.toDouble()
                    "dur" -> l.sumOf { ((it.end ?: it.start) - it.start) / 60_000.0 }
                    else -> l.flatMap { w -> w.exercises.map { Training.bestOf(it).e1rm } }.filter { it > 0 }.average().let { if (it.isNaN()) 0.0 else it }
                }
                if (ChartSel.weekly) ws.groupBy { startOfWeek(it.start) }.toSortedMap().map { (k, v) -> k to value(v) }
                else ws.map { it.start to value(listOf(it)) }
            }
            isExercise -> {
                val id = src.removePrefix("ex:")
                st.workouts.filter { it.start >= from }.sortedBy { it.start }.mapNotNull { w ->
                    w.exercises.find { it.exId == id }?.let { e ->
                        val b = Training.bestOf(e)
                        w.start to when (ChartSel.metric) { "volume" -> b.volume; "e1rm" -> b.e1rm; "reps" -> b.reps.toDouble(); else -> b.weight }
                    }
                }
            }
            src == "weight" -> BodyLog.sorted(st).filter { it.at >= from }.map { it.at to it.kg }
            src == "kcal" || src == "protein" -> st.foodLogs.filter { it.day >= startOfDay(from) }.groupBy { it.day }.toSortedMap()
                .map { (d, l) -> d to l.sumOf { it.values[src] ?: 0.0 } }
            src == "sleep" -> st.sleep.filterKeys { it >= from }.toSortedMap().map { it.key to it.value }
            src == "steps" -> st.steps.filterKeys { it >= from }.toSortedMap().map { it.key to it.value.toDouble() }
            src == "water" -> st.water.filterKeys { it >= from }.toSortedMap().map { it.key to it.value.toDouble() }
            else -> emptyList()
        }
    }
    val goal: Double? = when (src) {
        "kcal", "protein" -> Nutrition.goal(src, st)
        "sleep" -> st.settings.sleepGoal
        "steps" -> st.settings.stepGoal.toDouble()
        "water" -> st.settings.waterGoal.toDouble()
        else -> null
    }
    val avgLine = if (src == "weight") BodyLog.avg7(st).filter { it.first >= from } else null

    Screen {
        item {
            Panel {
                Heading("Was willst du sehen?")
                Muted("Training")
                LazyRow {
                    item { Pick("Alle Workouts", src == "all") { ChartSel.source = "all"; if (ChartSel.metric !in METRICS) ChartSel.metric = "volume" } }
                    items(dayNames) { n -> Pick(n, src == "day:$n") { ChartSel.source = "day:$n"; if (ChartSel.metric !in METRICS) ChartSel.metric = "volume" } }
                }
                Muted("Körper & Alltag")
                LazyRow { items(OTHER.keys.toList()) { k -> Pick(OTHER[k] ?: k, src == k) { ChartSel.source = k } } }
                Muted("Einzelne Übung")
                LazyRow { items(exIds) { id -> Pick(ExerciseDb.name(id).take(24), src == "ex:$id") { ChartSel.source = "ex:$id"; ChartSel.metric = "weight" } } }
            }
        }
        item {
            Panel {
                if (isTraining) {
                    LazyRow { items(METRICS.keys.toList()) { k -> Pick(METRICS[k] ?: k, ChartSel.metric == k) { ChartSel.metric = k } } }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pick("Pro Workout", !ChartSel.weekly) { ChartSel.weekly = false }
                        Pick("Pro Woche", ChartSel.weekly) { ChartSel.weekly = true }
                    }
                }
                if (isExercise) ChipRow {
                    listOf("weight" to "Max. Gewicht", "e1rm" to "1RM", "volume" to "Volumen", "reps" to "Max. Wdh.").forEach { (k, l) -> Pick(l, ChartSel.metric == k) { ChartSel.metric = k } }
                }
                ChipRow { listOf("1 M", "3 M", "1 J", "Alles").forEachIndexed { i, l -> Pick(l, ChartSel.range == i) { ChartSel.range = i } } }
                val title = when {
                    isTraining -> (if (src == "all") "Alle Workouts" else src.removePrefix("day:")) + " · " + (METRICS[ChartSel.metric] ?: "")
                    isExercise -> ExerciseDb.name(src.removePrefix("ex:"))
                    else -> OTHER[src] ?: src
                }
                Body(title, bold = true)
                LineChart(points, height = 220.dp, second = avgLine, goal = goal)
                if (points.isNotEmpty()) {
                    val vals = points.map { it.second }
                    Row(Modifier.padding(top = 6.dp)) {
                        StatBox("Ø", fmtKg(Math.round(vals.average() * 10) / 10.0), Modifier.weight(1f)); Spacer(Modifier.width(6.dp))
                        StatBox("Max", fmtKg(Math.round((vals.maxOrNull() ?: 0.0) * 10) / 10.0), Modifier.weight(1f)); Spacer(Modifier.width(6.dp))
                        val ch = if (vals.size >= 2 && vals.first() != 0.0) (vals.last() / vals.first() - 1) * 100 else null
                        StatBox("Veränderung", ch?.let { (if (it >= 0) "+" else "") + "${it.toInt()} %" } ?: "–", Modifier.weight(1f), if ((ch ?: 0.0) >= 0) p.good else p.secondary)
                    }
                }
                if (goal != null) Muted("Gestrichelt = dein Ziel", Modifier.padding(top = 4.dp))
                if (avgLine != null) Muted("Gold = gleitender 7-Tage-Schnitt", Modifier.padding(top = 4.dp))
            }
        }
    }
}
