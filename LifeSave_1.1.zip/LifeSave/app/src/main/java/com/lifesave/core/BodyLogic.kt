package com.lifesave.core

import java.io.File
import java.io.InputStream

object BodyLog {
    fun latest(s: AppState = Store.state): WeightEntry? = s.weights.maxByOrNull { it.at }
    fun sorted(s: AppState = Store.state) = s.weights.sortedBy { it.at }

    /** Veränderung gegenüber dem Eintrag, der etwa [days] Tage zurückliegt */
    fun change(days: Int, s: AppState = Store.state): Double? {
        val l = latest(s) ?: return null
        val ref = s.weights.filter { it.at <= addDays(l.at, -days) }.maxByOrNull { it.at } ?: s.weights.minByOrNull { it.at } ?: return null
        if (ref.id == l.id) return null
        return l.kg - ref.kg
    }

    fun addWeight(kg: Double, at: Long = now()) {
        val e = WeightEntry(kg = kg, at = at)
        Store.update { it.copy(weights = it.weights + e) }
        Rewards.addXp(e.id, "Gewogen", "weigh", 10)
    }

    fun deleteWeight(id: Long) = Store.update { s -> s.copy(weights = s.weights.filterNot { it.id == id }) }

    // ---------- Fortschrittsfotos (privat im App-Speicher, nicht in der Galerie) ----------
    fun newPhotoFile(): File = File(Store.photoDir, "p_${newId()}.jpg")

    fun addPhoto(file: File) {
        if (!file.exists() || file.length() == 0L) return
        val p = PhotoEntry(file = file.name)
        Store.update { it.copy(photos = it.photos + p) }
        Rewards.addXp(p.id, "Fortschrittsfoto", "photo", 5)
    }

    fun importPhoto(input: InputStream) {
        val f = newPhotoFile()
        input.use { i -> f.outputStream().use { i.copyTo(it) } }
        addPhoto(f)
    }

    fun fileOf(p: PhotoEntry) = File(Store.photoDir, p.file)

    fun deletePhoto(p: PhotoEntry) {
        runCatching { fileOf(p).delete() }
        Store.update { s -> s.copy(photos = s.photos.filterNot { it.id == p.id }) }
    }
}
