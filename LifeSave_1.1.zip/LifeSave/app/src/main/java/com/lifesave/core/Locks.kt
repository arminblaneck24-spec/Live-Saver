package com.lifesave.core

/**
 * Handy-Sperren: Wiegen (wöchentlich) und Tagesabschluss (abends).
 * Solange eine Sperre offen ist, leitet der Wächter-Dienst jede andere App auf Life Save um
 * (Telefon/Notruf/Uhr bleiben frei). Mit dem Passwort lässt sich das für 10 Minuten aussetzen.
 */
object Locks {
    /** letzter Wiege-Termin (z. B. Samstag 11 Uhr), der schon erreicht ist */
    fun weighDueAt(s: AppState = Store.state, at: Long = now()): Long {
        var d = startOfDay(at); var g = 0
        while (g < 8) {
            if (dow(d) == s.settings.weighDay && atHour(d, s.settings.weighHour) <= at) return atHour(d, s.settings.weighHour)
            d = startOfDay(addDays(d, -1)); g++
        }
        return 0L
    }

    fun weighedSince(s: AppState, t: Long) = s.weights.any { it.at >= startOfDay(t) }

    fun weighPending(s: AppState = Store.state): Boolean {
        if (!s.settings.locksOn) return false
        val due = weighDueAt(s)
        if (due == 0L) return false
        val n = now()
        return n >= due && !weighedSince(s, due) && n >= s.weighSnoozeUntil
    }

    /** „Gerade keine Waage" → morgen zur selben Uhrzeit wieder */
    fun snoozeWeigh() = Store.update { it.copy(weighSnoozeUntil = atHour(addDays(startOfDay(now()), 1), it.settings.weighHour)) }

    fun reviewPending(s: AppState = Store.state): Boolean =
        s.settings.locksOn && hourNow() >= s.settings.reviewHour && s.reviewDay != startOfDay(now())

    fun finishReview() {
        Store.update { it.copy(reviewDay = startOfDay(now())) }
        Rewards.addXp(0L, "Tagesabschluss", "review", 10)
    }

    /** "weigh", "review" oder null */
    fun pending(s: AppState = Store.state): String? = when {
        Store.adminActive() -> null
        // während eines laufenden Workouts (höchstens 3 Std.) wartet die Sperre
        s.active != null && now() - s.active.start < 3 * 3_600_000L -> null
        weighPending(s) -> "weigh"
        reviewPending(s) -> "review"
        else -> null
    }

    // ---------- Automatisch öffnen nach dem Entsperren ----------
    fun shouldOpen(s: AppState = Store.state, somethingOpen: Boolean): Boolean {
        val st = s.settings
        val n = now()
        return when (st.openMode) {
            0 -> true
            1 -> n - s.lastShown >= st.openInterval * 60_000L
            2 -> startOfDay(n) != startOfDay(s.lastShown)
            3 -> somethingOpen && n - s.lastShown >= 15 * 60_000L
            else -> false
        }
    }

    fun markShown() = Store.update { it.copy(lastShown = now()) }
}
