package com.lifesave.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.Pw
import com.lifesave.ui.*
import com.lifesave.widget.WidgetRenderer
import com.lifesave.widget.WidgetUpdater
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Menüpunkte der Einstellungen. Neue Bereiche: hier eintragen und unten im `when` ergänzen. */
val SETTINGS_SECTIONS = listOf(
    Triple("general", "Allgemein", "Startseite, Satzpause"),
    Triple("design", "Design & Farben", "Farbschema wählen oder eigene Farben"),
    Triple("navigation", "Navigation", "Welche Bereiche unten in der Leiste stehen"),
    Triple("dashboard", "Startseite anpassen", "Kacheln anordnen und ausblenden"),
    Triple("widget", "Widget", "Homescreen-Widget gestalten"),
    Triple("locks", "Sperren & Automatik 🔒", "Wiegen, Tagesabschluss, automatisches Öffnen"),
    Triple("setup", "Einrichtung", "Berechtigungen prüfen"),
    Triple("data", "Daten & Backup", "Sichern, wiederherstellen"),
    Triple("update", "App-Update", "Neue Version direkt in der App installieren"),
    Triple("about", "Über Life Save", "Version und Neuerungen")
)

@Composable
fun SettingsScreen() {
    val p = pal
    Screen {
        SETTINGS_SECTIONS.forEach { (k, t, d) ->
            item {
                Panel(onClick = { Nav.go("settings_x", k) }, padding = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Body(t, bold = true)
                            Muted(d)
                        }
                        Text("›", color = p.inkSoft, fontSize = 24.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSection(k: String) {
    when (k) {
        "general" -> GeneralSettings()
        "design" -> DesignSettings()
        "navigation" -> NavigationSettings()
        "dashboard" -> DashboardSettings()
        "widget" -> WidgetEditor()
        "locks" -> LockSettings()
        "setup" -> Screen { item { SetupPanel(always = true) } }
        "data" -> DataSettings()
        "about" -> AboutScreen()
        "update" -> UpdateScreen()
        else -> SettingsScreen()
    }
}

// ---------- Allgemein ----------
@Composable
fun GeneralSettings() {
    val s = Store.state.settings
    Screen {
        item {
            Panel {
                Heading("Startseite beim Öffnen")
                ChipRow { SECTIONS.filterKeys { it != "settings" }.forEach { (k, v) -> Pick(v, s.startPage == k) { Store.setSettings { it.copy(startPage = k) } } } }
            }
        }
        item {
            Panel {
                Heading("Satzpause")
                Muted("Startet automatisch, wenn du einen Satz abhakst. Gilt für alle Übungen.")
                Spacer(Modifier.height(6.dp))
                Stepper(fmtDuration(s.restSec * 1000L),
                    { Store.setSettings { it.copy(restSec = (it.restSec - 15).coerceAtLeast(15)) } },
                    { Store.setSettings { it.copy(restSec = (it.restSec + 15).coerceAtMost(600)) } })
            }
        }
    }
}

// ---------- Design ----------
@Composable
fun DesignSettings() {
    val s = Store.state.settings
    val p = pal
    Screen {
        item { Heading("Farbschema") }
        THEMES.forEach { t ->
            item {
                val sel = s.themeId == t.id
                Panel(accent = if (sel) t.p.primary else null, onClick = { Store.setSettings { it.copy(themeId = t.id, customColors = emptyMap()) } }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Body(t.name + if (sel) "  ✓" else "", bold = true)
                            Muted(t.desc)
                        }
                        listOf(t.p.header, t.p.bg, t.p.primary, t.p.secondary, t.p.gold).forEach { c ->
                            Box(Modifier.padding(start = 3.dp).size(20.dp).clip(CircleShape).background(c).border(1.dp, p.line, CircleShape))
                        }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("Eigene Farben")
                Muted("Überschreibt einzelne Farben des gewählten Schemas.")
                val base = paletteFor(s)
                CUSTOM_KEYS.forEach { (k, label) ->
                    val cur = s.customColors[k] ?: toHex(when (k) {
                        "primary" -> base.primary; "secondary" -> base.secondary; "gold" -> base.gold
                        "header" -> base.header; "bg" -> base.bg; else -> base.panel
                    })
                    ColorRow(label, cur) { hx -> Store.setSettings { it.copy(customColors = it.customColors + (k to hx)) } }
                }
                if (s.customColors.isNotEmpty()) Btn("Eigene Farben zurücksetzen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) {
                    Store.setSettings { it.copy(customColors = emptyMap()) }
                }
            }
        }
    }
}

// ---------- Navigation ----------
@Composable
fun NavigationSettings() {
    val s = Store.state.settings
    val p = pal
    Screen {
        item { Muted("Bis zu 5 Bereiche unten in der Leiste. Alle Bereiche findest du immer im Menü ☰ oben links.") }
        item {
            Panel {
                Heading("Unten in der Leiste")
                s.tabs.forEachIndexed { i, k ->
                    OrderRow(SECTIONS[k] ?: k, true, { if (s.tabs.size > 1) Store.setSettings { st -> st.copy(tabs = st.tabs - k) } },
                        if (i > 0) ({ Store.setSettings { st -> st.copy(tabs = st.tabs.moved(i, i - 1)) } }) else null,
                        if (i < s.tabs.size - 1) ({ Store.setSettings { st -> st.copy(tabs = st.tabs.moved(i, i + 1)) } }) else null)
                }
                Heading("Weitere Bereiche")
                SECTIONS.keys.filter { it !in s.tabs }.forEach { k ->
                    OrderRow(SECTIONS[k] ?: k, false, { if (s.tabs.size < 5) Store.setSettings { st -> st.copy(tabs = st.tabs + k) } }, null, null)
                }
                if (s.tabs.size >= 5) Muted("Maximal 5 – erst einen entfernen.", color = p.secondary)
            }
        }
    }
}

// ---------- Startseite ----------
@Composable
fun DashboardSettings() {
    val s = Store.state.settings
    Screen {
        item {
            Panel {
                Heading("Kacheln der Startseite")
                s.tiles.forEachIndexed { i, t ->
                    OrderRow(TILE_NAMES[t.id] ?: t.id, t.visible,
                        { v -> Store.setSettings { st -> st.copy(tiles = st.tiles.map { if (it.id == t.id) it.copy(visible = v) else it }) } },
                        if (i > 0) ({ Store.setSettings { st -> st.copy(tiles = st.tiles.moved(i, i - 1)) } }) else null,
                        if (i < s.tiles.size - 1) ({ Store.setSettings { st -> st.copy(tiles = st.tiles.moved(i, i + 1)) } }) else null)
                }
                Btn("Standard wiederherstellen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) {
                    Store.setSettings { it.copy(tiles = DEFAULT_TILES) }
                }
            }
        }
        item {
            Panel {
                Heading("Mannequin zeigt standardmäßig")
                RadioRow("Zuletzt trainiert (verblasst über 7 Tage)", s.mannequinMode == 0) { Store.setSettings { it.copy(mannequinMode = 0) } }
                RadioRow("Wochenvolumen (Sätze der letzten 7 Tage)", s.mannequinMode == 1) { Store.setSettings { it.copy(mannequinMode = 1) } }
            }
        }
    }
}

// ---------- Widget ----------
@Composable
fun WidgetEditor() {
    val ctx = LocalContext.current
    val st = Store.state
    val w = st.settings.widget
    val density = LocalDensity.current.density
    fun set(f: (WidgetCfg) -> WidgetCfg) { Store.setSettings { it.copy(widget = f(it.widget)) } }
    val preview = remember(w, st) { WidgetRenderer.render(w, st, (340 * density).toInt(), (200 * density).toInt(), density).asImageBitmap() }
    Screen {
        item {
            Panel {
                Heading("Vorschau")
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pal.header.copy(alpha = 0.25f)).padding(10.dp)) {
                    Image(preview, null, Modifier.fillMaxWidth().aspectRatio(1.7f))
                }
                Spacer(Modifier.height(8.dp))
                Btn("Widget zum Startbildschirm hinzufügen", Modifier.fillMaxWidth(), small = true) {
                    if (!WidgetUpdater.requestPin(ctx)) Toast.makeText(ctx, "Lange auf den Startbildschirm drücken → Widgets → Life Save", Toast.LENGTH_LONG).show()
                }
                Muted("Größe änderst du direkt auf dem Startbildschirm (lange drücken). Änderungen hier erscheinen sofort.", Modifier.padding(top = 6.dp))
            }
        }
        item {
            Panel {
                Heading("Vorlagen")
                ChipRow {
                    WIDGET_TEMPLATES.forEach { (k, list) ->
                        Pick(k.replaceFirstChar { it.uppercase() }, w.template == k) {
                            set { c -> c.copy(template = k, blocks = list.map { Tile(it, true) } + WIDGET_BLOCKS.keys.filter { it !in list }.map { Tile(it, false) }) }
                        }
                    }
                }
                Heading("Bausteine")
                w.blocks.forEachIndexed { i, b ->
                    OrderRow(WIDGET_BLOCKS[b.id] ?: b.id, b.visible,
                        { v -> set { c -> c.copy(template = "eigene", blocks = c.blocks.map { if (it.id == b.id) it.copy(visible = v) else it }) } },
                        if (i > 0) ({ set { c -> c.copy(template = "eigene", blocks = c.blocks.moved(i, i - 1)) } }) else null,
                        if (i < w.blocks.size - 1) ({ set { c -> c.copy(template = "eigene", blocks = c.blocks.moved(i, i + 1)) } }) else null)
                }
                Muted("Tipp: Das Mannequin erscheint bei breiten Widgets rechts neben dem Text.")
            }
        }
        item {
            Panel {
                Heading("Farben")
                ColorRow("Hintergrund", w.bg) { hx -> set { it.copy(bg = hx) } }
                ColorRow("Text", w.fg) { hx -> set { it.copy(fg = hx) } }
                ColorRow("Akzent", w.accent) { hx -> set { it.copy(accent = hx) } }
                Muted("Deckkraft: ${w.alpha * 100 / 255} %")
                Slider(w.alpha / 255f, { v -> set { it.copy(alpha = (v * 255).toInt()) } })
                Muted("Ecken: ${w.radius} dp")
                Slider(w.radius / 32f, { v -> set { it.copy(radius = (v * 32).toInt()) } })
                Btn("Farben wie App-Design", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) {
                    val pp = paletteFor(st.settings)
                    set { it.copy(bg = toHex(pp.header), fg = toHex(pp.onHeader), accent = toHex(pp.gold)) }
                }
            }
        }
    }
}

// ---------- Sperren (Passwort) ----------
@Composable
fun LockSettings() {
    val s = Store.state.settings
    val p = pal
    val admin = Store.adminActive()
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Screen {
        item {
            Panel(accent = p.gold) {
                Heading("Aktuell")
                Body("⚖ Wiegen: ${WEEKDAY_LONG[s.weighDay]} ab ${s.weighHour}:00 Uhr")
                Body("🌙 Tagesabschluss: täglich ab ${s.reviewHour}:00 Uhr")
                Body("📲 Öffnen nach dem Entsperren: " + OPEN_MODES[s.openMode.coerceIn(0, OPEN_MODES.size - 1)] + if (s.openMode == 1) " (${s.openInterval} Min.)" else "")
                Body("Sperren: " + if (s.locksOn) "an" else "aus")
                Muted("Während einer Sperre bleiben Telefon, Notruf und Uhr frei. Läuft ein Workout, wartet die Sperre.", Modifier.padding(top = 4.dp))
            }
        }
        if (!admin) item {
            Panel {
                Heading("🔒 Geschützt")
                Muted("Diese Einstellungen sind mit dem Passwort geschützt, das sich alle 5 Minuten ändert. Frag Claude nach dem aktuellen Passwort.")
                Spacer(Modifier.height(6.dp))
                Field(pw, { pw = it.uppercase().trim(); wrong = false }, "Passwort", caps = true)
                if (wrong) Muted("Falsches oder abgelaufenes Passwort", color = p.secondary)
                Btn("Entsperren", Modifier.fillMaxWidth().padding(top = 6.dp)) { if (Pw.check(pw)) { Store.unlockAdmin(); pw = "" } else wrong = true }
            }
        } else item {
            Panel(accent = p.primary) {
                Heading("🔓 Entsperrt bis ${fmtTime(Store.adminUntil)}")
                ToggleRow("Sperren aktiv (Wiegen & Tagesabschluss)", s.locksOn) { v -> Store.setSettings { it.copy(locksOn = v) } }
                ToggleRow("Einstellungen schützen", s.protect, "verhindert Ausschalten/Deinstallieren ohne Passwort") { v -> Store.setSettings { it.copy(protect = v) } }
                Sep()
                Heading("Wiegen")
                ChipRow { WEEKDAYS.forEach { (d, l) -> Pick(l, s.weighDay == d) { Store.setSettings { it.copy(weighDay = d) } } } }
                Stepper("${s.weighHour}:00", { Store.setSettings { it.copy(weighHour = (it.weighHour + 23) % 24) } }, { Store.setSettings { it.copy(weighHour = (it.weighHour + 1) % 24) } }, "Ab")
                Sep()
                Heading("Tagesabschluss")
                Stepper("${s.reviewHour}:00", { Store.setSettings { it.copy(reviewHour = (it.reviewHour + 23) % 24) } }, { Store.setSettings { it.copy(reviewHour = (it.reviewHour + 1) % 24) } }, "Ab")
                Sep()
                Heading("Nach dem Entsperren öffnen")
                OPEN_MODES.forEachIndexed { i, l -> RadioRow(l, s.openMode == i) { Store.setSettings { it.copy(openMode = i) } } }
                if (s.openMode == 1) Stepper("${s.openInterval} Min.",
                    { Store.setSettings { it.copy(openInterval = (it.openInterval - 15).coerceAtLeast(15)) } },
                    { Store.setSettings { it.copy(openInterval = (it.openInterval + 15).coerceAtMost(600)) } })
                Spacer(Modifier.height(8.dp))
                Btn("Wieder sperren", Modifier.fillMaxWidth(), BtnKind.DANGER) { Store.lockAdmin() }
            }
        }
    }
}

val OPEN_MODES = listOf("Bei jedem Entsperren", "Höchstens alle X Minuten", "Einmal pro Tag", "Nur wenn etwas offen ist (Training, Aufgaben, Gewohnheiten)", "Aus")

// ---------- Daten ----------
@Composable
fun DataSettings() {
    val ctx = LocalContext.current
    var confirmImport by remember { mutableStateOf<AppState?>(null) }
    var importPhotos by remember { mutableStateOf<Map<String, ByteArray>>(emptyMap()) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching {
            Store.flush()
            ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                ZipOutputStream(os).use { z ->
                    z.putNextEntry(ZipEntry("data.json")); z.write(Json.encode(Store.state).toByteArray()); z.closeEntry()
                    Store.photoDir.listFiles()?.forEach { f -> z.putNextEntry(ZipEntry("photos/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
                }
            }
        }.onSuccess { Toast.makeText(ctx, "Backup gespeichert", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(ctx, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show() }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                var json: String? = null
                val photos = mutableMapOf<String, ByteArray>()
                ZipInputStream(bytes.inputStream()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (e.name == "data.json") json = z.readBytes().toString(Charsets.UTF_8)
                        else if (e.name.startsWith("photos/") && !e.isDirectory) photos[e.name.removePrefix("photos/").substringAfterLast('/')] = z.readBytes()
                        e = z.nextEntry
                    }
                }
                confirmImport = Json.decode(json!!); importPhotos = photos
            } else { confirmImport = Json.decode(bytes.toString(Charsets.UTF_8)); importPhotos = emptyMap() }
        }.onFailure { Toast.makeText(ctx, "Datei ungültig", Toast.LENGTH_SHORT).show() }
    }
    confirmImport?.let { imp ->
        ConfirmDialog("Backup laden?", "Deine aktuellen Daten werden durch das Backup ersetzt (${imp.workouts.size} Workouts, ${imp.weights.size} Gewichte, ${imp.photos.size} Fotos).", "Laden",
            { confirmImport = null }) {
            importPhotos.forEach { (n, b) -> runCatching { File(Store.photoDir, n).writeBytes(b) } }
            // Sperr-Einstellungen nur mit Passwort per Backup überschreibbar
            val cur = Store.state.settings
            Store.replace(if (Store.adminActive()) imp else imp.copy(settings = imp.settings.copy(
                openMode = cur.openMode, openInterval = cur.openInterval, reviewHour = cur.reviewHour,
                weighDay = cur.weighDay, weighHour = cur.weighHour, locksOn = cur.locksOn, protect = cur.protect)))
            Toast.makeText(ctx, "Backup geladen", Toast.LENGTH_SHORT).show()
        }
    }
    Screen {
        item {
            Panel {
                Heading("Automatische Sicherung")
                Body("Deine Daten werden automatisch über die Android-Sicherung in deinem Google-Konto gesichert und beim Neuinstallieren wiederhergestellt.")
                Muted("Voraussetzung: In den Android-Einstellungen unter »Google → Sicherung« ist die Sicherung eingeschaltet. Fotos sind wegen der Größe nur im manuellen Backup enthalten.", Modifier.padding(top = 4.dp))
            }
        }
        item {
            Panel {
                Heading("Manuelles Backup")
                Muted("Eine ZIP-Datei mit allen Daten und Fotos, z. B. für Google Drive oder ein neues Handy.")
                Spacer(Modifier.height(8.dp))
                Btn("Backup exportieren", Modifier.fillMaxWidth()) {
                    exportL.launch("lifesave-backup-" + java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMAN).format(java.util.Date()) + ".zip")
                }
                Spacer(Modifier.height(8.dp))
                Btn("Backup importieren", Modifier.fillMaxWidth(), BtnKind.GHOST) { importL.launch(arrayOf("application/zip", "application/json", "*/*")) }
            }
        }
    }
}

// ---------- Update ----------
@Composable
fun UpdateScreen() {
    val ctx = LocalContext.current
    val p = pal
    val s = Store.state.settings
    val u = com.lifesave.system.Updater
    var repo by remember { mutableStateOf(s.updateRepo) }
    var perm by remember { mutableIntStateOf(0) }
    val canInstall = remember(perm, u.status) { u.canInstall(ctx) }
    Screen {
        item {
            Panel(accent = p.primary) {
                Heading("Installiert")
                BigNumber("Version $VERSION")
                Spacer(Modifier.height(8.dp))
                val a = u.available
                if (a != null) {
                    Pill("Neu: Version ${a.version}", p.good)
                    if (a.notes.isNotBlank()) Muted(a.notes, Modifier.padding(top = 6.dp), maxLines = 12)
                    Spacer(Modifier.height(8.dp))
                    if (!canInstall) {
                        Muted("Einmalig nötig: Life Save erlauben, Apps zu installieren.", color = p.secondary)
                        Btn("Erlaubnis öffnen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY) { u.openInstallPermission(ctx); perm++ }
                        Btn("Erledigt – neu prüfen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) { perm++ }
                    } else Btn("Jetzt installieren", Modifier.fillMaxWidth(), BtnKind.GOLD, enabled = !u.busy) { u.downloadAndInstall(ctx) }
                }
                Btn("Nach Update suchen", Modifier.fillMaxWidth().padding(top = 8.dp), BtnKind.SECONDARY, enabled = !u.busy) { u.check() }
                if (u.status.isNotBlank()) Muted(u.status, Modifier.padding(top = 6.dp))
                Muted("Deine Daten bleiben beim Update erhalten.", Modifier.padding(top = 6.dp))
            }
        }
        item {
            Panel {
                Heading("GitHub-Repo")
                Muted("Von hier holt sich die App neue Versionen. Das Repo muss öffentlich sein.")
                Field(repo, { repo = it.trim(); Store.setSettings { st -> st.copy(updateRepo = repo) } }, "Benutzername/Repo")
            }
        }
    }
}

// ---------- Über ----------
val PATCH_NOTES = listOf(
    "1.1" to listOf(
        "Workout-Ansicht neu: alle Übungen untereinander mit Satz · Vorherige · kg · Wdh. und Speichern-Knopf unten",
        "Steigerungsvorschläge nach Doppelprogression: erst Wiederholungen, dann ca. 5 % mehr Gewicht",
        "Graue Vorschläge in leeren Feldern – Haken übernimmt sie, Antippen und direkt Neues tippen",
        "Wiederholungsbereiche (z. B. 8–12) im Trainingsplan",
        "Pläne als JSON importieren (z. B. von Claude), ohne andere Daten zu ersetzen",
        "App-Update direkt in der App (über GitHub Releases)"
    ),
    "1.0" to listOf(
        "Neu: Life Save ersetzt Unlock To-do – cleanes Design im Stil der MEL-Liga, 4 Farbschemata + eigene Farben",
        "Training: Pläne als Wochenplan (Zyklus 1–12 Wochen) oder feste Reihenfolge, Vorlagen, laufendes Workout mit Satzpause",
        "Übungsdatenbank mit 876 Übungen, Bildern, Mannequin, YouTube-Link und eigenen Übungen",
        "Automatische Rekorde mit Feier, 37 Abzeichen, XP & Level",
        "Cardio, Statistik je Muskel, Volumen pro Woche",
        "Gewicht mit Verlauf, private Fortschrittsfotos mit Vorher/Nachher-Vergleich",
        "Wiege-Sperre (Sa 11 Uhr) und Tagesabschluss-Sperre (22 Uhr), Notfall-Passwort",
        "Aufgaben mit Training als eigener Kategorie, Gewohnheiten täglich / Wochentage / X-mal pro Woche",
        "Einstellbare Startseite, Leiste unten, Seitenmenü und gestaltbares Widget",
        "Automatische Sicherung + Backup als ZIP"
    )
)

@Composable
fun AboutScreen() {
    val p = pal
    Screen {
        item {
            Panel(accent = p.primary) {
                Title(APP_NAME)
                Muted("Version $VERSION")
                Spacer(Modifier.height(6.dp))
                Body("Training, Aufgaben, Gewohnheiten und Körper an einem Ort. Ernährung folgt in Version 1.1.")
                Muted("Übungsdaten & Bilder: free-exercise-db (Public Domain). Schrift: Barlow Condensed (OFL).", Modifier.padding(top = 6.dp))
            }
        }
        PATCH_NOTES.forEach { (v, notes) ->
            item {
                Panel {
                    Heading("Neu in $v")
                    notes.forEach { Body("• $it", Modifier.padding(vertical = 2.dp), size = 14.sp) }
                }
            }
        }
    }
}
