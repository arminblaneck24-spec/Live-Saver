package com.lifesave

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.lifesave.core.Store
import com.lifesave.core.Tasks
import com.lifesave.screens.LifeSaveApp
import com.lifesave.screens.Nav
import com.lifesave.system.UnlockService
import com.lifesave.training.ExerciseDb
import com.lifesave.widget.WidgetUpdater

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        ExerciseDb.init(this)
        WidgetUpdater.attach(this)
        runCatching { startForegroundService(Intent(this, UnlockService::class.java)) }
        if (savedInstanceState == null) openStart()
        com.lifesave.system.Updater.autoCheck()
        setContent { LifeSaveApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // läuft ein Workout, direkt dorthin
        if (Store.state.active != null && Nav.current.name != "workout") Nav.go("workout")
    }

    private fun openStart() {
        Nav.root(Store.state.settings.startPage)
        if (Store.state.active != null) Nav.go("workout")
    }

    override fun onResume() {
        super.onResume()
        Tasks.archiveOld()
    }

    override fun onStop() {
        super.onStop()
        Store.flush()
        WidgetUpdater.update(this)
    }
}
