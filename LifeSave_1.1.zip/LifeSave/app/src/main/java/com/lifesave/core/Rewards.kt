package com.lifesave.core

// ---------- Hilfen fürs Training (hier, weil Abzeichen sie brauchen) ----------
fun Workout.doneSets(): Int = exercises.sumOf { e -> e.sets.count { it.done } }
fun Workout.volume(): Double = exercises.sumOf { e -> e.sets.filter { it.done }.sumOf { it.weight * it.reps } }
fun AppState.totalVolume(): Double = workouts.sumOf { it.volume() }

// ---------- XP, Level, Streak ----------
data class LevelInfo(val level: Int, val into: Int, val needed: Int)

object Rewards {
    /** Gesamt-XP, um Level n zu erreichen: 0, 100, 300, 600, 1000 ... */
    private fun xpFor(n: Int) = 50 * (n - 1) * n

    fun levelInfo(xp: Int): LevelInfo {
        var n = 1
        while (xpFor(n + 1) <= xp) n++
        return LevelInfo(n, xp - xpFor(n), xpFor(n + 1) - xpFor(n))
    }

    fun totalXp(s: AppState = Store.state) = s.history.sumOf { it.xp }
    fun xpToday(s: AppState = Store.state): Int { val t = startOfDay(now()); return s.history.filter { it.at >= t }.sumOf { it.xp } }

    fun dayChain(days: Set<Long>, from: Long): Int {
        var d = from; var n = 0
        while (d in days) { n++; d = startOfDay(addDays(d, -1)) }
        return n
    }

    /** Tage in Folge, an denen irgendetwas erledigt wurde */
    fun streak(s: AppState = Store.state): Int {
        val days = s.history.map { startOfDay(it.at) }.toSet()
        val t = startOfDay(now())
        return if (t in days) dayChain(days, t) else dayChain(days, startOfDay(addDays(t, -1)))
    }

    fun addXp(refId: Long, title: String, kind: String, xp: Int, at: Long = now()) {
        val before = levelInfo(totalXp()).level
        Store.update { it.copy(history = it.history + XpEntry(refId, title, kind, xp, at)) }
        val after = levelInfo(totalXp()).level
        if (after > before) Store.celebrate(Celebration("Level $after!", listOf("Du bist aufgestiegen. Weiter so!"), "⭐"))
        checkBadges()
    }

    fun removeXp(pred: (XpEntry) -> Boolean) = Store.update { s ->
        val e = s.history.lastOrNull(pred) ?: return@update s
        s.copy(history = s.history - e)
    }

    // ---------- Abzeichen ----------
    data class Badge(val id: String, val emoji: String, val title: String, val desc: String, val check: (AppState) -> Boolean)

    val BADGES: List<Badge> = buildList {
        listOf(1 to "Erstes Workout", 10 to "Dranbleiber", 25 to "Stammgast", 50 to "Eisern", 100 to "Hundert", 250 to "Legende").forEach { (n, t) ->
            add(Badge("workouts_$n", "🏋", t, "$n Workouts abgeschlossen") { it.workouts.size >= n })
        }
        listOf(1 to "1 Tonne", 10 to "10 Tonnen", 50 to "50 Tonnen", 100 to "100 Tonnen", 500 to "500 Tonnen", 1000 to "1000 Tonnen").forEach { (n, t) ->
            add(Badge("volume_$n", "🪨", t, "Insgesamt ${n * 1000} kg bewegt") { it.totalVolume() >= n * 1000.0 })
        }
        listOf(3, 7, 14, 30, 100).forEach { n ->
            add(Badge("streak_$n", "🔥", "$n-Tage-Streak", "$n Tage in Folge etwas erledigt") { streak(it) >= n })
        }
        listOf(1 to "Erster Rekord", 10 to "Rekordjäger", 50 to "Rekordmaschine").forEach { (n, t) ->
            add(Badge("pr_$n", "📈", t, "$n persönliche Rekorde") { it.records.size >= n })
        }
        listOf(4 to "Waage-Freund", 12 to "Gewichts-Profi", 52 to "Ein Jahr gewogen").forEach { (n, t) ->
            add(Badge("weigh_$n", "⚖", t, "$n-mal gewogen") { it.weights.size >= n })
        }
        listOf(10, 100, 500).forEach { n ->
            add(Badge("tasks_$n", "✅", "$n Aufgaben", "$n Aufgaben erledigt") { s -> s.history.count { it.kind == "task" } >= n })
        }
        listOf(7, 30).forEach { n ->
            add(Badge("habit_$n", "🌱", "Gewohnheit $n", "Eine Gewohnheit $n-mal in Folge geschafft") { s -> s.habits.any { Habits.streak(it) >= n } })
        }
        add(Badge("cardio_10", "🏃", "Ausdauernd", "10 Cardio-Einheiten") { it.cardio.size >= 10 })
        add(Badge("cardio_100km", "🛣", "100 Kilometer", "100 km Cardio insgesamt") { s -> s.cardio.sumOf { it.km } >= 100.0 })
        add(Badge("photo_1", "📸", "Erstes Foto", "Erstes Fortschrittsfoto") { it.photos.isNotEmpty() })
        add(Badge("photo_10", "🖼", "Fotoalbum", "10 Fortschrittsfotos") { it.photos.size >= 10 })
        add(Badge("early", "🌅", "Frühaufsteher", "Workout vor 7 Uhr gestartet") { s -> s.workouts.any { hourOf(it.start) < 7 } })
        add(Badge("late", "🌙", "Nachteule", "Workout nach 21 Uhr gestartet") { s -> s.workouts.any { hourOf(it.start) >= 21 } })
        listOf(5, 10, 25).forEach { n ->
            add(Badge("level_$n", "⭐", "Level $n", "Level $n erreicht") { levelInfo(totalXp(it)).level >= n })
        }
    }

    private fun hourOf(t: Long) = java.util.Calendar.getInstance().apply { timeInMillis = t }.get(java.util.Calendar.HOUR_OF_DAY)

    fun checkBadges() {
        val s = Store.state
        val fresh = BADGES.filter { it.id !in s.badges && it.check(s) }
        if (fresh.isEmpty()) return
        val t = now()
        Store.update { st -> st.copy(badges = st.badges + fresh.associate { it.id to t }) }
        fresh.forEach { Store.celebrate(Celebration("Abzeichen: ${it.title}", listOf(it.desc), it.emoji)) }
    }
}
