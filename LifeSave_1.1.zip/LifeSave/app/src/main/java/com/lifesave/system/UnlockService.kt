package com.lifesave.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.lifesave.MainActivity
import com.lifesave.core.*
import com.lifesave.training.ExerciseDb
import com.lifesave.training.Training
import com.lifesave.widget.WidgetUpdater

fun openApp(c: Context) {
    c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
}

/** Ist gerade etwas offen, für das sich das automatische Öffnen lohnt? */
fun somethingOpen(s: AppState = Store.state): Boolean =
    s.active != null || Training.dueToday(s) != null || Tasks.dueToday(s).isNotEmpty() ||
        s.habits.any { Habits.dueToday(it) && !Habits.doneToday(it) }

/**
 * Hintergrunddienst: öffnet die App nach dem Entsperren, erinnert an fällige Aufgaben,
 * meldet das Ende der Satzpause und hält das Widget aktuell.
 */
class UnlockService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_USER_PRESENT) return
            val lock = Locks.pending() != null
            if (lock || Locks.shouldOpen(Store.state, somethingOpen())) {
                Locks.markShown()
                openApp(c)
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            runCatching { onTick() }
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        ExerciseDb.init(this)
        WidgetUpdater.attach(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("service", "Hintergrunddienst", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("due", "Erinnerungen", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("rest", "Satzpause", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "service")
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setContentTitle("$APP_NAME ist aktiv")
            .setContentText("Öffnet sich nach dem Entsperren")
            .setContentIntent(openIntent())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        registerReceiver(receiver, IntentFilter(Intent.ACTION_USER_PRESENT))
        handler.post(tick)
    }

    private fun openIntent() = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun onTick() {
        ticks++
        checkRest()
        if (ticks % 12 == 0) checkDue()          // jede Minute
        if (ticks % 180 == 0) WidgetUpdater.update(this) // alle 15 Minuten
    }

    private fun checkRest() {
        val r = Store.state.restUntil
        if (r == 0L || r == Store.restAlerted || now() < r) return
        Store.restAlerted = r
        val v = getSystemService(Vibrator::class.java)
        runCatching { v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)) }
        getSystemService(NotificationManager::class.java).notify(2, Notification.Builder(this, "rest")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Pause vorbei")
            .setContentText("Weiter mit dem nächsten Satz 💪")
            .setContentIntent(openIntent()).setAutoCancel(true).setTimeoutAfter(60_000).build())
    }

    private fun checkDue() {
        val n = now()
        val due = Store.state.tasks.filter { it.doneAt == null && !it.archived && !it.notified && it.due != null && it.due <= n }
        if (due.isEmpty()) return
        val nm = getSystemService(NotificationManager::class.java)
        due.forEach { t ->
            nm.notify((t.id % Int.MAX_VALUE).toInt(), Notification.Builder(this, "due")
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Fällig: ${t.title}")
                .setContentText(t.note.ifBlank { "Jetzt erledigen" })
                .setContentIntent(openIntent()).setAutoCancel(true).build())
        }
        val ids = due.map { it.id }.toSet()
        Store.update { s -> s.copy(tasks = s.tasks.map { if (it.id in ids) it.copy(notified = true) else it }) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        runCatching { unregisterReceiver(receiver) }
        handler.removeCallbacks(tick)
        Store.flush()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) runCatching { c.startForegroundService(Intent(c, UnlockService::class.java)) }
    }
}
