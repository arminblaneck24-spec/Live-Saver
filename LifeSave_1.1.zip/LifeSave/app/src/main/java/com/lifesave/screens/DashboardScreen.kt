package com.lifesave.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.lifesave.core.*
import com.lifesave.system.guardOn
import com.lifesave.training.*
import com.lifesave.ui.*

@Composable
fun DashboardScreen() {
    val st = Store.state
    val tiles = st.settings.tiles.filter { it.visible }
    Screen {
        item {
            Column {
                Muted(fmtDay(now()))
                Title(greeting())
            }
        }
        item { SetupPanel() }
        items(tiles, key = { it.id }) { t ->
            when (t.id) {
                "hero" -> HeroTile(st)
                "training" -> TrainingTile(st)
                "body" -> BodyTile(st)
                "tasks" -> TasksTile(st)
                "habits" -> HabitsTile(st)
                "weight" -> WeightTile(st)
                "records" -> RecordsTile(st)
            }
        }
        item {
            Btn("Startseite anpassen", Modifier.fillMaxWidth(), BtnKind.GHOST) { Nav.go("settings_x", "dashboard") }
        }
    }
}

private fun greeting(): String = when (hourNow()) {
    in 5..10 -> "Guten Morgen"
    in 11..17 -> "Hallo"
    in 18..22 -> "Guten Abend"
    else -> "Gute Nacht"
}

@Composable
fun HeroTile(st: AppState) {
    val p = pal
    val xp = Rewards.totalXp(st)
    val li = Rewards.levelInfo(xp)
    Panel(accent = p.gold) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Muted("LEVEL")
                BigNumber("${li.level}", p.primary)
            }
            Column(Modifier.weight(1f)) {
                Muted("STREAK")
                BigNumber("🔥 ${Rewards.streak(st)}", p.secondary)
            }
            Column(Modifier.weight(1f)) {
                Muted("HEUTE")
                BigNumber("+${Rewards.xpToday(st)}", p.good)
            }
        }
        Spacer(Modifier.height(8.dp))
        Bar(li.into / li.needed.coerceAtLeast(1).toFloat(), p.gold)
        Muted("${li.into}/${li.needed} XP bis Level ${li.level + 1}", Modifier.padding(top = 4.dp))
    }
}

@Composable
fun TrainingTile(st: AppState) {
    val p = pal
    val active = st.active
    val next = Training.nextSession(st)
    val trained = Training.trainedToday(st)
    Panel(accent = if (next?.today == true && !trained) p.secondary else p.primary) {
        Heading("Training")
        when {
            active != null -> {
                Body("${active.name} läuft gerade", bold = true)
                Muted("${active.exercises.size} Übungen · ${active.doneSets()} Sätze erledigt")
                Spacer(Modifier.height(8.dp))
                Btn("Fortsetzen", Modifier.fillMaxWidth()) { Nav.go("workout") }
            }
            next == null -> {
                Body("Noch kein Trainingsplan")
                Muted("Lege einen Plan an oder starte ein freies Training.")
                Spacer(Modifier.height(8.dp))
                Row {
                    Btn("Plan anlegen", Modifier.weight(1f)) { Nav.root("training") }
                    Spacer(Modifier.width(8.dp))
                    Btn("Frei starten", Modifier.weight(1f), BtnKind.SECONDARY) { Training.start(null, null); Nav.go("workout") }
                }
            }
            else -> {
                val whenTxt = when {
                    trained && next.today -> "Heute schon trainiert ✓"
                    next.today -> "HEUTE"
                    next.date != null -> (WEEKDAY_LONG[dow(next.date)] ?: "") + ", " + fmtShort(next.date)
                    else -> "Als Nächstes (${next.plan.name})"
                }
                Pill(whenTxt, if (next.today && !trained) p.secondary else p.primary)
                Spacer(Modifier.height(6.dp))
                Title(next.day.name, size = 24.sp)
                Muted(next.day.exercises.take(4).joinToString(" · ") { ExerciseDb.name(it.exId) } + if (next.day.exercises.size > 4) " …" else "", maxLines = 2)
                Spacer(Modifier.height(8.dp))
                Btn(if (next.today && !trained) "Jetzt starten" else "Starten", Modifier.fillMaxWidth(),
                    if (next.today && !trained) BtnKind.DANGER else BtnKind.PRIMARY) {
                    Training.start(next.plan, next.day); Nav.go("workout")
                }
            }
        }
    }
}

@Composable
fun BodyTile(st: AppState) {
    val p = pal
    val mode = st.settings.mannequinMode
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Heading("Muskeln", Modifier.weight(1f))
            Pick("Zuletzt", mode == 0) { Store.setSettings { it.copy(mannequinMode = 0) } }
            Pick("Woche", mode == 1) { Store.setSettings { it.copy(mannequinMode = 1) } }
        }
        Mannequin(Training.intensity(mode, st))
        Muted(if (mode == 0) "Kräftig = frisch trainiert, verblasst über 7 Tage" else "Trainierte Sätze der letzten 7 Tage je Muskel")
    }
}

@Composable
fun TasksTile(st: AppState) {
    val p = pal
    val open = Tasks.dueToday(st)
    Panel(onClick = { Nav.root("tasks") }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Heading("Aufgaben heute", Modifier.weight(1f))
            Pill("${open.size} offen", if (open.isEmpty()) p.good else p.primary)
        }
        if (open.isEmpty()) Empty("Alles erledigt 🎉")
        open.take(5).forEach { t ->
            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Check(false, prioColor(t.priority)) { Tasks.complete(t) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Body(t.title, maxLines = 1)
                    t.due?.let { Muted(fmtDateTime(it), color = if (it < now()) p.secondary else p.inkSoft) }
                }
                Muted("+${t.xp}")
            }
        }
        if (open.size > 5) Muted("… und ${open.size - 5} weitere")
    }
}

@Composable
fun prioColor(prio: Int) = when (prio) { 3 -> pal.secondary; 2 -> pal.primary; else -> pal.inkSoft }

@Composable
fun HabitsTile(st: AppState) {
    val due = st.habits.filter { Habits.dueToday(it) }
    Panel(onClick = { Nav.root("habits") }) {
        Heading("Gewohnheiten heute")
        if (due.isEmpty()) Empty(if (st.habits.isEmpty()) "Noch keine Gewohnheiten angelegt" else "Heute nichts geplant")
        due.forEach { h -> HabitLine(h) }
    }
}

@Composable
fun HabitLine(h: Habit) {
    val p = pal
    val pr = Habits.progress(h)
    val done = Habits.doneToday(h)
    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Body(h.title, bold = true, color = if (done) p.inkSoft else p.ink)
            Muted("🔥 ${Habits.streak(h)} · ${Habits.modeText(h)}" + if (h.target > 1) " · $pr/${h.target} ${h.unit}" else "")
        }
        if (h.target <= 1) Check(done, p.good) { Habits.step(h.id, if (done) -1 else 1) }
        else Stepper("$pr/${h.target}", { Habits.step(h.id, -1) }, { Habits.step(h.id, 1) })
    }
}

@Composable
fun WeightTile(st: AppState) {
    val p = pal
    val l = BodyLog.latest(st)
    Panel(onClick = { Nav.root("body") }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Heading("Gewicht", Modifier.weight(1f))
            val due = Locks.weighDueAt(st)
            Muted("Wiegen: ${WEEKDAY_LONG[st.settings.weighDay]} ${st.settings.weighHour} Uhr")
        }
        if (l == null) Empty("Noch kein Gewicht eingetragen")
        else {
            Row(verticalAlignment = Alignment.Bottom) {
                BigNumber("${fmtKg(l.kg)} kg")
                Spacer(Modifier.width(10.dp))
                BodyLog.change(28, st)?.let { ch ->
                    Muted((if (ch >= 0) "+" else "") + fmtKg(Math.round(ch * 10) / 10.0) + " kg in 4 Wochen", Modifier.padding(bottom = 6.dp))
                }
            }
            LineChart(BodyLog.sorted(st).takeLast(20).map { it.at to it.kg }, height = 110.dp, unit = "")
        }
    }
}

@Composable
fun RecordsTile(st: AppState) {
    val p = pal
    Panel(onClick = { Nav.root("stats") }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Heading("Rekorde & Abzeichen", Modifier.weight(1f))
            Pill("🏅 ${st.badges.size}/${Rewards.BADGES.size}", p.gold)
        }
        val recent = st.records.sortedByDescending { it.at }.take(3)
        if (recent.isEmpty()) Empty("Rekorde erscheinen automatisch, sobald du dich steigerst.")
        recent.forEach { r ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text2("🏆", Modifier.width(26.dp))
                Column(Modifier.weight(1f)) {
                    Body(ExerciseDb.name(r.exId), bold = true, maxLines = 1)
                    Muted(Training.recordText(r) + " · " + ago(r.at))
                }
            }
        }
    }
}

@Composable
fun Text2(t: String, modifier: Modifier = Modifier) = androidx.compose.material3.Text(t, modifier, fontSize = 18.sp)

// ---------- Einrichtung (Berechtigungen) ----------
data class SetupState(val overlay: Boolean, val notif: Boolean, val battery: Boolean, val guard: Boolean) {
    val allOk get() = overlay && notif && battery && guard
}

fun setupState(ctx: Context) = SetupState(
    AndroidSettings.canDrawOverlays(ctx),
    Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED,
    (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName),
    guardOn(ctx)
)

@Composable
fun SetupPanel(always: Boolean = false) {
    val ctx = LocalContext.current
    val p = pal
    var refresh by remember { mutableIntStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    // bei Rückkehr aus den Systemeinstellungen neu prüfen
    val st = remember(refresh, Store.state) { setupState(ctx) }
    if (st.allOk && !always) return
    Panel(accent = p.secondary) {
        Heading("Einrichtung")
        Muted("Damit Life Save sich nach dem Entsperren öffnet und die Sperren funktionieren. Reihenfolge einhalten – den Wächter zuletzt.")
        Spacer(Modifier.height(8.dp))
        SetupStep("1. Über anderen Apps einblenden", st.overlay) {
            ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
        }
        SetupStep("2. Benachrichtigungen", st.notif) {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        SetupStep("3. Akku-Optimierung aus", st.battery) {
            ctx.startActivity(Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        }
        SetupStep("4. Wächter (Bedienungshilfe) an", st.guard) { ctx.startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
        if (!st.guard) {
            Muted("Unter »Installierte Apps« → »Life Save Wächter« einschalten. Ist der Schalter ausgegraut: App-Info → ⋮ oben rechts → »Eingeschränkte Einstellungen zulassen«.")
            Btn("App-Info öffnen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.GHOST, small = true) {
                ctx.startActivity(Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }
        }
        Btn("Neu prüfen", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY, small = true) { refresh++ }
    }
}

@Composable
private fun SetupStep(label: String, ok: Boolean, onClick: () -> Unit) {
    val p = pal
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Body(label, Modifier.weight(1f), color = if (ok) p.inkSoft else p.ink)
        if (ok) Pill("✓ erledigt", p.good) else Btn("Öffnen", small = true) { onClick() }
    }
}
