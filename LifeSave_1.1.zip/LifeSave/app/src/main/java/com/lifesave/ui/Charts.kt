package com.lifesave.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lifesave.core.fmtKg
import com.lifesave.core.fmtShort

private fun label(c: android.graphics.Canvas, t: String, x: Float, y: Float, color: Int, size: Float, align: android.graphics.Paint.Align) {
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = color; textSize = size; textAlign = align }
    c.drawText(t, x, y, p)
}

/** Liniendiagramm über die Zeit (z. B. Gewicht, Maximalgewicht einer Übung) */
@Composable
fun LineChart(points: List<Pair<Long, Double>>, modifier: Modifier = Modifier, color: Color = pal.primary, height: Dp = 170.dp, unit: String = "") {
    val p = pal
    if (points.size < 2) {
        Muted(if (points.isEmpty()) "Noch keine Daten" else "Ab zwei Einträgen erscheint hier ein Verlauf", modifier.padding(vertical = 8.dp))
        return
    }
    val sorted = points.sortedBy { it.first }
    Canvas(modifier.fillMaxWidth().height(height)) {
        val padL = 40.dp.toPx(); val padB = 20.dp.toPx(); val padT = 10.dp.toPx(); val padR = 8.dp.toPx()
        val w = size.width - padL - padR; val h = size.height - padB - padT
        val minV = sorted.minOf { it.second }; val maxV = sorted.maxOf { it.second }
        val span = (maxV - minV).let { if (it < 0.001) 1.0 else it }
        val lo = minV - span * 0.1; val hi = maxV + span * 0.1
        val t0 = sorted.first().first; val t1 = sorted.last().first
        val tSpan = (t1 - t0).coerceAtLeast(1L).toFloat()
        fun x(t: Long) = padL + (t - t0) / tSpan * w
        fun y(v: Double) = padT + (1f - ((v - lo) / (hi - lo)).toFloat()) * h
        val txt = p.inkSoft.toArgb(); val ts = 10.dp.toPx()
        // Gitter
        for (i in 0..3) {
            val v = lo + (hi - lo) * i / 3
            val yy = y(v)
            drawLine(p.line, Offset(padL, yy), Offset(size.width - padR, yy), 1.dp.toPx())
            drawIntoCanvas { label(it.nativeCanvas, fmtKg(Math.round(v * 10) / 10.0) + unit, padL - 4.dp.toPx(), yy + ts / 3, txt, ts, android.graphics.Paint.Align.RIGHT) }
        }
        drawIntoCanvas {
            label(it.nativeCanvas, fmtShort(t0), padL, size.height - 4.dp.toPx(), txt, ts, android.graphics.Paint.Align.LEFT)
            label(it.nativeCanvas, fmtShort(t1), size.width - padR, size.height - 4.dp.toPx(), txt, ts, android.graphics.Paint.Align.RIGHT)
        }
        // Fläche + Linie
        val path = Path(); val area = Path()
        sorted.forEachIndexed { i, (t, v) ->
            if (i == 0) { path.moveTo(x(t), y(v)); area.moveTo(x(t), padT + h); area.lineTo(x(t), y(v)) }
            else { path.lineTo(x(t), y(v)); area.lineTo(x(t), y(v)) }
        }
        area.lineTo(x(t1), padT + h); area.close()
        drawPath(area, color.copy(alpha = 0.12f))
        drawPath(path, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))
        sorted.forEach { (t, v) -> drawCircle(color, 3.5.dp.toPx(), Offset(x(t), y(v))) }
    }
}

/** Säulendiagramm mit Beschriftung */
@Composable
fun BarChart(values: List<Double>, labels: List<String>, modifier: Modifier = Modifier, color: Color = pal.primary, height: Dp = 150.dp, highlightLast: Boolean = true) {
    val p = pal
    val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(0.0001)
    Canvas(modifier.fillMaxWidth().height(height)) {
        val padB = 18.dp.toPx(); val padT = 14.dp.toPx()
        val n = values.size.coerceAtLeast(1)
        val slot = size.width / n
        val bw = slot * 0.6f
        val h = size.height - padB - padT
        val txt = p.inkSoft.toArgb(); val ts = 10.dp.toPx()
        values.forEachIndexed { i, v ->
            val bh = (v / max).toFloat() * h
            val x = i * slot + (slot - bw) / 2
            val c = if (highlightLast && i == values.size - 1) color else color.copy(alpha = 0.55f)
            drawRoundRect(p.line, Offset(x, padT), Size(bw, h), CornerRadius(4.dp.toPx()))
            if (bh > 0) drawRoundRect(c, Offset(x, padT + h - bh), Size(bw, bh), CornerRadius(4.dp.toPx()))
            drawIntoCanvas {
                label(it.nativeCanvas, labels.getOrElse(i) { "" }, x + bw / 2, size.height - 4.dp.toPx(), txt, ts, android.graphics.Paint.Align.CENTER)
                if (v > 0) label(it.nativeCanvas, compact(v), x + bw / 2, padT + h - bh - 3.dp.toPx(), txt, ts, android.graphics.Paint.Align.CENTER)
            }
        }
    }
}

private fun compact(v: Double): String = when {
    v >= 1000 -> String.format(java.util.Locale.GERMAN, "%.1fk", v / 1000)
    v == Math.floor(v) -> v.toLong().toString()
    else -> String.format(java.util.Locale.GERMAN, "%.1f", v)
}
