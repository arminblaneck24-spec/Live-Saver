package com.lifesave.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.lifesave.core.*
import com.lifesave.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------- Kamera & Galerie ----------
@Composable
fun rememberPhotoCapture(onDone: () -> Unit = {}): () -> Unit {
    val ctx = LocalContext.current
    var pending by rememberSaveable { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = if (pending.isNotBlank()) File(pending) else null
        pending = ""
        if (ok && f != null) { BodyLog.addPhoto(f); onDone() } else f?.delete()
    }
    return {
        val f = BodyLog.newPhotoFile()
        pending = f.path
        runCatching { launcher.launch(FileProvider.getUriForFile(ctx, "com.lifesave.files", f)) }
    }
}

@Composable
fun rememberGalleryPick(onDone: () -> Unit = {}): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)?.let { BodyLog.importPhoto(it) }; onDone() }
    }
    return { launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
}

// ================= Körper =================
@Composable
fun BodyScreen() {
    val st = Store.state
    val p = pal
    var kg by remember { mutableStateOf("") }
    var range by remember { mutableIntStateOf(1) }
    val capture = rememberPhotoCapture()
    val gallery = rememberGalleryPick()
    val sorted = BodyLog.sorted(st)
    val from = when (range) { 0 -> addDays(now(), -30); 1 -> addDays(now(), -90); 2 -> addDays(now(), -365); else -> 0L }
    Screen {
        item {
            Panel(accent = p.primary) {
                Heading("Gewicht")
                val l = BodyLog.latest(st)
                Row(verticalAlignment = Alignment.Bottom) {
                    BigNumber(l?.let { fmtKg(it.kg) + " kg" } ?: "–")
                    Spacer(Modifier.width(10.dp))
                    BodyLog.change(28, st)?.let { ch ->
                        Muted((if (ch >= 0) "+" else "") + fmtKg(Math.round(ch * 10) / 10.0) + " kg in 4 Wochen", Modifier.padding(bottom = 6.dp))
                    }
                }
                l?.let { Muted("zuletzt ${fmtDate(it.at)}") }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(kg, { kg = it }, "Gewicht (kg)", Modifier.weight(1f), decimal = true)
                    Spacer(Modifier.width(8.dp))
                    Btn("Eintragen", enabled = (parseNum(kg) ?: 0.0) in 20.0..400.0) { BodyLog.addWeight(parseNum(kg)!!); kg = "" }
                }
                Muted("Automatische Abfrage: ${WEEKDAY_LONG[st.settings.weighDay]} ab ${st.settings.weighHour} Uhr", Modifier.padding(top = 4.dp))
            }
        }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Heading("Verlauf", Modifier.weight(1f))
                    listOf("30 T", "90 T", "1 J", "Alles").forEachIndexed { i, l -> Pick(l, range == i) { range = i } }
                }
                LineChart(sorted.filter { it.at >= from }.map { it.at to it.kg }, unit = "")
            }
        }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Heading("Fortschrittsfotos", Modifier.weight(1f))
                    Muted("${st.photos.size} Fotos")
                }
                Muted("Fotos bleiben privat in der App und landen nicht in deiner Galerie.")
                Spacer(Modifier.height(8.dp))
                val recent = st.photos.sortedByDescending { it.at }.take(4)
                if (recent.isNotEmpty()) Row {
                    recent.forEach { ph ->
                        PhotoImage(BodyLog.fileOf(ph), Modifier.weight(1f).aspectRatio(0.75f).padding(end = 4.dp).clip(RoundedCornerShape(8.dp))
                            .clickable { Nav.go("photo", ph.id.toString()) }, maxSide = 300)
                    }
                    repeat(4 - recent.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(8.dp))
                Row {
                    Btn("📷 Foto", Modifier.weight(1f), small = true) { capture() }
                    Spacer(Modifier.width(6.dp))
                    Btn("Galerie", Modifier.weight(1f), BtnKind.SECONDARY, small = true) { gallery() }
                    Spacer(Modifier.width(6.dp))
                    Btn("Alle", Modifier.weight(1f), BtnKind.GHOST, small = true) { Nav.go("photos") }
                }
                if (st.photos.size >= 2) Btn("Vorher / Nachher vergleichen", Modifier.fillMaxWidth().padding(top = 8.dp), BtnKind.GOLD, small = true) { Nav.go("compare") }
            }
        }
        item { Heading("Einträge") }
        items(sorted.reversed().take(60), key = { it.id }) { w ->
            var del by remember { mutableStateOf(false) }
            if (del) ConfirmDialog("Eintrag löschen?", "${fmtKg(w.kg)} kg vom ${fmtDate(w.at)}", "Löschen", { del = false }) { BodyLog.deleteWeight(w.id) }
            Panel(padding = 10.dp, onClick = { del = true }) {
                Row {
                    Body(fmtDate(w.at), Modifier.weight(1f))
                    Body("${fmtKg(w.kg)} kg", bold = true)
                }
            }
        }
    }
}

// ================= Fotos =================
@Composable
fun PhotosScreen() {
    val st = Store.state
    val capture = rememberPhotoCapture()
    val gallery = rememberGalleryPick()
    val photos = st.photos.sortedByDescending { it.at }
    Screen {
        item {
            Row {
                Btn("📷 Foto aufnehmen", Modifier.weight(1f)) { capture() }
                Spacer(Modifier.width(8.dp))
                Btn("Aus Galerie", Modifier.weight(1f), BtnKind.SECONDARY) { gallery() }
            }
        }
        if (photos.size >= 2) item { Btn("Vorher / Nachher vergleichen", Modifier.fillMaxWidth(), BtnKind.GOLD) { Nav.go("compare") } }
        if (photos.isEmpty()) item { Empty("Noch keine Fotos") }
        // Zeitleiste: je Monat eine Reihe
        val byMonth = photos.groupBy { java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.GERMAN).format(java.util.Date(it.at)) }
        byMonth.forEach { (month, list) ->
            item { Heading(month) }
            items(list.chunked(3)) { row ->
                Row {
                    row.forEach { ph ->
                        Column(Modifier.weight(1f).padding(end = 4.dp)) {
                            PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(8.dp))
                                .clickable { Nav.go("photo", ph.id.toString()) }, maxSide = 360)
                            Muted(fmtShort(ph.at), size = 11.sp)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}


@Composable
fun PhotoView(id: Long) {
    val st = Store.state
    val ph = st.photos.find { it.id == id } ?: run { Empty("Foto nicht gefunden"); return }
    var del by remember { mutableStateOf(false) }
    val w = st.weights.minByOrNull { kotlin.math.abs(it.at - ph.at) }?.takeIf { kotlin.math.abs(it.at - ph.at) < 3 * 86_400_000L }
    if (del) ConfirmDialog("Foto löschen?", "Das Foto wird endgültig gelöscht.", "Löschen", { del = false }) { BodyLog.deletePhoto(ph); Nav.back() }
    Screen {
        item { PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(10.dp)), maxSide = 1400, crop = false) }
        item {
            Panel {
                Body(fmtDay(ph.at), bold = true)
                w?.let { Muted("Gewicht um diese Zeit: ${fmtKg(it.kg)} kg") }
            }
        }
        item { Btn("Foto löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { del = true } }
    }
}

// ================= Vorher / Nachher =================
@Composable
fun CompareScreen() {
    val st = Store.state
    val p = pal
    val photos = st.photos.sortedBy { it.at }
    if (photos.size < 2) { Screen { item { Empty("Für einen Vergleich brauchst du mindestens zwei Fotos.") } }; return }
    var a by remember { mutableStateOf(photos.first().id) }
    var b by remember { mutableStateOf(photos.last().id) }
    var frac by remember { mutableFloatStateOf(0.5f) }
    val pa = photos.find { it.id == a } ?: photos.first()
    val pb = photos.find { it.id == b } ?: photos.last()
    val ia = rememberPhotoBitmap(BodyLog.fileOf(pa))
    val ib = rememberPhotoBitmap(BodyLog.fileOf(pb))
    Screen {
        item {
            Panel(padding = 8.dp) {
                Canvas(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(8.dp))) {
                    ia?.let { drawCover(it) }
                    clipRect(left = size.width * frac) { ib?.let { drawCover(it) } }
                    drawLine(androidx.compose.ui.graphics.Color.White, androidx.compose.ui.geometry.Offset(size.width * frac, 0f),
                        androidx.compose.ui.geometry.Offset(size.width * frac, size.height), 3.dp.toPx())
                }
                Slider(frac, { frac = it })
                Row {
                    Muted("Vorher: ${fmtDate(pa.at)}", Modifier.weight(1f))
                    Muted("Nachher: ${fmtDate(pb.at)}")
                }
                val wa = st.weights.minByOrNull { kotlin.math.abs(it.at - pa.at) }
                val wb = st.weights.minByOrNull { kotlin.math.abs(it.at - pb.at) }
                if (wa != null && wb != null && wa.id != wb.id) {
                    val d = wb.kg - wa.kg
                    Muted("Gewicht: ${fmtKg(wa.kg)} → ${fmtKg(wb.kg)} kg (" + (if (d >= 0) "+" else "") + fmtKg(Math.round(d * 10) / 10.0) + " kg)")
                }
                Muted("${daysBetween(pa.at, pb.at)} Tage dazwischen")
            }
        }
        item { Heading("Vorher wählen") }
        item { PhotoStrip(photos, a) { a = it } }
        item { Heading("Nachher wählen") }
        item { PhotoStrip(photos, b) { b = it } }
    }
}

@Composable
private fun PhotoStrip(photos: List<PhotoEntry>, sel: Long, onPick: (Long) -> Unit) {
    val p = pal
    LazyRow {
        items(photos, key = { it.id }) { ph ->
            Column(Modifier.padding(end = 6.dp).width(76.dp).clickable { onPick(ph.id) }) {
                PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(8.dp)), maxSide = 200)
                if (ph.id == sel) Bar(1f, p.primary, height = 4.dp) else Spacer(Modifier.height(4.dp))
                Muted(fmtShort(ph.at), size = 11.sp)
            }
        }
    }
}

@Composable
private fun rememberPhotoBitmap(f: File): ImageBitmap? {
    var img by remember(f.path) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(f.path) { img = withContext(Dispatchers.IO) { Images.file(f, 1200)?.asImageBitmap() } }
    return img
}

/** Bild so zeichnen, dass es die Fläche füllt (zugeschnitten) */
private fun DrawScope.drawCover(img: ImageBitmap) {
    val sw = img.width.toFloat(); val sh = img.height.toFloat()
    val scale = maxOf(size.width / sw, size.height / sh)
    val cw = (size.width / scale); val ch = (size.height / scale)
    val sx = ((sw - cw) / 2).toInt().coerceAtLeast(0); val sy = ((sh - ch) / 2).toInt().coerceAtLeast(0)
    drawImage(img, IntOffset(sx, sy), IntSize(cw.toInt().coerceAtMost(img.width), ch.toInt().coerceAtMost(img.height)),
        IntOffset.Zero, IntSize(size.width.toInt(), size.height.toInt()))
}
