package com.lifesave.ui

import android.content.Context
import android.content.Intent
import android.graphics.*
import androidx.core.content.FileProvider
import java.io.File

/** Eine Karte im Story-Format (9:16) – für den Jahresrückblick und zum Teilen */
data class ShareCard(
    val emoji: String,
    val kicker: String,          // kleine Überschrift
    val big: String,             // große Zahl / Aussage
    val sub: String = "",
    val lines: List<String> = emptyList(),
    val bars: List<Int>? = null,
    val barLabels: List<String> = emptyList(),
    val muscles: Map<String, Float>? = null,
    val photos: Pair<File, File>? = null,
    val accent: Int = Color.parseColor("#C9A227")
)

object ShareCards {
    /** Zeichnet die Karte. Basisgröße 1080 × 1920, [scale] verkleinert für die Vorschau. */
    fun render(c: ShareCard, footer: String, bgTop: Int, bgBottom: Int, scale: Float = 1f): Bitmap {
        val w = (1080 * scale).toInt(); val h = (1920 * scale).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(scale, scale)
        val W = 1080f; val H = 1920f
        cv.drawRect(0f, 0f, W, H, Paint().apply { shader = LinearGradient(0f, 0f, 0f, H, bgTop, bgBottom, Shader.TileMode.CLAMP) })
        // dezente Kreise im Hintergrund
        val deco = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (c.accent and 0x00FFFFFF) or (0x22 shl 24) }
        cv.drawCircle(W * 0.92f, H * 0.08f, 300f, deco); cv.drawCircle(W * 0.05f, H * 0.95f, 380f, deco)

        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        fun p(size: Float, color: Int, b: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
            Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; if (b) typeface = bold; textAlign = align }
        val white = Color.WHITE; val soft = Color.argb(190, 255, 255, 255)
        val pad = 90f
        var y = 200f
        cv.drawText("LIFE SAVE", pad, 140f, p(40f, c.accent, true))
        cv.drawText(c.emoji, pad, y + 130f, p(150f, white))
        y += 230f
        cv.drawText(c.kicker.uppercase(), pad, y, p(46f, soft, true))
        y += 40f
        // große Zahl, ggf. umbrechen
        val bigP = p(if (c.big.length > 14) 110f else 160f, white, true)
        wrap(c.big, bigP, W - 2 * pad).forEach { line -> y += bigP.textSize * 1.05f; cv.drawText(line, pad, y, bigP) }
        if (c.sub.isNotBlank()) {
            y += 30f
            val sp = p(52f, c.accent, true)
            wrap(c.sub, sp, W - 2 * pad).forEach { line -> y += 64f; cv.drawText(line, pad, y, sp) }
        }
        y += 50f
        val lp = p(46f, white)
        c.lines.forEach { l -> wrap(l, lp, W - 2 * pad).forEach { line -> y += 66f; cv.drawText(line, pad, y, lp) } }

        // Balken
        c.bars?.let { bars ->
            y += 60f
            val bh = 360f; val max = (bars.maxOrNull() ?: 0).coerceAtLeast(1)
            val slot = (W - 2 * pad) / bars.size; val bw = slot * 0.62f
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            val lbl = p(30f, soft, align = Paint.Align.CENTER)
            bars.forEachIndexed { i, v ->
                val x = pad + i * slot + (slot - bw) / 2
                bp.color = Color.argb(50, 255, 255, 255)
                cv.drawRoundRect(RectF(x, y, x + bw, y + bh), 14f, 14f, bp)
                val hh = bh * v / max
                bp.color = c.accent
                if (v > 0) cv.drawRoundRect(RectF(x, y + bh - hh, x + bw, y + bh), 14f, 14f, bp)
                cv.drawText(c.barLabels.getOrElse(i) { "" }, x + bw / 2, y + bh + 44f, lbl)
                if (v > 0) cv.drawText("$v", x + bw / 2, y + bh - hh - 12f, lbl)
            }
            y += bh + 70f
        }
        // Mannequin
        c.muscles?.let { m ->
            y += 30f
            val mh = (H - 200f - y).coerceAtMost(620f)
            if (mh > 250f) {
                cv.save(); cv.translate(pad, y)
                BodyMap.draw(cv, W - 2 * pad, mh, m, Color.argb(70, 255, 255, 255), Color.argb(220, 255, 255, 255), c.accent, soft)
                cv.restore(); y += mh
            }
        }
        // Vorher/Nachher-Fotos
        c.photos?.let { (a, b) ->
            y += 40f
            val ph = (H - 220f - y).coerceAtMost(760f)
            if (ph > 250f) {
                val pw = (W - 2 * pad - 30f) / 2
                listOf(a, b).forEachIndexed { i, f ->
                    val img = Images.file(f, 900) ?: return@forEachIndexed
                    val dst = RectF(pad + i * (pw + 30f), y, pad + i * (pw + 30f) + pw, y + ph)
                    val sc = maxOf(dst.width() / img.width, dst.height() / img.height)
                    val sw = dst.width() / sc; val sh = dst.height() / sc
                    val src = Rect(((img.width - sw) / 2).toInt(), ((img.height - sh) / 2).toInt(), ((img.width + sw) / 2).toInt(), ((img.height + sh) / 2).toInt())
                    cv.save()
                    cv.clipPath(Path().apply { addRoundRect(dst, 30f, 30f, Path.Direction.CW) })
                    cv.drawBitmap(img, src, dst, Paint(Paint.FILTER_BITMAP_FLAG))
                    cv.restore()
                    cv.drawText(if (i == 0) "VORHER" else "NACHHER", dst.left + 24f, dst.bottom - 28f, p(36f, white, true))
                }
                y += ph
            }
        }
        cv.drawText(footer, W / 2, H - 90f, p(38f, soft, align = Paint.Align.CENTER))
        return bmp
    }

    private fun wrap(t: String, p: Paint, maxW: Float): List<String> {
        val words = t.split(" "); val out = mutableListOf<String>(); var cur = ""
        words.forEach { w -> val n = if (cur.isEmpty()) w else "$cur $w"; if (p.measureText(n) <= maxW) cur = n else { if (cur.isNotEmpty()) out += cur; cur = w } }
        if (cur.isNotEmpty()) out += cur
        return out
    }

    /** Karten als Bilder teilen (WhatsApp, Instagram-Story, TikTok …) */
    fun share(ctx: Context, bitmaps: List<Bitmap>, text: String) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val uris = ArrayList(bitmaps.mapIndexed { i, b ->
            val f = File(dir, "lifesave_${i + 1}.png")
            f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            FileProvider.getUriForFile(ctx, "com.lifesave.files", f)
        })
        val intent = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        intent.type = "image/png"
        intent.putExtra(Intent.EXTRA_TEXT, text)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(intent, "Teilen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
