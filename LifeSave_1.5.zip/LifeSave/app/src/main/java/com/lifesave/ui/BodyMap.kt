package com.lifesave.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb

/**
 * Anatomisches Mannequin im Stil von Geräte-Schildern: weiße Figur mit Muskel-Konturen,
 * trainierte Muskeln farbig gefüllt. Hinten links, vorne rechts.
 * Gezeichnet auf einen Android-Canvas → gleiche Grafik in App, Widget und Teilen-Karten.
 * Koordinaten je Figur in einem 100 × 215-Raster; Formen der linken Körperhälfte werden gespiegelt.
 */
private typealias P = Pair<Float, Float>

object BodyMap {
    private class M(val muscle: String, val pts: List<P>, val mirror: Boolean = true)

    // ---------- Umriss (linke Hälfte, von Hals bis Schritt) ----------
    private val OUTLINE: List<P> = listOf(
        47f to 21f, 46.5f to 27f, 40f to 30.5f, 32f to 32f, 27f to 34.5f, 24f to 39f, 22.5f to 46f, 21.5f to 54f, 20.5f to 62f,
        18.5f to 71f, 16.5f to 80f, 15f to 89f, 14.5f to 97f, 13f to 103f, 13.5f to 109f, 16.5f to 111f, 19f to 107f,
        20.5f to 99f, 22.5f to 90f, 24.5f to 81f, 26.5f to 72f, 28.5f to 63f, 30.5f to 54f, 33f to 48f, 34f to 58f,
        35.5f to 70f, 36.5f to 80f, 35.5f to 90f, 34f to 98f, 32.5f to 110f, 33f to 124f, 34.5f to 138f, 36f to 151f,
        35f to 162f, 35.5f to 175f, 37.5f to 189f, 38.5f to 199f, 35.5f to 205f, 37f to 208f, 45f to 208f, 45.5f to 200f,
        45.5f to 190f, 46.5f to 176f, 47f to 162f, 47f to 151f, 47.5f to 138f, 48.5f to 124f, 50f to 113f
    )

    // ---------- Vorderseite ----------
    private val FRONT: List<M> = listOf(
        M("neck", listOf(45.5f to 22f, 45f to 28f, 48f to 31f, 49f to 24f)),
        M("traps", listOf(45.5f to 28.5f, 37f to 31.5f, 44f to 33.5f, 48f to 31.5f)),
        M("shoulders", listOf(33f to 32.5f, 27f to 34.5f, 24f to 40f, 23f to 47f, 27f to 48.5f, 31f to 42f, 34.5f to 35.5f)),
        M("chest", listOf(35.5f to 35f, 33f to 42f, 34.5f to 49f, 41f to 52.5f, 49.2f to 50f, 49.2f to 36.5f, 42f to 34f)),
        M("biceps", listOf(26.5f to 49.5f, 23.5f to 57f, 23.5f to 65f, 26f to 70f, 28.5f to 62f, 30f to 53f)),
        M("forearms", listOf(19.5f to 73f, 16.5f to 84f, 16.5f to 95f, 20f to 96f, 23f to 85f, 25.5f to 74f)),
        M("abdominals", listOf(44.6f to 54f, 44.6f to 61.5f, 49.4f to 61.5f, 49.4f to 54f)),
        M("abdominals", listOf(44.6f to 63f, 44.6f to 70.5f, 49.4f to 70.5f, 49.4f to 63f)),
        M("abdominals", listOf(44.6f to 72f, 44.6f to 79.5f, 49.4f to 79.5f, 49.4f to 72f)),
        M("abdominals", listOf(45f to 81f, 45.5f to 93f, 49.4f to 97f, 49.4f to 81f)),
        M("abdominals", listOf(37f to 55f, 36.5f to 68f, 38f to 82f, 43f to 88f, 43.2f to 62f, 40f to 54f)),
        M("abductors", listOf(35f to 92f, 33.5f to 102f, 36.5f to 108f, 38.5f to 99f)),
        M("quadriceps", listOf(34f to 104f, 33.2f to 120f, 34.8f to 140f, 38.5f to 147f, 39.5f to 126f, 37.5f to 108f)),
        M("quadriceps", listOf(39f to 104f, 38.5f to 126f, 40.5f to 146f, 44f to 146f, 45f to 124f, 42.5f to 104f)),
        M("quadriceps", listOf(43.5f to 130f, 42f to 146f, 45.5f to 150f, 47.2f to 141f, 46.5f to 129f)),
        M("adductors", listOf(44.5f to 103f, 44f to 116f, 46.5f to 127f, 49.5f to 113f)),
        M("calves", listOf(37f to 157f, 36.5f to 172f, 39.5f to 189f, 41f to 171f, 40f to 157f)),
        M("calves", listOf(44f to 158f, 44.2f to 174f, 46.2f to 170f, 46.5f to 159f))
    )

    // ---------- Rückseite ----------
    private val BACK: List<M> = listOf(
        M("neck", listOf(46f to 22f, 46f to 27.5f, 49.5f to 29f, 49.5f to 22f)),
        M("traps", listOf(49.8f to 26f, 45f to 28f, 36f to 32f, 43.5f to 37.5f, 47.5f to 48f, 49.8f to 57f)),
        M("shoulders", listOf(33f to 32.5f, 27f to 34.5f, 24f to 40f, 23.5f to 47f, 27.5f to 47f, 31.5f to 40f, 35f to 35f)),
        M("middle back", listOf(40.5f to 38f, 36.5f to 44f, 41.5f to 52f, 47f to 50f, 46.5f to 40.5f)),
        M("lats", listOf(34f to 46f, 35f to 60f, 38.5f to 76f, 45f to 81f, 44.5f to 65f, 40f to 53f)),
        M("lower back", listOf(46f to 61f, 45.5f to 80f, 47.5f to 91f, 49.6f to 91f, 49.6f to 60f)),
        M("triceps", listOf(24.5f to 48.5f, 22.5f to 57f, 23f to 67f, 26.5f to 70f, 29f to 60f, 29.5f to 50f)),
        M("forearms", listOf(19.5f to 73f, 16.5f to 84f, 16.5f to 95f, 20f to 96f, 23f to 85f, 25.5f to 74f)),
        M("abductors", listOf(35.5f to 85f, 34f to 93f, 38.5f to 95f, 41.5f to 88f)),
        M("glutes", listOf(36f to 94f, 34.5f to 104f, 39f to 112f, 47.5f to 112.5f, 49.6f to 104f, 49f to 95f, 42f to 91f)),
        M("hamstrings", listOf(34.5f to 114f, 34.6f to 132f, 37.8f to 148f, 41.6f to 148f, 41.8f to 127f, 39.8f to 114.5f)),
        M("hamstrings", listOf(42.8f to 115f, 42.8f to 132f, 44.8f to 148f, 47.8f to 147f, 48.2f to 125f, 46.5f to 114f)),
        M("calves", listOf(36f to 154f, 35.3f to 166f, 38f to 178f, 41f to 170f, 41.3f to 155f)),
        M("calves", listOf(42.2f to 155f, 42.2f to 170f, 44.2f to 180f, 46.8f to 170f, 46.4f to 156f))
    )

    // Zusätzliche Linien (Details ohne Muskelzuordnung)
    private val FRONT_LINES: List<List<P>> = listOf(listOf(49.6f to 36f, 49.6f to 98f))
    private val BACK_LINES: List<List<P>> = listOf(listOf(49.8f to 57f, 49.8f to 92f))

    private fun mx(p: P, mirror: Boolean) = if (mirror) (100f - p.first) to p.second else p

    /** geschlossene, weich gerundete Form (Catmull-Rom → Bézier) */
    private fun smooth(pts: List<P>, mirror: Boolean): Path {
        val q = pts.map { mx(it, mirror) }
        val path = Path()
        val n = q.size
        if (n < 3) return path
        path.moveTo(q[0].first, q[0].second)
        for (i in 0 until n) {
            val p0 = q[(i - 1 + n) % n]; val p1 = q[i]; val p2 = q[(i + 1) % n]; val p3 = q[(i + 2) % n]
            path.cubicTo(
                p1.first + (p2.first - p0.first) / 6f, p1.second + (p2.second - p0.second) / 6f,
                p2.first - (p3.first - p1.first) / 6f, p2.second - (p3.second - p1.second) / 6f,
                p2.first, p2.second
            )
        }
        path.close()
        return path
    }

    private fun silhouette(): Path {
        // linke Hälfte + gespiegelte rechte Hälfte zu einem Umriss verbinden
        val pts = OUTLINE + OUTLINE.reversed().map { mx(it, true) }
        return smooth(pts, false)
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(sh: Int) = (((a shr sh) and 255) + (((b shr sh) and 255) - ((a shr sh) and 255)) * k).toInt().coerceIn(0, 255)
        return (255 shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * @param intensity 0..1 je Muskel (Datenbank-Namen wie "chest")
     * @param fill Körperfläche, [line] Konturfarbe, [hot] Farbe trainierter Muskeln, [label] Beschriftung
     */
    fun draw(c: Canvas, w: Float, h: Float, intensity: Map<String, Float>, fill: Int, line: Int, hot: Int, label: Int, showLabels: Boolean = true) {
        val labelH = if (showLabels) h * 0.07f else 0f
        val figW = w / 2f
        val scale = minOf(figW / 100f, (h - labelH) / 215f)
        val stroke = (1.1f / scale.coerceAtLeast(0.01f)) * (h / 300f).coerceIn(0.7f, 1.6f)
        val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; style = Paint.Style.FILL }
        val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = line; style = Paint.Style.STROKE; strokeWidth = stroke; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
        }
        val thin = Paint(lineP).apply { strokeWidth = stroke * 0.7f; alpha = (android.graphics.Color.alpha(line) * 0.75f).toInt() }
        val hotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = label; textAlign = Paint.Align.CENTER; textSize = (h * 0.045f).coerceIn(9f, 40f); isFakeBoldText = true }
        val body = silhouette()
        listOf(Triple(BACK, BACK_LINES, "HINTEN"), Triple(FRONT, FRONT_LINES, "VORNE")).forEachIndexed { i, (muscles, lines, name) ->
            c.save()
            c.translate(i * figW + (figW - 100f * scale) / 2f, 0f)
            c.scale(scale, scale)
            // Figur
            c.drawOval(RectF(42f, 1.5f, 58f, 21.5f), fillP); c.drawOval(RectF(42f, 1.5f, 58f, 21.5f), lineP)
            c.drawPath(body, fillP)
            // Muskeln (gefüllt, wenn trainiert)
            muscles.forEach { m ->
                val v = intensity[m.muscle] ?: 0f
                listOf(false, true).forEach { mir ->
                    val path = smooth(m.pts, mir)
                    if (v > 0.01f) { hotP.color = mix(fill, hot, 0.3f + 0.7f * v); c.drawPath(path, hotP) }
                    c.drawPath(path, thin)
                }
            }
            lines.forEach { l -> val p = Path(); l.forEachIndexed { j, (x, y) -> if (j == 0) p.moveTo(x, y) else p.lineTo(x, y) }; c.drawPath(p, thin) }
            c.drawPath(body, lineP)
            c.restore()
            if (showLabels) c.drawText(name, i * figW + figW / 2f, h - labelH * 0.2f, tp)
        }
    }
}

/** Mannequin als Compose-Element */
@Composable
fun Mannequin(intensity: Map<String, Float>, modifier: Modifier = Modifier, hot: Color = Color(0xFFE07B1F)) {
    val p = pal
    val fill = (if (p.dark) Color(0xFF2A2E35) else Color.White).toArgb()
    val line = (if (p.dark) Color(0xFFB8C0CA) else Color(0xFF1E2329)).toArgb()
    androidx.compose.foundation.Canvas(modifier.fillMaxWidth().aspectRatio(1.05f)) {
        drawIntoCanvas { BodyMap.draw(it.nativeCanvas, size.width, size.height, intensity, fill, line, hot.toArgb(), p.inkSoft.toArgb()) }
    }
}
