package com.lifesave.system

import android.content.Context
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.lifesave.core.Food
import com.lifesave.core.VERSION
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Open Food Facts (kostenlos, offen): Nährwerte per Barcode oder Suche.
 * Mikronährstoffe stehen dort in Gramm pro 100 g und werden in mg/µg umgerechnet.
 */
object FoodApi {
    private const val UA = "LifeSave/$VERSION (Android; private app)"
    private const val FIELDS = "code,product_name,product_name_de,brands,nutriments,serving_quantity,serving_size"

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 10_000; c.readTimeout = 15_000
        if (c.responseCode != 200) error("Server antwortet mit ${c.responseCode}")
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }

    /** blockierend – im Hintergrund aufrufen */
    fun byBarcode(code: String): Food? {
        val o = get("https://world.openfoodfacts.org/api/v2/product/${code.trim()}.json?fields=$FIELDS")
        if (o.optInt("status") != 1) return null
        return parse(o.optJSONObject("product") ?: return null, code.trim())
    }

    /** blockierend – im Hintergrund aufrufen */
    fun search(q: String): List<Food> {
        val url = "https://world.openfoodfacts.org/cgi/search.pl?search_terms=${URLEncoder.encode(q, "UTF-8")}" +
            "&search_simple=1&action=process&json=1&page_size=25&lc=de&cc=de&fields=$FIELDS"
        val a = get(url).optJSONArray("products") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let { p -> parse(p, p.optString("code")) } }
    }

    private fun parse(p: JSONObject, code: String): Food? {
        val n = p.optJSONObject("nutriments") ?: return null
        fun v(k: String, factor: Double = 1.0): Double = n.optDouble("${k}_100g", 0.0).let { if (it.isNaN()) 0.0 else it * factor }
        val kcal = v("energy-kcal").takeIf { it > 0 } ?: (v("energy") / 4.184)
        val name = p.optString("product_name_de").ifBlank { p.optString("product_name") }.ifBlank { return null }
        val per100 = linkedMapOf(
            "kcal" to kcal, "protein" to v("proteins"), "carbs" to v("carbohydrates"), "fat" to v("fat"), "fiber" to v("fiber"),
            "sugar" to v("sugars"), "satfat" to v("saturated-fat"), "salt" to v("salt"),
            "calcium" to v("calcium", 1000.0), "iron" to v("iron", 1000.0), "magnesium" to v("magnesium", 1000.0), "zinc" to v("zinc", 1000.0),
            "potassium" to v("potassium", 1000.0), "vitd" to v("vitamin-d", 1_000_000.0), "b12" to v("vitamin-b12", 1_000_000.0),
            "vitc" to v("vitamin-c", 1000.0), "omega3" to v("omega-3-fat")
        )
        val serving = p.optDouble("serving_quantity", 0.0).let { if (it.isNaN() || it <= 0) 100.0 else it }
        return Food(
            id = "off_$code", name = name, brand = p.optString("brands").substringBefore(","), per100 = per100,
            portionG = serving, portionName = p.optString("serving_size").ifBlank { "Portion" }.take(24), barcode = code, source = "off"
        )
    }

    /** Barcode mit dem Google-Scanner lesen (keine Kamera-Berechtigung nötig) */
    fun scan(c: Context, onCode: (String) -> Unit, onError: (String) -> Unit) {
        val opts = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
            .build()
        GmsBarcodeScanning.getClient(c, opts).startScan()
            .addOnSuccessListener { b -> b.rawValue?.let(onCode) ?: onError("Kein Code erkannt") }
            .addOnCanceledListener { }
            .addOnFailureListener { onError(it.message ?: "Scanner nicht verfügbar") }
    }
}
