package com.lifesave.training

import com.lifesave.core.*
import java.util.Calendar

/** Alle Zahlen für den Jahresrückblick */
data class YearStats(
    val year: Int,
    val workouts: List<Workout>,
    val trainDays: Int,
    val hours: Double,
    val avgMin: Int,
    val sets: Int,
    val reps: Int,
    val volume: Double,
    val heaviest: Pair<String, Double>?,            // Übung, kg
    val improvements: List<Triple<String, Double, Double>>, // Übung, 1RM Start, 1RM Bestwert
    val records: Int,
    val favExercises: List<Pair<String, Int>>,     // Übung, Einheiten
    val muscleSets: Map<String, Double>,
    val months: List<Int>,                          // Workouts je Monat
    val weekdays: List<Int>,                        // Mo..So
    val earliest: Long?, val latest: Long?,
    val longestStreak: Int,
    val longestWeekStreak: Int,
    val weeksGoalMet: Int, val weeksTotal: Int,
    val weightStart: WeightEntry?, val weightEnd: WeightEntry?,
    val firstPhoto: PhotoEntry?, val lastPhoto: PhotoEntry?,
    val cardioMin: Int, val cardioKm: Double, val cardioCount: Int, val favCardio: String?,
    val avgSleep: Double?, val waterDays: Int, val habitsDone: Int, val bestHabit: Pair<String, Int>?, val tasksDone: Int,
    val xp: Int, val levelStart: Int, val levelEnd: Int,
    val badges: List<Rewards.Badge>
)

object YearReview {
    private fun yearOf(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.YEAR)
    private fun startOfYear(y: Int) = Calendar.getInstance().apply { clear(); set(y, 0, 1) }.timeInMillis

    /** Jahre, in denen es Daten gibt (neuestes zuerst) */
    fun years(s: AppState = Store.state): List<Int> {
        val t = s.workouts.map { it.start } + s.history.map { it.at } + s.weights.map { it.at }
        return (t.map { yearOf(it) } + yearOf(now())).distinct().sortedDescending()
    }

    fun compute(year: Int, s: AppState = Store.state): YearStats {
        val from = startOfYear(year); val to = startOfYear(year + 1)
        fun inY(t: Long) = t in from until to
        val ws = s.workouts.filter { inY(it.start) }.sortedBy { it.start }
        val done = ws.flatMap { w -> w.exercises.map { e -> w to e } }
        val days = ws.map { startOfDay(it.start) }.toSet()

        // Längste Tages-Streak (irgendetwas erledigt)
        val actDays = s.history.filter { inY(it.at) }.map { startOfDay(it.at) }.toSortedSet()
        var best = 0; var cur = 0; var prev = 0L
        actDays.forEach { d -> cur = if (prev != 0L && daysBetween(prev, d) == 1) cur + 1 else 1; best = maxOf(best, cur); prev = d }

        // Wochen
        val goal = s.settings.weeklyGoal.coerceAtLeast(1)
        val endT = minOf(to, now())
        var wk = startOfWeek(from); var met = 0; var total = 0; var ws1 = 0; var wsBest = 0
        while (wk < endT) {
            val c = Training.weekCount(s, wk)
            total++
            if (c >= goal) { met++; ws1++; wsBest = maxOf(wsBest, ws1) } else ws1 = 0
            wk = addDays(wk, 7)
        }

        // Kraft: Start (erste 3 Einheiten) vs. Bestwert je Übung
        val byEx = done.groupBy { it.second.exId }
        val impr = byEx.mapNotNull { (id, l) ->
            val v = l.map { (_, e) -> Training.bestOf(e).e1rm }.filter { it > 0 }
            if (v.size < 3) null else Triple(id, v.take(3).average(), v.maxOrNull() ?: 0.0)
        }.filter { it.second > 0 && it.third > it.second }.sortedByDescending { it.third / it.second }

        val heaviest = done.flatMap { (_, e) -> e.sets.filter { it.done }.map { e.exId to it.weight } }.maxByOrNull { it.second }
        val months = (0..11).map { m -> ws.count { Calendar.getInstance().apply { timeInMillis = it.start }.get(Calendar.MONTH) == m } }
        val order = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)
        val wd = order.map { d -> ws.count { dow(it.start) == d } }
        fun minuteOfDay(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

        val wy = s.weights.filter { inY(it.at) }.sortedBy { it.at }
        val ph = s.photos.filter { inY(it.at) }.sortedBy { it.at }
        val cy = s.cardio.filter { inY(it.at) }
        val hy = s.history.filter { inY(it.at) }
        val xpBefore = s.history.filter { it.at < from }.sumOf { it.xp }
        val xpY = hy.sumOf { it.xp }
        val habitBest = s.habits.map { h ->
            val d = h.doneDays.filter { inY(it) }.sorted()
            var b = 0; var c = 0; var p = 0L
            d.forEach { x -> c = if (p != 0L && daysBetween(p, x) == 1) c + 1 else 1; b = maxOf(b, c); p = x }
            h.title to b
        }.maxByOrNull { it.second }?.takeIf { it.second > 0 }

        return YearStats(
            year = year, workouts = ws, trainDays = days.size,
            hours = ws.sumOf { ((it.end ?: it.start) - it.start) } / 3_600_000.0,
            avgMin = if (ws.isEmpty()) 0 else (ws.sumOf { ((it.end ?: it.start) - it.start) } / ws.size / 60_000).toInt(),
            sets = ws.sumOf { it.doneSets() },
            reps = ws.sumOf { w -> w.exercises.sumOf { e -> e.sets.filter { it.done }.sumOf { it.reps } } },
            volume = ws.sumOf { it.volume() },
            heaviest = heaviest?.takeIf { it.second > 0 },
            improvements = impr.take(5),
            records = s.records.count { inY(it.at) },
            favExercises = byEx.map { it.key to it.value.size }.sortedByDescending { it.second }.take(5),
            muscleSets = Training.muscleStats(from, s.copy(workouts = ws)).mapValues { it.value.sets },
            months = months, weekdays = wd,
            earliest = ws.minByOrNull { minuteOfDay(it.start) }?.start,
            latest = ws.maxByOrNull { minuteOfDay(it.start) }?.start,
            longestStreak = best, longestWeekStreak = wsBest, weeksGoalMet = met, weeksTotal = total,
            weightStart = wy.firstOrNull(), weightEnd = wy.lastOrNull(),
            firstPhoto = ph.firstOrNull(), lastPhoto = ph.lastOrNull(),
            cardioMin = cy.sumOf { it.minutes }, cardioKm = cy.sumOf { it.km }, cardioCount = cy.size,
            favCardio = cy.groupBy { it.type }.maxByOrNull { it.value.size }?.key,
            avgSleep = s.sleep.filterKeys { inY(it) }.values.takeIf { it.isNotEmpty() }?.average(),
            waterDays = s.water.filter { inY(it.key) && it.value >= s.settings.waterGoal }.size,
            habitsDone = hy.count { it.kind == "habit" }, bestHabit = habitBest,
            tasksDone = hy.count { it.kind == "task" },
            xp = xpY, levelStart = Rewards.levelInfo(xpBefore).level, levelEnd = Rewards.levelInfo(xpBefore + xpY).level,
            badges = Rewards.BADGES.filter { b -> s.badges[b.id]?.let { inY(it) } == true }
        )
    }

    /** anschauliche Vergleiche für bewegte Kilos */
    fun tonnageComparison(kg: Double): String = when {
        kg >= 7_300_000 -> "so viel wie ${"%.1f".format(kg / 7_300_000)} Eiffeltürme"
        kg >= 150_000 -> "so viel wie ${"%.1f".format(kg / 150_000)} Blauwale"
        kg >= 6_000 -> "so viel wie ${(kg / 6_000).toInt()} Elefanten"
        kg >= 1_500 -> "so viel wie ${(kg / 1_500).toInt()} Autos"
        kg > 0 -> "so viel wie ${(kg / 80).toInt()} Erwachsene"
        else -> "Los geht's!"
    }

    val MONTHS = listOf("Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez")
    val WEEKDAY_SHORT = listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
}
