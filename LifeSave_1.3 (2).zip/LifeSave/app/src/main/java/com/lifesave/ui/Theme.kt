package com.lifesave.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.lifesave.R
import com.lifesave.core.Settings

/** Komplette Farbpalette. Standard = Look der MEL-Liga (hell, Navy, Stahlblau, Rot, Gold). */
data class Palette(
    val bg: Color, val panel: Color, val header: Color, val onHeader: Color,
    val primary: Color, val secondary: Color, val gold: Color, val good: Color,
    val ink: Color, val inkSoft: Color, val line: Color, val dark: Boolean
) {
    val onPrimary: Color get() = if (primary.lum() > 0.6f) Color(0xFF12161C) else Color.White
    val soft: Color get() = primary.copy(alpha = if (dark) 0.22f else 0.10f)
}

fun Color.lum(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue

fun hex(s: String): Color? = runCatching { Color(android.graphics.Color.parseColor(s.trim())) }.getOrNull()
fun toHex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())

data class ThemePreset(val id: String, val name: String, val desc: String, val p: Palette)

val THEMES = listOf(
    ThemePreset("mel", "MEL Eis", "Hell, Navy & Stahlblau wie die MEL-Liga", Palette(
        bg = Color(0xFFEEF3F7), panel = Color.White, header = Color(0xFF0B1E33), onHeader = Color.White,
        primary = Color(0xFF1F4E79), secondary = Color(0xFFC8102E), gold = Color(0xFFC9A227), good = Color(0xFF2E7D46),
        ink = Color(0xFF12161C), inkSoft = Color(0xFF54606E), line = Color(0xFFD8E1E8), dark = false)),
    ThemePreset("frisch_hell", "Frisch Hell", "Hell mit Türkis & warmem Orange", Palette(
        bg = Color(0xFFF2F6F5), panel = Color.White, header = Color(0xFF0E3B37), onHeader = Color.White,
        primary = Color(0xFF0F8F7E), secondary = Color(0xFFF2762E), gold = Color(0xFFE0A526), good = Color(0xFF2E9D5B),
        ink = Color(0xFF111816), inkSoft = Color(0xFF55635F), line = Color(0xFFD6E2DF), dark = false)),
    ThemePreset("frisch_dunkel", "Frisch Dunkel", "Dunkelgrau mit Türkis & Orange", Palette(
        bg = Color(0xFF16181C), panel = Color(0xFF202329), header = Color(0xFF0F1114), onHeader = Color(0xFFF2F4F6),
        primary = Color(0xFF1FBFA6), secondary = Color(0xFFFF8A3D), gold = Color(0xFFFFC24B), good = Color(0xFF3DD68C),
        ink = Color(0xFFEEF1F4), inkSoft = Color(0xFF9AA3AD), line = Color(0xFF2E333A), dark = true)),
    ThemePreset("klassik", "Klassik", "Schwarz, Blau & Rot wie Unlock To-do", Palette(
        bg = Color(0xFF000000), panel = Color(0xFF1C1B2E), header = Color(0xFF0A0A14), onHeader = Color.White,
        primary = Color(0xFF2F6BFF), secondary = Color(0xFFE53945), gold = Color(0xFFFFC24B), good = Color(0xFF3DD68C),
        ink = Color.White, inkSoft = Color(0xFFBDB6C8), line = Color(0xFF2C2B44), dark = true))
)

/** Farben, die man selbst überschreiben kann */
val CUSTOM_KEYS = linkedMapOf(
    "primary" to "Hauptfarbe", "secondary" to "Zweitfarbe (Warnungen)", "gold" to "Akzent (Rekorde, Streak)",
    "header" to "Kopfleiste", "bg" to "Hintergrund", "panel" to "Karten"
)

fun paletteFor(s: Settings): Palette {
    val base = (THEMES.find { it.id == s.themeId } ?: THEMES[0]).p
    val c = s.customColors
    fun o(k: String, d: Color) = c[k]?.let { hex(it) } ?: d
    val bg = o("bg", base.bg)
    val dark = if (c.containsKey("bg")) bg.lum() < 0.4f else base.dark
    // passt Textfarben an, wenn der Hintergrund selbst gewählt wurde
    val ink = if (c.containsKey("bg") && dark != base.dark) (if (dark) Color(0xFFEEF1F4) else Color(0xFF12161C)) else base.ink
    val soft = if (c.containsKey("bg") && dark != base.dark) (if (dark) Color(0xFF9AA3AD) else Color(0xFF54606E)) else base.inkSoft
    val line = if (c.containsKey("bg") && dark != base.dark) (if (dark) Color(0xFF2E333A) else Color(0xFFD8E1E8)) else base.line
    val header = o("header", base.header)
    return base.copy(
        bg = bg, panel = o("panel", base.panel), header = header,
        onHeader = if (header.lum() > 0.6f) Color(0xFF12161C) else Color.White,
        primary = o("primary", base.primary), secondary = o("secondary", base.secondary), gold = o("gold", base.gold),
        ink = ink, inkSoft = soft, line = line, dark = dark
    )
}

val LocalPalette = staticCompositionLocalOf { THEMES[0].p }

val Barlow = FontFamily(Font(R.font.barlow_semibold, FontWeight.SemiBold), Font(R.font.barlow_bold, FontWeight.Bold))

@Composable
fun LifeTheme(p: Palette, content: @Composable () -> Unit) {
    val scheme = if (p.dark) darkColorScheme(
        primary = p.primary, onPrimary = p.onPrimary, secondary = p.secondary, onSecondary = Color.White,
        background = p.bg, onBackground = p.ink, surface = p.panel, onSurface = p.ink,
        surfaceVariant = p.panel, onSurfaceVariant = p.inkSoft, outline = p.line,
        surfaceContainer = p.panel, surfaceContainerHigh = p.panel, surfaceContainerHighest = p.panel, surfaceContainerLow = p.panel
    ) else lightColorScheme(
        primary = p.primary, onPrimary = p.onPrimary, secondary = p.secondary, onSecondary = Color.White,
        background = p.bg, onBackground = p.ink, surface = p.panel, onSurface = p.ink,
        surfaceVariant = p.bg, onSurfaceVariant = p.inkSoft, outline = p.line,
        surfaceContainer = p.panel, surfaceContainerHigh = p.panel, surfaceContainerHighest = p.panel, surfaceContainerLow = p.panel
    )
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}
