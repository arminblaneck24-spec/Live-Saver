package com.lifesave.screens

import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import android.os.Build
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*
import kotlinx.coroutines.delay

/**
 * Laufendes Workout: alle Übungen untereinander (wie in Strive).
 * Grau = Vorschlag (Steigerung bzw. letztes Mal). Haken bei leerem Feld übernimmt den grauen Wert.
 */
@Composable
fun WorkoutScreen() {
    val st = Store.state
    val p = pal
    val ctx = LocalContext.current
    val w = st.active
    var t by remember { mutableLongStateOf(now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500); t = now()
            val r = Store.state.restUntil
            if (r != 0L && t >= r && Store.restAlerted != r) {
                Store.restAlerted = r
                runCatching { ctx.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)) }
                Training.stopRest()
            }
        }
    }
    var finishAsk by remember { mutableStateOf(false) }
    var cancelAsk by remember { mutableStateOf(false) }

    // ---------- Gym-Modus: Bildschirm an, über dem Sperrbildschirm ----------
    val view = LocalView.current
    val gym = st.settings.gymMode && w != null
    val keep = gym && st.settings.gymKeepScreen
    val overLock = gym && st.settings.gymLockScreen
    DisposableEffect(keep) { view.keepScreenOn = keep; onDispose { view.keepScreenOn = false } }
    DisposableEffect(overLock) {
        val act = ctx as? android.app.Activity
        if (Build.VERSION.SDK_INT >= 27) act?.setShowWhenLocked(overLock)
        onDispose { if (Build.VERSION.SDK_INT >= 27) act?.setShowWhenLocked(false) }
    }

    if (w == null) {
        Screen {
            item {
                Panel {
                    Body("Gerade läuft kein Workout.", bold = true)
                    Spacer(Modifier.height(8.dp))
                    Btn("Freies Training starten", Modifier.fillMaxWidth()) { Training.start(null, null) }
                    Spacer(Modifier.height(8.dp))
                    Btn("Zum Training", Modifier.fillMaxWidth(), BtnKind.GHOST) { Nav.root("training") }
                }
            }
        }
        return
    }

    val total = w.exercises.sumOf { it.sets.size }
    val done = w.doneSets()
    if (finishAsk) {
        val open = total - done
        ConfirmDialog("Workout speichern?",
            if (open > 0) "$open Sätze sind nicht abgehakt und werden nicht gespeichert." else "Super Arbeit! Workout speichern?",
            "Speichern", { finishAsk = false }) { Training.finish(); Nav.back() }
    }
    if (cancelAsk) ConfirmDialog("Workout verwerfen?", "Alle Einträge dieses Workouts gehen verloren.", "Verwerfen", { cancelAsk = false }) {
        Training.cancel(); Nav.back()
    }

    Column(Modifier.fillMaxSize()) {
        // ---------- Kopf: Abbrechen · Dauer · Pause ----------
        Row(Modifier.fillMaxWidth().background(p.panel).padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn("✕", color = p.ink) { cancelAsk = true }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(fmtDuration(t - w.start), fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = p.ink)
                Muted(w.name, size = 12.sp, maxLines = 1)
            }
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(p.soft).clickable { if (st.restUntil > t) Training.stopRest() else Training.startRest() }
                .padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(if (st.settings.restAuto) "⏳ je Übung" else "⏳ ${st.settings.restSec}s", color = p.primary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        if (st.restUntil > t) RestBar(st.restUntil - t)

        Box(Modifier.weight(1f)) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (w.exercises.isEmpty()) item { Empty("Noch keine Übungen in diesem Workout.") }
                itemsIndexed(w.exercises, key = { i, e -> "$i-${e.exId}" }) { i, e -> ExerciseCard(w, i, e) }
                item {
                    Btn("+ Übung hinzufügen", Modifier.fillMaxWidth(), BtnKind.SECONDARY) { Nav.pickExercise { Training.addExercise(it) } }
                }
                item { Spacer(Modifier.height(70.dp)) }
            }
            // ---------- Speichern unten ----------
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)) {
                Box(Modifier.clip(RoundedCornerShape(14.dp)).background(if (done == total && total > 0) p.good else p.primary)
                    .clickable { finishAsk = true }.padding(horizontal = 34.dp, vertical = 14.dp)) {
                    Text("$done/$total  SPEICHERN", color = Color.White, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
private fun RestBar(leftMs: Long) {
    val p = pal
    val total = remember(Store.state.restUntil) { leftMs.toFloat().coerceAtLeast(1f) }
    Column(Modifier.fillMaxWidth().background(p.header).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Muted("SATZPAUSE", color = p.onHeader.copy(alpha = 0.7f), size = 11.sp)
                BigNumber(fmtDuration(leftMs + 999), p.onHeader, 28.sp)
            }
            Btn("−15", small = true, kind = BtnKind.SECONDARY) { Training.shiftRest(-15) }
            Spacer(Modifier.width(6.dp))
            Btn("+15", small = true, kind = BtnKind.SECONDARY) { Training.shiftRest(15) }
            Spacer(Modifier.width(6.dp))
            Btn("Weiter", small = true, kind = BtnKind.GOLD) { Training.stopRest() }
        }
        Spacer(Modifier.height(6.dp))
        Bar(leftMs / total, p.gold, height = 5.dp)
    }
}

@Composable
private fun ExerciseCard(w: Workout, idx: Int, e: WorkoutExercise) {
    val p = pal
    val ex = remember(e.exId) { ExerciseDb.get(e.exId) }
    val last = remember(e.exId, w.id) { Training.lastSets(e.exId) }
    val sug = remember(e.exId, w.id, e.sets.size, e.targetReps) { Training.suggest(e, last) }
    var menu by remember { mutableStateOf(false) }
    val allDone = e.sets.isNotEmpty() && e.sets.all { it.done }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.panel)
            .border(1.dp, if (allDone) p.good.copy(alpha = 0.6f) else p.line, RoundedCornerShape(16.dp)).padding(14.dp)
    ) {
        // ---------- Kopf der Übung ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            ExImage(ex?.images ?: emptyList(), Modifier.size(64.dp).clickable { Nav.go("exercise", e.exId) })
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).clickable { Nav.go("exercise", e.exId) }) {
                Text(ex?.name ?: e.exId, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 21.sp, color = if (allDone) p.inkSoft else p.ink, maxLines = 2)
                Muted("Ziel ${e.sets.size} × ${e.lo}–${e.hi} · Pause ${fmtDuration(Training.restFor(e.exId) * 1000L)}", size = 12.sp)
            }
            Box {
                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(p.soft).clickable { menu = true }.padding(horizontal = 14.dp, vertical = 6.dp)) {
                    Text("•••", color = p.primary, fontWeight = FontWeight.Bold)
                }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Anleitung & Verlauf") }, { menu = false; Nav.go("exercise", e.exId) })
                    if (idx > 0) DropdownMenuItem({ Text("Nach oben") }, { menu = false; Training.moveExercise(idx, idx - 1) })
                    if (idx < w.exercises.size - 1) DropdownMenuItem({ Text("Nach unten") }, { menu = false; Training.moveExercise(idx, idx + 1) })
                    if (e.sets.size > 1) DropdownMenuItem({ Text("Letzten Satz entfernen") }, { menu = false; Training.removeSet(idx) })
                    DropdownMenuItem({ Text("Übung entfernen", color = p.secondary) }, { menu = false; Training.removeExercise(idx) })
                }
            }
        }
        if (sug != null) {
            Spacer(Modifier.height(8.dp))
            Pill(sug.note, if (sug.increase) p.good else p.primary)
        }
        Spacer(Modifier.height(10.dp))
        // ---------- Tabelle ----------
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Muted("Satz", Modifier.width(44.dp), size = 13.sp)
            Muted("Vorherige", Modifier.weight(1.25f), size = 13.sp)
            Muted("kg", Modifier.weight(1f), size = 13.sp, color = p.inkSoft)
            Muted("Wdh.", Modifier.weight(1f).padding(start = 6.dp), size = 13.sp)
            Spacer(Modifier.width(48.dp))
        }
        e.sets.forEachIndexed { si, s ->
            val prev = last.getOrNull(si)
            val hint = sug?.sets?.getOrNull(si) ?: prev
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(if (s.done) p.good else p.soft), contentAlignment = Alignment.Center) {
                    Text("${si + 1}", color = if (s.done) Color.White else p.primary, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(8.dp))
                Text(prev?.let { "${fmtKg(it.weight)} kg × ${it.reps}" } ?: "–", Modifier.weight(1.25f), color = p.inkSoft, fontSize = 14.sp, maxLines = 1)
                NumField(if (s.weight > 0) fmtKg(s.weight) else "", hint?.takeIf { it.weight > 0 }?.let { fmtKg(it.weight) } ?: "kg",
                    Modifier.weight(1f).padding(end = 6.dp), done = s.done) { v -> Training.setSet(idx, si) { it.copy(weight = parseNum(v) ?: 0.0) } }
                NumField(if (s.reps > 0) "${s.reps}" else "", hint?.takeIf { it.reps > 0 }?.let { "${it.reps}" } ?: "${e.hi}",
                    Modifier.weight(1f), decimal = false, done = s.done) { v -> Training.setSet(idx, si) { it.copy(reps = v.toIntOrNull() ?: 0) } }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(if (s.done) p.good else p.line.copy(alpha = 0.7f))
                        .clickable { Training.checkSet(idx, si, hint ?: SetEntry(0.0, e.hi)) },
                    contentAlignment = Alignment.Center
                ) { Text("✓", color = if (s.done) Color.White else p.inkSoft, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(p.soft).clickable { Training.addSet(idx) }.padding(horizontal = 22.dp, vertical = 8.dp)) {
                Text("Satz hinzufügen", color = p.primary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
        }
    }
}
