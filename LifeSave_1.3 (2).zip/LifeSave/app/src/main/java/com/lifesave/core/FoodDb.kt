package com.lifesave.core

/**
 * Eingebaute Grundliste mit typischen Nährwerten pro 100 g (Durchschnittswerte, angelehnt an
 * Bundeslebensmittelschlüssel/USDA). Für genaue Werte: Barcode scannen oder Nährwerttabelle an Claude schicken.
 */
object FoodDb {
    private fun f(
        id: String, name: String, portionG: Double, portionName: String,
        kcal: Double, p: Double, c: Double, fat: Double, fib: Double = 0.0, sugar: Double = 0.0, sat: Double = 0.0, salt: Double = 0.0,
        ca: Double = 0.0, fe: Double = 0.0, mg: Double = 0.0, zn: Double = 0.0, k: Double = 0.0,
        d: Double = 0.0, b12: Double = 0.0, vc: Double = 0.0, o3: Double = 0.0
    ) = Food(
        "b_$id", name, "", linkedMapOf(
            "kcal" to kcal, "protein" to p, "carbs" to c, "fat" to fat, "fiber" to fib, "sugar" to sugar, "satfat" to sat, "salt" to salt,
            "calcium" to ca, "iron" to fe, "magnesium" to mg, "zinc" to zn, "potassium" to k, "vitd" to d, "b12" to b12, "vitc" to vc, "omega3" to o3
        ), portionG, portionName, source = "builtin"
    )

    val BUILTIN: List<Food> = listOf(
        f("ei", "Ei", 60.0, "Ei (M)", 137.0, 12.9, 0.7, 9.3, 0.0, 0.7, 2.8, 0.35, 56.0, 1.8, 12.0, 1.3, 140.0, 2.5, 0.9, 0.0, 0.1),
        f("magerquark", "Magerquark", 250.0, "Becher (250 g)", 67.0, 12.0, 4.0, 0.3, 0.0, 4.0, 0.2, 0.1, 90.0, 0.2, 11.0, 0.5, 150.0, 0.0, 0.6, 1.0),
        f("skyr", "Skyr natur", 150.0, "Portion (150 g)", 63.0, 11.0, 4.0, 0.2, 0.0, 4.0, 0.1, 0.1, 100.0, 0.1, 11.0, 0.5, 150.0, 0.0, 0.5),
        f("joghurt", "Naturjoghurt 3,5 %", 150.0, "Portion (150 g)", 63.0, 3.8, 4.7, 3.5, 0.0, 4.7, 2.2, 0.1, 120.0, 0.1, 12.0, 0.5, 160.0, 0.05, 0.4, 1.0),
        f("griech_joghurt", "Griechischer Joghurt 10 %", 150.0, "Portion (150 g)", 120.0, 4.0, 4.0, 10.0, 0.0, 4.0, 6.5, 0.1, 110.0, 0.1, 11.0, 0.5, 150.0, 0.1, 0.4),
        f("milch15", "Milch 1,5 %", 250.0, "Glas (250 ml)", 47.0, 3.4, 4.9, 1.5, 0.0, 4.9, 0.9, 0.1, 120.0, 0.0, 12.0, 0.4, 150.0, 0.03, 0.4, 1.0),
        f("milch35", "Milch 3,5 %", 250.0, "Glas (250 ml)", 64.0, 3.4, 4.8, 3.5, 0.0, 4.8, 2.2, 0.1, 120.0, 0.0, 12.0, 0.4, 150.0, 0.08, 0.4, 1.0),
        f("hafer", "Haferflocken", 50.0, "Portion (50 g)", 372.0, 13.5, 58.7, 7.0, 10.0, 0.7, 1.3, 0.01, 54.0, 4.2, 130.0, 4.0, 360.0, 0.0, 0.0, 0.0, 0.1),
        f("muesli", "Müsli mit Früchten", 60.0, "Portion (60 g)", 360.0, 10.0, 60.0, 7.0, 8.0, 15.0, 1.5, 0.05, 60.0, 3.5, 100.0, 2.5, 400.0),
        f("toast", "Toastbrot (Weizen)", 28.0, "Scheibe", 260.0, 8.0, 48.0, 3.5, 3.0, 4.0, 0.5, 1.2, 40.0, 1.0, 25.0, 0.7, 120.0),
        f("vk_toast", "Vollkorntoast", 30.0, "Scheibe", 245.0, 9.5, 41.0, 4.0, 6.5, 3.5, 0.6, 1.1, 40.0, 2.0, 60.0, 1.5, 230.0),
        f("vk_brot", "Vollkornbrot", 50.0, "Scheibe", 220.0, 7.0, 40.0, 1.5, 7.0, 3.0, 0.3, 1.1, 40.0, 2.0, 60.0, 1.5, 250.0),
        f("butter", "Butter", 10.0, "Portion (10 g)", 741.0, 0.7, 0.6, 83.0, 0.0, 0.6, 53.0, 0.02, 15.0, 0.0, 2.0, 0.1, 20.0, 1.2, 0.2),
        f("frischkaese", "Frischkäse (Doppelrahm)", 30.0, "Portion (30 g)", 225.0, 5.4, 3.2, 21.5, 0.0, 3.2, 14.0, 0.75, 80.0, 0.1, 9.0, 0.5, 130.0, 0.2, 0.3),
        f("gouda", "Gouda", 25.0, "Scheibe", 360.0, 25.0, 0.0, 28.0, 0.0, 0.0, 18.0, 2.0, 800.0, 0.2, 30.0, 4.0, 100.0, 0.3, 1.5),
        f("salami", "Salami", 8.0, "Scheibe", 380.0, 21.0, 1.0, 33.0, 0.0, 1.0, 12.5, 4.2, 15.0, 1.5, 20.0, 3.0, 300.0, 0.5, 1.5),
        f("schinken", "Kochschinken", 20.0, "Scheibe", 110.0, 19.0, 1.0, 3.5, 0.0, 1.0, 1.2, 2.3, 8.0, 0.8, 20.0, 2.0, 300.0, 0.2, 0.6),
        f("haehnchen", "Hähnchenbrust (gebraten)", 150.0, "Stück (150 g)", 165.0, 31.0, 0.0, 3.6, 0.0, 0.0, 1.0, 0.2, 15.0, 0.7, 29.0, 1.0, 256.0, 0.1, 0.3),
        f("haehnchen_pan", "Hähnchen paniert (Airfryer)", 150.0, "Portion (150 g)", 230.0, 20.0, 13.0, 11.0, 1.0, 1.0, 2.0, 1.2, 20.0, 1.0, 25.0, 1.0, 250.0, 0.1, 0.3),
        f("hack", "Hackfleisch gemischt (gebraten)", 125.0, "Portion (125 g)", 270.0, 24.0, 0.0, 19.0, 0.0, 0.0, 7.5, 0.2, 15.0, 2.2, 22.0, 4.5, 300.0, 0.2, 2.2),
        f("kohl_hack", "Kohl mit Hackfleisch", 350.0, "Teller", 110.0, 7.0, 5.0, 7.0, 2.0, 3.0, 2.5, 0.8, 40.0, 1.0, 18.0, 1.5, 250.0, 0.1, 0.6, 15.0),
        f("weisskohl", "Weißkohl (gekocht)", 150.0, "Portion (150 g)", 23.0, 1.3, 3.4, 0.2, 2.5, 3.0, 0.0, 0.02, 45.0, 0.4, 12.0, 0.2, 200.0, 0.0, 0.0, 20.0),
        f("brokkoli", "Brokkoli (gekocht)", 150.0, "Portion (150 g)", 35.0, 2.4, 4.0, 0.4, 3.3, 1.4, 0.1, 0.03, 40.0, 0.7, 21.0, 0.4, 290.0, 0.0, 0.0, 65.0, 0.1),
        f("fischstaebchen", "Fischstäbchen (gebacken)", 30.0, "Stück", 200.0, 13.0, 17.0, 9.0, 1.0, 1.0, 1.0, 0.8, 20.0, 0.5, 25.0, 0.4, 250.0, 0.5, 1.0, 0.0, 0.3),
        f("kartoffelbrei", "Kartoffelbrei (mit Milch & Butter)", 250.0, "Portion (250 g)", 95.0, 2.0, 13.0, 4.0, 1.3, 1.5, 2.5, 0.5, 25.0, 0.4, 20.0, 0.3, 300.0, 0.1, 0.1, 6.0),
        f("kartoffeln", "Kartoffeln (gekocht)", 200.0, "Portion (200 g)", 72.0, 2.0, 15.6, 0.1, 1.8, 0.8, 0.0, 0.01, 6.0, 0.4, 22.0, 0.3, 400.0, 0.0, 0.0, 12.0),
        f("reis", "Reis (gekocht)", 200.0, "Portion (200 g)", 130.0, 2.7, 28.0, 0.3, 0.4, 0.1, 0.1, 0.0, 10.0, 0.2, 12.0, 0.5, 35.0),
        f("nudeln", "Nudeln (gekocht)", 250.0, "Portion (250 g)", 150.0, 5.3, 30.0, 0.9, 1.8, 0.6, 0.2, 0.0, 10.0, 0.6, 18.0, 0.5, 45.0),
        f("banane", "Banane", 120.0, "Banane", 93.0, 1.2, 20.0, 0.2, 2.0, 17.0, 0.1, 0.0, 6.0, 0.3, 30.0, 0.2, 380.0, 0.0, 0.0, 10.0),
        f("apfel", "Apfel", 150.0, "Apfel", 54.0, 0.3, 12.0, 0.2, 2.3, 10.0, 0.0, 0.0, 6.0, 0.2, 5.0, 0.1, 120.0, 0.0, 0.0, 10.0),
        f("lachs", "Lachs (gebraten)", 125.0, "Filet (125 g)", 210.0, 22.0, 0.0, 13.5, 0.0, 0.0, 2.5, 0.15, 12.0, 0.4, 30.0, 0.5, 380.0, 8.0, 3.0, 0.0, 2.2),
        f("thunfisch", "Thunfisch (Dose, eigener Saft)", 130.0, "Dose (abgetropft)", 110.0, 25.0, 0.0, 1.0, 0.0, 0.0, 0.3, 1.0, 10.0, 1.0, 30.0, 0.6, 250.0, 4.0, 2.5, 0.0, 0.3),
        f("linsen", "Linsen (gekocht)", 200.0, "Portion (200 g)", 116.0, 9.0, 17.0, 0.4, 8.0, 1.8, 0.1, 0.0, 19.0, 3.3, 36.0, 1.3, 370.0, 0.0, 0.0, 1.5),
        f("erdnussbutter", "Erdnussbutter", 15.0, "Esslöffel", 600.0, 25.0, 13.0, 50.0, 6.0, 6.0, 9.0, 0.5, 45.0, 1.9, 170.0, 3.0, 650.0),
        f("mandeln", "Mandeln", 30.0, "Handvoll (30 g)", 600.0, 21.0, 6.0, 52.0, 12.0, 4.0, 4.0, 0.0, 260.0, 3.7, 270.0, 3.0, 730.0),
        f("o_saft", "Orangensaft", 250.0, "Glas (250 ml)", 45.0, 0.7, 10.0, 0.2, 0.2, 9.0, 0.0, 0.0, 11.0, 0.2, 11.0, 0.1, 200.0, 0.0, 0.0, 40.0),
        f("pizza", "Pizza Margherita (TK)", 350.0, "Pizza", 250.0, 10.0, 32.0, 9.0, 2.0, 3.0, 4.0, 1.2, 150.0, 1.0, 20.0, 1.0, 180.0),
        f("whey", "Proteinpulver (Whey)", 30.0, "Shake (30 g)", 380.0, 78.0, 7.0, 5.0, 0.0, 5.0, 3.0, 0.5, 450.0, 0.5, 70.0, 1.5, 500.0),
        f("kreatin", "Kreatin-Monohydrat", 5.0, "Portion (5 g)", 0.0, 0.0, 0.0, 0.0)
    )

    /** typische Lebensmittel bei dir zuhause – Grundlage für Vorschläge */
    val HOME = setOf("b_ei", "b_magerquark", "b_joghurt", "b_milch15", "b_hafer", "b_muesli", "b_toast", "b_butter", "b_frischkaese",
        "b_salami", "b_schinken", "b_haehnchen", "b_haehnchen_pan", "b_hack", "b_kohl_hack", "b_brokkoli", "b_fischstaebchen",
        "b_kartoffelbrei", "b_banane", "b_apfel")
}
