package com.lifesave.core

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Zeit-Hilfen (alles in lokaler Zeit, Woche beginnt Montag) ----------

fun now(): Long = System.currentTimeMillis()

private fun cal(t: Long): Calendar = Calendar.getInstance().apply { firstDayOfWeek = Calendar.MONDAY; timeInMillis = t }

fun startOfDay(t: Long): Long = cal(t).apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun addDays(t: Long, d: Int): Long = cal(t).apply { add(Calendar.DAY_OF_YEAR, d) }.timeInMillis

/** Montag 00:00 der Woche, in der t liegt */
fun startOfWeek(t: Long): Long {
    var d = startOfDay(t)
    var g = 0
    while (dow(d) != Calendar.MONDAY && g < 8) { d = addDays(d, -1); g++ }
    return d
}

fun dow(t: Long): Int = cal(t).get(Calendar.DAY_OF_WEEK)
fun hourNow(): Int = cal(now()).get(Calendar.HOUR_OF_DAY)

/** Zeitpunkt am Tag d (Tagesbeginn) um h Uhr */
fun atHour(day: Long, h: Int): Long = cal(startOfDay(day)).apply { set(Calendar.HOUR_OF_DAY, h) }.timeInMillis

fun daysBetween(a: Long, b: Long): Int = Math.round((startOfDay(b) - startOfDay(a)) / 86_400_000.0).toInt()
fun weeksBetween(a: Long, b: Long): Int = Math.floorDiv(daysBetween(startOfWeek(a), startOfWeek(b)), 7)

val WEEKDAYS = listOf(
    Calendar.MONDAY to "Mo", Calendar.TUESDAY to "Di", Calendar.WEDNESDAY to "Mi", Calendar.THURSDAY to "Do",
    Calendar.FRIDAY to "Fr", Calendar.SATURDAY to "Sa", Calendar.SUNDAY to "So"
)
val WEEKDAY_LONG = mapOf(
    Calendar.MONDAY to "Montag", Calendar.TUESDAY to "Dienstag", Calendar.WEDNESDAY to "Mittwoch", Calendar.THURSDAY to "Donnerstag",
    Calendar.FRIDAY to "Freitag", Calendar.SATURDAY to "Samstag", Calendar.SUNDAY to "Sonntag"
)

private fun f(p: String, t: Long) = SimpleDateFormat(p, Locale.GERMAN).format(Date(t))
fun fmtDateTime(t: Long) = f("EE dd.MM. HH:mm", t)
fun fmtDate(t: Long) = f("dd.MM.yyyy", t)
fun fmtShort(t: Long) = f("dd.MM.", t)
fun fmtDay(t: Long) = f("EEEE, dd. MMMM", t)
fun fmtTime(t: Long) = f("HH:mm", t)

fun fmtDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

fun ago(t: Long): String {
    val d = daysBetween(t, now())
    return when {
        d <= 0 -> "heute"
        d == 1 -> "gestern"
        d < 7 -> "vor $d Tagen"
        d < 14 -> "vor 1 Woche"
        d < 60 -> "vor ${d / 7} Wochen"
        else -> "vor ${d / 30} Monaten"
    }
}

fun fmtKg(v: Double): String = if (v == Math.floor(v)) v.toLong().toString() else "%.1f".format(Locale.GERMAN, v)
fun fmtNum(v: Double): String = when {
    v >= 1_000_000 -> "%.1f Mio.".format(Locale.GERMAN, v / 1_000_000)
    v >= 10_000 -> "%.1f t".format(Locale.GERMAN, v / 1000)
    else -> fmtKg(v) + " kg"
}

fun parseNum(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()
