package com.lifesave.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object Images {
    private val cache = object : LruCache<String, Bitmap>(40 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun asset(ctx: android.content.Context, name: String): Bitmap? {
        val k = "a:$name"
        cache.get(k)?.let { return it }
        val b = runCatching { ctx.assets.open("ex/$name").use { BitmapFactory.decodeStream(it) } }.getOrNull() ?: return null
        cache.put(k, b); return b
    }

    /** Foto verkleinert laden (maxSide in Pixeln) */
    fun file(f: File, maxSide: Int): Bitmap? {
        val k = "f:${f.path}:$maxSide"
        cache.get(k)?.let { return it }
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
        val b = runCatching { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) }.getOrNull() ?: return null
        val r = rotateIfNeeded(f, b)
        cache.put(k, r); return r
    }

    private fun rotateIfNeeded(f: File, b: Bitmap): Bitmap = runCatching {
        val exif = android.media.ExifInterface(f.path)
        val deg = when (exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg == 0f) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, android.graphics.Matrix().apply { postRotate(deg) }, true)
    }.getOrDefault(b)

    fun forget(f: File) { cache.snapshot().keys.filter { it.startsWith("f:${f.path}") }.forEach { cache.remove(it) } }
}

@Composable
private fun rememberBitmap(key: String, load: () -> Bitmap?): ImageBitmap? {
    var img by remember(key) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(key) { img = withContext(Dispatchers.IO) { load()?.asImageBitmap() } }
    return img
}

/** Übungsbild; bei zwei Bildern wird im Wechsel abgespielt (kleine Animation) */
@Composable
fun ExImage(images: List<String>, modifier: Modifier = Modifier, animate: Boolean = false) {
    val ctx = LocalContext.current
    val p = pal
    var frame by remember(images) { mutableIntStateOf(0) }
    if (animate && images.size > 1) LaunchedEffect(images) { while (true) { delay(900); frame = (frame + 1) % images.size } }
    val name = images.getOrNull(frame)
    val img = if (name == null) null else rememberBitmap("ex:$name") { Images.asset(ctx, name) }
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(p.bg), contentAlignment = Alignment.Center) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("🏋", fontSize = 22.sp)
    }
}

@Composable
fun PhotoImage(f: File, modifier: Modifier = Modifier, maxSide: Int = 400, crop: Boolean = true) {
    val p = pal
    val img = rememberBitmap("ph:${f.path}:$maxSide") { Images.file(f, maxSide) }
    Box(modifier.background(p.bg), contentAlignment = Alignment.Center) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = if (crop) ContentScale.Crop else ContentScale.Fit)
        else Text("…", color = p.inkSoft)
    }
}

