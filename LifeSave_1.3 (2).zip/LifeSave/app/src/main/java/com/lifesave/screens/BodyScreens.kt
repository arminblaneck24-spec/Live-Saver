package com.lifesave.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.lifesave.core.*
import com.lifesave.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------- Kamera & Galerie (mit Kategorie, z. B. „Front") ----------
@Composable
fun rememberPhotoCapture(onDone: () -> Unit = {}): (String) -> Unit {
    val ctx = LocalContext.current
    var pending by rememberSaveable { mutableStateOf("") }
    var pendingCat by rememberSaveable { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = if (pending.isNotBlank()) File(pending) else null
        pending = ""
        if (ok && f != null) { BodyLog.addPhoto(f, pendingCat); onDone() } else f?.delete()
    }
    return { cat ->
        val f = BodyLog.newPhotoFile()
        pending = f.path; pendingCat = cat
        runCatching { launcher.launch(FileProvider.getUriForFile(ctx, "com.lifesave.files", f)) }
    }
}

@Composable
fun rememberGalleryPick(onDone: () -> Unit = {}): (String) -> Unit {
    val ctx = LocalContext.current
    var pendingCat by rememberSaveable { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)?.let { BodyLog.importPhoto(it, pendingCat) }; onDone() }
    }
    return { cat -> pendingCat = cat; launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
}

/** Fotos von heute: je Kategorie ein Feld mit Kamera/Galerie */
@Composable
fun PhotoDayPanel(compact: Boolean = false) {
    val st = Store.state
    val p = pal
    val capture = rememberPhotoCapture()
    val gallery = rememberGalleryPick()
    val today = startOfDay(now())
    val todays = st.photos.filter { startOfDay(it.at) == today }
    Row(Modifier.fillMaxWidth()) {
        st.settings.photoCats.forEach { cat ->
            val ph = todays.find { it.category == cat }
            Column(Modifier.weight(1f).padding(end = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(10.dp)).background(p.bg)
                    .clickable { if (ph != null) Nav.go("photo", ph.id.toString()) else capture(cat) }, contentAlignment = Alignment.Center) {
                    if (ph != null) PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxSize(), maxSide = 300)
                    else Text("📷", fontSize = 26.sp)
                }
                Text(cat, fontSize = 12.sp, color = if (ph != null) p.good else p.inkSoft, maxLines = 1)
                if (!compact) Row {
                    Text("📷", Modifier.clickable { capture(cat) }.padding(6.dp), fontSize = 16.sp)
                    Text("🖼", Modifier.clickable { gallery(cat) }.padding(6.dp), fontSize = 16.sp)
                }
            }
        }
    }
}

// ================= Körper (Teil von „Fortschritt") =================
fun LazyListScope.bodyContent(st: AppState, kg: String, setKg: (String) -> Unit, range: Int, setRange: (Int) -> Unit) {
    val sorted = BodyLog.sorted(st)
    val from = when (range) { 0 -> addDays(now(), -30); 1 -> addDays(now(), -90); 2 -> addDays(now(), -365); else -> 0L }
    item {
        val p = pal
        Panel(accent = p.primary) {
            Heading("Gewicht")
            val l = BodyLog.latest(st)
            Row(verticalAlignment = Alignment.Bottom) {
                BigNumber(l?.let { fmtKg(it.kg) + " kg" } ?: "–")
                Spacer(Modifier.width(10.dp))
                BodyLog.avg7(st).lastOrNull()?.let { (_, a) -> Muted("Ø 7 Tage: ${"%.1f".format(a)} kg", Modifier.padding(bottom = 6.dp)) }
            }
            BodyLog.change(28, st)?.let { ch -> Muted((if (ch >= 0) "+" else "") + fmtKg(Math.round(ch * 10) / 10.0) + " kg in 4 Wochen") }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Field(kg, setKg, "Gewicht (kg)", Modifier.weight(1f), decimal = true)
                Spacer(Modifier.width(8.dp))
                Btn("Eintragen", enabled = (parseNum(kg) ?: 0.0) in 20.0..400.0) { BodyLog.addWeight(parseNum(kg)!!); setKg("") }
            }
            Muted(if (st.settings.weighDaily) "Pflicht-Abfrage jeden Morgen ab ${st.settings.weighDailyHour} Uhr – am besten nach dem Klo, vor dem Frühstück."
                else "Automatische Abfrage: ${WEEKDAY_LONG[st.settings.weighDay]} ab ${st.settings.weighHour} Uhr", Modifier.padding(top = 4.dp))
        }
    }
    item {
        val p = pal
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Heading("Verlauf", Modifier.weight(1f))
                listOf("30 T", "90 T", "1 J", "Alles").forEachIndexed { i, l -> Pick(l, range == i) { setRange(i) } }
            }
            LineChart(sorted.filter { it.at >= from }.map { it.at to it.kg }, unit = "", second = BodyLog.avg7(st).filter { it.first >= from })
            Row { Pill("● Messung", p.primary); Spacer(Modifier.width(6.dp)); Pill("● Ø 7 Tage", p.gold) }
        }
    }
    item {
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Heading("Fortschrittsfotos heute", Modifier.weight(1f))
                Muted("${BodyLog.photoDays(st).size} Tage")
            }
            Muted("Privat in der App, nicht in der Galerie. Alle Fotos eines Tages gehören zusammen.")
            Spacer(Modifier.height(8.dp))
            PhotoDayPanel()
            Row(Modifier.padding(top = 8.dp)) {
                Btn("Alle Fotos", Modifier.weight(1f), BtnKind.GHOST, small = true) { Nav.go("photos") }
                Spacer(Modifier.width(8.dp))
                Btn("Vergleichen", Modifier.weight(1f), BtnKind.GOLD, small = true, enabled = BodyLog.photoDays(st).size >= 2) { Nav.go("compare") }
            }
        }
    }
    item { Heading("Einträge") }
    items(sorted.reversed().take(60), key = { "w" + it.id }) { w ->
        var del by remember { mutableStateOf(false) }
        if (del) ConfirmDialog("Eintrag löschen?", "${fmtKg(w.kg)} kg vom ${fmtDateTime(w.at)}", "Löschen", { del = false }) { BodyLog.deleteWeight(w.id) }
        Panel(padding = 10.dp, onClick = { del = true }) {
            Row {
                Body(fmtDateTime(w.at), Modifier.weight(1f))
                Body("${fmtKg(w.kg)} kg", bold = true)
            }
        }
    }
}

@Composable
fun BodyScreen() {
    val st = Store.state
    var kg by remember { mutableStateOf("") }
    var range by remember { mutableIntStateOf(1) }
    Screen { bodyContent(st, kg, { kg = it }, range, { range = it }) }
}

// ================= Alle Fotos (nach Tagen) =================
@Composable
fun PhotosScreen() {
    val st = Store.state
    val days = BodyLog.photoDays(st)
    Screen {
        item { Panel { Heading("Heute"); PhotoDayPanel() } }
        if (days.size >= 2) item { Btn("Zwei Tage vergleichen", Modifier.fillMaxWidth(), BtnKind.GOLD) { Nav.go("compare") } }
        if (days.isEmpty()) item { Empty("Noch keine Fotos") }
        items(days, key = { it.first }) { (day, list) ->
            val w = st.weights.filter { startOfDay(it.at) == day }.minByOrNull { it.at }
            Panel(padding = 10.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body(fmtDay(day), Modifier.weight(1f), bold = true)
                    w?.let { Muted("${fmtKg(it.kg)} kg") }
                }
                Spacer(Modifier.height(6.dp))
                Row {
                    list.sortedBy { st.settings.photoCats.indexOf(it.category).let { i -> if (i < 0) 99 else i } }.take(4).forEach { ph ->
                        Column(Modifier.weight(1f).padding(end = 4.dp)) {
                            PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(8.dp))
                                .clickable { Nav.go("photo", ph.id.toString()) }, maxSide = 300)
                            Muted(BodyLog.catLabel(ph), size = 11.sp, maxLines = 1)
                        }
                    }
                    repeat((4 - list.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
fun PhotoView(id: Long) {
    val st = Store.state
    val ph = st.photos.find { it.id == id } ?: run { Empty("Foto nicht gefunden"); return }
    var del by remember { mutableStateOf(false) }
    val w = st.weights.filter { startOfDay(it.at) == startOfDay(ph.at) }.minByOrNull { it.at }
    if (del) ConfirmDialog("Foto löschen?", "Das Foto wird endgültig gelöscht.", "Löschen", { del = false }) { BodyLog.deletePhoto(ph); Nav.back() }
    Screen {
        item { PhotoImage(BodyLog.fileOf(ph), Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(10.dp)), maxSide = 1400, crop = false) }
        item {
            Panel {
                Body("${BodyLog.catLabel(ph)} · ${fmtDay(ph.at)}", bold = true)
                w?.let { Muted("Gewicht an dem Tag: ${fmtKg(it.kg)} kg") }
                Heading("Kategorie")
                ChipRow {
                    Store.state.settings.photoCats.forEach { c ->
                        Pick(c, ph.category == c) { Store.update { s -> s.copy(photos = s.photos.map { if (it.id == ph.id) it.copy(category = c) else it }) } }
                    }
                }
            }
        }
        item { Btn("Foto löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { del = true } }
    }
}

// ================= Vorher / Nachher (Tag gegen Tag) =================
@Composable
fun CompareScreen() {
    val st = Store.state
    val days = BodyLog.photoDays(st).reversed() // älteste zuerst
    if (days.size < 2) { Screen { item { Empty("Für einen Vergleich brauchst du Fotos von mindestens zwei Tagen.") } }; return }
    var a by remember { mutableLongStateOf(days.first().first) }
    var b by remember { mutableLongStateOf(days.last().first) }
    val la = days.find { it.first == a }?.second ?: emptyList()
    val lb = days.find { it.first == b }?.second ?: emptyList()
    val cats = (st.settings.photoCats + la.map { BodyLog.catLabel(it) } + lb.map { BodyLog.catLabel(it) }).distinct()
        .filter { c -> la.any { BodyLog.catLabel(it) == c } && lb.any { BodyLog.catLabel(it) == c } }
    Screen {
        item {
            Panel {
                Heading("Vorher")
                DayStrip(days.map { it.first }, a) { a = it }
                Heading("Nachher")
                DayStrip(days.map { it.first }, b) { b = it }
                val wa = st.weights.filter { startOfDay(it.at) == a }.minByOrNull { it.at }
                val wb = st.weights.filter { startOfDay(it.at) == b }.minByOrNull { it.at }
                Muted("${daysBetween(a, b)} Tage dazwischen" + if (wa != null && wb != null) " · ${fmtKg(wa.kg)} → ${fmtKg(wb.kg)} kg (" +
                    (if (wb.kg - wa.kg >= 0) "+" else "") + fmtKg(Math.round((wb.kg - wa.kg) * 10) / 10.0) + " kg)" else "")
            }
        }
        if (cats.isEmpty()) item { Empty("An diesen beiden Tagen gibt es keine Fotos derselben Kategorie.") }
        items(cats, key = { it }) { c ->
            val pa = la.first { BodyLog.catLabel(it) == c }
            val pb = lb.first { BodyLog.catLabel(it) == c }
            CompareCard(c, pa, pb)
        }
    }
}

@Composable
private fun DayStrip(days: List<Long>, sel: Long, onPick: (Long) -> Unit) {
    LazyRow { items(days, key = { it }) { d -> Pick(fmtShort(d), d == sel) { onPick(d) } } }
}

@Composable
private fun CompareCard(cat: String, pa: PhotoEntry, pb: PhotoEntry) {
    var frac by remember { mutableFloatStateOf(0.5f) }
    val ia = rememberPhotoBitmap(BodyLog.fileOf(pa))
    val ib = rememberPhotoBitmap(BodyLog.fileOf(pb))
    Panel(padding = 8.dp) {
        Heading(cat)
        Canvas(Modifier.fillMaxWidth().aspectRatio(0.75f).clip(RoundedCornerShape(8.dp))) {
            ia?.let { drawCover(it) }
            clipRect(left = size.width * frac) { ib?.let { drawCover(it) } }
            drawLine(androidx.compose.ui.graphics.Color.White, androidx.compose.ui.geometry.Offset(size.width * frac, 0f),
                androidx.compose.ui.geometry.Offset(size.width * frac, size.height), 3.dp.toPx())
        }
        Slider(frac, { frac = it })
        Row {
            Muted("Vorher: ${fmtDate(pa.at)}", Modifier.weight(1f))
            Muted("Nachher: ${fmtDate(pb.at)}")
        }
    }
}

@Composable
private fun rememberPhotoBitmap(f: File): ImageBitmap? {
    var img by remember(f.path) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(f.path) { img = withContext(Dispatchers.IO) { Images.file(f, 1200)?.asImageBitmap() } }
    return img
}

/** Bild so zeichnen, dass es die Fläche füllt (zugeschnitten) */
private fun DrawScope.drawCover(img: ImageBitmap) {
    val sw = img.width.toFloat(); val sh = img.height.toFloat()
    val scale = maxOf(size.width / sw, size.height / sh)
    val cw = (size.width / scale); val ch = (size.height / scale)
    val sx = ((sw - cw) / 2).toInt().coerceAtLeast(0); val sy = ((sh - ch) / 2).toInt().coerceAtLeast(0)
    drawImage(img, IntOffset(sx, sy), IntSize(cw.toInt().coerceAtMost(img.width), ch.toInt().coerceAtMost(img.height)),
        IntOffset.Zero, IntSize(size.width.toInt(), size.height.toInt()))
}
