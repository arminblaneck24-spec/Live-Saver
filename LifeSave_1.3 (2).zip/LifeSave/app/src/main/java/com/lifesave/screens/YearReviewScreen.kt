package com.lifesave.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/** Baut aus den Jahreszahlen die einzelnen Karten */
fun yearCards(y: YearStats, accent: Int): List<ShareCard> {
    val out = mutableListOf<ShareCard>()
    fun n(v: Double) = String.format(Locale.GERMAN, "%,.0f", v)
    out += ShareCard("🗓", "Dein Jahr ${y.year}", "${y.trainDays} Trainingstage",
        "${y.workouts.size} Workouts · ${y.hours.toInt()} Stunden im Gym",
        listOf("Level ${y.levelStart} → ${y.levelEnd}", "+${y.xp} XP gesammelt", "${y.badges.size} neue Abzeichen"), accent = accent)
    out += ShareCard("🏋", "Workouts", "${y.workouts.size}",
        "Ø ${y.avgMin} Minuten pro Einheit",
        listOf("${n(y.sets.toDouble())} Sätze", "${n(y.reps.toDouble())} Wiederholungen", "${String.format(Locale.GERMAN, "%.0f", y.hours)} Stunden Training"),
        bars = y.months, barLabels = YearReview.MONTHS.map { it.take(1) }, accent = accent)
    out += ShareCard("🪨", "Bewegtes Gewicht", fmtNum(y.volume), YearReview.tonnageComparison(y.volume),
        listOf("Das sind im Schnitt ${fmtNum(if (y.workouts.isEmpty()) 0.0 else y.volume / y.workouts.size)} pro Workout"), accent = accent)
    val strong = mutableListOf<String>()
    y.heaviest?.let { strong += "Schwerstes Gewicht: ${fmtKg(it.second)} kg (${ExerciseDb.name(it.first)})" }
    y.improvements.take(3).forEach { (id, a, b) -> strong += "${ExerciseDb.name(id)}: +${((b / a - 1) * 100).toInt()} % Kraft" }
    out += ShareCard("📈", "Stärker geworden", "${y.records} Rekorde",
        y.improvements.firstOrNull()?.let { (id, a, b) -> "Größter Sprung: ${ExerciseDb.name(id)} +${((b / a - 1) * 100).toInt()} %" } ?: "",
        strong, accent = accent)
    val maxSets = (y.muscleSets.values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val topMuscle = y.muscleSets.maxByOrNull { it.value }?.key
    out += ShareCard("💪", "Lieblingsübungen", y.favExercises.firstOrNull()?.let { ExerciseDb.name(it.first) } ?: "–",
        y.favExercises.firstOrNull()?.let { "${it.second}× trainiert" } ?: "",
        y.favExercises.drop(1).take(3).map { "${ExerciseDb.name(it.first)} · ${it.second}×" } +
            listOfNotNull(topMuscle?.let { "Meisttrainierter Muskel: ${muscleDe(it)}" }),
        muscles = y.muscleSets.mapValues { (it.value / maxSets).toFloat() }, accent = accent)
    val favDay = y.weekdays.withIndex().maxByOrNull { it.value }?.takeIf { it.value > 0 }
    out += ShareCard("🔥", "Dranbleiben", "${y.longestStreak} Tage",
        "längste Streak am Stück",
        listOfNotNull(
            "Wochenziel ${y.weeksGoalMet}/${y.weeksTotal} Wochen erreicht",
            "Längste Wochen-Serie: ${y.longestWeekStreak} Wochen",
            favDay?.let { "Lieblingstag: ${WEEKDAY_LONG[listOf(2, 3, 4, 5, 6, 7, 1)[it.index]]}" },
            y.earliest?.let { "Frühestes Workout: ${fmtTime(it)} Uhr" },
            y.latest?.let { "Spätestes Workout: ${fmtTime(it)} Uhr" }
        ), bars = y.weekdays, barLabels = YearReview.WEEKDAY_SHORT, accent = accent)
    if (y.weightStart != null && y.weightEnd != null) {
        val d = y.weightEnd.kg - y.weightStart.kg
        out += ShareCard("⚖", "Körper", (if (d >= 0) "+" else "") + fmtKg(Math.round(d * 10) / 10.0) + " kg",
            "${fmtKg(y.weightStart.kg)} kg → ${fmtKg(y.weightEnd.kg)} kg",
            listOf("${fmtDate(y.weightStart.at)} bis ${fmtDate(y.weightEnd.at)}"),
            photos = if (y.firstPhoto != null && y.lastPhoto != null && y.firstPhoto.id != y.lastPhoto.id)
                BodyLog.fileOf(y.firstPhoto) to BodyLog.fileOf(y.lastPhoto) else null, accent = accent)
    }
    if (y.cardioCount > 0) out += ShareCard("🏃", "Cardio", "${y.cardioMin} Minuten",
        if (y.cardioKm > 0) "${fmtKg(Math.round(y.cardioKm * 10) / 10.0)} km zurückgelegt" else "",
        listOfNotNull("${y.cardioCount} Einheiten", y.favCardio?.let { "Am liebsten: $it" }), accent = accent)
    out += ShareCard("🌱", "Alltag", "${y.habitsDone + y.tasksDone} erledigt",
        "${y.habitsDone} Gewohnheiten · ${y.tasksDone} Aufgaben",
        listOfNotNull(
            y.bestHabit?.let { "Beste Serie: ${it.first} (${it.second} Tage)" },
            y.avgSleep?.let { "Ø Schlaf: ${Vitals.fmtHours(it)}" },
            if (y.waterDays > 0) "Wasserziel an ${y.waterDays} Tagen" else null
        ), accent = accent)
    if (y.badges.isNotEmpty()) out += ShareCard("🏅", "Abzeichen", "${y.badges.size} neu",
        "", y.badges.take(8).map { "${it.emoji} ${it.title}" }, accent = accent)
    out += ShareCard("⭐", "Zusammengefasst", "${y.year}",
        "Level ${y.levelEnd} erreicht",
        listOf("🏋 ${y.workouts.size} Workouts", "🪨 ${fmtNum(y.volume)} bewegt", "📈 ${y.records} Rekorde", "🔥 ${y.longestStreak} Tage Streak",
            "🎯 ${y.weeksGoalMet} Wochenziele"), accent = accent)
    return out
}

@Composable
fun YearReviewScreen() {
    val ctx = LocalContext.current
    val st = Store.state
    val p = pal
    val years = remember { YearReview.years(st) }
    var year by remember { mutableIntStateOf(years.first()) }
    val stats = remember(year, st) { YearReview.compute(year, st) }
    val accent = p.gold.toArgb()
    val top = p.header.toArgb(); val bottom = p.primary.toArgb()
    val cards = remember(stats) { yearCards(stats, accent) }
    var previews by remember(cards) { mutableStateOf<List<Bitmap>>(emptyList()) }
    LaunchedEffect(cards) { previews = withContext(Dispatchers.Default) { cards.map { ShareCards.render(it, "Life Save · Jahresrückblick $year", top, bottom, 0.33f) } } }
    var sharing by remember { mutableStateOf(false) }
    LaunchedEffect(sharing) {
        if (!sharing) return@LaunchedEffect
        val full = withContext(Dispatchers.Default) { cards.map { ShareCards.render(it, "Life Save · Jahresrückblick $year", top, bottom, 1f) } }
        ShareCards.share(ctx, full, "Mein Fitness-Jahr $year mit Life Save 💪")
        sharing = false
    }
    Screen {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Title("Rückblick", Modifier.weight(1f))
                years.take(4).forEach { yy -> Pick("$yy", yy == year) { year = yy } }
            }
            if (stats.workouts.isEmpty()) Muted("In diesem Jahr gibt es noch keine Workouts – die Karten füllen sich, sobald du trainierst.")
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(previews.size) { i ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(previews[i].asImageBitmap(), null, Modifier.width(220.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(14.dp)))
                        Btn("Teilen", Modifier.padding(top = 6.dp), BtnKind.GHOST, small = true) {
                            ShareCards.share(ctx, listOf(ShareCards.render(cards[i], "Life Save · Jahresrückblick $year", top, bottom, 1f)), "Mein Fitness-Jahr $year 💪")
                        }
                    }
                }
            }
            if (previews.isEmpty()) Muted("Karten werden erstellt …")
        }
        item { Btn(if (sharing) "Wird vorbereitet …" else "Alle Karten teilen", Modifier.fillMaxWidth(), BtnKind.GOLD, enabled = !sharing && previews.isNotEmpty()) { sharing = true } }
        // ---------- ausführliche Zahlen ----------
        item {
            Panel(accent = p.primary) {
                Heading("Training")
                Row {
                    StatBox("Workouts", "${stats.workouts.size}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Trainingstage", "${stats.trainDays}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Stunden", String.format(Locale.GERMAN, "%.0f", stats.hours), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row {
                    StatBox("Sätze", "${stats.sets}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Wiederholungen", "${stats.reps}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Ø Dauer", "${stats.avgMin} Min.", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Body("🪨 ${fmtNum(stats.volume)} bewegt – ${YearReview.tonnageComparison(stats.volume)}")
                Heading("Workouts pro Monat")
                BarChart(stats.months.map { it.toDouble() }, YearReview.MONTHS.map { it.take(1) }, highlightLast = false)
                Heading("Nach Wochentag")
                BarChart(stats.weekdays.map { it.toDouble() }, YearReview.WEEKDAY_SHORT, color = p.gold, height = 110.dp, highlightLast = false)
            }
        }
        item {
            Panel {
                Heading("Kraft")
                stats.heaviest?.let { Body("Schwerstes Gewicht: ${fmtKg(it.second)} kg · ${ExerciseDb.name(it.first)}") }
                Body("Neue Rekorde: ${stats.records}")
                if (stats.improvements.isNotEmpty()) Muted("Größte Fortschritte (geschätztes 1RM, Start → Bestwert):", Modifier.padding(top = 6.dp))
                stats.improvements.forEach { (id, a, b) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Body(ExerciseDb.name(id), Modifier.weight(1f), maxLines = 1)
                        Body("${fmtKg(Math.round(a * 10) / 10.0)} → ${fmtKg(Math.round(b * 10) / 10.0)} kg", bold = true)
                        Pill("+${((b / a - 1) * 100).toInt()} %", p.good)
                    }
                }
                Heading("Lieblingsübungen")
                stats.favExercises.forEachIndexed { i, (id, c) -> Body("${i + 1}. ${ExerciseDb.name(id)} · ${c}×") }
                val maxSets = (stats.muscleSets.values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
                Mannequin(stats.muscleSets.mapValues { (it.value / maxSets).toFloat() })
                Muted("Farbe = trainierte Sätze im Jahr je Muskel")
            }
        }
        item {
            Panel {
                Heading("Dranbleiben")
                Body("Längste Streak: ${stats.longestStreak} Tage")
                Body("Wochenziel erreicht: ${stats.weeksGoalMet} von ${stats.weeksTotal} Wochen")
                Body("Längste Wochen-Serie: ${stats.longestWeekStreak} Wochen")
                stats.earliest?.let { Body("Frühestes Workout: ${fmtTime(it)} Uhr") }
                stats.latest?.let { Body("Spätestes Workout: ${fmtTime(it)} Uhr") }
            }
        }
        item {
            Panel {
                Heading("Körper & Alltag")
                if (stats.weightStart != null && stats.weightEnd != null)
                    Body("Gewicht: ${fmtKg(stats.weightStart.kg)} → ${fmtKg(stats.weightEnd.kg)} kg")
                if (stats.cardioCount > 0) Body("Cardio: ${stats.cardioCount}× · ${stats.cardioMin} Min. · ${fmtKg(Math.round(stats.cardioKm * 10) / 10.0)} km")
                stats.avgSleep?.let { Body("Ø Schlaf: ${Vitals.fmtHours(it)}") }
                Body("Wasserziel erreicht: ${stats.waterDays} Tage")
                Body("Gewohnheiten erledigt: ${stats.habitsDone}" + (stats.bestHabit?.let { " · beste Serie: ${it.first} (${it.second} Tage)" } ?: ""))
                Body("Aufgaben erledigt: ${stats.tasksDone}")
                Body("XP: +${stats.xp} · Level ${stats.levelStart} → ${stats.levelEnd}")
            }
        }
        if (stats.badges.isNotEmpty()) item {
            Panel {
                Heading("Neue Abzeichen")
                stats.badges.forEach { Body("${it.emoji} ${it.title} – ${it.desc}") }
            }
        }
    }
}
