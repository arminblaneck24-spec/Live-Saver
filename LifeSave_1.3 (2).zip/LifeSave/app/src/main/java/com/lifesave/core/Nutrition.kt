package com.lifesave.core

import kotlin.math.roundToInt

// ================= Nährstoffe =================
data class NutrientDef(val key: String, val label: String, val unit: String, val isMax: Boolean = false)

/** Reihenfolge = Anzeige. Werte in Lebensmitteln immer pro 100 g. */
val NUTRIENTS = listOf(
    NutrientDef("kcal", "Kalorien", "kcal"),
    NutrientDef("protein", "Eiweiß", "g"),
    NutrientDef("carbs", "Kohlenhydrate", "g"),
    NutrientDef("fat", "Fett", "g"),
    NutrientDef("fiber", "Ballaststoffe", "g"),
    NutrientDef("sugar", "Zucker", "g", isMax = true),
    NutrientDef("satfat", "Gesättigte Fette", "g", isMax = true),
    NutrientDef("salt", "Salz", "g", isMax = true),
    NutrientDef("calcium", "Kalzium", "mg"),
    NutrientDef("iron", "Eisen", "mg"),
    NutrientDef("magnesium", "Magnesium", "mg"),
    NutrientDef("zinc", "Zink", "mg"),
    NutrientDef("potassium", "Kalium", "mg"),
    NutrientDef("vitd", "Vitamin D", "µg"),
    NutrientDef("b12", "Vitamin B12", "µg"),
    NutrientDef("vitc", "Vitamin C", "mg"),
    NutrientDef("omega3", "Omega-3", "g")
)
val NUTRIENT_BY_KEY = NUTRIENTS.associateBy { it.key }
val MACROS = listOf("protein", "fat", "carbs", "fiber")

val MEALS = listOf("Frühstück", "Mittagessen", "Abendessen", "Snacks")
val MEAL_ICONS = listOf("🥐", "🍽", "🥗", "🍎")

data class Food(
    val id: String,
    val name: String,
    val brand: String = "",
    val per100: Map<String, Double>,
    val portionG: Double = 100.0,
    val portionName: String = "Portion",
    val barcode: String = "",
    val source: String = "manual",       // builtin, off, claude, manual
    val fav: Boolean = false,
    val excluded: Boolean = false
)

data class FoodLog(
    val id: Long = newId(),
    val day: Long,
    val meal: Int,
    val foodId: String = "",
    val name: String,
    val grams: Double,
    val values: Map<String, Double>,      // absolut für diese Menge
    val at: Long = now()
)

data class MealItem(val foodId: String, val grams: Double)
data class SavedMeal(val id: Long = newId(), val name: String, val meal: Int = 0, val items: List<MealItem>)

data class NutritionGoals(
    val targets: Map<String, Double> = DEFAULT_TARGETS,
    val mealSplit: List<Double> = listOf(0.25, 0.30, 0.30, 0.15),
    val supplements: List<String> = emptyList(),   // z. B. "creatine", "whey"
    val note: String = "Startwerte: leichter Aufbau (+250–300 kcal), 2 g Eiweiß/kg",
    val setAt: Long = 0L,
    val source: String = "Standard"
)

/** Startwerte für 1,84 m / 76 kg / 4× Training, sauberer Aufbau; Mikros nach DGE-Referenzwerten (15–19 J., männlich) */
val DEFAULT_TARGETS = linkedMapOf(
    "kcal" to 3100.0, "protein" to 150.0, "carbs" to 450.0, "fat" to 75.0, "fiber" to 38.0,
    "sugar" to 75.0, "satfat" to 34.0, "salt" to 6.0,
    "calcium" to 1200.0, "iron" to 11.0, "magnesium" to 400.0, "zinc" to 14.0, "potassium" to 4000.0,
    "vitd" to 20.0, "b12" to 4.0, "vitc" to 110.0, "omega3" to 1.6
)

val SUPPLEMENTS = linkedMapOf("creatine" to "Kreatin (3–5 g)", "whey" to "Proteinpulver")

object Nutrition {
    fun day() = startOfDay(now())

    fun logs(day: Long, s: AppState = Store.state) = s.foodLogs.filter { it.day == day }
    fun total(logs: List<FoodLog>): Map<String, Double> {
        val m = mutableMapOf<String, Double>()
        logs.forEach { l -> l.values.forEach { (k, v) -> m[k] = (m[k] ?: 0.0) + v } }
        return m
    }
    fun totals(day: Long, s: AppState = Store.state) = total(logs(day, s))
    fun mealTotal(day: Long, meal: Int, s: AppState = Store.state) = total(logs(day, s).filter { it.meal == meal })

    fun goal(key: String, s: AppState = Store.state) = s.nutritionGoals.targets[key] ?: DEFAULT_TARGETS[key] ?: 0.0
    fun mealGoal(meal: Int, s: AppState = Store.state) = goal("kcal", s) * (s.nutritionGoals.mealSplit.getOrNull(meal) ?: 0.25)

    fun values(f: Food, grams: Double): Map<String, Double> = f.per100.mapValues { it.value * grams / 100.0 }

    fun allFoods(s: AppState = Store.state): List<Food> {
        val own = s.foods
        return own + FoodDb.BUILTIN.filter { b -> own.none { it.id == b.id } }
    }
    fun food(id: String, s: AppState = Store.state) = allFoods(s).find { it.id == id }

    fun search(q: String, s: AppState = Store.state): List<Food> {
        val words = q.trim().lowercase().split(" ").filter { it.isNotBlank() }
        return allFoods(s).filter { f -> !f.excluded && words.all { w -> f.name.lowercase().contains(w) || f.brand.lowercase().contains(w) } }
            .sortedWith(compareBy<Food>({ if (it.fav) 0 else 1 }, { it.name.lowercase() }))
    }

    /** zuletzt gegessen (für die Schnellauswahl) */
    fun recent(s: AppState = Store.state): List<Food> =
        s.foodLogs.sortedByDescending { it.at }.map { it.foodId }.filter { it.isNotBlank() }.distinct().take(15).mapNotNull { food(it, s) }

    // ---------- Einträge ----------
    fun log(f: Food, grams: Double, meal: Int, day: Long = day()) {
        val e = FoodLog(day = day, meal = meal, foodId = f.id, name = f.name, grams = grams, values = values(f, grams))
        val firstToday = logs(day).isEmpty()
        Store.update { it.copy(foodLogs = it.foodLogs + e) }
        if (firstToday && day == day()) Rewards.addXp(day, "Ernährung getrackt", "food", 5)
        checkGoals(day)
    }
    fun logMeal(m: SavedMeal, meal: Int, day: Long = day()) = m.items.forEach { i -> food(i.foodId)?.let { log(it, i.grams, meal, day) } }
    fun updateGrams(l: FoodLog, grams: Double) {
        val f = food(l.foodId)
        val v = if (f != null) values(f, grams) else l.values.mapValues { it.value * grams / l.grams.coerceAtLeast(0.01) }
        Store.update { s -> s.copy(foodLogs = s.foodLogs.map { if (it.id == l.id) it.copy(grams = grams, values = v) else it }) }
    }
    fun deleteLog(id: Long) = Store.update { s -> s.copy(foodLogs = s.foodLogs.filterNot { it.id == id }) }

    fun skipMeal(day: Long, meal: Int, skip: Boolean) = Store.update { s ->
        val cur = s.mealSkips[day] ?: emptySet()
        s.copy(mealSkips = s.mealSkips + (day to if (skip) cur + meal else cur - meal))
    }
    fun mealDone(day: Long, meal: Int, s: AppState = Store.state) = logs(day, s).any { it.meal == meal } || meal in (s.mealSkips[day] ?: emptySet())

    /** XP, wenn Eiweiß- und Kalorienziel (±10 %) erreicht sind */
    private fun checkGoals(day: Long) {
        if (day != day()) return
        val t = totals(day)
        val ok = (t["protein"] ?: 0.0) >= goal("protein") && (t["kcal"] ?: 0.0) in goal("kcal") * 0.9..goal("kcal") * 1.1
        val had = Store.state.history.any { it.kind == "nutrition_goal" && startOfDay(it.at) == day }
        if (ok && !had) Rewards.addXp(day, "Ernährungsziel erreicht", "nutrition_goal", 15)
    }

    // ---------- Lebensmittel ----------
    fun upsertFood(f: Food) = Store.update { s ->
        if (s.foods.any { it.id == f.id }) s.copy(foods = s.foods.map { if (it.id == f.id) f else it }) else s.copy(foods = s.foods + f)
    }
    fun toggleFav(f: Food) = upsertFood(f.copy(fav = !f.fav))
    fun deleteFood(id: String) = Store.update { s -> s.copy(foods = s.foods.filterNot { it.id == id }) }

    fun upsertMeal(m: SavedMeal) = Store.update { s ->
        if (s.savedMeals.any { it.id == m.id }) s.copy(savedMeals = s.savedMeals.map { if (it.id == m.id) m else it }) else s.copy(savedMeals = s.savedMeals + m)
    }
    fun deleteMeal(id: Long) = Store.update { s -> s.copy(savedMeals = s.savedMeals.filterNot { it.id == id }) }

    /** Wochenplan (optional): Wochentag → Mahlzeit → gespeicherte Mahlzeit */
    fun planFor(weekday: Int, meal: Int, s: AppState = Store.state): SavedMeal? =
        s.mealPlan["$weekday-$meal"]?.let { id -> s.savedMeals.find { it.id == id } }
    fun setPlan(weekday: Int, meal: Int, mealId: Long?) = Store.update { s ->
        val k = "$weekday-$meal"
        s.copy(mealPlan = if (mealId == null) s.mealPlan - k else s.mealPlan + (k to mealId))
    }

    // ---------- Supplements ----------
    fun suppTaken(key: String, s: AppState = Store.state) = key in (s.suppTaken[day()] ?: emptySet())
    fun toggleSupp(key: String) = Store.update { s ->
        val d = day(); val cur = s.suppTaken[d] ?: emptySet()
        s.copy(suppTaken = s.suppTaken + (d to if (key in cur) cur - key else cur + key))
    }

    // ---------- Was fehlt noch? ----------
    data class Suggestion(val food: Food, val grams: Double, val label: String, val values: Map<String, Double>)

    /**
     * Vorschläge aus deinen Lebensmitteln (Favoriten, zuletzt gegessen, Standardliste), passend zu dem, was heute noch fehlt.
     * Vorrang hat Eiweiß, dann Kalorien.
     */
    fun suggestions(day: Long = day(), s: AppState = Store.state): List<Suggestion> {
        val t = totals(day, s)
        val needP = goal("protein", s) - (t["protein"] ?: 0.0)
        val needK = goal("kcal", s) - (t["kcal"] ?: 0.0)
        if (needK < 80 && needP < 5) return emptyList()
        val pool = (allFoods(s).filter { it.fav } + recent(s) + FoodDb.BUILTIN.filter { it.id in FoodDb.HOME })
            .distinctBy { it.id }.filter { !it.excluded && (it.per100["kcal"] ?: 0.0) > 0 }
        return pool.mapNotNull { f ->
            val p = f.per100["protein"] ?: 0.0; val k = f.per100["kcal"] ?: 0.0
            // Menge: deckt die Eiweißlücke, ohne die Kalorien zu sprengen, höchstens 3 Portionen
            var g = if (needP > 5 && p > 0) needP / p * 100 else needK / k * 100
            g = minOf(g, (needK.coerceAtLeast(150.0)) / k * 100, f.portionG * 3)
            val portions = (g / f.portionG).let { if (it >= 1) it.roundToInt().toDouble() else it }
            g = if (portions >= 1) portions * f.portionG else (g / 10).roundToInt() * 10.0
            if (g < 10) return@mapNotNull null
            val v = values(f, g)
            val label = (if (portions >= 1 && f.portionName != "Portion") "${portions.toInt()}× ${f.portionName}" else "${g.toInt()} g") + " ${f.name}"
            Suggestion(f, g, label, v)
        }.sortedByDescending { sg ->
            val pv = sg.values["protein"] ?: 0.0; val kv = (sg.values["kcal"] ?: 1.0).coerceAtLeast(1.0)
            if (needP > 5) pv / kv * 100 + (if (sg.food.fav) 5 else 0) else kv / 100 + (if (sg.food.fav) 5 else 0)
        }.take(4)
    }

    // ---------- Wochenbericht für Claude ----------
    fun weeklyReport(s: AppState = Store.state): String {
        val today = day()
        val sb = StringBuilder()
        sb.appendLine("LIFE SAVE – WOCHENBERICHT (${fmtDate(now())})")
        sb.appendLine("Ziele aktuell: " + NUTRIENTS.take(8).joinToString(", ") { "${it.label} ${fmt(goal(it.key, s))} ${it.unit}" })
        if (s.nutritionGoals.supplements.isNotEmpty()) sb.appendLine("Supplements: " + s.nutritionGoals.supplements.joinToString { SUPPLEMENTS[it] ?: it })
        sb.appendLine()
        sb.appendLine("GEWICHT (morgens):")
        (13 downTo 0).forEach { i ->
            val d = startOfDay(addDays(today, -i))
            val w = s.weights.filter { startOfDay(it.at) == d }.minByOrNull { it.at }
            sb.appendLine("  ${fmtShort(d)} ${WEEKDAYS.find { it.first == dow(d) }?.second}: " + (w?.let { "${fmtKg(it.kg)} kg" } ?: "–"))
        }
        fun avgW(from: Int, to: Int): Double? {
            val l = s.weights.filter { it.at >= addDays(today, -from) && it.at < addDays(today, -to) }.map { it.kg }
            return if (l.isEmpty()) null else l.average()
        }
        val a1 = avgW(6, -1); val a2 = avgW(13, 6)
        sb.appendLine("  Ø letzte 7 Tage: ${a1?.let { "%.1f".format(it) } ?: "–"} kg · Ø davor: ${a2?.let { "%.1f".format(it) } ?: "–"} kg")
        sb.appendLine()
        sb.appendLine("ERNÄHRUNG (Tagessummen):")
        val tracked = (6 downTo 0).map { startOfDay(addDays(today, -it)) }.filter { logs(it, s).isNotEmpty() }
        (6 downTo 0).forEach { i ->
            val d = startOfDay(addDays(today, -i)); val t = totals(d, s)
            if (t.isEmpty()) sb.appendLine("  ${fmtShort(d)}: nicht getrackt")
            else sb.appendLine("  ${fmtShort(d)}: ${fmt(t["kcal"] ?: 0.0)} kcal · E ${fmt(t["protein"] ?: 0.0)} g · K ${fmt(t["carbs"] ?: 0.0)} g · F ${fmt(t["fat"] ?: 0.0)} g · Bal ${fmt(t["fiber"] ?: 0.0)} g")
        }
        if (tracked.isNotEmpty()) {
            sb.appendLine("  Ø pro getracktem Tag:")
            NUTRIENTS.forEach { n ->
                val avg = tracked.map { totals(it, s)[n.key] ?: 0.0 }.average()
                sb.appendLine("    ${n.label}: ${fmt(avg)} ${n.unit} (Ziel ${fmt(goal(n.key, s))})")
            }
        }
        sb.appendLine()
        sb.appendLine("TRAINING:")
        val ws = s.workouts.filter { it.start >= addDays(today, -13) }.sortedBy { it.start }
        ws.forEach { w -> sb.appendLine("  ${fmtShort(w.start)} ${w.name}: ${w.doneSets()} Sätze, ${fmtNum(w.volume())}") }
        if (ws.isEmpty()) sb.appendLine("  keine Workouts")
        sb.appendLine()
        val sl = (6 downTo 0).mapNotNull { s.sleep[startOfDay(addDays(today, -it))] }
        if (sl.isNotEmpty()) sb.appendLine("SCHLAF: Ø ${"%.1f".format(sl.average())} Std. (${sl.size} Nächte)")
        val st = (6 downTo 0).mapNotNull { s.steps[startOfDay(addDays(today, -it))] }
        if (st.isNotEmpty()) sb.appendLine("SCHRITTE: Ø ${st.average().toInt()} pro Tag")
        sb.appendLine()
        sb.appendLine("Bitte Ziele prüfen und neue Ziel-Datei (JSON) für Life Save erstellen.")
        return sb.toString()
    }

    private fun fmt(v: Double) = if (v >= 100) v.roundToInt().toString() else "%.1f".format(v)
}
