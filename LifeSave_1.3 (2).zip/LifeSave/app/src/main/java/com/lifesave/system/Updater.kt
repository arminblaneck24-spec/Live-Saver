package com.lifesave.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import com.lifesave.core.Store
import com.lifesave.core.VERSION
import com.lifesave.core.now
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Selbst-Update über GitHub Releases: Der Build-Workflow legt jede Version als Release „vX.Y" mit der APK ab.
 * Die App fragt die neueste Version ab, lädt die APK und öffnet die Installation. Daten bleiben erhalten
 * (gleicher Signierschlüssel).
 */
object Updater {
    data class Release(val version: String, val apkUrl: String, val notes: String)

    var available by mutableStateOf<Release?>(null); private set
    var status by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    /** solange darf der Paket-Installer trotz Einstellungsschutz offen sein */
    var installUntil = 0L
    private val main = Handler(Looper.getMainLooper())

    /** "1.10" > "1.9" */
    fun newer(a: String, b: String): Boolean {
        val x = a.trim().removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.trim().removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = x.getOrElse(i) { 0 } - y.getOrElse(i) { 0 }
            if (d != 0) return d > 0
        }
        return false
    }

    /** einmal am Tag automatisch prüfen */
    fun autoCheck() {
        if (now() - Store.state.settings.lastUpdateCheck < 20 * 3_600_000L) return
        check(silent = true)
    }

    fun check(silent: Boolean = false) {
        if (busy) return
        val repo = Store.state.settings.updateRepo.trim()
        if (repo.isBlank() || !repo.contains("/")) { if (!silent) status = "Bitte GitHub-Repo eintragen (Name/Repo)."; return }
        busy = true; if (!silent) status = "Suche nach Updates …"
        thread {
            val res = runCatching {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.connectTimeout = 10_000; c.readTimeout = 15_000
                if (c.responseCode == 404) error("Noch kein Release gefunden. Ist das Repo öffentlich und der neue Build-Workflow aktiv?")
                if (c.responseCode != 200) error("GitHub antwortet mit Fehler ${c.responseCode}")
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val assets = o.getJSONArray("assets")
                val apk = (0 until assets.length()).map { assets.getJSONObject(it) }
                    .firstOrNull { it.optString("name").endsWith(".apk") } ?: error("Im Release ist keine APK.")
                Release(o.optString("tag_name").removePrefix("v"), apk.optString("browser_download_url"), o.optString("body"))
            }
            main.post {
                busy = false
                Store.setSettings { it.copy(lastUpdateCheck = now()) }
                res.onSuccess { r ->
                    if (newer(r.version, VERSION)) { available = r; status = "Version ${r.version} ist verfügbar." }
                    else { available = null; if (!silent) status = "Du hast die neueste Version ($VERSION)." }
                }.onFailure { if (!silent) status = it.message ?: "Keine Verbindung." }
            }
        }
    }

    fun canInstall(c: Context) = Build.VERSION.SDK_INT < 26 || c.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(c: Context) {
        c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun downloadAndInstall(c: Context) {
        val r = available ?: return
        if (busy) return
        val app = c.applicationContext
        busy = true; status = "Lade Version ${r.version} …"
        thread {
            val res = runCatching {
                val f = File(app.cacheDir, "update.apk")
                var url = URL(r.apkUrl)
                var conn = url.openConnection() as HttpURLConnection
                var hops = 0
                // GitHub leitet auf einen Download-Server weiter
                while (conn.responseCode in 300..399 && hops < 5) {
                    url = URL(conn.getHeaderField("Location")); conn = url.openConnection() as HttpURLConnection; hops++
                }
                if (conn.responseCode != 200) error("Download fehlgeschlagen (${conn.responseCode})")
                conn.inputStream.use { i -> f.outputStream().use { i.copyTo(it) } }
                f
            }
            main.post {
                busy = false
                res.onSuccess { f ->
                    Store.flush()
                    status = "Installation wird geöffnet …"
                    installUntil = now() + 3 * 60_000L
                    val uri = FileProvider.getUriForFile(app, "com.lifesave.files", f)
                    app.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure { status = it.message ?: "Download fehlgeschlagen." }
            }
        }
    }
}
