package com.lifesave.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*
import java.util.Calendar

fun pickDateTime(ctx: Context, initial: Long?, onPick: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { if (initial != null) timeInMillis = initial }
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min ->
            c.set(y, m, d, h, min, 0); c.set(Calendar.MILLISECOND, 0); onPick(c.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

// ================= Aufgaben =================
@Composable
fun TasksScreen() {
    val st = Store.state
    val p = pal
    var cat by remember { mutableStateOf<String?>(null) }
    val today = startOfDay(now())
    val open = Tasks.open(st).filter { cat == null || it.category == cat }
        .sortedWith(compareByDescending<Task> { it.priority }.thenBy { it.due ?: Long.MAX_VALUE })
    val upcoming = open.filter { it.due != null && startOfDay(it.due) > today }
    val current = open - upcoming.toSet()
    val done = Tasks.doneToday(st).filter { cat == null || it.category == cat }
    val session = Training.nextSession(st)?.takeIf { it.today }
    Screen {
        item { Btn("+ Neue Aufgabe", Modifier.fillMaxWidth()) { Nav.go("task", "new") } }
        if (st.categories.isNotEmpty()) item {
            LazyRow {
                item { Pick("Alle", cat == null) { cat = null } }
                if (session != null) item { Pick("Training", cat == "Training") { cat = "Training" } }
                items(st.categories) { c -> Pick(c, cat == c) { cat = if (cat == c) null else c } }
            }
        }
        // Training als eigene Kategorie im Tagesplan
        if (session != null && (cat == null || cat == "Training")) {
            item { Heading("Training") }
            item {
                val doneT = Training.trainedToday(st)
                Panel(accent = if (doneT) p.good else p.secondary, onClick = {
                    if (st.active != null) Nav.go("workout") else if (!doneT) { Training.start(session.plan, session.day); Nav.go("workout") }
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Check(doneT, p.good) { }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Body("🏋 ${session.day.name}", bold = true, color = if (doneT) p.inkSoft else p.ink)
                            Muted(if (doneT) "Erledigt" else "${session.day.exercises.size} Übungen · tippen zum Starten")
                        }
                    }
                }
            }
        }
        if (cat != "Training") {
            item { Heading("Offen") }
            if (current.isEmpty()) item { Empty("Keine offenen Aufgaben 🎉") }
            items(current, key = { it.id }) { TaskRow(it) }
            if (upcoming.isNotEmpty()) {
                item { Heading("Demnächst") }
                items(upcoming, key = { "u" + it.id }) { TaskRow(it) }
            }
            if (done.isNotEmpty()) {
                item { Heading("Heute erledigt") }
                items(done, key = { "d" + it.id }) { TaskRow(it) }
            }
        }
    }
}

@Composable
fun TaskRow(t: Task) {
    val p = pal
    val done = t.doneAt != null
    val pc = prioColor(t.priority)
    Panel(accent = null, onClick = { Nav.go("task", t.id.toString()) }) {
        Row(verticalAlignment = Alignment.Top) {
            Check(done, pc) { if (!done) Tasks.complete(t) else Tasks.uncomplete(t) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                androidx.compose.material3.Text(t.title, fontSize = 15.sp, color = if (done) p.inkSoft else p.ink,
                    textDecoration = if (done) TextDecoration.LineThrough else null)
                val overdue = !done && t.due != null && t.due < now()
                val meta = listOfNotNull(t.category.ifBlank { null }, t.due?.let { fmtDateTime(it) }, Tasks.repeatText(t), "+${t.xp} XP").joinToString(" · ")
                Muted(meta, color = if (overdue) p.secondary else p.inkSoft)
                if (t.note.isNotBlank()) Muted(t.note, maxLines = 2)
                if (!done) t.subtasks.forEachIndexed { i, s ->
                    Row(Modifier.clickable { Tasks.toggleSub(t.id, i) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Body(if (s.done) "☑" else "☐", color = p.primary)
                        Spacer(Modifier.width(6.dp))
                        androidx.compose.material3.Text(s.title, fontSize = 14.sp, color = p.ink, textDecoration = if (s.done) TextDecoration.LineThrough else null)
                    }
                }
            }
        }
    }
}

@Composable
fun TaskEditor(id: Long?) {
    val ctx = LocalContext.current
    val p = pal
    val st = Store.state
    val orig = id?.let { i -> st.tasks.find { it.id == i } }
    var title by remember { mutableStateOf(orig?.title ?: "") }
    var note by remember { mutableStateOf(orig?.note ?: "") }
    var due by remember { mutableStateOf(orig?.due) }
    var prio by remember { mutableIntStateOf(orig?.priority ?: 2) }
    var cat by remember { mutableStateOf(orig?.category ?: "") }
    var newCat by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(when { orig?.weekdays?.isNotEmpty() == true -> 2; (orig?.repeatDays ?: 0) > 0 -> 1; else -> 0 }) }
    var interval by remember { mutableStateOf(((orig?.repeatDays ?: 0).takeIf { it > 0 } ?: 2).toString()) }
    val days = remember { mutableStateListOf<Int>().apply { addAll(orig?.weekdays ?: emptyList()) } }
    var xp by remember { mutableStateOf((orig?.xp ?: 10).toString()) }
    val subs = remember { mutableStateListOf<Subtask>().apply { addAll(orig?.subtasks ?: emptyList()) } }
    var newSub by remember { mutableStateOf("") }

    Screen {
        item {
            Panel {
                Field(title, { title = it }, "Titel")
                Spacer(Modifier.height(6.dp))
                Field(note, { note = it }, "Notiz", singleLine = false, minLines = 2)
            }
        }
        item {
            Panel {
                Heading("Priorität")
                ChipRow { listOf(1 to "Niedrig", 2 to "Mittel", 3 to "Hoch").forEach { (v, l) -> Pick(l, prio == v) { prio = v } } }
                Heading("Fällig")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pick(due?.let { fmtDateTime(it) } ?: "Datum & Uhrzeit wählen", due != null) { pickDateTime(ctx, due) { due = it } }
                    if (due != null) IconBtn("✕", color = p.secondary) { due = null }
                }
                Heading("Kategorie")
                ChipRow {
                    Pick("Keine", cat.isEmpty()) { cat = "" }
                    st.categories.forEach { c -> Pick(c, cat == c) { cat = c } }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(newCat, { newCat = it }, "Neue Kategorie", Modifier.weight(1f))
                    IconBtn("＋", color = p.primary) { val n = newCat.trim(); if (n.isNotEmpty()) { Tasks.addCategory(n); cat = n; newCat = "" } }
                }
            }
        }
        item {
            Panel {
                Heading("Wiederholung")
                ChipRow {
                    Pick("Keine", mode == 0) { mode = 0 }
                    Pick("Alle X Tage", mode == 1) { mode = 1 }
                    Pick("Wochentage", mode == 2) { mode = 2 }
                }
                if (mode == 1) Field(interval, { interval = it.filter(Char::isDigit) }, "Alle wie viele Tage? (1 = täglich)", number = true)
                if (mode == 2) ChipRow { WEEKDAYS.forEach { (d, l) -> Pick(l, d in days) { if (d in days) days.remove(d) else days.add(d) } } }
            }
        }
        item {
            Panel {
                Field(xp, { xp = it.filter(Char::isDigit) }, "XP für diese Aufgabe", number = true)
                Heading("Unteraufgaben")
                subs.forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Check(s.done) { subs[i] = s.copy(done = !s.done) }
                        Body(s.title, Modifier.weight(1f).padding(start = 10.dp))
                        IconBtn("✕", color = p.secondary) { subs.removeAt(i) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(newSub, { newSub = it }, "Neue Unteraufgabe", Modifier.weight(1f))
                    IconBtn("＋", color = p.primary) { if (newSub.isNotBlank()) { subs.add(Subtask(newSub.trim())); newSub = "" } }
                }
            }
        }
        item {
            Btn("Speichern", Modifier.fillMaxWidth(), enabled = title.isNotBlank()) {
                val wd = if (mode == 2) days.sorted() else emptyList()
                val rd = if (mode == 1) (interval.toIntOrNull() ?: 1).coerceAtLeast(1) else 0
                val d = due ?: if (wd.isNotEmpty()) Tasks.firstWeekday(wd) else null
                val base = orig ?: Task(title = "")
                Tasks.upsert(base.copy(
                    title = title.trim(), note = note.trim(), due = d, priority = prio, category = cat,
                    repeatDays = rd, weekdays = wd, xp = xp.toIntOrNull() ?: 0, subtasks = subs.toList(),
                    notified = if (d != orig?.due) false else base.notified
                ))
                Nav.back()
            }
        }
        if (orig != null) item { Btn("Löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { Tasks.delete(orig.id); Nav.back() } }
    }
}

// ================= Gewohnheiten =================
@Composable
fun HabitsScreen() {
    val st = Store.state
    Screen {
        item { Muted("Jede Streak-Einheit in Folge gibt +5 % XP, höchstens ×10. Abends fragt der Tagesabschluss alle fälligen Gewohnheiten ab.") }
        item { Btn("+ Neue Gewohnheit", Modifier.fillMaxWidth()) { Nav.go("habit", "new") } }
        val (due, other) = st.habits.partition { Habits.dueToday(it) }
        if (st.habits.isEmpty()) item { Empty("Noch keine Gewohnheiten, z. B. »Wasser trinken« mit Ziel 8 Gläser.") }
        if (due.isNotEmpty()) item { Heading("Heute") }
        items(due, key = { it.id }) { h -> HabitCard(h) }
        if (other.isNotEmpty()) item { Heading("Heute nicht fällig") }
        items(other, key = { "o" + it.id }) { h -> HabitCard(h) }
    }
}

@Composable
fun HabitCard(h: Habit) {
    val p = pal
    val done = Habits.doneToday(h)
    Panel(accent = if (done) p.good else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { Nav.go("habit", h.id.toString()) }) {
                Body(h.title, bold = true)
                Muted("🔥 ${Habits.streak(h)} · ×${"%.2f".format(Habits.mult(h))} · ${Habits.nextXp(h)} XP · ${Habits.modeText(h)}")
            }
            val pr = Habits.progress(h)
            if (h.target <= 1) Check(done, p.good) { Habits.step(h.id, if (done) -1 else 1) }
            else Stepper("$pr/${h.target}", { Habits.step(h.id, -1) }, { Habits.step(h.id, 1) })
        }
        if (h.target > 1) {
            Spacer(Modifier.height(8.dp))
            Bar(Habits.progress(h) / h.target.toFloat(), p.good)
            if (h.unit.isNotBlank()) Muted("${Habits.progress(h)} von ${h.target} ${h.unit}", Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun HabitEditor(id: Long?) {
    val st = Store.state
    val orig = id?.let { i -> st.habits.find { it.id == i } }
    var title by remember { mutableStateOf(orig?.title ?: "") }
    var target by remember { mutableStateOf((orig?.target ?: 1).toString()) }
    var unit by remember { mutableStateOf(orig?.unit ?: "") }
    var xp by remember { mutableStateOf((orig?.baseXp ?: 10).toString()) }
    var mode by remember { mutableIntStateOf(orig?.mode ?: HABIT_DAILY) }
    val days = remember { mutableStateListOf<Int>().apply { addAll(orig?.weekdays ?: emptyList()) } }
    var perWeek by remember { mutableIntStateOf(orig?.perWeek ?: 3) }
    Screen {
        item {
            Panel {
                Field(title, { title = it }, "Name (z. B. Wasser trinken)")
                Spacer(Modifier.height(6.dp))
                Row {
                    Field(target, { target = it.filter(Char::isDigit) }, "Tagesziel (Anzahl)", Modifier.weight(1f), number = true)
                    Spacer(Modifier.width(8.dp))
                    Field(unit, { unit = it }, "Einheit (z. B. Gläser)", Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
                Field(xp, { xp = it.filter(Char::isDigit) }, "Basis-XP", number = true)
            }
        }
        item {
            Panel {
                Heading("Wie oft?")
                ChipRow {
                    Pick("Täglich", mode == HABIT_DAILY) { mode = HABIT_DAILY }
                    Pick("Bestimmte Tage", mode == HABIT_WEEKDAYS) { mode = HABIT_WEEKDAYS }
                    Pick("X-mal pro Woche", mode == HABIT_PER_WEEK) { mode = HABIT_PER_WEEK }
                }
                if (mode == HABIT_WEEKDAYS) ChipRow { WEEKDAYS.forEach { (d, l) -> Pick(l, d in days) { if (d in days) days.remove(d) else days.add(d) } } }
                if (mode == HABIT_PER_WEEK) Stepper("$perWeek×", { perWeek = (perWeek - 1).coerceAtLeast(1) }, { perWeek = (perWeek + 1).coerceAtMost(7) }, "pro Woche")
            }
        }
        item {
            Btn("Speichern", Modifier.fillMaxWidth(), enabled = title.isNotBlank() && (mode != HABIT_WEEKDAYS || days.isNotEmpty())) {
                val base = orig ?: Habit(title = "")
                Habits.upsert(base.copy(title = title.trim(), target = (target.toIntOrNull() ?: 1).coerceAtLeast(1), unit = unit.trim(),
                    baseXp = xp.toIntOrNull() ?: 0, mode = mode, weekdays = days.sorted(), perWeek = perWeek))
                Nav.back()
            }
        }
        if (orig != null) item { Btn("Löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { Habits.delete(orig.id); Nav.back() } }
    }
}
