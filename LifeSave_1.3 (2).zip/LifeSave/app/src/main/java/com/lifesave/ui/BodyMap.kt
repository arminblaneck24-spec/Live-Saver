package com.lifesave.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb

/**
 * Mannequin (vorne + hinten). Zeichnet direkt auf einen Android-Canvas,
 * damit dieselbe Grafik in der App und im Homescreen-Widget verwendet wird.
 * Koordinaten je Figur in einem 100 × 210-Raster, linke Körperhälfte wird gespiegelt.
 */
object BodyMap {
    private sealed class Shape {
        data class Ell(val cx: Float, val cy: Float, val rx: Float, val ry: Float, val mirror: Boolean = true) : Shape()
        data class Rr(val l: Float, val t: Float, val r: Float, val b: Float, val rad: Float) : Shape()
        data class Poly(val pts: List<Pair<Float, Float>>, val mirror: Boolean = false) : Shape()
    }

    private val FRONT: Map<String, List<Shape>> = mapOf(
        "neck" to listOf(Shape.Rr(45.5f, 24f, 54.5f, 31f, 2f)),
        "traps" to listOf(Shape.Ell(41f, 32f, 5f, 2.6f)),
        "shoulders" to listOf(Shape.Ell(29.5f, 39f, 7.5f, 6.8f)),
        "chest" to listOf(Shape.Ell(41.2f, 47f, 9.5f, 7.5f)),
        "biceps" to listOf(Shape.Ell(24f, 56f, 5f, 10f)),
        "forearms" to listOf(Shape.Ell(19.5f, 84f, 4.6f, 12f)),
        "abdominals" to listOf(Shape.Rr(43f, 57f, 57f, 92f, 5f)),
        "abductors" to listOf(Shape.Ell(33.5f, 102f, 3.6f, 7f)),
        "adductors" to listOf(Shape.Ell(46f, 116f, 3.2f, 11f)),
        "quadriceps" to listOf(Shape.Ell(39.5f, 128f, 7f, 21f)),
        "calves" to listOf(Shape.Ell(40f, 177f, 4.6f, 14f))
    )
    private val BACK: Map<String, List<Shape>> = mapOf(
        "neck" to listOf(Shape.Rr(45.5f, 24f, 54.5f, 31f, 2f)),
        "traps" to listOf(Shape.Poly(listOf(50f to 25f, 37f to 35f, 50f to 58f, 63f to 35f))),
        "shoulders" to listOf(Shape.Ell(29.5f, 39f, 7.5f, 6.8f)),
        "middle back" to listOf(Shape.Ell(44.5f, 54f, 4.2f, 8f)),
        "lats" to listOf(Shape.Ell(37.5f, 62f, 6.2f, 13f)),
        "lower back" to listOf(Shape.Rr(43.5f, 74f, 56.5f, 92f, 4f)),
        "triceps" to listOf(Shape.Ell(24f, 56f, 5f, 10f)),
        "forearms" to listOf(Shape.Ell(19.5f, 84f, 4.6f, 12f)),
        "glutes" to listOf(Shape.Ell(42.5f, 104f, 8.5f, 8.5f)),
        "abductors" to listOf(Shape.Ell(33.5f, 101f, 3f, 6f)),
        "hamstrings" to listOf(Shape.Ell(41f, 134f, 6.8f, 18f)),
        "calves" to listOf(Shape.Ell(41f, 174f, 5.6f, 13f))
    )

    private fun silhouette(): Path = Path().apply {
        addCircle(50f, 13f, 10f, Path.Direction.CW)
        addRoundRect(RectF(45f, 21f, 55f, 32f), 3f, 3f, Path.Direction.CW)
        // Rumpf
        moveTo(33f, 31f); lineTo(67f, 31f); quadTo(73f, 33f, 72f, 42f); lineTo(66f, 60f); lineTo(64f, 95f)
        quadTo(66f, 104f, 63f, 110f); lineTo(37f, 110f); quadTo(34f, 104f, 36f, 95f); lineTo(34f, 60f); lineTo(28f, 42f)
        quadTo(27f, 33f, 33f, 31f); close()
        // Arme
        for (m in listOf(false, true)) {
            fun x(v: Float) = if (m) 100f - v else v
            addRoundRect(RectF(minOf(x(18f), x(30f)), 33f, maxOf(x(18f), x(30f)), 70f), 6f, 6f, Path.Direction.CW)
            addRoundRect(RectF(minOf(x(14f), x(25f)), 68f, maxOf(x(14f), x(25f)), 100f), 5f, 5f, Path.Direction.CW)
            addCircle(x(19f), 105f, 5f, Path.Direction.CW)
            // Beine
            addRoundRect(RectF(minOf(x(31f), x(49.5f)), 100f, maxOf(x(31f), x(49.5f)), 157f), 8f, 8f, Path.Direction.CW)
            addRoundRect(RectF(minOf(x(34f), x(47f)), 154f, maxOf(x(34f), x(47f)), 198f), 6f, 6f, Path.Direction.CW)
            addRoundRect(RectF(minOf(x(33f), x(48f)), 196f, maxOf(x(33f), x(48f)), 204f), 3f, 3f, Path.Direction.CW)
        }
    }

    private fun drawShape(c: Canvas, s: Shape, p: Paint) {
        when (s) {
            is Shape.Ell -> {
                c.drawOval(RectF(s.cx - s.rx, s.cy - s.ry, s.cx + s.rx, s.cy + s.ry), p)
                if (s.mirror) c.drawOval(RectF(100f - s.cx - s.rx, s.cy - s.ry, 100f - s.cx + s.rx, s.cy + s.ry), p)
            }
            is Shape.Rr -> c.drawRoundRect(RectF(s.l, s.t, s.r, s.b), s.rad, s.rad, p)
            is Shape.Poly -> {
                val path = Path()
                s.pts.forEachIndexed { i, (x, y) -> if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                path.close(); c.drawPath(path, p)
            }
        }
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(sh: Int) = (((a shr sh) and 255) + (((b shr sh) and 255) - ((a shr sh) and 255)) * k).toInt().coerceIn(0, 255)
        return (255 shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * @param intensity 0..1 je Muskel (Datenbank-Namen wie "chest")
     * @param base Körperfarbe, [muscleOff] Farbe untrainierter Muskeln, [hot] Farbe bei voller Stärke
     */
    fun draw(c: Canvas, w: Float, h: Float, intensity: Map<String, Float>, base: Int, muscleOff: Int, hot: Int, label: Int, showLabels: Boolean = true) {
        val figW = w / 2f
        val scale = minOf(figW / 100f, (h - if (showLabels) 18f * (h / 260f) else 0f) / 210f)
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = base; style = Paint.Style.FILL }
        val mp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = label; textAlign = Paint.Align.CENTER; textSize = 11f * (h / 260f).coerceIn(0.6f, 1.6f); isFakeBoldText = true }
        listOf(FRONT to "VORNE", BACK to "HINTEN").forEachIndexed { i, (map, name) ->
            c.save()
            val ox = i * figW + (figW - 100f * scale) / 2f
            c.translate(ox, 0f)
            c.scale(scale, scale)
            c.drawPath(silhouette(), bodyPaint)
            map.forEach { (muscle, shapes) ->
                val v = intensity[muscle] ?: 0f
                mp.color = if (v <= 0.01f) muscleOff else mix(muscleOff, hot, 0.25f + 0.75f * v)
                shapes.forEach { drawShape(c, it, mp) }
            }
            c.restore()
            if (showLabels) c.drawText(name, i * figW + figW / 2f, h - 4f, tp)
        }
    }
}

/** Mannequin als Compose-Element */
@Composable
fun Mannequin(intensity: Map<String, Float>, modifier: Modifier = Modifier, hot: Color = pal.secondary) {
    val p = pal
    val base = (if (p.dark) Color(0xFF3A3F47) else Color(0xFFDCE4EB)).toArgb()
    val off = (if (p.dark) Color(0xFF4C535D) else Color(0xFFC3CFDA)).toArgb()
    androidx.compose.foundation.Canvas(modifier.fillMaxWidth().aspectRatio(1.25f)) {
        drawIntoCanvas { BodyMap.draw(it.nativeCanvas, size.width, size.height, intensity, base, off, hot.toArgb(), p.inkSoft.toArgb()) }
    }
}
