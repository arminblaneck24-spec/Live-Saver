package com.lifesave.system

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import com.lifesave.core.APP_NAME
import com.lifesave.core.Locks
import com.lifesave.core.Store
import com.lifesave.training.ExerciseDb

fun guardOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/")
}

/**
 * Wächter (Bedienungshilfe):
 *  - Solange Wiegen oder Tagesabschluss offen sind, wird jede andere App auf Life Save umgeleitet.
 *    Telefon, Notruf, Uhr und Tastatur bleiben immer frei.
 *  - Schützt die eigenen Einstellungsseiten (App-Info, Bedienungshilfe) vor dem Ausschalten ohne Passwort.
 */
class GuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastRedirect = 0L
    private var keyboards: Set<String> = emptySet()

    private val tick = object : Runnable {
        override fun run() {
            runCatching { onTick() }
            handler.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(this)
        ExerciseDb.init(this)
        keyboards = runCatching {
            getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
        }.getOrDefault(emptySet())
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private val ALWAYS_FREE = setOf(
        "com.android.systemui", "android",
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer", "com.android.phone",
        "com.samsung.android.incallui", "com.android.incallui", "com.android.server.telecom", "com.android.contacts",
        "com.samsung.android.app.contacts", "com.android.emergency", "com.samsung.android.emergency", "com.google.android.apps.safetyhub",
        "com.android.deskclock", "com.google.android.deskclock", "com.sec.android.app.clockpackage",
        // Kamera für das Fortschrittsfoto beim Wiegen
        "com.sec.android.app.camera", "com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2",
        // Google-Dienste (Barcode-Scanner, Health Connect)
        "com.google.android.gms", "com.google.android.apps.healthdata", "com.google.android.healthconnect.controller",
        "com.google.android.documentsui", "com.android.documentsui", "com.google.android.providers.media.module", "com.android.providers.media"
    )

    private fun free(pkg: String) = pkg == packageName || pkg in ALWAYS_FREE || pkg in keyboards || pkg.contains("inputmethod") || pkg.contains("keyboard")

    private fun guarded(p: String) = p == "com.android.settings" || p.contains("packageinstaller") || p == "com.samsung.accessibility"

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (guarded(pkg)) { runCatching { checkProtection() }; return }
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) checkLock(pkg)
    }

    private fun checkLock(pkg: String) {
        if (free(pkg)) return
        if (Locks.pending() == null) return
        redirect()
    }

    private fun onTick() {
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        if (getSystemService(KeyguardManager::class.java).isKeyguardLocked) return
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (guarded(pkg)) { if (Locks.pending() != null && !Store.adminActive() && System.currentTimeMillis() >= Updater.installUntil) redirect(); return }
        checkLock(pkg)
    }

    private fun redirect() {
        val n = System.currentTimeMillis()
        if (n - lastRedirect < 900) return
        lastRedirect = n
        openApp(this)
    }

    /** App-Info, Deinstallieren und Bedienungshilfe-Seite dieser App nur mit Passwort */
    private fun checkProtection() {
        if (!Store.state.settings.protect || Store.adminActive() || System.currentTimeMillis() < Updater.installUntil) return
        val root = rootInActiveWindow ?: return
        if (root.findAccessibilityNodeInfosByText(APP_NAME).isNotEmpty()) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            redirect()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        Store.flush()
        super.onDestroy()
    }
}
