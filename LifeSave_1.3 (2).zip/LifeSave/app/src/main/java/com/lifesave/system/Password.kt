package com.lifesave.system

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

// Passwort wechselt alle 5 Minuten (Zeitfenster seit 1970 in UTC)
object Pw {
    private const val A = "957b81556ff9e4738d86788d6030d81c871c4bf19799c1761b9abede1d3fa253"
    private const val B = "d255795c2ce71e5495b95e85b46a4aff967f91321f7d389e3f7d2d1e624fb3b9"
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    private fun key(): ByteArray { val a = hex(A); val b = hex(B); return ByteArray(a.size) { (a[it].toInt() xor b[it].toInt()).toByte() } }

    fun at(slot: Long): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key(), "HmacSHA256"))
        val h = mac.doFinal("UT2|$slot".toByteArray(Charsets.UTF_8))
        return (0 until 8).map { ALPHABET[h[it].toInt() and 31] }.joinToString("")
    }

    fun slot(now: Long = System.currentTimeMillis()) = now / 1000 / 300

    // aktuelles und vorheriges Passwort gelten (Puffer fürs Abtippen)
    fun check(input: String): Boolean {
        val i = input.trim().uppercase()
        val s = slot()
        return i.isNotEmpty() && (i == at(s) || i == at(s - 1))
    }
}
