package com.lifesave.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.util.concurrent.Executors

/** Etwas, das gefeiert wird (Rekord, Abzeichen, Level-Up ...) */
data class Celebration(val title: String, val lines: List<String>, val emoji: String = "🏆")

/**
 * Zentraler Speicher. Der Zustand ist Compose-State: jede Oberfläche, die Store.state liest,
 * aktualisiert sich automatisch. Gespeichert wird verzögert im Hintergrund.
 */
object Store {
    var state by mutableStateOf(AppState()); private set
    val celebrations = mutableStateListOf<Celebration>()
    var adminUntil by mutableStateOf(0L); private set
    /** Ende der Satzpause, für das schon vibriert wurde (nicht gespeichert) */
    var restAlerted = 0L

    lateinit var app: Context; private set
    private var file: File? = null
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val writeTask = Runnable { val snap = state; io.execute { writeNow(snap) } }

    /** wird nach Änderungen aufgerufen (z. B. Widget aktualisieren) */
    var onChanged: (() -> Unit)? = null
    private val changedTask = Runnable { onChanged?.invoke() }

    val photoDir: File get() = File(app.filesDir, "photos").apply { mkdirs() }

    fun init(c: Context) {
        if (file != null) return
        app = c.applicationContext
        val f = File(app.filesDir, "data.json")
        file = f
        state = if (f.exists()) runCatching { Json.decode(f.readText()) }.getOrDefault(AppState()) else AppState()
        Tasks.archiveOld()
    }

    fun update(f: (AppState) -> AppState) {
        state = f(state)
        main.removeCallbacks(writeTask); main.postDelayed(writeTask, 400)
        main.removeCallbacks(changedTask); main.postDelayed(changedTask, 1500)
    }

    @Synchronized
    private fun writeNow(s: AppState) {
        val f = file ?: return
        runCatching {
            val tmp = File(f.parentFile, "data.json.tmp")
            tmp.writeText(Json.encode(s))
            if (!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
        }
    }

    /** sofort speichern (z. B. wenn die App in den Hintergrund geht) */
    fun flush() { main.removeCallbacks(writeTask); writeNow(state) }

    fun replace(s: AppState) = update { s }
    fun setSettings(f: (Settings) -> Settings) = update { it.copy(settings = f(it.settings)) }

    fun celebrate(c: Celebration) { celebrations.add(c) }

    // ---------- Admin (Passwort) ----------
    fun adminActive() = now() < adminUntil
    fun unlockAdmin() { adminUntil = now() + 10 * 60_000L }
    fun lockAdmin() { adminUntil = 0L }
}
