package com.lifesave.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*

// ================= Übungsdatenbank =================
private object ExFilter {
    var q by mutableStateOf("")
    var group by mutableStateOf<String?>(null)
    var equip by mutableStateOf<String?>(null)
}

@Composable
fun ExercisesScreen(pick: Boolean) {
    val p = pal
    val st = Store.state
    val list = remember(ExFilter.q, ExFilter.group, ExFilter.equip, st.customEx) { ExerciseDb.search(ExFilter.q, ExFilter.group, ExFilter.equip) }
    var showEquip by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp)) {
            Field(ExFilter.q, { ExFilter.q = it }, "Übung suchen (deutsch oder englisch)")
            LazyRow(Modifier.padding(top = 8.dp)) {
                item { Pick("Alle", ExFilter.group == null) { ExFilter.group = null } }
                items(MUSCLE_GROUPS.keys.toList()) { g -> Pick(g, ExFilter.group == g) { ExFilter.group = if (ExFilter.group == g) null else g } }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Muted("${list.size} Übungen", Modifier.weight(1f))
                Btn(if (ExFilter.equip == null) "Geräte ▾" else equipDe(ExFilter.equip!!) + " ✕", small = true, kind = BtnKind.GHOST) {
                    if (ExFilter.equip != null) ExFilter.equip = null else showEquip = !showEquip
                }
            }
            if (showEquip) ChipRow { EQUIPMENT.forEach { (k, v) -> Pick(v, ExFilter.equip == k) { ExFilter.equip = k; showEquip = false } } }
        }
        Box(Modifier.weight(1f)) {
            Screen {
                item { Btn("+ Eigene Übung anlegen", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) { Nav.go("exercise_new") } }
                items(list.take(250), key = { it.id }) { e ->
                    Panel(padding = 10.dp, onClick = { if (pick) Nav.deliverPick(e.id) else Nav.go("exercise", e.id) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ExImage(e.images, Modifier.size(56.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Body(e.name, bold = true, maxLines = 2)
                                Muted(e.primary.joinToString(", ") { muscleDe(it) } + " · " + equipDe(e.equipment), maxLines = 1)
                                if (e.name != e.en) Muted(e.en, size = 11.sp, maxLines = 1)
                            }
                            if (e.popular >= 0) Pill("★", p.gold)
                            if (e.custom) Pill("eigene", p.primary)
                            if (pick) { Spacer(Modifier.width(6.dp)); Btn("+", small = true) { Nav.deliverPick(e.id) } }
                        }
                    }
                }
                if (list.size > 250) item { Muted("Weitere ${list.size - 250} Treffer – Suche genauer eingrenzen.") }
            }
        }
    }
}

// ================= Übung im Detail =================
@Composable
fun ExerciseDetail(id: String) {
    val p = pal
    val ctx = LocalContext.current
    val st = Store.state
    val e = ExerciseDb.get(id) ?: run { Empty("Übung nicht gefunden"); return }
    val history = st.workouts.sortedBy { it.start }.mapNotNull { w -> w.exercises.find { it.exId == id }?.let { w to it } }
    val best = Training.bests(id, st)
    var link by remember(id) { mutableStateOf(st.exLinks[id] ?: "") }
    var chartKind by remember { mutableIntStateOf(0) }
    Screen {
        item {
            Panel(padding = 0.dp) {
                if (e.images.isNotEmpty()) ExImage(e.images, Modifier.fillMaxWidth().aspectRatio(1.5f), animate = true)
                Column(Modifier.padding(14.dp)) {
                    Title(e.name)
                    if (e.name != e.en) Muted(e.en)
                    Spacer(Modifier.height(6.dp))
                    ChipRow {
                        Pill(equipDe(e.equipment), p.primary)
                        Spacer(Modifier.width(6.dp))
                        CATEGORIES[e.category]?.let { Pill(it, p.inkSoft); Spacer(Modifier.width(6.dp)) }
                        LEVELS[e.level]?.let { Pill(it, p.gold) }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("Trainierte Muskeln")
                Mannequin(Training.exerciseIntensity(e))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill("Haupt", p.secondary); Spacer(Modifier.width(6.dp))
                    Body(e.primary.joinToString(", ") { muscleDe(it) }, size = 14.sp)
                }
                if (e.secondary.isNotEmpty()) Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pill("Neben", p.secondary.copy(alpha = 0.6f)); Spacer(Modifier.width(6.dp))
                    Body(e.secondary.joinToString(", ") { muscleDe(it) }, size = 14.sp)
                }
            }
        }
        item {
            Panel {
                Heading("Ausführung")
                Btn("▶ Erklärvideo auf YouTube", Modifier.fillMaxWidth(), BtnKind.DANGER) {
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ExerciseDb.youtubeUrl(e)))) }
                }
                Spacer(Modifier.height(8.dp))
                if (e.instructions.isEmpty()) Muted("Keine Anleitung hinterlegt.")
                e.instructions.forEachIndexed { i, s ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        BigNumber("${i + 1}", p.primary, 16.sp)
                        Spacer(Modifier.width(10.dp))
                        Body(s, size = 14.sp)
                    }
                }
                if (!e.custom) Muted("Anleitung vorerst auf Englisch.", Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(8.dp))
                Field(link, { link = it; ExerciseDb.setLink(id, it) }, "Eigener Video-Link (optional)")
            }
        }
        item {
            Panel {
                Heading("Deine Werte")
                if (best == null) Empty("Noch nicht trainiert")
                else {
                    Row {
                        StatBox("Max. Gewicht", fmtKg(best.weight) + " kg", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                        StatBox("1RM (geschätzt)", fmtKg(Math.round(best.e1rm * 10) / 10.0) + " kg", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row {
                        StatBox("Bestes Volumen", fmtNum(best.volume), Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                        StatBox("Einheiten", "${history.size}", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    ChipRow {
                        Pick("Max. Gewicht", chartKind == 0) { chartKind = 0 }
                        Pick("Volumen", chartKind == 1) { chartKind = 1 }
                        Pick("1RM", chartKind == 2) { chartKind = 2 }
                    }
                    val pts = history.map { (w, we) ->
                        val b = Training.bestOf(we)
                        w.start to when (chartKind) { 1 -> b.volume; 2 -> b.e1rm; else -> b.weight }
                    }
                    LineChart(pts, unit = "")
                    Sep()
                    history.takeLast(8).reversed().forEach { (w, we) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            Muted(fmtShort(w.start), Modifier.width(56.dp))
                            Body(we.sets.filter { it.done }.joinToString("  ") { "${fmtKg(it.weight)}×${it.reps}" }, size = 14.sp)
                        }
                    }
                }
                val recs = st.records.filter { it.exId == id }.sortedByDescending { it.at }.take(5)
                if (recs.isNotEmpty()) {
                    Sep()
                    recs.forEach { Muted("🏆 ${Training.recordText(it)} · ${fmtDate(it.at)}") }
                }
            }
        }
        if (e.custom) item {
            Btn("Eigene Übung löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { ExerciseDb.deleteCustom(id); Nav.back() }
        }
    }
}

// ================= Eigene Übung =================
@Composable
fun CustomExerciseEditor() {
    var name by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var equip by remember { mutableStateOf("other") }
    val prim = remember { mutableStateListOf<String>() }
    val sec = remember { mutableStateListOf<String>() }
    Screen {
        item {
            Panel {
                Field(name, { name = it }, "Name der Übung")
                Spacer(Modifier.height(6.dp))
                Field(note, { note = it }, "Kurze Anleitung (optional)", singleLine = false, minLines = 2)
            }
        }
        item {
            Panel {
                Heading("Hauptmuskeln")
                ChipRow { MUSCLES.forEach { (k, v) -> Pick(v, k in prim) { if (k in prim) prim.remove(k) else { prim.add(k); sec.remove(k) } } } }
                Heading("Nebenmuskeln")
                ChipRow { MUSCLES.forEach { (k, v) -> Pick(v, k in sec, color = pal.inkSoft) { if (k in sec) sec.remove(k) else if (k !in prim) sec.add(k) } } }
                Heading("Gerät")
                ChipRow { EQUIPMENT.forEach { (k, v) -> Pick(v, equip == k) { equip = k } } }
                Mannequin(sec.associateWith { 0.45f } + prim.associateWith { 1f })
            }
        }
        item {
            Btn("Speichern", Modifier.fillMaxWidth(), enabled = name.isNotBlank() && prim.isNotEmpty()) {
                ExerciseDb.addCustom(name.trim(), prim.toList(), sec.toList(), equip, note.trim())
                Nav.back()
            }
        }
    }
}
