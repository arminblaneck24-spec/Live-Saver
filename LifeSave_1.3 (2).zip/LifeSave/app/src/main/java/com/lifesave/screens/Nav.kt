package com.lifesave.screens

import androidx.compose.runtime.mutableStateListOf

/** Eine Seite der App. arg = z. B. ID der Übung/Aufgabe */
data class Route(val name: String, val arg: String = "")

/**
 * Einfache Navigation mit Rückwärts-Stapel.
 * Neue Seiten: Namen hier vergeben und in Shell.kt im `when` eintragen.
 */
object Nav {
    val stack = mutableStateListOf(Route("dashboard"))
    val current: Route get() = stack.last()

    /** Übungsauswahl: wer die Auswahl gestartet hat, bekommt die gewählte ID */
    var pickHandler: ((String) -> Unit)? = null

    fun go(name: String, arg: String = "") { stack.add(Route(name, arg)) }
    fun back(): Boolean { if (stack.size <= 1) return false; stack.removeAt(stack.size - 1); return true }
    fun root(name: String) { stack.clear(); stack.add(Route(name)) }
    fun replace(name: String, arg: String = "") { if (stack.isNotEmpty()) stack.removeAt(stack.size - 1); stack.add(Route(name, arg)) }

    fun pickExercise(onPick: (String) -> Unit) { pickHandler = onPick; go("exercises", "pick") }
    fun deliverPick(id: String) { val h = pickHandler; pickHandler = null; back(); h?.invoke(id) }
}
