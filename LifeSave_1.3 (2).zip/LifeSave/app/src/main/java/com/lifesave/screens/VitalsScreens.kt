package com.lifesave.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*

/** Fortschrittsring */
@Composable
fun Ring(fraction: Float, color: Color, size: Dp = 84.dp, stroke: Dp = 10.dp, content: @Composable () -> Unit) {
    val p = pal
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.toPx()
            val r = Size(this.size.width - s, this.size.height - s)
            drawArc(p.line, -90f, 360f, false, Offset(s / 2, s / 2), r, style = Stroke(s))
            drawArc(color, -90f, 360f * fraction.coerceIn(0f, 1f), false, Offset(s / 2, s / 2), r, style = Stroke(s, cap = StrokeCap.Round))
        }
        content()
    }
}

// ---------- Kachel: Wochenziel ----------
@Composable
fun WeekTile(st: AppState) {
    val p = pal
    val goal = st.settings.weeklyGoal.coerceAtLeast(1)
    val c = Training.weekCount(st)
    val days = (0..6).map { addDays(startOfWeek(now()), it) }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ring(c / goal.toFloat(), if (c >= goal) p.good else p.primary) {
                Text("$c/$goal", fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = p.ink)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Heading("Wochenziel")
                Body(if (c >= goal) "Geschafft! 🎯" else "Noch ${goal - c} Workout${if (goal - c == 1) "" else "s"} diese Woche", bold = true)
                Muted("🎯 ${Training.weekStreak(st)} Wochen in Folge")
                Row(Modifier.padding(top = 6.dp)) {
                    days.forEachIndexed { i, d ->
                        val trained = st.workouts.any { startOfDay(it.start) == d }
                        val today = d == startOfDay(now())
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(WEEKDAYS[i].second, fontSize = 11.sp, color = if (today) p.primary else p.inkSoft,
                                fontWeight = if (today) FontWeight.Bold else FontWeight.Normal)
                            Text(if (trained) "●" else "○", fontSize = 14.sp, color = if (trained) p.good else p.line)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Kachel: Schlaf, Wasser, Schritte ----------
@Composable
fun VitalsTile(st: AppState) {
    val p = pal
    val s = st.settings
    val water = Vitals.water(st)
    val sleep = Vitals.sleep(st)
    val steps = Vitals.steps(st)
    Panel {
        Heading("Schlaf, Wasser & Schritte")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Ring(water / s.waterGoal.coerceAtLeast(1).toFloat(), Color(0xFF2E9BD6), 72.dp, 8.dp) { Text("💧", fontSize = 22.sp) }
                Body("$water/${s.waterGoal}", bold = true)
                Muted("Gläser")
                Row {
                    Btn("−", small = true, kind = BtnKind.GHOST) { Vitals.addWater(-1) }
                    Spacer(Modifier.width(4.dp))
                    Btn("+", small = true) { Vitals.addWater(1) }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Ring(((sleep ?: 0.0) / s.sleepGoal).toFloat(), Color(0xFF7E57C2), 72.dp, 8.dp) { Text("😴", fontSize = 22.sp) }
                Body(sleep?.let { Vitals.fmtHours(it) } ?: "–", bold = true)
                Muted("letzte Nacht")
                Row {
                    Btn("−", small = true, kind = BtnKind.GHOST) { Vitals.setSleep(((sleep ?: s.sleepGoal) - 0.5)) }
                    Spacer(Modifier.width(4.dp))
                    Btn("+", small = true) { Vitals.setSleep((sleep ?: (s.sleepGoal - 0.5)) + 0.5) }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Ring(((steps ?: 0L) / s.stepGoal.coerceAtLeast(1).toFloat()), p.good, 72.dp, 8.dp) { Text("👟", fontSize = 22.sp) }
                Body(steps?.let { String.format(java.util.Locale.GERMAN, "%,d", it) } ?: "–", bold = true)
                Muted(if (s.hcEnabled) "Schritte" else "über Health Connect")
            }
        }
        Vitals.sleepStrengthEffect(st)?.let { (pct, n) ->
            Sep()
            Muted("💡 Nach ≥ 7,5 Std. Schlaf warst du im Schnitt ${if (pct >= 0) "%.0f %% stärker".format(pct) else "%.0f %% schwächer".format(-pct)} als nach < 7 Std. ($n Workouts)")
        }
    }
}
