package com.lifesave.core

import java.io.File
import java.io.InputStream

object BodyLog {
    fun latest(s: AppState = Store.state): WeightEntry? = s.weights.maxByOrNull { it.at }
    fun sorted(s: AppState = Store.state) = s.weights.sortedBy { it.at }

    /** Veränderung gegenüber dem Eintrag, der etwa [days] Tage zurückliegt */
    fun change(days: Int, s: AppState = Store.state): Double? {
        val l = latest(s) ?: return null
        val ref = s.weights.filter { it.at <= addDays(l.at, -days) }.maxByOrNull { it.at } ?: s.weights.minByOrNull { it.at } ?: return null
        if (ref.id == l.id) return null
        return l.kg - ref.kg
    }

    fun addWeight(kg: Double, at: Long = now()) {
        val e = WeightEntry(kg = kg, at = at)
        Store.update { it.copy(weights = it.weights + e) }
        Rewards.addXp(e.id, "Gewogen", "weigh", 10)
    }

    fun deleteWeight(id: Long) = Store.update { s -> s.copy(weights = s.weights.filterNot { it.id == id }) }

    // ---------- Fortschrittsfotos (privat im App-Speicher, nicht in der Galerie) ----------
    fun newPhotoFile(): File = File(Store.photoDir, "p_${newId()}.jpg")

    fun addPhoto(file: File, category: String = "") {
        if (!file.exists() || file.length() == 0L) return
        // pro Tag und Kategorie nur ein Foto: altes ersetzen
        val today = startOfDay(now())
        Store.state.photos.filter { category.isNotBlank() && it.category == category && startOfDay(it.at) == today }.forEach { deletePhoto(it) }
        val p = PhotoEntry(file = file.name, category = category)
        Store.update { it.copy(photos = it.photos + p) }
        Rewards.addXp(p.id, "Fortschrittsfoto", "photo", 5)
    }

    fun importPhoto(input: InputStream, category: String = "") {
        val f = newPhotoFile()
        input.use { i -> f.outputStream().use { i.copyTo(it) } }
        addPhoto(f, category)
    }

    /** Fotos gruppiert nach Tag (neueste zuerst) */
    fun photoDays(s: AppState = Store.state): List<Pair<Long, List<PhotoEntry>>> =
        s.photos.groupBy { startOfDay(it.at) }.toList().sortedByDescending { it.first }

    /** Kategorien in fester Reihenfolge (eigene + evtl. alte ohne Kategorie) */
    fun catLabel(p: PhotoEntry) = p.category.ifBlank { "Sonstige" }

    /** gleitender 7-Tage-Durchschnitt des Gewichts (je Tag) */
    fun avg7(s: AppState = Store.state): List<Pair<Long, Double>> {
        val byDay = s.weights.groupBy { startOfDay(it.at) }.mapValues { e -> e.value.minByOrNull { it.at }!!.kg }.toSortedMap()
        return byDay.keys.map { d -> d to byDay.filterKeys { it > addDays(d, -7) && it <= d }.values.average() }
    }

    fun fileOf(p: PhotoEntry) = File(Store.photoDir, p.file)

    fun deletePhoto(p: PhotoEntry) {
        runCatching { fileOf(p).delete() }
        Store.update { s -> s.copy(photos = s.photos.filterNot { it.id == p.id }) }
    }
}
