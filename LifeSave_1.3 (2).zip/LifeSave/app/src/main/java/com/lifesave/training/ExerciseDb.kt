package com.lifesave.training

import android.content.Context
import com.lifesave.core.*
import org.json.JSONArray

/** Eine Übung – aus der freien Datenbank (free-exercise-db, Public Domain) oder selbst angelegt */
data class Ex(
    val id: String,
    val name: String,          // Anzeigename (deutsch, falls vorhanden)
    val en: String,            // Originalname
    val primary: List<String>,
    val secondary: List<String>,
    val equipment: String,
    val category: String,
    val level: String,
    val instructions: List<String>,
    val images: List<String>,
    val popular: Int,          // -1 = nicht in der Favoritenliste
    val custom: Boolean = false
)

val MUSCLES = linkedMapOf(
    "chest" to "Brust", "shoulders" to "Schultern", "biceps" to "Bizeps", "triceps" to "Trizeps",
    "forearms" to "Unterarme", "abdominals" to "Bauch", "lats" to "Latissimus", "middle back" to "Oberer Rücken",
    "lower back" to "Unterer Rücken", "traps" to "Trapez", "neck" to "Nacken", "quadriceps" to "Beinstrecker (Quads)",
    "hamstrings" to "Beinbeuger", "glutes" to "Gesäß", "calves" to "Waden", "adductors" to "Adduktoren", "abductors" to "Abduktoren"
)

/** grobe Gruppen für Filter und Übersicht */
val MUSCLE_GROUPS = linkedMapOf(
    "Brust" to listOf("chest"),
    "Rücken" to listOf("lats", "middle back", "lower back", "traps"),
    "Schultern" to listOf("shoulders"),
    "Arme" to listOf("biceps", "triceps", "forearms"),
    "Bauch" to listOf("abdominals"),
    "Beine" to listOf("quadriceps", "hamstrings", "glutes", "calves", "adductors", "abductors"),
    "Nacken" to listOf("neck")
)

val EQUIPMENT = linkedMapOf(
    "barbell" to "Langhantel", "dumbbell" to "Kurzhantel", "machine" to "Maschine", "cable" to "Kabelzug",
    "body only" to "Körpergewicht", "kettlebells" to "Kettlebell", "e-z curl bar" to "SZ-Stange", "bands" to "Band",
    "medicine ball" to "Medizinball", "exercise ball" to "Gymnastikball", "foam roll" to "Faszienrolle", "other" to "Sonstiges"
)

val CATEGORIES = mapOf(
    "strength" to "Kraft", "stretching" to "Dehnen", "plyometrics" to "Sprungkraft", "powerlifting" to "Powerlifting",
    "olympic weightlifting" to "Gewichtheben", "strongman" to "Strongman", "cardio" to "Cardio"
)

val LEVELS = mapOf("beginner" to "Anfänger", "intermediate" to "Fortgeschritten", "expert" to "Experte")

fun muscleDe(m: String) = MUSCLES[m] ?: m
fun equipDe(e: String) = EQUIPMENT[e] ?: e

object ExerciseDb {
    private var base: List<Ex> = emptyList()
    private var byId: Map<String, Ex> = emptyMap()

    fun init(c: Context) {
        if (base.isNotEmpty()) return
        val text = runCatching { c.assets.open("exercises.json").bufferedReader().use { it.readText() } }.getOrNull() ?: return
        val a = JSONArray(text)
        fun strs(o: org.json.JSONObject, k: String) = o.optJSONArray(k)?.let { x -> (0 until x.length()).map { x.optString(it) } } ?: emptyList()
        base = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val en = o.optString("n")
            Ex(
                id = o.optString("id"), name = o.optString("de").ifBlank { en }, en = en,
                primary = strs(o, "p"), secondary = strs(o, "s"), equipment = o.optString("e", "other"),
                category = o.optString("c"), level = o.optString("l"), instructions = strs(o, "i"),
                images = strs(o, "img"), popular = o.optInt("pop", -1)
            )
        }
        byId = base.associateBy { it.id }
    }

    private fun customs(s: AppState = Store.state) = s.customEx.map {
        Ex(it.id, it.name, it.name, it.primary, it.secondary, it.equipment, "strength", "", listOfNotNull(it.note.ifBlank { null }), emptyList(), -1, true)
    }

    fun all(): List<Ex> = customs() + base

    fun get(id: String): Ex? = byId[id] ?: customs().find { it.id == id }

    fun name(id: String) = get(id)?.name ?: "Unbekannte Übung"

    /** Beliebte zuerst (in fester Reihenfolge), dann eigene, dann alphabetisch */
    fun sorted(list: List<Ex>): List<Ex> = list.sortedWith(
        compareBy<Ex>({ if (it.popular >= 0) 0 else if (it.custom) 1 else 2 }, { if (it.popular >= 0) it.popular else 0 }, { it.name.lowercase() })
    )

    fun search(q: String, group: String?, equipment: String?): List<Ex> {
        val muscles = group?.let { MUSCLE_GROUPS[it] }
        val words = q.trim().lowercase().split(" ").filter { it.isNotBlank() }
        return sorted(all().filter { e ->
            (muscles == null || e.primary.any { it in muscles }) &&
                (equipment == null || e.equipment == equipment) &&
                words.all { w -> e.name.lowercase().contains(w) || e.en.lowercase().contains(w) || e.primary.any { muscleDe(it).lowercase().contains(w) } }
        })
    }

    fun addCustom(name: String, primary: List<String>, secondary: List<String>, equipment: String, note: String): String {
        val id = "c_" + newId()
        Store.update { it.copy(customEx = it.customEx + CustomExercise(id, name, primary, secondary, equipment, note)) }
        return id
    }

    fun deleteCustom(id: String) = Store.update { s -> s.copy(customEx = s.customEx.filterNot { it.id == id }) }

    fun setLink(id: String, url: String) = Store.update { s ->
        s.copy(exLinks = if (url.isBlank()) s.exLinks - id else s.exLinks + (id to url.trim()))
    }

    fun youtubeUrl(e: Ex): String {
        val custom = Store.state.exLinks[e.id]
        if (!custom.isNullOrBlank()) return custom
        return "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(e.en + " exercise proper form", "UTF-8")
    }
}
