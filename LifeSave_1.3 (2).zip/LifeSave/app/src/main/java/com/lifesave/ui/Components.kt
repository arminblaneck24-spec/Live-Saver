@file:OptIn(ExperimentalLayoutApi::class)

package com.lifesave.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** aktuelle Palette */
val pal: Palette
    @Composable @ReadOnlyComposable get() = LocalPalette.current

val CardShape = RoundedCornerShape(10.dp)

// ---------- Layout ----------
@Composable
fun Screen(content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    accent: Color? = null,
    onClick: (() -> Unit)? = null,
    padding: Dp = 14.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = pal
    Column(
        modifier.fillMaxWidth().clip(CardShape).background(p.panel).border(1.dp, p.line, CardShape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        if (accent != null) Box(Modifier.fillMaxWidth().height(4.dp).background(accent))
        Column(Modifier.fillMaxWidth().padding(padding), content = content)
    }
}

// ---------- Text ----------
@Composable
fun Title(t: String, modifier: Modifier = Modifier, color: Color = pal.ink, size: TextUnit = 26.sp) =
    Text(t.uppercase(), modifier, color = color, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = size, letterSpacing = 0.5.sp)

@Composable
fun Heading(t: String, modifier: Modifier = Modifier, color: Color = pal.inkSoft) =
    Text(t.uppercase(), modifier.padding(top = 2.dp, bottom = 4.dp), color = color, fontFamily = Barlow,
        fontWeight = FontWeight.SemiBold, fontSize = 15.sp, letterSpacing = 1.sp)

@Composable
fun Body(t: String, modifier: Modifier = Modifier, color: Color = pal.ink, bold: Boolean = false, size: TextUnit = 15.sp, maxLines: Int = Int.MAX_VALUE) =
    Text(t, modifier, color = color, fontSize = size, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis)

@Composable
fun Muted(t: String, modifier: Modifier = Modifier, color: Color = pal.inkSoft, size: TextUnit = 13.sp, maxLines: Int = Int.MAX_VALUE) =
    Text(t, modifier, color = color, fontSize = size, maxLines = maxLines, overflow = TextOverflow.Ellipsis)

@Composable
fun BigNumber(t: String, color: Color = pal.ink, size: TextUnit = 30.sp) =
    Text(t, color = color, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = size)

// ---------- Buttons ----------
enum class BtnKind { PRIMARY, SECONDARY, GHOST, DANGER, GOLD }

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.PRIMARY, enabled: Boolean = true, small: Boolean = false, onClick: () -> Unit) {
    val p = pal
    val (bg, fg) = when (kind) {
        BtnKind.PRIMARY -> p.primary to p.onPrimary
        BtnKind.SECONDARY -> p.soft to p.primary
        BtnKind.GHOST -> Color.Transparent to p.primary
        BtnKind.DANGER -> p.secondary to Color.White
        BtnKind.GOLD -> p.gold to Color(0xFF12161C)
    }
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.clip(shape).background(if (enabled) bg else p.line)
            .then(if (kind == BtnKind.GHOST) Modifier.border(1.dp, p.line, shape) else Modifier)
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = if (small) 10.dp else 16.dp, vertical = if (small) 6.dp else 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text.uppercase(), color = if (enabled) fg else p.inkSoft, fontFamily = Barlow, fontWeight = FontWeight.Bold,
            fontSize = if (small) 14.sp else 16.sp, letterSpacing = 0.8.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
fun Pick(text: String, selected: Boolean, modifier: Modifier = Modifier, color: Color = pal.primary, onClick: () -> Unit) {
    val p = pal
    val shape = RoundedCornerShape(50)
    Box(
        modifier.padding(end = 6.dp, bottom = 6.dp).clip(shape)
            .background(if (selected) color else p.panel)
            .border(1.dp, if (selected) color else p.line, shape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(text, color = if (selected) (if (color.lum() > 0.6f) Color(0xFF12161C) else Color.White) else p.ink, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
fun ChipRow(content: @Composable () -> Unit) = FlowRow(Modifier.fillMaxWidth()) { content() }

@Composable
fun IconBtn(symbol: String, modifier: Modifier = Modifier, color: Color = pal.ink, size: Dp = 40.dp, onClick: () -> Unit) {
    Box(modifier.size(size).clip(CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(symbol, color = color, fontSize = 20.sp)
    }
}

@Composable
fun Check(checked: Boolean, color: Color = pal.primary, size: Dp = 30.dp, onClick: () -> Unit) {
    val p = pal
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.size(size).clip(shape).background(if (checked) color else p.panel)
            .border(2.dp, if (checked) color else p.line, shape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { if (checked) Text("✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

@Composable
fun Stepper(value: String, onMinus: () -> Unit, onPlus: () -> Unit, label: String = "") {
    val p = pal
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (label.isNotBlank()) Muted(label, Modifier.padding(end = 8.dp))
        Box(Modifier.size(34.dp).clip(CircleShape).background(p.soft).clickable { onMinus() }, contentAlignment = Alignment.Center) {
            Text("−", color = p.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Text(value, Modifier.widthIn(min = 44.dp).padding(horizontal = 6.dp), textAlign = TextAlign.Center,
            fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = p.ink)
        Box(Modifier.size(34.dp).clip(CircleShape).background(p.soft).clickable { onPlus() }, contentAlignment = Alignment.Center) {
            Text("+", color = p.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

// ---------- Eingaben ----------
@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    number: Boolean = false, decimal: Boolean = false, singleLine: Boolean = true, minLines: Int = 1, caps: Boolean = false
) {
    val p = pal
    OutlinedTextField(
        value, onChange, modifier = modifier, label = { Text(label) }, singleLine = singleLine, minLines = minLines,
        shape = RoundedCornerShape(8.dp),
        keyboardOptions = KeyboardOptions(
            keyboardType = when { decimal -> KeyboardType.Decimal; number -> KeyboardType.Number; else -> KeyboardType.Text },
            capitalization = if (caps) KeyboardCapitalization.Characters else KeyboardCapitalization.Sentences
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = p.primary, unfocusedBorderColor = p.line,
            focusedContainerColor = p.panel, unfocusedContainerColor = p.panel,
            focusedTextColor = p.ink, unfocusedTextColor = p.ink, focusedLabelColor = p.primary, unfocusedLabelColor = p.inkSoft
        )
    )
}

/**
 * Kleines Zahlenfeld (kg / Wdh. im Workout). Leere Felder zeigen [placeholder] grau an –
 * antippen und direkt tippen, ohne etwas löschen zu müssen. Ändert sich [value] von außen
 * (z. B. automatisch ausgefüllt), wird das Feld angepasst.
 */
@Composable
fun NumField(value: String, placeholder: String, modifier: Modifier = Modifier, decimal: Boolean = true, done: Boolean = false, onValue: (String) -> Unit) {
    var t by remember { mutableStateOf(value) }
    LaunchedEffect(value) {
        val a = t.replace(',', '.').toDoubleOrNull(); val b = value.replace(',', '.').toDoubleOrNull()
        if (a != b) t = value
    }
    val p = pal
    OutlinedTextField(
        t, { v -> t = v.filter { it.isDigit() || it == ',' || it == '.' }.take(6); onValue(t) },
        modifier = modifier.heightIn(min = 48.dp), singleLine = true,
        placeholder = { Text(placeholder, Modifier.fillMaxWidth(), color = p.inkSoft.copy(alpha = 0.6f), textAlign = TextAlign.Center,
            fontFamily = Barlow, fontWeight = FontWeight.SemiBold, fontSize = 18.sp) },
        textStyle = LocalTextStyle.current.copy(fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center),
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = p.primary, unfocusedBorderColor = if (done) p.good.copy(alpha = 0.5f) else p.line,
            focusedContainerColor = p.bg, unfocusedContainerColor = if (done) p.good.copy(alpha = 0.10f) else p.bg,
            focusedTextColor = p.ink, unfocusedTextColor = p.ink
        )
    )
}

@Composable
fun ToggleRow(label: String, checked: Boolean, sub: String = "", onChange: (Boolean) -> Unit) {
    val p = pal
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Body(label)
            if (sub.isNotBlank()) Muted(sub)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = Color.White))
    }
}

@Composable
fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }, verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = pal.primary))
        Body(label)
    }
}

// ---------- Anzeigen ----------
@Composable
fun Bar(fraction: Float, color: Color = pal.primary, modifier: Modifier = Modifier, height: Dp = 8.dp) {
    val p = pal
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(p.line)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable
fun StatBox(label: String, value: String, modifier: Modifier = Modifier, color: Color = pal.ink) {
    val p = pal
    Column(modifier.clip(RoundedCornerShape(8.dp)).background(p.bg).padding(10.dp)) {
        Text(value, color = color, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1)
        Muted(label, size = 12.sp, maxLines = 1)
    }
}

@Composable
fun Sep() = Box(Modifier.fillMaxWidth().padding(vertical = 6.dp).height(1.dp).background(pal.line))

@Composable
fun Pill(text: String, color: Color = pal.primary) {
    Text(text, Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 2.dp),
        color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
}

@Composable
fun Empty(t: String) = Muted(t, Modifier.fillMaxWidth().padding(vertical = 8.dp))

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String = "Ja", onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton({ onConfirm(); onDismiss() }) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Abbrechen") } }
    )
}

/** Reihe mit Hoch/Runter zum Sortieren, Schalter zum Ein-/Ausblenden */
@Composable
fun OrderRow(label: String, visible: Boolean, onToggle: (Boolean) -> Unit, onUp: (() -> Unit)?, onDown: (() -> Unit)?) {
    val p = pal
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Body(label, Modifier.weight(1f), color = if (visible) p.ink else p.inkSoft)
        IconBtn("▲", color = if (onUp != null) p.primary else p.line, size = 34.dp) { onUp?.invoke() }
        IconBtn("▼", color = if (onDown != null) p.primary else p.line, size = 34.dp) { onDown?.invoke() }
        Switch(visible, onToggle, colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = Color.White))
    }
}

fun <T> List<T>.moved(from: Int, to: Int): List<T> {
    if (from !in indices || to !in indices) return this
    val m = toMutableList(); val x = m.removeAt(from); m.add(to, x); return m
}
