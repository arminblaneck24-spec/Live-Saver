@file:OptIn(ExperimentalLayoutApi::class)

package com.lifesave.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

val COLOR_PRESETS = listOf(
    "#0B1E33", "#122A47", "#1F4E79", "#2C6BA0", "#C8102E", "#C9A227", "#2E7D46", "#EEF3F7", "#FFFFFF", "#12161C",
    "#0F8F7E", "#1FBFA6", "#F2762E", "#FF8A3D", "#FFC24B", "#16181C", "#202329", "#2F6BFF", "#E53945", "#7030A0"
)

@Composable
fun ColorPickerDialog(title: String, initial: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val start = hex(initial) ?: Color.Blue
    val hsv0 = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(start.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(hsv0[0]) }
    var s by remember { mutableFloatStateOf(hsv0[1]) }
    var v by remember { mutableFloatStateOf(hsv0[2]) }
    var hexText by remember { mutableStateOf(toHex(start)) }
    fun cur() = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    fun sync() { hexText = toHex(cur()) }
    fun setSV(ns: Float, nv: Float) { s = ns.coerceIn(0f, 1f); v = nv.coerceIn(0f, 1f); sync() }
    fun setH(nh: Float) { h = nh.coerceIn(0f, 359.9f); sync() }
    fun load(c: Color) { val a = FloatArray(3); android.graphics.Color.colorToHSV(c.toArgb(), a); h = a[0]; s = a[1]; v = a[2] }
    val hue = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, 1f, 1f)))
    val rainbow = (0..6).map { Color(android.graphics.Color.HSVToColor(floatArrayOf((it * 60f).coerceAtMost(359.9f), 1f, 1f))) }

    Dialog(onDismissRequest = onDismiss) {
        Panel(Modifier.verticalScroll(rememberScrollState())) {
            Heading(title)
            Box(
                Modifier.fillMaxWidth().height(170.dp)
                    .pointerInput("tap") { detectTapGestures { o -> setSV(o.x / size.width, 1f - o.y / size.height) } }
                    .pointerInput("drag") { detectDragGestures { ch, _ -> setSV(ch.position.x / size.width, 1f - ch.position.y / size.height) } }
                    .drawBehind {
                        drawRect(Brush.horizontalGradient(listOf(Color.White, hue)))
                        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                        val pt = Offset(s * size.width, (1 - v) * size.height)
                        drawCircle(Color.Black, 11.dp.toPx(), pt, style = Stroke(2.dp.toPx()))
                        drawCircle(Color.White, 8.dp.toPx(), pt, style = Stroke(3.dp.toPx()))
                    }
            )
            Spacer(Modifier.height(10.dp))
            Muted("Farbton")
            Box(
                Modifier.fillMaxWidth().height(28.dp)
                    .pointerInput("htap") { detectTapGestures { o -> setH(o.x / size.width * 360f) } }
                    .pointerInput("hdrag") { detectDragGestures { ch, _ -> setH(ch.position.x / size.width * 360f) } }
                    .drawBehind {
                        drawRect(Brush.horizontalGradient(rainbow))
                        val x = h / 360f * size.width
                        drawRect(Color.Black, Offset(x - 3.dp.toPx(), 0f), Size(6.dp.toPx(), size.height))
                        drawRect(Color.White, Offset(x - 1.5f.dp.toPx(), 0f), Size(3.dp.toPx(), size.height))
                    }
            )
            Muted("Helligkeit"); Slider(value = v, onValueChange = { setSV(s, it) })
            Muted("Sättigung"); Slider(value = s, onValueChange = { setSV(it, v) })
            Muted("Vorschläge")
            FlowRow {
                COLOR_PRESETS.forEach { p ->
                    val c = hex(p)!!
                    Box(Modifier.padding(end = 6.dp, bottom = 6.dp).size(28.dp).clip(CircleShape).background(c)
                        .border(2.dp, if (hexText.equals(p, true)) pal.primary else pal.line, CircleShape)
                        .clickable { load(c); hexText = p })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(start).border(1.dp, pal.line, CircleShape))
                Muted("  →  ")
                Box(Modifier.size(40.dp).clip(CircleShape).background(cur()).border(1.dp, pal.line, CircleShape))
                Spacer(Modifier.width(12.dp))
                Field(hexText, { x -> hexText = x; hex(x)?.let { load(it) } }, "Hex-Code", Modifier.weight(1f), caps = true)
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Btn("Abbrechen", Modifier.weight(1f), BtnKind.GHOST) { onDismiss() }
                Spacer(Modifier.width(8.dp))
                Btn("Übernehmen", Modifier.weight(1f)) { onPick(toHex(cur())) }
            }
        }
    }
}

/** Farbfeld + Name, öffnet den Farbwähler */
@Composable
fun ColorRow(label: String, value: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val p = pal
    if (open) ColorPickerDialog(label, value, { open = false }) { onPick(it); open = false }
    Row(Modifier.fillMaxWidth().clickable { open = true }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(hex(value) ?: Color.Gray).border(1.dp, p.line, CircleShape))
        Spacer(Modifier.width(12.dp))
        Body(label, Modifier.weight(1f))
        Muted(value.uppercase())
    }
}
