package com.lifesave.core

/** Schlaf, Wasser, Schritte – manuell oder über Health Connect */
object Vitals {
    fun today() = startOfDay(now())

    fun water(s: AppState = Store.state, day: Long = today()) = s.water[day] ?: 0
    fun addWater(delta: Int) {
        val d = today()
        val before = water()
        Store.update { st -> st.copy(water = st.water + (d to (water(st, d) + delta).coerceIn(0, 40))) }
        val goal = Store.state.settings.waterGoal
        if (before < goal && water() >= goal) Rewards.addXp(d, "Wasserziel", "water", 5)
        else if (before >= goal && water() < goal) Rewards.removeXp { it.kind == "water" && startOfDay(it.at) == d }
    }

    /** Schlaf der letzten Nacht (eingetragen am Tag des Aufwachens) */
    fun sleep(s: AppState = Store.state, day: Long = today()): Double? = s.sleep[day]
    fun setSleep(hours: Double, day: Long = today()) =
        Store.update { st -> st.copy(sleep = st.sleep + (day to hours.coerceIn(0.0, 16.0))) }

    fun steps(s: AppState = Store.state, day: Long = today()): Long? = s.steps[day]

    fun avgSleep(days: Int, s: AppState = Store.state): Double? {
        val from = addDays(today(), -days)
        val v = s.sleep.filterKeys { it > from }.values
        return if (v.isEmpty()) null else v.average()
    }

    fun fmtHours(h: Double): String {
        val m = Math.round(h * 60).toInt()
        return "${m / 60}:${"%02d".format(m % 60)} Std."
    }

    /**
     * Wie stark warst du nach viel vs. wenig Schlaf?
     * Je Workout: Durchschnitt über die Übungen von (bestes 1RM heute / dein Durchschnitts-1RM der Übung).
     * Ergebnis in Prozent Unterschied (≥ 7,5 Std. vs. < 7 Std.), null wenn zu wenig Daten.
     */
    fun sleepStrengthEffect(s: AppState = Store.state): Pair<Double, Int>? {
        val avg = mutableMapOf<String, Double>()
        s.workouts.flatMap { it.exercises }.groupBy { it.exId }.forEach { (id, l) ->
            val v = l.mapNotNull { e -> e.sets.filter { it.done && it.weight > 0 }.maxOfOrNull { it.weight * (1 + it.reps / 30.0) } }
            if (v.size >= 2) avg[id] = v.average()
        }
        fun score(w: Workout): Double? {
            val r = w.exercises.mapNotNull { e ->
                val a = avg[e.exId] ?: return@mapNotNull null
                e.sets.filter { it.done && it.weight > 0 }.maxOfOrNull { it.weight * (1 + it.reps / 30.0) }?.div(a)
            }
            return if (r.isEmpty()) null else r.average()
        }
        val good = mutableListOf<Double>(); val bad = mutableListOf<Double>()
        s.workouts.forEach { w ->
            val sl = s.sleep[startOfDay(w.start)] ?: return@forEach
            val sc = score(w) ?: return@forEach
            if (sl >= 7.5) good += sc else if (sl < 7.0) bad += sc
        }
        if (good.size < 3 || bad.size < 3) return null
        return (good.average() / bad.average() - 1) * 100 to (good.size + bad.size)
    }
}
