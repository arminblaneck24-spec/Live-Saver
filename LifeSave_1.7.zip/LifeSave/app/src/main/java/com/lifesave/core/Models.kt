package com.lifesave.core

import java.util.Calendar

const val APP_NAME = "Life Save"
const val VERSION = "1.7"

private var lastId = 0L
fun newId(): Long {
    val t = System.currentTimeMillis()
    lastId = if (t > lastId) t else lastId + 1
    return lastId
}

// ================= Aufgaben =================
data class Subtask(val title: String, val done: Boolean = false)

data class Task(
    val id: Long = newId(),
    val title: String,
    val note: String = "",
    val due: Long? = null,
    val priority: Int = 2,               // 1 niedrig, 2 mittel, 3 hoch
    val category: String = "",
    val subtasks: List<Subtask> = emptyList(),
    val repeatDays: Int = 0,             // alle X Tage (0 = aus)
    val weekdays: List<Int> = emptyList(), // feste Wochentage
    val xp: Int = 10,
    val doneAt: Long? = null,
    val archived: Boolean = false,
    val notified: Boolean = false
)

// ================= Gewohnheiten =================
const val HABIT_DAILY = 0
const val HABIT_WEEKDAYS = 1
const val HABIT_PER_WEEK = 2

data class Habit(
    val id: Long = newId(),
    val title: String,
    val target: Int = 1,                 // Tagesziel (Anzahl)
    val unit: String = "",
    val baseXp: Int = 10,
    val mode: Int = HABIT_DAILY,
    val weekdays: List<Int> = emptyList(),
    val perWeek: Int = 3,
    val progress: Int = 0,
    val progressDay: Long = 0L,
    val doneDays: List<Long> = emptyList()
)

// ================= XP-Verlauf (Grundlage für Level, Streak und das spätere Spiel) =================
data class XpEntry(val refId: Long, val title: String, val kind: String, val xp: Int, val at: Long)

// ================= Training =================
/** reps = obere Grenze des Wiederholungsbereichs, repMin = untere Grenze (Doppelprogression) */
data class PlanExercise(val exId: String, val sets: Int = 3, val reps: Int = 12, val note: String = "", val repMin: Int = 0) {
    val lo: Int get() = if (repMin in 1..reps) repMin else (reps - 4).coerceAtLeast(1)
}

data class PlanDay(
    val id: Long = newId(),
    val name: String,
    val exercises: List<PlanExercise> = emptyList(),
    val week: Int = 1,                   // nur Wochenplan: Woche im Zyklus (1..N)
    val weekdays: List<Int> = emptyList() // nur Wochenplan: an diesen Tagen
)

const val PLAN_SCHEDULE = 0   // Wochenplan, wiederholt sich alle N Wochen
const val PLAN_ROTATION = 1   // feste Reihenfolge, egal wann (A, B, A, B ...)

data class Plan(
    val id: Long = newId(),
    val name: String,
    val mode: Int = PLAN_ROTATION,
    val cycleWeeks: Int = 1,
    val startDate: Long = startOfWeek(now()),
    val days: List<PlanDay> = emptyList(),
    val nextIndex: Int = 0,              // Rotation: welcher Tag als Nächstes dran ist
    val trainDays: List<Int> = emptyList() // Rotation: an diesen Wochentagen wird erinnert
)

data class SetEntry(val weight: Double = 0.0, val reps: Int = 0, val done: Boolean = false)
data class WorkoutExercise(val exId: String, val sets: List<SetEntry>, val targetReps: Int = 0, val repMin: Int = 0) {
    /** Wiederholungsbereich lo..hi (ohne Plan: 8–12) */
    val hi: Int get() = if (targetReps > 0) targetReps else 12
    val lo: Int get() = if (repMin in 1..hi) repMin else if (targetReps > 0) (targetReps - 4).coerceAtLeast(1) else 8
}

data class Workout(
    val id: Long = newId(),
    val name: String,
    val planId: Long? = null,
    val dayId: Long? = null,
    val start: Long = now(),
    val end: Long? = null,
    val exercises: List<WorkoutExercise> = emptyList(),
    val current: Int = 0
)

data class CardioSession(
    val id: Long = newId(), val type: String, val minutes: Int, val km: Double = 0.0,
    val at: Long = now(), val note: String = ""
)

data class RecordEntry(val exId: String, val kind: String, val value: Double, val at: Long, val workoutId: Long)

data class CustomExercise(
    val id: String, val name: String, val primary: List<String>, val secondary: List<String> = emptyList(),
    val equipment: String = "other", val note: String = ""
)

// ================= Körper =================
data class WeightEntry(val id: Long = newId(), val kg: Double, val at: Long = now())
data class PhotoEntry(val id: Long = newId(), val file: String, val at: Long = now(), val note: String = "", val category: String = "")

// ================= Einstellungen =================
data class Tile(val id: String, val visible: Boolean = true)

/** Hauptbereiche (gleichwertig). Unterseiten wie Aufgaben/Körper liegen in Alltag/Fortschritt. */
val SECTIONS = linkedMapOf(
    "dashboard" to "Start",
    "training" to "Training",
    "nutrition" to "Ernährung",
    "daily" to "Alltag",
    "progress" to "Fortschritt",
    "exercises" to "Übungen",
    "settings" to "Einstellungen"
)
val SECTION_ICONS = mapOf(
    "dashboard" to "⌂", "training" to "🏋", "nutrition" to "🥗", "daily" to "✓", "progress" to "📈",
    "exercises" to "📖", "settings" to "⚙"
)
/** alte Bereichsnamen (≤ 1.2) → neue */
val SECTION_MIGRATION = mapOf("tasks" to "daily", "habits" to "daily", "body" to "progress", "stats" to "progress")

val TILE_NAMES = linkedMapOf(
    "hero" to "Level & Streak",
    "plan" to "Tagesplan (jetzt & als Nächstes)",
    "week" to "Wochenziel",
    "nutrition" to "Ernährung heute",
    "training" to "Nächstes Training",
    "body" to "Mannequin",
    "tasks" to "Aufgaben heute",
    "habits" to "Gewohnheiten heute",
    "weight" to "Gewicht",
    "vitals" to "Schlaf, Wasser & Schritte",
    "records" to "Rekorde & Abzeichen"
)
val DEFAULT_TILES = TILE_NAMES.keys.map { Tile(it) }

val WIDGET_BLOCKS = linkedMapOf(
    "header" to "Kopfzeile (Datum)",
    "plan" to "Tagesplan: jetzt & als Nächstes",
    "streak" to "Streak & Level",
    "training" to "Training",
    "tasks" to "Aufgaben",
    "habits" to "Gewohnheiten",
    "weight" to "Gewicht",
    "week" to "Wochenziel",
    "nutrition" to "Ernährung",
    "vitals" to "Schlaf, Wasser & Schritte",
    "body" to "Mannequin"
)
val WIDGET_TEMPLATES = linkedMapOf(
    "kompakt" to listOf("streak", "training"),
    "training" to listOf("training", "body", "streak"),
    "komplett" to listOf("header", "streak", "training", "tasks", "habits", "weight")
)

data class WidgetCfg(
    val template: String = "komplett",
    val blocks: List<Tile> = WIDGET_BLOCKS.keys.map { Tile(it, it in WIDGET_TEMPLATES["komplett"]!!) },
    val bg: String = "#0B1E33",
    val fg: String = "#FFFFFF",
    val accent: String = "#C9A227",
    val alpha: Int = 235,
    val radius: Int = 18
)

data class Settings(
    val startPage: String = "dashboard",
    val tabs: List<String> = listOf("dashboard", "training", "nutrition", "daily", "progress"),
    val tiles: List<Tile> = DEFAULT_TILES,
    val mannequinMode: Int = 0,          // 0 = zuletzt trainiert, 1 = Wochenvolumen
    val restSec: Int = 90,
    val restAuto: Boolean = true,         // Pause je Übung nach Expertenempfehlung
    val weeklyGoal: Int = 4,
    val waterGoal: Int = 8,               // Gläser à 250 ml
    val sleepGoal: Double = 8.0,
    val gymMode: Boolean = true,
    val gymKeepScreen: Boolean = true,
    val gymNotify: Boolean = true,
    val gymLockScreen: Boolean = true,
    val hcEnabled: Boolean = false,
    val hcSteps: Boolean = true,
    val hcSleep: Boolean = true,
    val hcWeight: Boolean = true,
    val stepGoal: Int = 8000,
    val photoCats: List<String> = listOf("Front", "Seite", "Rücken"),
    val mealReminders: Boolean = true,
    val nutritionPlanOn: Boolean = false,
    val foodImportOpen: Boolean = true,   // „Von Claude importieren“ beim Eintragen aufgeklappt
    // ---- Tagesplan ----
    val schedExtend: Int = 30,            // „Noch nicht fertig“ verlängert um X Minuten
    val schedRemind: Int = 5,             // Erinnerung X Minuten vor Beginn (0 = aus)
    val schedNowNotif: Boolean = true,    // Dauer-Benachrichtigung „Jetzt dran“
    val schedAskDone: Boolean = true,     // nach dem Ende fragen, ob erledigt
    val schedPlanPrompt: Boolean = true,  // morgens nach dem Wiegen zum Tagesplan
    val schedDefaultDur: Int = 60,
    val calRead: Boolean = false,         // Termine aus dem Google-Kalender anzeigen
    val calWrite: Boolean = false,        // eigene Blöcke in den Kalender eintragen
    val calHidden: List<Long> = emptyList(),
    val calTarget: Long = -1L,
    val weighDaily: Boolean = true,      // jeden Morgen wiegen (Pflicht)
    val weighDailyHour: Int = 5,          // ab dieser Uhrzeit gilt der Tag als „Morgen"
    val themeId: String = "mel",
    val customColors: Map<String, String> = emptyMap(),
    val activePlanId: Long? = null,
    val widget: WidgetCfg = WidgetCfg(),
    // ---- Minecraft-Challenge (Life Save Mod) ----
    val gameOn: Boolean = false,          // Fortschritt automatisch in den Gist laden
    val gameToken: String = "",           // GitHub-Token mit Recht „gist“
    val gameGistId: String = "",
    val gameRawUrl: String = "",          // dieser Link kommt in die Mod (config/lifesave/config.json)
    val gameStart: Long = 0L,             // ab diesem Tag zählt es (0 = noch nicht gestartet)
    val gameLastSync: Long = 0L,
    val gameStatus: String = "",
    val updateRepo: String = "arminblaneck24/Live-Saver",
    val lastUpdateCheck: Long = 0L,
    // ---- nur mit Passwort änderbar ----
    val openMode: Int = 3,               // 0 jedes Entsperren, 1 alle X Min., 2 1× täglich, 3 nur wenn etwas offen ist, 4 aus
    val openInterval: Int = 60,
    val reviewHour: Int = 22,
    val weighDay: Int = Calendar.SATURDAY,
    val weighHour: Int = 11,
    val locksOn: Boolean = true,
    val protect: Boolean = true
)

data class AppState(
    val tasks: List<Task> = emptyList(),
    val categories: List<String> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val history: List<XpEntry> = emptyList(),
    val plans: List<Plan> = emptyList(),
    val workouts: List<Workout> = emptyList(),
    val active: Workout? = null,
    val cardio: List<CardioSession> = emptyList(),
    val records: List<RecordEntry> = emptyList(),
    val customEx: List<CustomExercise> = emptyList(),
    val exLinks: Map<String, String> = emptyMap(),
    val weights: List<WeightEntry> = emptyList(),
    val photos: List<PhotoEntry> = emptyList(),
    val badges: Map<String, Long> = emptyMap(),
    val settings: Settings = Settings(),
    val lastShown: Long = 0L,
    val reviewDay: Long = 0L,
    val weighSnoozeUntil: Long = 0L,
    val restUntil: Long = 0L,
    val water: Map<Long, Int> = emptyMap(),     // Tag → Gläser
    val sleep: Map<Long, Double> = emptyMap(),  // Tag des Aufwachens → Stunden
    val steps: Map<Long, Long> = emptyMap(),    // Tag → Schritte (Health Connect)
    val lastHcSync: Long = 0L,
    // ---- Ernährung ----
    val foods: List<Food> = emptyList(),
    val foodLogs: List<FoodLog> = emptyList(),
    val savedMeals: List<SavedMeal> = emptyList(),
    val nutritionGoals: NutritionGoals = NutritionGoals(),
    val mealPlan: Map<String, Long> = emptyMap(),        // "Wochentag-Mahlzeit" → SavedMeal-ID
    val mealSkips: Map<Long, Set<Int>> = emptyMap(),     // Tag → ausgelassene Mahlzeiten
    val suppTaken: Map<Long, Set<String>> = emptyMap(),
    val lockBypassUntil: Long = 0L,
    val lastFoodReminder: Long = 0L,
    // ---- Tagesplan ----
    val blocks: List<Block> = emptyList(),
    val schedCats: List<SchedCat> = DEFAULT_SCHED_CATS,
    val schedHidden: Set<String> = emptySet(),     // gelöschte Auto-Blöcke ("t:<id>@<Tag>")
    val calShifts: Map<String, Int> = emptyMap(),  // Kalendertermin → in der App verschoben um X Min.
    val calDeleted: List<Long> = emptyList(),      // Kalendertermine, die noch gelöscht werden müssen
    val planPromptDay: Long = 0L
)
