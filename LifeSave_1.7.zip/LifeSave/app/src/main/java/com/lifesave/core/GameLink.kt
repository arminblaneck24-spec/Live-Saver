package com.lifesave.core

import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.pow

/**
 * Brücke zur Minecraft-Challenge (Life Save Mod). Rechnet die XP seit Spielstart je Bereich aus –
 * mit genau denselben Kurven wie die Mod (config/lifesave/config.json: stages, curveBase, yearXp).
 * Schlaf, Schritte, Wasser, Wiegen und Fotos zählen nicht.
 */
object GameLink {
    data class Area(val id: String, val title: String, val emoji: String, val affects: String, val kinds: Set<String>, val yearXp: Double)

    const val STAGES = 40
    const val BASE = 1.08

    val AREAS = listOf(
        Area("kraft", "Kraft", "💪", "Herzen, Schaden, Abbautempo", setOf("workout"), 15000.0),
        Area("cardio", "Ausdauer", "🏃", "Lauftempo, Sprungkraft", setOf("cardio"), 2500.0),
        Area("ernaehrung", "Ernährung", "🥗", "Hungerverbrauch", setOf("food", "nutrition_goal"), 4500.0),
        Area("aufgaben", "Disziplin", "✅", "Inventarplätze", setOf("task", "habit", "review"), 15000.0)
    )

    fun started(s: AppState = Store.state) = s.settings.gameStart > 0L

    /** XP je Bereich seit Spielstart */
    fun xp(s: AppState = Store.state): Map<String, Int> {
        val from = s.settings.gameStart
        if (from <= 0L) return AREAS.associate { it.id to 0 }
        return AREAS.associate { a -> a.id to s.history.filter { it.at >= from && it.kind in a.kinds }.sumOf { it.xp }.coerceAtLeast(0) }
    }

    private fun share(n: Int) = (BASE.pow(n) - 1) / (BASE.pow(STAGES) - 1)

    fun xpFor(a: Area, n: Int): Int = if (n <= 0) 0 else ceil(a.yearXp * share(n)).toInt()

    fun level(a: Area, xp: Int): Int { var n = 0; while (n < STAGES && xp >= xpFor(a, n + 1)) n++; return n }

    /** Skillpunkte im Hardcore-Skilltree = Life-Save-Level aus den zählenden XP − 1 */
    fun skillPoints(xp: Map<String, Int>): Int = Rewards.levelInfo(xp.values.sum()).level - 1

    /** Inhalt der Gist-Datei, die die Mod liest */
    fun payload(s: AppState = Store.state): String {
        val x = xp(s)
        val o = JSONObject().put("v", 1).put("updated", now()).put("start", s.settings.gameStart)
            .put("xp", JSONObject().apply { x.forEach { (k, v) -> put(k, v) } })
            .put("level", Rewards.levelInfo(x.values.sum()).level)
            .put("app", VERSION)
        return o.toString(2)
    }
}
