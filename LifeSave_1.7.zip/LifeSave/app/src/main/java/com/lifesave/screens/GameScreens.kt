package com.lifesave.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.GistSync
import com.lifesave.ui.*
import java.util.Calendar

/** Einstellungen → Minecraft-Challenge: Fortschritt je Bereich und Verbindung zur Life Save Mod. */
@Composable
fun GameSettings() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val st = Store.state
    val s = st.settings
    val p = pal
    val xp = GameLink.xp(st)
    var token by remember { mutableStateOf(s.gameToken) }
    var showToken by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }

    fun pickStart() {
        val c = Calendar.getInstance().apply { timeInMillis = if (s.gameStart > 0) s.gameStart else now() }
        DatePickerDialog(ctx, { _, y, m, d ->
            val t = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            Store.setSettings { it.copy(gameStart = t) }
            GistSync.schedule(1_000)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    Screen {
        // ---------------- Überblick ----------------
        item {
            Panel {
                Heading("Dein Spiel-Fortschritt")
                if (!GameLink.started()) {
                    Muted("Noch nicht gestartet. Leg fest, ab welchem Tag gezählt wird – am besten der Tag deiner ersten Minecraft-Session.")
                    Spacer(Modifier.height(8.dp))
                    Btn("Spielstart: heute") { Store.setSettings { it.copy(gameStart = startOfDay(now())) }; GistSync.schedule(1_000) }
                } else {
                    val lvl = Rewards.levelInfo(xp.values.sum()).level
                    Row(Modifier.fillMaxWidth()) {
                        StatBox("Life-Save-Level", "$lvl", Modifier.weight(1f))
                        StatBox("Skillpunkte", "${GameLink.skillPoints(xp)}", Modifier.weight(1f), p.gold)
                        StatBox("Seit", fmtShort(s.gameStart), Modifier.weight(1f))
                    }
                    Muted("Jedes Life-Save-Level ist ein Punkt im Hardcore-Skilltree (Taste J).", size = 12.sp)
                }
            }
        }
        GameLink.AREAS.forEach { a ->
            item(key = "area_" + a.id) {
                val v = xp[a.id] ?: 0
                val lvl = GameLink.level(a, v)
                val cur = GameLink.xpFor(a, lvl)
                val next = GameLink.xpFor(a, (lvl + 1).coerceAtMost(GameLink.STAGES))
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Body("${a.emoji}  ${a.title}", bold = true, modifier = Modifier.weight(1f))
                        Pill("Level $lvl / ${GameLink.STAGES}", if (lvl >= GameLink.STAGES) p.gold else p.primary)
                    }
                    Muted("Im Spiel: ${a.affects}", size = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    val frac = if (lvl >= GameLink.STAGES) 1f else ((v - cur).toFloat() / (next - cur).coerceAtLeast(1)).coerceIn(0f, 1f)
                    Bar(frac)
                    Spacer(Modifier.height(4.dp))
                    Muted(if (lvl >= GameLink.STAGES) "$v XP · Maximum erreicht" else "$v XP · noch ${next - v} XP bis Level ${lvl + 1}", size = 12.sp)
                }
            }
        }
        item {
            Panel {
                Heading("Was zählt")
                Body("💪 Kraft: Krafttraining", size = 14.sp)
                Body("🏃 Ausdauer: Cardio", size = 14.sp)
                Body("🥗 Ernährung: Tracken und Tagesziel erreicht", size = 14.sp)
                Body("✅ Disziplin: Aufgaben, Gewohnheiten, Tagesabschluss", size = 14.sp)
                Muted("Nicht gezählt: Schlaf, Schritte, Wasser, Wiegen und Fotos. Die Level werden exponentiell teurer – das Maximum dauert rund ein Jahr.", size = 12.sp)
            }
        }

        // ---------------- Verbindung ----------------
        item {
            Panel {
                Heading("Verbindung zur Minecraft-Mod")
                ToggleRow("Automatisch hochladen", s.gameOn, "Nach jeder neuen XP und beim Öffnen der App") { on ->
                    Store.setSettings { it.copy(gameOn = on) }; if (on) GistSync.schedule(1_000)
                }
                Sep()
                Body("Spielstart: " + (if (GameLink.started()) fmtDate(s.gameStart) else "noch nicht festgelegt"), size = 14.sp)
                Btn("Startdatum ändern", kind = BtnKind.SECONDARY, small = true) { pickStart() }
                Sep()
                Muted("GitHub-Token: auf github.com → Settings → Developer settings → Personal access tokens → Tokens (classic) → „Generate new token“, nur das Häkchen „gist“ setzen. Den Token gibst du nur hier ein – er wird nur zum Hochladen genutzt.", size = 12.sp)
                Spacer(Modifier.height(4.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = token, onValueChange = { token = it.trim() }, singleLine = true,
                    label = { androidx.compose.material3.Text("GitHub-Token (Recht „gist“)") },
                    visualTransformation = if (showToken) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn(if (showToken) "Verbergen" else "Anzeigen", kind = BtnKind.GHOST, small = true) { showToken = !showToken }
                    Btn("Speichern", small = true, enabled = token != s.gameToken) { Store.setSettings { it.copy(gameToken = token) } }
                }
                Sep()
                Btn(if (GistSync.busy) "Lädt hoch …" else "Jetzt hochladen", enabled = !GistSync.busy && s.gameToken.isNotBlank() && GameLink.started(), modifier = Modifier.fillMaxWidth()) {
                    GistSync.upload()
                }
                if (s.gameStatus.isNotBlank() || s.gameLastSync > 0)
                    Muted((if (s.gameLastSync > 0) "Zuletzt: ${fmtDateTime(s.gameLastSync)} · " else "") + s.gameStatus, size = 12.sp)
            }
        }
        if (s.gameRawUrl.isNotBlank()) item {
            Panel {
                Heading("Link für die Mod")
                Muted("Diesen Link einmal am PC in .minecraft/config/lifesave/config.json bei \"gistUrl\" eintragen (bzw. im Modrinth-Profil unter config/lifesave). Danach im Spiel /lifesave reload.", size = 12.sp)
                Spacer(Modifier.height(4.dp))
                Body(s.gameRawUrl, size = 12.sp)
                Spacer(Modifier.height(6.dp))
                Btn(if (copied) "Kopiert ✓" else "Link kopieren", kind = BtnKind.GOLD, small = true) {
                    clip.setText(AnnotatedString(s.gameRawUrl)); copied = true
                }
            }
        }
    }
}
