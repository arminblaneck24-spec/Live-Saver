package com.lifesave.system

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.lifesave.core.GameLink
import com.lifesave.core.Store
import com.lifesave.core.now
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Lädt den Spiel-Fortschritt in einen geheimen GitHub-Gist (kostenlos). Die Minecraft-Mod liest
 * ihn über den Raw-Link. Hochgeladen wird kurz nach jeder XP-Änderung und beim Öffnen der App.
 */
object GistSync {
    private const val FILE = "lifesave.json"
    private val main = Handler(Looper.getMainLooper())
    private val pending = Runnable { upload(silent = true) }
    var busy by mutableStateOf(false); private set
    private var lastPayloadXp = ""

    /** nach Änderungen: 20 Sekunden sammeln, dann einmal hochladen */
    fun schedule(delayMs: Long = 20_000) {
        val s = Store.state.settings
        if (!s.gameOn || s.gameToken.isBlank() || !GameLink.started()) return
        main.removeCallbacks(pending)
        main.postDelayed(pending, delayMs)
    }

    fun upload(silent: Boolean = false) {
        val st = Store.state
        val s = st.settings
        if (s.gameToken.isBlank()) { status("Bitte zuerst den GitHub-Token eintragen."); return }
        if (!GameLink.started()) { status("Bitte zuerst den Spielstart festlegen."); return }
        val xpKey = GameLink.xp(st).toString()
        if (silent && xpKey == lastPayloadXp && s.gameRawUrl.isNotBlank()) return
        if (busy) return
        busy = true
        val body = JSONObject()
            .put("description", "Life Save – Fortschritt für die Minecraft-Challenge")
            .put("files", JSONObject().put(FILE, JSONObject().put("content", GameLink.payload(st))))
        val id = s.gameGistId
        val token = s.gameToken.trim()
        thread {
            val res = runCatching {
                val create = id.isBlank()
                if (create) body.put("public", false)
                val c = URL(if (create) "https://api.github.com/gists" else "https://api.github.com/gists/$id").openConnection() as HttpURLConnection
                if (create) c.requestMethod = "POST"
                else try { c.requestMethod = "PATCH" } catch (e: java.net.ProtocolException) {
                    c.requestMethod = "POST"; c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
                }
                c.setRequestProperty("Authorization", "Bearer $token")
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.connectTimeout = 10_000; c.readTimeout = 20_000
                c.doOutput = true
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                if (code == 401) error("Token ungültig oder abgelaufen.")
                if (code == 403) error("Dem Token fehlt das Recht „gist“.")
                if (code == 404 && !create) error("NEU")
                if (code !in 200..299) error("GitHub antwortet mit Fehler $code")
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val gid = o.getString("id")
                val owner = o.optJSONObject("owner")?.optString("login").orEmpty()
                gid to "https://gist.githubusercontent.com/$owner/$gid/raw/$FILE"
            }
            main.post {
                busy = false
                res.onSuccess { (gid, raw) ->
                    lastPayloadXp = xpKey
                    Store.setSettings { it.copy(gameGistId = gid, gameRawUrl = raw, gameLastSync = now(), gameStatus = "Hochgeladen") }
                }.onFailure { e ->
                    if (e.message == "NEU") {   // Gist wurde gelöscht → neu anlegen
                        Store.setSettings { it.copy(gameGistId = "") }
                        upload(silent)
                    } else status(e.message ?: "Keine Verbindung.")
                }
            }
        }
    }

    private fun status(t: String) = Store.setSettings { it.copy(gameStatus = t) }
}
