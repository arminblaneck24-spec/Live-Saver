package com.lifesave.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Speicherformat. Jedes Feld wird mit Standardwert gelesen, damit neue Versionen
 * alte Dateien problemlos laden (neue Felder einfach hier ergänzen).
 */
object Json {
    const val FORMAT = 1

    // ---------- kleine Helfer ----------
    private fun JSONObject.objs(name: String): List<JSONObject> =
        optJSONArray(name)?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } } ?: emptyList()
    private fun JSONObject.ints(name: String): List<Int> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optInt(it) } } ?: emptyList()
    private fun JSONObject.longs(name: String): List<Long> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optLong(it) } } ?: emptyList()
    private fun JSONObject.strs(name: String): List<String> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
    private fun JSONObject.optLongOrNull(name: String): Long? = if (has(name) && !isNull(name)) optLong(name) else null
    private fun JSONObject.strMap(name: String): Map<String, String> {
        val o = optJSONObject(name) ?: return emptyMap()
        return o.keys().asSequence().associateWith { o.optString(it) }
    }
    private fun JSONObject.dayMap(name: String): Map<Long, Double> {
        val o = optJSONObject(name) ?: return emptyMap()
        return o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.optDouble(k, 0.0) } }.toMap()
    }
    private fun dayObj(m: Map<Long, Number>) = JSONObject().apply { m.forEach { (k, v) -> put(k.toString(), v) } }
    private fun JSONObject.longMap(name: String): Map<String, Long> {
        val o = optJSONObject(name) ?: return emptyMap()
        return o.keys().asSequence().associateWith { o.optLong(it) }
    }
    private fun arr(l: List<Any?>) = JSONArray(l)
    private fun <T> arrOf(l: List<T>, f: (T) -> JSONObject) = JSONArray(l.map(f))
    private fun mapObj(m: Map<String, Any>) = JSONObject().apply { m.forEach { (k, v) -> put(k, v) } }
    private fun JSONObject.putN(k: String, v: Long?) = apply { put(k, v ?: JSONObject.NULL) }

    // ---------- Tiles ----------
    private fun tile(t: Tile) = JSONObject().put("id", t.id).put("v", t.visible)
    private fun tileFrom(o: JSONObject) = Tile(o.optString("id"), o.optBoolean("v", true))
    /** gespeicherte Reihenfolge behalten, neu hinzugekommene Kacheln hinten anhängen */
    private fun mergeTiles(saved: List<Tile>, all: Collection<String>, defaultVisible: (String) -> Boolean): List<Tile> {
        val known = saved.filter { it.id in all }.toMutableList()
        // neue Kacheln an ihrer Standard-Position einfügen
        all.forEachIndexed { i, id -> if (known.none { it.id == id }) known.add(i.coerceAtMost(known.size), Tile(id, defaultVisible(id))) }
        return known
    }

    // ================= Kodieren =================
    fun encode(s: AppState): String = JSONObject().apply {
        put("format", FORMAT)
        put("tasks", arrOf(s.tasks) { t ->
            JSONObject().put("id", t.id).put("title", t.title).put("note", t.note).putN("due", t.due)
                .put("priority", t.priority).put("category", t.category)
                .put("subtasks", arrOf(t.subtasks) { JSONObject().put("t", it.title).put("d", it.done) })
                .put("repeatDays", t.repeatDays).put("weekdays", arr(t.weekdays)).put("xp", t.xp)
                .putN("doneAt", t.doneAt).put("archived", t.archived).put("notified", t.notified)
        })
        put("categories", arr(s.categories))
        put("habits", arrOf(s.habits) { h ->
            JSONObject().put("id", h.id).put("title", h.title).put("target", h.target).put("unit", h.unit)
                .put("baseXp", h.baseXp).put("mode", h.mode).put("weekdays", arr(h.weekdays)).put("perWeek", h.perWeek)
                .put("progress", h.progress).put("progressDay", h.progressDay).put("doneDays", arr(h.doneDays))
        })
        put("history", arrOf(s.history) {
            JSONObject().put("r", it.refId).put("t", it.title).put("k", it.kind).put("x", it.xp).put("a", it.at)
        })
        put("plans", arrOf(s.plans) { p ->
            JSONObject().put("id", p.id).put("name", p.name).put("mode", p.mode).put("cycleWeeks", p.cycleWeeks)
                .put("startDate", p.startDate).put("nextIndex", p.nextIndex).put("trainDays", arr(p.trainDays))
                .put("days", arrOf(p.days) { d ->
                    JSONObject().put("id", d.id).put("name", d.name).put("week", d.week).put("weekdays", arr(d.weekdays))
                        .put("ex", arrOf(d.exercises) { e ->
                            JSONObject().put("id", e.exId).put("s", e.sets).put("r", e.reps).put("n", e.note).put("rm", e.repMin)
                        })
                })
        })
        put("workouts", arrOf(s.workouts) { workout(it) })
        s.active?.let { put("active", workout(it)) }
        put("cardio", arrOf(s.cardio) {
            JSONObject().put("id", it.id).put("type", it.type).put("min", it.minutes).put("km", it.km).put("at", it.at).put("note", it.note)
        })
        put("records", arrOf(s.records) {
            JSONObject().put("e", it.exId).put("k", it.kind).put("v", it.value).put("a", it.at).put("w", it.workoutId)
        })
        put("customEx", arrOf(s.customEx) {
            JSONObject().put("id", it.id).put("name", it.name).put("p", arr(it.primary)).put("s", arr(it.secondary))
                .put("e", it.equipment).put("note", it.note)
        })
        put("exLinks", mapObj(s.exLinks))
        put("weights", arrOf(s.weights) { JSONObject().put("id", it.id).put("kg", it.kg).put("at", it.at) })
        put("photos", arrOf(s.photos) { JSONObject().put("id", it.id).put("file", it.file).put("at", it.at).put("note", it.note).put("cat", it.category) })
        put("badges", mapObj(s.badges))
        val st = s.settings
        val w = st.widget
        put("settings", JSONObject()
            .put("startPage", st.startPage).put("tabs", arr(st.tabs))
            .put("tiles", arrOf(st.tiles) { tile(it) })
            .put("mannequinMode", st.mannequinMode).put("restSec", st.restSec).put("restAuto", st.restAuto)
            .put("weeklyGoal", st.weeklyGoal).put("waterGoal", st.waterGoal).put("sleepGoal", st.sleepGoal).put("stepGoal", st.stepGoal)
            .put("gymMode", st.gymMode).put("gymKeepScreen", st.gymKeepScreen).put("gymNotify", st.gymNotify).put("gymLockScreen", st.gymLockScreen)
            .put("photoCats", arr(st.photoCats)).put("mealReminders", st.mealReminders).put("nutritionPlanOn", st.nutritionPlanOn)
            .put("foodImportOpen", st.foodImportOpen)
            .put("schedExtend", st.schedExtend).put("schedRemind", st.schedRemind).put("schedNowNotif", st.schedNowNotif)
            .put("schedAskDone", st.schedAskDone).put("schedPlanPrompt", st.schedPlanPrompt).put("schedDefaultDur", st.schedDefaultDur)
            .put("calRead", st.calRead).put("calWrite", st.calWrite).put("calHidden", arr(st.calHidden)).put("calTarget", st.calTarget)
            .put("weighDaily", st.weighDaily).put("weighDailyHour", st.weighDailyHour)
            .put("hcEnabled", st.hcEnabled).put("hcSteps", st.hcSteps).put("hcSleep", st.hcSleep).put("hcWeight", st.hcWeight)
            .put("gameOn", st.gameOn).put("gameToken", st.gameToken).put("gameGistId", st.gameGistId).put("gameRawUrl", st.gameRawUrl)
            .put("gameStart", st.gameStart).put("gameLastSync", st.gameLastSync).put("gameStatus", st.gameStatus)
            .put("themeId", st.themeId).put("customColors", mapObj(st.customColors))
            .putN("activePlanId", st.activePlanId)
            .put("updateRepo", st.updateRepo).put("lastUpdateCheck", st.lastUpdateCheck)
            .put("widget", JSONObject().put("template", w.template).put("blocks", arrOf(w.blocks) { tile(it) })
                .put("bg", w.bg).put("fg", w.fg).put("accent", w.accent).put("alpha", w.alpha).put("radius", w.radius))
            .put("openMode", st.openMode).put("openInterval", st.openInterval).put("reviewHour", st.reviewHour)
            .put("weighDay", st.weighDay).put("weighHour", st.weighHour).put("locksOn", st.locksOn).put("protect", st.protect))
        put("lastShown", s.lastShown)
        put("reviewDay", s.reviewDay)
        put("weighSnoozeUntil", s.weighSnoozeUntil)
        put("restUntil", s.restUntil)
        put("foods", arrOf(s.foods) { foodJson(it) })
        put("foodLogs", arrOf(s.foodLogs) { l ->
            JSONObject().put("id", l.id).put("day", l.day).put("meal", l.meal).put("f", l.foodId).put("n", l.name).put("g", l.grams)
                .put("v", numObj(l.values)).put("at", l.at)
        })
        put("savedMeals", arrOf(s.savedMeals) { m ->
            JSONObject().put("id", m.id).put("name", m.name).put("meal", m.meal).put("items", arrOf(m.items) { JSONObject().put("f", it.foodId).put("g", it.grams) })
        })
        put("nutritionGoals", goalsJson(s.nutritionGoals))
        put("mealPlan", mapObj(s.mealPlan))
        put("mealSkips", JSONObject().apply { s.mealSkips.forEach { (k, v) -> put(k.toString(), arr(v.toList())) } })
        put("suppTaken", JSONObject().apply { s.suppTaken.forEach { (k, v) -> put(k.toString(), arr(v.toList())) } })
        put("lockBypassUntil", s.lockBypassUntil); put("lastFoodReminder", s.lastFoodReminder)
        put("water", dayObj(s.water)); put("sleep", dayObj(s.sleep)); put("steps", dayObj(s.steps)); put("lastHcSync", s.lastHcSync)
        // ---- Tagesplan ----
        put("blocks", arrOf(s.blocks) { b ->
            JSONObject().put("id", b.id).put("day", b.day).put("s", b.start).put("d", b.dur).put("t", b.title).put("c", b.cat)
                .put("n", b.note).put("src", b.source).put("ref", b.ref).put("st", b.status).put("ext", b.extended)
                .put("rem", b.reminded).put("ev", b.calEventId).put("sig", b.calSig)
        })
        put("schedCats", arrOf(s.schedCats) { JSONObject().put("id", it.id).put("name", it.name).put("color", it.color) })
        put("schedHidden", arr(s.schedHidden.toList()))
        put("calShifts", JSONObject().apply { s.calShifts.forEach { (k, v) -> put(k, v) } })
        put("calDeleted", arr(s.calDeleted))
        put("planPromptDay", s.planPromptDay)
    }.toString()

    private fun workout(w: Workout) = JSONObject().put("id", w.id).put("name", w.name)
        .putN("planId", w.planId).putN("dayId", w.dayId).put("start", w.start).putN("end", w.end).put("cur", w.current)
        .put("ex", arrOf(w.exercises) { e ->
            JSONObject().put("id", e.exId).put("tr", e.targetReps).put("rm", e.repMin).put("sets", arrOf(e.sets) {
                JSONObject().put("w", it.weight).put("r", it.reps).put("d", it.done)
            })
        })

    private fun workoutFrom(o: JSONObject) = Workout(
        id = o.optLong("id"), name = o.optString("name"),
        planId = o.optLongOrNull("planId"), dayId = o.optLongOrNull("dayId"),
        start = o.optLong("start"), end = o.optLongOrNull("end"), current = o.optInt("cur"),
        exercises = o.objs("ex").map { e ->
            WorkoutExercise(e.optString("id"), e.objs("sets").map { SetEntry(it.optDouble("w", 0.0), it.optInt("r"), it.optBoolean("d")) }, e.optInt("tr"), e.optInt("rm"))
        }
    )

    fun planFrom(p: JSONObject) = Plan(
        id = p.optLong("id", newId()), name = p.optString("name", "Importierter Plan"), mode = p.optInt("mode", PLAN_ROTATION),
        cycleWeeks = p.optInt("cycleWeeks", 1).coerceAtLeast(1), startDate = p.optLong("startDate", startOfWeek(now())),
        nextIndex = p.optInt("nextIndex"), trainDays = p.ints("trainDays"),
        days = p.objs("days").map { dd ->
            PlanDay(
                id = dd.optLong("id", newId()), name = dd.optString("name"), week = dd.optInt("week", 1), weekdays = dd.ints("weekdays"),
                exercises = dd.objs("ex").map { PlanExercise(it.optString("id"), it.optInt("s", 3), it.optInt("r", 12), it.optString("n"), it.optInt("rm")) }
            )
        }
    )

    /** Pläne aus einer Datei/Text: Backup-Format {"plans":[…]}, Liste […] oder einzelner Plan {"name","days"} */
    fun decodePlans(text: String): List<Plan> {
        val t = text.trim()
        val objs: List<JSONObject> = if (t.startsWith("[")) JSONArray(t).let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } }
        else JSONObject(t).let { o -> if (o.has("plans")) o.objs("plans") else listOf(o) }
        return objs.map { planFrom(it) }.filter { it.days.isNotEmpty() }
    }

    // ---------- Ernährung ----------
    fun numObj(m: Map<String, Double>) = JSONObject().apply { m.forEach { (k, v) -> put(k, v) } }
    fun numMap(o: JSONObject?): Map<String, Double> = o?.let { x -> x.keys().asSequence().associateWith { x.optDouble(it, 0.0) } } ?: emptyMap()

    fun foodJson(f: Food) = JSONObject().put("id", f.id).put("name", f.name).put("brand", f.brand).put("per100", numObj(f.per100))
        .put("portionG", f.portionG).put("portionName", f.portionName).put("barcode", f.barcode).put("source", f.source)
        .put("fav", f.fav).put("excluded", f.excluded)

    fun foodFrom(o: JSONObject) = Food(
        id = o.optString("id").ifBlank { "c_" + newId() }, name = o.optString("name"), brand = o.optString("brand"),
        per100 = numMap(o.optJSONObject("per100")), portionG = o.optDouble("portionG", 100.0), portionName = o.optString("portionName", "Portion"),
        barcode = o.optString("barcode"), source = o.optString("source", "manual"), fav = o.optBoolean("fav"), excluded = o.optBoolean("excluded")
    )

    fun goalsJson(g: NutritionGoals) = JSONObject().put("targets", numObj(g.targets)).put("mealSplit", arr(g.mealSplit))
        .put("supplements", arr(g.supplements)).put("note", g.note).put("setAt", g.setAt).put("source", g.source)

    fun goalsFrom(o: JSONObject): NutritionGoals {
        val d = NutritionGoals()
        val split = o.optJSONArray("mealSplit")?.let { a -> (0 until a.length()).map { a.optDouble(it, 0.25) } }?.takeIf { it.size == 4 } ?: d.mealSplit
        return NutritionGoals(
            targets = d.targets + numMap(o.optJSONObject("targets")), mealSplit = split,
            supplements = o.strs("supplements"), note = o.optString("note", d.note), setAt = o.optLong("setAt"), source = o.optString("source", "Import")
        )
    }

    // ================= Dekodieren =================
    fun decode(text: String): AppState {
        val o = JSONObject(text)
        val so = o.optJSONObject("settings") ?: JSONObject()
        val d = Settings()
        val wo = so.optJSONObject("widget")
        val dw = WidgetCfg()
        val widget = if (wo == null) dw else WidgetCfg(
            template = wo.optString("template", dw.template),
            blocks = mergeTiles(wo.objs("blocks").map { tileFrom(it) }, WIDGET_BLOCKS.keys) { false },
            bg = wo.optString("bg", dw.bg), fg = wo.optString("fg", dw.fg), accent = wo.optString("accent", dw.accent),
            alpha = wo.optInt("alpha", dw.alpha), radius = wo.optInt("radius", dw.radius)
        )
        val settings = Settings(
            startPage = so.optString("startPage", d.startPage).let { SECTION_MIGRATION[it] ?: it },
            tabs = so.strs("tabs").let { raw ->
                // alte Standardleiste (≤ 1.2) → neue Standardleiste
                if (raw == listOf("dashboard", "training", "tasks", "body", "stats")) d.tabs
                else raw.map { SECTION_MIGRATION[it] ?: it }.filter { it in SECTIONS }.distinct()
            }.ifEmpty { d.tabs },
            tiles = mergeTiles(so.objs("tiles").map { tileFrom(it) }, TILE_NAMES.keys) { true },
            mannequinMode = so.optInt("mannequinMode", d.mannequinMode),
            restSec = so.optInt("restSec", d.restSec),
            restAuto = so.optBoolean("restAuto", d.restAuto),
            weeklyGoal = so.optInt("weeklyGoal", d.weeklyGoal), waterGoal = so.optInt("waterGoal", d.waterGoal),
            sleepGoal = so.optDouble("sleepGoal", d.sleepGoal), stepGoal = so.optInt("stepGoal", d.stepGoal),
            gymMode = so.optBoolean("gymMode", d.gymMode), gymKeepScreen = so.optBoolean("gymKeepScreen", d.gymKeepScreen),
            gymNotify = so.optBoolean("gymNotify", d.gymNotify), gymLockScreen = so.optBoolean("gymLockScreen", d.gymLockScreen),
            photoCats = so.strs("photoCats").ifEmpty { d.photoCats },
            mealReminders = so.optBoolean("mealReminders", d.mealReminders),
            nutritionPlanOn = so.optBoolean("nutritionPlanOn", d.nutritionPlanOn),
            foodImportOpen = so.optBoolean("foodImportOpen", d.foodImportOpen),
            schedExtend = so.optInt("schedExtend", d.schedExtend), schedRemind = so.optInt("schedRemind", d.schedRemind),
            schedNowNotif = so.optBoolean("schedNowNotif", d.schedNowNotif), schedAskDone = so.optBoolean("schedAskDone", d.schedAskDone),
            schedPlanPrompt = so.optBoolean("schedPlanPrompt", d.schedPlanPrompt), schedDefaultDur = so.optInt("schedDefaultDur", d.schedDefaultDur),
            calRead = so.optBoolean("calRead", d.calRead), calWrite = so.optBoolean("calWrite", d.calWrite),
            calHidden = so.longs("calHidden"), calTarget = so.optLong("calTarget", d.calTarget),
            gameOn = so.optBoolean("gameOn", d.gameOn), gameToken = so.optString("gameToken", d.gameToken),
            gameGistId = so.optString("gameGistId", d.gameGistId), gameRawUrl = so.optString("gameRawUrl", d.gameRawUrl),
            gameStart = so.optLong("gameStart", d.gameStart), gameLastSync = so.optLong("gameLastSync", d.gameLastSync),
            gameStatus = so.optString("gameStatus", d.gameStatus),
            weighDaily = so.optBoolean("weighDaily", d.weighDaily),
            weighDailyHour = so.optInt("weighDailyHour", d.weighDailyHour),
            hcEnabled = so.optBoolean("hcEnabled", d.hcEnabled), hcSteps = so.optBoolean("hcSteps", d.hcSteps),
            hcSleep = so.optBoolean("hcSleep", d.hcSleep), hcWeight = so.optBoolean("hcWeight", d.hcWeight),
            themeId = so.optString("themeId", d.themeId),
            customColors = so.strMap("customColors"),
            activePlanId = so.optLongOrNull("activePlanId"),
            updateRepo = so.optString("updateRepo", d.updateRepo),
            lastUpdateCheck = so.optLong("lastUpdateCheck"),
            widget = widget,
            openMode = so.optInt("openMode", d.openMode),
            openInterval = so.optInt("openInterval", d.openInterval),
            reviewHour = so.optInt("reviewHour", d.reviewHour),
            weighDay = so.optInt("weighDay", d.weighDay),
            weighHour = so.optInt("weighHour", d.weighHour),
            locksOn = so.optBoolean("locksOn", d.locksOn),
            protect = so.optBoolean("protect", d.protect)
        )
        return AppState(
            tasks = o.objs("tasks").map { t ->
                Task(
                    id = t.optLong("id"), title = t.optString("title"), note = t.optString("note"), due = t.optLongOrNull("due"),
                    priority = t.optInt("priority", 2), category = t.optString("category"),
                    subtasks = t.objs("subtasks").map { Subtask(it.optString("t"), it.optBoolean("d")) },
                    repeatDays = t.optInt("repeatDays"), weekdays = t.ints("weekdays"), xp = t.optInt("xp", 10),
                    doneAt = t.optLongOrNull("doneAt"), archived = t.optBoolean("archived"), notified = t.optBoolean("notified")
                )
            },
            categories = o.strs("categories"),
            habits = o.objs("habits").map { h ->
                Habit(
                    id = h.optLong("id"), title = h.optString("title"), target = h.optInt("target", 1), unit = h.optString("unit"),
                    baseXp = h.optInt("baseXp", 10), mode = h.optInt("mode"), weekdays = h.ints("weekdays"), perWeek = h.optInt("perWeek", 3),
                    progress = h.optInt("progress"), progressDay = h.optLong("progressDay"), doneDays = h.longs("doneDays")
                )
            },
            history = o.objs("history").map { XpEntry(it.optLong("r"), it.optString("t"), it.optString("k"), it.optInt("x"), it.optLong("a")) },
            plans = o.objs("plans").map { planFrom(it) },
            workouts = o.objs("workouts").map { workoutFrom(it) },
            active = o.optJSONObject("active")?.let { workoutFrom(it) },
            cardio = o.objs("cardio").map {
                CardioSession(it.optLong("id"), it.optString("type"), it.optInt("min"), it.optDouble("km", 0.0), it.optLong("at"), it.optString("note"))
            },
            records = o.objs("records").map { RecordEntry(it.optString("e"), it.optString("k"), it.optDouble("v", 0.0), it.optLong("a"), it.optLong("w")) },
            customEx = o.objs("customEx").map {
                CustomExercise(it.optString("id"), it.optString("name"), it.strs("p"), it.strs("s"), it.optString("e", "other"), it.optString("note"))
            },
            exLinks = o.strMap("exLinks"),
            weights = o.objs("weights").map { WeightEntry(it.optLong("id"), it.optDouble("kg", 0.0), it.optLong("at")) },
            photos = o.objs("photos").map { PhotoEntry(it.optLong("id"), it.optString("file"), it.optLong("at"), it.optString("note"), it.optString("cat")) },
            badges = o.longMap("badges"),
            settings = settings,
            lastShown = o.optLong("lastShown"),
            reviewDay = o.optLong("reviewDay"),
            weighSnoozeUntil = o.optLong("weighSnoozeUntil"),
            restUntil = o.optLong("restUntil"),
            water = o.dayMap("water").mapValues { it.value.toInt() },
            sleep = o.dayMap("sleep"),
            steps = o.dayMap("steps").mapValues { it.value.toLong() },
            lastHcSync = o.optLong("lastHcSync"),
            foods = o.objs("foods").map { foodFrom(it) },
            foodLogs = o.objs("foodLogs").map { l ->
                FoodLog(l.optLong("id"), l.optLong("day"), l.optInt("meal"), l.optString("f"), l.optString("n"), l.optDouble("g", 0.0),
                    numMap(l.optJSONObject("v")), l.optLong("at"))
            },
            savedMeals = o.objs("savedMeals").map { m ->
                SavedMeal(m.optLong("id"), m.optString("name"), m.optInt("meal"), m.objs("items").map { MealItem(it.optString("f"), it.optDouble("g", 100.0)) })
            },
            nutritionGoals = o.optJSONObject("nutritionGoals")?.let { goalsFrom(it) } ?: NutritionGoals(),
            mealPlan = o.longMap("mealPlan"),
            mealSkips = o.optJSONObject("mealSkips")?.let { mo -> mo.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to mo.ints(k).toSet() } }.toMap() } ?: emptyMap(),
            suppTaken = o.optJSONObject("suppTaken")?.let { mo -> mo.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to mo.strs(k).toSet() } }.toMap() } ?: emptyMap(),
            lockBypassUntil = o.optLong("lockBypassUntil"),
            lastFoodReminder = o.optLong("lastFoodReminder"),
            blocks = o.objs("blocks").map { b ->
                Block(
                    id = b.optLong("id", newId()), day = b.optLong("day"), start = b.optInt("s", 9 * 60), dur = b.optInt("d", 60),
                    title = b.optString("t"), cat = b.optString("c"), note = b.optString("n"), source = b.optString("src", SRC_OWN),
                    ref = b.optString("ref"), status = b.optInt("st"), extended = b.optInt("ext"), reminded = b.optLong("rem"),
                    calEventId = b.optLong("ev"), calSig = b.optString("sig")
                )
            },
            schedCats = if (o.has("schedCats")) o.objs("schedCats").map { SchedCat(it.optString("id"), it.optString("name"), it.optString("color", "#1F4E79")) }
                else DEFAULT_SCHED_CATS,
            schedHidden = o.strs("schedHidden").toSet(),
            calShifts = o.optJSONObject("calShifts")?.let { m -> m.keys().asSequence().associateWith { m.optInt(it) } } ?: emptyMap(),
            calDeleted = o.longs("calDeleted"),
            planPromptDay = o.optLong("planPromptDay")
        )
    }
}
