package com.lifesave

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.lifesave.core.Store
import com.lifesave.core.Tasks
import com.lifesave.screens.LifeSaveApp
import com.lifesave.screens.Nav
import com.lifesave.system.UnlockService
import com.lifesave.training.ExerciseDb
import com.lifesave.widget.WidgetUpdater

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        ExerciseDb.init(this)
        WidgetUpdater.attach(this)
        com.lifesave.system.CalendarSync.attach(this)
        runCatching { startForegroundService(Intent(this, UnlockService::class.java)) }
        if (savedInstanceState == null) { openStart(); handleOpen(intent) }
        com.lifesave.system.Updater.autoCheck()
        com.lifesave.system.Health.autoSync(this)
        setContent { LifeSaveApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // läuft ein Workout, direkt dorthin
        if (Store.state.active != null && Nav.current.name != "workout") Nav.go("workout")
        else handleOpen(intent)
    }

    /** aus der Tagesplan-Benachrichtigung: direkt zum heutigen Plan */
    private fun handleOpen(i: Intent?) {
        if (i?.getStringExtra("open") != "plan") return
        i.removeExtra("open")
        if (Store.state.active != null) return
        com.lifesave.screens.PlanUi.showToday()
    }

    private fun openStart() {
        Nav.root(Store.state.settings.startPage)
        if (Store.state.active != null) Nav.go("workout")
    }

    override fun onResume() {
        super.onResume()
        com.lifesave.system.GistSync.schedule(2_000)
        Tasks.archiveOld()
    }

    override fun onStop() {
        super.onStop()
        Store.flush()
        WidgetUpdater.update(this)
    }
}
