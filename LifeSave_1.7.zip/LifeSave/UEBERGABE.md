# Life Save 1.7 – Übergabe

Diese Datei zu Beginn eines neuen Chats einfügen, damit Claude den Stand kennt.

## Projekt

- Android-App **Life Save** (Paket `com.lifesave`), Kotlin + Jetpack Compose, Nachfolger von Unlock To-do.
- Aktueller Stand: **Version 1.6** (`LifeSave_1.6.zip`). Code modular halten, Dateien mit Versionsnummer benennen (1.7, 1.8 … / 2.0 bei großem Umbau).
- Build über GitHub-Repo `arminblaneck24/Live-Saver` (GitHub Actions, `.github/workflows/build.yml`, Gradle 8.11.1 im Workflow, AGP 8.5.2, Kotlin 2.0.20, compileSdk 34). Claude kann die APK hier nicht selbst bauen (Google-/Maven-Server gesperrt; GitHub-Konto ist nicht mit Claude verknüpft) → bei Fehlern den Log ab „What went wrong“ schicken.
- 1.6 wurde ohne Testbuild geliefert → zuerst prüfen, ob es baut.
- In-App-Update braucht: neue build.yml mit Release-Schritt + öffentliches Repo.

## Aufbau

- Fünf gleichwertige Bereiche unten: Start, Training, Ernährung, Alltag (Plan + Aufgaben + Gewohnheiten), Fortschritt (Übersicht, Diagramme, Körper, Muskeln, Rekorde, Abzeichen).
- Ordner: `core/` (Modelle, Speicher, Ernährung, Import, Sperren), `training/`, `ui/` (Design, Mannequin, Diagramme), `screens/`, `system/` (Dienst, Wächter, Updater, FoodApi), `widget/`.
- Design: MEL-Farben (Navy #0B1E33, Steel #1F4E79, Rot #C8102E, Gold #C9A227, Ice #EEF3F7), Schrift Barlow Condensed, abgerundete Karten, Segment-Schalter.
- Mannequin: anatomische Linienzeichnung wie FitX-Geräteschilder, trainierte Muskeln orange.

## Sperren & Passwort

- Jeden Morgen Wiegen (Pflicht), Fotos am Foto-Tag (Samstag), Tagesabschluss 22 Uhr inkl. Mahlzeiten.
- Passwort: HMAC-SHA256, Schlüssel `472ef809431efa27183f2608d45a92e31163dac388e4f9e824e793c07f7011ea`, Nachricht `UT2|<Unixzeit/300>`, erste 8 Bytes & 31 → Alphabet `ABCDEFGHJKLMNPQRSTUVWXYZ23456789`. Wechselt alle 5 Minuten.
- Ab 1.4 blockiert der Wächter Updates nicht mehr, nur Deinstallieren.

## Tagesplan (neu in 1.6)

- Alltag → Plan: Stundenplan wie UNTIS, Standard Wochenansicht, umschaltbar Tag/Monat. Raster 5–24 Uhr, Einrasten auf 10 Minuten.
- Plant meist täglich morgens neu (manchmal vorab). Nach dem Wiegen öffnet sich einmal am Tag der heutige Plan.
- Blöcke: Kategorien mit eigenen Farben; lange drücken & ziehen = verschieben, unten am Block ziehen = Länge. Freie Fläche antippen = neuer Block.
- Beim Anlegen: Name oben, darunter durchsuchbare Vorschläge aus früheren Einträgen (+ offene Aufgaben, Training laut Plan).
- Aufgaben mit Uhrzeit → automatisch Block; Training → „noch einplanen“-Hinweis in der Tagesansicht.
- Ende eines Blocks: App öffnet sich nach dem Entsperren mit „Erledigt?“ (auch als Knöpfe in der Benachrichtigung). Nicht fertig → +30 Min. (einstellbar), alles danach am Tag rutscht nach hinten – auch Kalendertermine mit Uhrzeit (nur in der App verschoben, der echte Termin bleibt). Ganztägige Termine bleiben als Info-Zeile oben.
- Benachrichtigungsleiste zeigt dauerhaft „Jetzt: … bis …“ + nächsten Block, kommt nach dem Wegwischen wieder.
- Google-Kalender (über Android-Kalender): Termine lesen; eigene Blöcke werden in einen gewählten Kalender geschrieben (Einbahn: App → Kalender).
- Code: `core/Schedule.kt` (Modelle + Logik), `system/CalendarSync.kt`, `system/PlanNotifier.kt`, `screens/PlannerScreens.kt` (Raster), `screens/PlanEditor.kt` (Block-Editor + Einstellungen „Tagesplan & Kalender“).

## Minecraft-Challenge (neu in 1.7)
- `core/GameLink.kt`: XP je Bereich seit `settings.gameStart` (kraft = workout, cardio = cardio, ernaehrung = food + nutrition_goal, aufgaben = task + habit + review). Kurven identisch zur Life Save Mod (40 Level, Basis 1,08, Jahres-XP 15000/2500/4500/15000). Skillpunkte = `Rewards.levelInfo(summe).level - 1`.
- `system/GistSync.kt`: geheimer Gist `lifesave.json` (POST anlegen, PATCH aktualisieren), 20 s entprellt nach `Rewards.addXp/removeXp`, außerdem beim Öffnen der App. Format: `{"v":1,"updated":ms,"start":ms,"xp":{...},"level":n}`.
- `screens/GameScreens.kt`: Einstellungen → Spiel → Minecraft-Challenge (Fortschritt, Token, Startdatum, Raw-Link kopieren).
- Achtung: Der Token liegt in data.json und damit auch in Backups.

## Ernährung

- Ziel: sauberer Aufbau (Lean Bulk). Startwerte 3.100 kcal, 150 g Eiweiß, 450 g KH, 75 g Fett, Mikros nach DGE.
- Ziele nur per Import von Claude änderbar (oder Passwort). Wochenbericht aus der App an Claude schicken → neue Ziele.
- Essen per Foto an Claude → JSON-Import (`logs` mit `day`, `meal` 0–3, `grams`, `per100`/`foodId`, `saveFood`). Eingebaute IDs z. B. `b_ei`, `b_vk_toast`, `b_vk_brot`, `b_kartoffeln`, `b_butter`, `b_milch35`.
- Seit 1.6 importiert er meist über das ＋ einer Mahlzeit: dann landen alle Einträge in genau dieser Mahlzeit und an diesem Tag, egal was im JSON steht. Einträge lassen sich löschen (✕ + Rückgängig) und per Ziehen in eine andere Mahlzeit oder auf einen anderen Tag verschieben.
- Supplements (Kreatin, Whey) noch nicht gekauft – sagt Bescheid, dann per Import ergänzen.
- Shrimps ausschließen (Halsschwellung, Arzt abklären); Lachs bleibt erlaubt.
- Isst gern: Eier, Joghurt, Quark, Toast mit Wurst/Schinken/Hähnchen, Müsli, Porridge, Brokkoli, Fischstäbchen, Kartoffelbrei, Kohl mit Hack, Hähnchen aus dem Airfryer. Drei Mahlzeiten + Snack.

## Körper & Training

- 1,84 m, ca. 76 kg, schlank (grob 11–14 % KFA), BWL-Student.
- 4-Tage Ober-/Unterkörper-Split bei FitX (nur Maschinen, kein Kabelzug), Samstag zuhause. Plan-JSON 1.3.

## Offen

- Prüfen, ob 1.6 baut und installiert (ohne Testbuild geliefert).
- Avatar-Spiel (später).
- Gefundene Fehler immer gleich mit beheben und am Ende auflisten; unübersichtliche Bildschirme direkt aufräumen.
- Gestrichen: Strive-Import (fängt frisch an), deutsche Übungsanleitungen (vorerst nicht nötig).

## Inhalt dieses Pakets

- Kompletter Quellcode der App (Ordner `app/`, Gradle-Dateien, `.github/workflows/build.yml`).
- `UEBERGABE.md` – diese Datei.
- `extras/` – Trainingsplan-JSON (zum Import in der App).
- Hinweis für Claude: ZIP entpacken, `UEBERGABE.md` und `README.md` lesen, dann direkt im Code weiterarbeiten. Neue Version → `versionCode`/`versionName` in `app/build.gradle.kts`, `VERSION` in `core/Models.kt` und `PATCH_NOTES` in `screens/SettingsScreens.kt` anpassen.
