# Life Save 1.7

Android-App (Kotlin + Jetpack Compose): Training, Ernährung, Tagesplan, Aufgaben, Gewohnheiten und Körper an einem Ort.
Nachfolger von Unlock To-do – eigene, neue App (Paket `com.lifesave`).

## APK bauen (wie bisher über GitHub)
1. Im Repo `Live-Saver` die alte `LifeSave_*.zip` löschen.
2. `LifeSave_1.6.zip` ins Repo hochladen.
3. Die Datei `.github/workflows/build.yml` muss im Repo liegen (sie sucht automatisch den Ordner `LifeSave`).
4. Actions-Tab → neuester Lauf → Artefakt **LifeSave-APK** herunterladen (oder In-App-Update über das Release).
5. Falls der Build fehlschlägt: das Build-Log ab „What went wrong“ an Claude schicken.

Build-Stand: Android Gradle Plugin 8.5.2, Kotlin 2.0.20, compileSdk/targetSdk 34, Gradle 8.11.1 (im Workflow).

## Installieren
1. APK installieren (läuft neben der alten App).
2. Unlock To-do deinstallieren (vorher die Bedienungshilfe dort mit dem Passwort freigeben).
3. In Life Save auf der Startseite die **Einrichtung** der Reihe nach erledigen – den Wächter (Bedienungshilfe) ZULETZT.
   Ist der Schalter ausgegraut: App-Info → ⋮ → „Eingeschränkte Einstellungen zulassen".

## Passwort
Gleiches System wie bei Unlock To-do (wechselt alle 5 Minuten) – Claude nach dem aktuellen Passwort fragen.
Geschützt sind: Sperren an/aus, Wiege-Tag/-Uhrzeit, Tagesabschluss-Uhrzeit, automatisches Öffnen, Einstellungsschutz.
Auf den Sperrbildschirmen hebt das Passwort die Sperre für 10 Minuten auf.

## Aufbau (für Erweiterungen)
- `core/` – Datenmodelle (`Models.kt`), Speichern (`Store.kt`, `Json.kt`), Logik für Aufgaben/Gewohnheiten, XP & Abzeichen, Sperren, Körper, Tagesplan (`Schedule.kt`), Rückgängig (`Undo.kt`)
- `training/` – Übungsdatenbank (`assets/exercises.json`), Pläne, Workouts, Rekorde, Muskelstatistik
- `ui/` – Design (Farbschemata in `Theme.kt`), Bausteine, Diagramme, Mannequin, Farbwähler
- `screens/` – alle Seiten; Navigation in `Nav.kt` + `Shell.kt`
- `system/` – Hintergrunddienst (Öffnen nach Entsperren, Erinnerungen, Satzpause), Wächter (Sperren), Kalender-Abgleich (`CalendarSync.kt`), Plan-Benachrichtigungen (`PlanNotifier.kt`)
- `widget/` – Homescreen-Widget (wird als Bild gezeichnet → frei gestaltbar)

Neue Felder im Speicher immer mit Standardwert in `Json.kt` lesen, dann bleiben alte Daten kompatibel.

## Quellen
- Übungen & Bilder: free-exercise-db (Public Domain), siehe `licenses/`
- Schrift: Barlow Condensed (SIL Open Font License)

## Changelog
### 1.7
- Minecraft-Challenge: Spiel-Level je Bereich, Skillpunkte, automatischer Upload in einen GitHub-Gist für die Life Save Mod

### 1.6
- Tagesplan im Stundenplan-Stil (Woche/Tag/Monat), Kategorien mit Farben, Drag & Drop im 10-Minuten-Raster (5–24 Uhr), Länge ziehen
- Vorschläge beim Anlegen, Aufgaben mit Uhrzeit und Training automatisch, Google-Kalender lesen & eigene Blöcke eintragen
- „Jetzt dran“-Benachrichtigung, Erinnerungen, „Erledigt?“ mit Verlängerung und Nach-hinten-Schieben, Planen nach dem Wiegen
- Ernährung: Import im ＋ der Mahlzeit, festes Import-Feld, Löschen mit Rückgängig, Einträge per Ziehen verschieben
- Fehlerbehebungen (siehe Patchnotes in der App)

### 1.3
- Ernährung (Tagebuch, Vorschläge, Barcode/Open Food Facts, Mahlzeiten, Wochenplan optional, Mikronährstoffe)
- Universeller Import von Claude (Pläne, Ziele, Lebensmittel, Einträge, Mahlzeiten), Wochenbericht
- 5 gleichwertige Bereiche, Fortschritt mit Diagramm-Baukasten
- Fotos pro Tag mit Kategorien, tägliches Wiegen, Ernährung im Tagesabschluss

### 1.2
- Pause je Übung nach Studienlage, Wochenziel mit Ring & Serie
- Jahresrückblick mit Story-Karten zum Teilen
- Schlaf & Wasser, Auswertung Schlaf ↔ Kraft
- Health Connect (Schritte, Schlaf, Gewicht)
- Gym-Modus (Bildschirm an, Benachrichtigung mit Pause, über dem Sperrbildschirm)
- Build: Android Gradle Plugin 8.7.3, Gradle 8.11.1, compileSdk 35 (neuer build.yml!)

### 1.1
- Neue Workout-Ansicht (alle Übungen untereinander, Speichern-Knopf unten)
- Steigerungsvorschläge (Doppelprogression), Wiederholungsbereiche im Plan
- Graue Vorschläge, Haken füllt leere Felder automatisch
- Pläne per JSON importieren, ohne Daten zu ersetzen
- In-App-Update über GitHub Releases (Repo muss öffentlich sein, neuer build.yml nötig)

### 1.0
- Komplett neue App im Stil der MEL-Liga, 4 Farbschemata + eigene Farben
- Trainingspläne: Wochenplan (Zyklus 1–12 Wochen) oder feste Reihenfolge, Vorlagen
- Workout mit aktueller Übung, Werten vom letzten Mal, Satzpause mit Vibration
- 876 Übungen mit Bildern, Mannequin, YouTube-Link, eigene Übungen
- Rekorde mit Feier, 37 Abzeichen, XP & Level, Cardio, Statistik je Muskel
- Gewicht + private Fortschrittsfotos mit Vorher/Nachher-Vergleich
- Wiege-Sperre (Sa 11 Uhr, „Gerade keine Waage" → nächster Tag) und Tagesabschluss-Sperre (22 Uhr)
- Aufgaben (Training als eigene Kategorie), Gewohnheiten täglich / Wochentage / X-mal pro Woche
- Einstellbare Startseite, Tabs, Seitenmenü, gestaltbares Widget
- Automatische Android-Sicherung + ZIP-Backup inkl. Fotos

### Geplant (1.1+)
- Ernährung: Lebensmittel-Datenbank, Barcode, Rezepte, Essensplan, Einkaufsliste
- Import aus Strive, deutsche Übungsanleitungen, Spiel (Kämpfer, der mit deinem Training wächst)
