package com.lifesave.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*

@Composable
fun StatsScreen(fixedTab: Int? = null) {
    val st = Store.state
    val p = pal
    var tabState by remember { mutableIntStateOf(0) }
    val tab = fixedTab ?: tabState
    Screen {
        if (fixedTab == null) item {
            Segmented(listOf("Übersicht", "Muskeln", "Rekorde", "Abzeichen"), tab) { tabState = it }
        }
        when (tab) {
            0 -> {
                item {
                    Panel(accent = p.gold, onClick = { Nav.go("yearreview") }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🗓", fontSize = 28.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Body("Jahresrückblick", bold = true)
                                Muted("Dein Jahr in Zahlen – mit Karten zum Teilen")
                            }
                            Text("›", fontSize = 24.sp, color = p.inkSoft)
                        }
                    }
                }
                Vitals.sleepStrengthEffect(st)?.let { (pct, n) ->
                    item { Panel { Heading("Schlaf & Kraft"); Body("Nach ≥ 7,5 Std. Schlaf warst du im Schnitt " + (if (pct >= 0) "%.0f %% stärker".format(pct) else "%.0f %% schwächer".format(-pct)) + " als nach < 7 Std."); Muted("Basis: $n Workouts mit eingetragenem Schlaf") } }
                }
                item {
                    val weekStart = startOfWeek(now())
                    val wk = st.workouts.filter { it.start >= weekStart }
                    Panel(accent = p.primary) {
                        Heading("Diese Woche")
                        Row {
                            StatBox("Workouts", "${wk.size}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                            StatBox("Sätze", "${wk.sumOf { it.doneSets() }}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                            StatBox("Volumen", fmtNum(wk.sumOf { it.volume() }), Modifier.weight(1f))
                        }
                    }
                }
                item {
                    val weeks = (7 downTo 0).map { startOfWeek(addDays(now(), -7 * it)) }
                    Panel {
                        Heading("Volumen pro Woche (kg)")
                        BarChart(weeks.map { w -> st.workouts.filter { it.start >= w && it.start < addDays(w, 7) }.sumOf { it.volume() } },
                            weeks.map { fmtShort(it) })
                        Heading("Workouts pro Woche")
                        BarChart(weeks.map { w -> st.workouts.count { it.start >= w && it.start < addDays(w, 7) }.toDouble() },
                            weeks.map { fmtShort(it) }, color = p.gold, height = 110.dp)
                    }
                }
                item {
                    Panel {
                        Heading("Gesamt")
                        Row {
                            StatBox("Workouts", "${st.workouts.size}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                            StatBox("Bewegt", fmtNum(st.totalVolume()), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row {
                            StatBox("Trainingszeit", "${st.workouts.sumOf { ((it.end ?: it.start) - it.start) } / 3_600_000} Std.", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                            StatBox("Cardio", "${st.cardio.sumOf { it.minutes }} Min.", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row {
                            StatBox("Aufgaben", "${st.history.count { it.kind == "task" }}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                            StatBox("Gesamt-XP", "${Rewards.totalXp(st)}", Modifier.weight(1f))
                        }
                    }
                }
                item {
                    val days = (13 downTo 0).map { startOfDay(addDays(now(), -it)) }
                    Panel {
                        Heading("XP der letzten 14 Tage")
                        BarChart(days.map { d -> st.history.filter { startOfDay(it.at) == d }.sumOf { it.xp }.toDouble() },
                            days.map { if (dow(it) == java.util.Calendar.MONDAY) fmtShort(it) else "" }, color = p.good, height = 120.dp)
                    }
                }
            }
            1 -> {
                val weekStats = Training.muscleStats(addDays(startOfDay(now()), -6), st)
                val last = Training.lastTrained(st)
                item {
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Heading("Muskeln", Modifier.weight(1f))
                            Pick("Zuletzt", st.settings.mannequinMode == 0) { Store.setSettings { it.copy(mannequinMode = 0) } }
                            Pick("Woche", st.settings.mannequinMode == 1) { Store.setSettings { it.copy(mannequinMode = 1) } }
                        }
                        Mannequin(Training.intensity(st.settings.mannequinMode, st))
                    }
                }
                item {
                    Panel {
                        Heading("Letzte 7 Tage")
                        Row {
                            Muted("Muskel", Modifier.weight(1.4f), size = 11.sp)
                            Muted("Sätze", Modifier.weight(0.7f), size = 11.sp)
                            Muted("Volumen", Modifier.weight(1f), size = 11.sp)
                            Muted("Zuletzt", Modifier.weight(1f), size = 11.sp)
                        }
                        val maxSets = (weekStats.values.maxOfOrNull { it.sets } ?: 0.0).coerceAtLeast(10.0)
                        MUSCLES.forEach { (k, name) ->
                            val s = weekStats[k]
                            Column(Modifier.padding(vertical = 4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Body(name, Modifier.weight(1.4f), size = 14.sp, maxLines = 1)
                                    Body(s?.let { fmtKg(Math.round(it.sets * 10) / 10.0) } ?: "–", Modifier.weight(0.7f), size = 14.sp, bold = true)
                                    Body(s?.let { fmtNum(it.volume) } ?: "–", Modifier.weight(1f), size = 13.sp)
                                    Muted(last[k]?.let { ago(it) } ?: "nie", Modifier.weight(1f), size = 12.sp)
                                }
                                Bar(((s?.sets ?: 0.0) / maxSets).toFloat(), p.secondary, height = 4.dp)
                            }
                        }
                        Muted("Sätze: Hauptmuskel zählt voll, Nebenmuskel halb. Volumen = Gewicht × Wiederholungen.", Modifier.padding(top = 6.dp))
                    }
                }
            }
            2 -> {
                val byEx = st.records.groupBy { it.exId }
                if (byEx.isEmpty()) item { Empty("Noch keine Rekorde. Ab dem zweiten Training einer Übung erkennt die App automatisch, wenn du dich steigerst.") }
                items(byEx.keys.toList(), key = { it }) { exId ->
                    val best = Training.bests(exId, st)
                    val recs = byEx[exId].orEmpty().sortedByDescending { it.at }
                    Panel(onClick = { Nav.go("exercise", exId) }) {
                        Body(ExerciseDb.name(exId), bold = true)
                        if (best != null) Muted("Max ${fmtKg(best.weight)} kg · 1RM ≈ ${fmtKg(Math.round(best.e1rm * 10) / 10.0)} kg · bestes Volumen ${fmtNum(best.volume)}")
                        recs.take(3).forEach { Muted("🏆 ${Training.recordText(it)} · ${fmtDate(it.at)}") }
                    }
                }
            }
            4 -> dayStatsTab()
            5 -> watchStatsTab()
            else -> {
                item { BadgeGrid(st) }
            }
        }
    }
}

@Composable
fun BadgesScreen() {
    Screen { item { BadgeGrid(Store.state) } }
}

@Composable
fun BadgeGrid(st: AppState) {
    val p = pal
    Panel {
        Heading("Abzeichen · ${st.badges.size}/${Rewards.BADGES.size}")
        Rewards.BADGES.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                row.forEach { b ->
                    val got = st.badges[b.id]
                    Column(
                        Modifier.weight(1f).padding(3.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (got != null) p.gold.copy(alpha = 0.16f) else p.bg).padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(if (got != null) b.emoji else "🔒", fontSize = 26.sp)
                        Text(b.title, fontSize = 13.sp, color = if (got != null) p.ink else p.inkSoft, textAlign = TextAlign.Center, maxLines = 2)
                        Muted(if (got != null) fmtDate(got) else b.desc, size = 10.sp, maxLines = 2)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

