package com.lifesave.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.ScreenTime
import com.lifesave.ui.*

/** Entwurf der Tagesbewertung, solange der Tagesabschluss offen ist. */
class RatingDraft(val day: Long, prefill: Map<String, Double>, existing: DayRating?) {
    val scores = mutableStateMapOf<String, Int>().apply { existing?.scores?.let { putAll(it) } }
    val facts = mutableStateMapOf<String, Double>().apply { putAll(prefill); existing?.facts?.let { putAll(it) } }
    var note by mutableStateOf(existing?.note ?: "")
    val complete: Boolean get() = RATINGS.all { scores.containsKey(it.key) }
    fun toRating() = DayRating(day, scores.toMap(), facts.toMap(), note.trim())
}

@Composable
fun rememberRatingDraft(day: Long): RatingDraft {
    val ctx = LocalContext.current
    return remember(day) {
        RatingDraft(day, DayRatings.prefill(day, Store.state, ScreenTime.todayHours(ctx)), DayRatings.get(day))
    }
}

/** Noten 1–10 als antippbare Kreise */
@Composable
fun ScoreRow(value: Int?, invert: Boolean, onPick: (Int) -> Unit) {
    val p = pal
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        (1..10).forEach { n ->
            val sel = value == n
            val goodness = if (invert) (10 - n) / 9f else (n - 1) / 9f
            val col = when { goodness >= 0.66f -> p.good; goodness >= 0.33f -> p.gold; else -> p.secondary }
            Box(
                Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
                    .background(if (sel) col else p.panel).border(1.dp, if (sel) col else p.line, RoundedCornerShape(14.dp))
                    .clickable { onPick(n) },
                contentAlignment = Alignment.Center
            ) { Text("$n", fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) p.onPrimary else p.ink) }
        }
    }
}

@Composable
fun FactRow(def: FactDef, value: Double?, onChange: (Double) -> Unit) {
    val p = pal
    val v = value ?: 0.0
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Body("${def.emoji} ${def.label}", Modifier.weight(1f), size = 14.sp)
        Btn("−", small = true, kind = BtnKind.GHOST) { onChange((v - def.step).coerceAtLeast(0.0)) }
        val txt = if (value == null) "–" else if (def.unit == "Min.") "${v.toInt()} ${def.unit}" else "${fmtKg(v)} ${def.unit}"
        Body(txt, Modifier.width(78.dp), bold = true, size = 14.sp, color = if (value == null) p.inkSoft else p.ink)
        Btn("+", small = true) { onChange((v + def.step).coerceAtMost(def.max)) }
    }
}

/** Ganz oben im Tagesabschluss */
@Composable
fun DayRatingPanel(d: RatingDraft) {
    val p = pal
    val ctx = LocalContext.current
    Panel(accent = if (d.complete) p.good else p.gold) {
        Heading("Wie war dein Tag?")
        Muted("Bewerte ehrlich – die ${DayRatings.XP} XP gibt es immer, egal welche Note.", size = 12.sp)
        RATINGS.forEach { r ->
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Body("${r.emoji} ${r.label}", Modifier.weight(1f), bold = true, size = 14.sp)
                d.scores[r.key]?.let { Body("$it", bold = true, size = 14.sp) }
            }
            Muted("1 = ${r.low} · 10 = ${r.high}", size = 11.sp)
            Spacer(Modifier.height(4.dp))
            ScoreRow(d.scores[r.key], !r.higherIsBetter) { d.scores[r.key] = it }
        }
        Sep()
        Body("Was hast du heute gemacht?", bold = true, size = 14.sp)
        Muted("Nur Zahlen – wie sie deine Noten beeinflussen, rechnet die App in den Statistiken aus.", size = 11.sp)
        FACTS.forEach { f -> FactRow(f, d.facts[f.key]) { d.facts[f.key] = it } }
        if (!ScreenTime.allowed(ctx)) {
            Btn("Bildschirmzeit automatisch übernehmen", Modifier.fillMaxWidth().padding(top = 4.dp), BtnKind.GHOST, small = true) { ScreenTime.openSettings(ctx) }
        }
        Spacer(Modifier.height(6.dp))
        Field(d.note, { d.note = it }, "Was war heute besonders? (optional)", Modifier.fillMaxWidth(), singleLine = false, maxLines = 3)
        if (!d.complete) Muted("Noch ${RATINGS.count { !d.scores.containsKey(it.key) }} Noten offen.", color = p.secondary, size = 12.sp)
    }
}

/** Ernährungsnote 1–6 mit Begründung */
@Composable
fun NutritionGradeCard(day: Long) {
    val p = pal
    val g = NutritionGrade.of(day, Store.state) ?: return
    val col = when (g.note) { 1, 2 -> p.good; 3, 4 -> p.gold; else -> p.secondary }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(col), contentAlignment = Alignment.Center) {
            Text("${g.note}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = p.onPrimary)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Body("Ernährungsnote: ${NutritionGrade.label(g.note)}", bold = true, size = 14.sp)
            Muted(g.reason, size = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ Statistiken
fun LazyListScope.dayStatsTab() {
    item {
        val st = Store.state
        val p = pal
        Panel {
            Heading("Deine Tage")
            if (st.ratings.isEmpty()) { Muted("Noch keine Bewertung. Sie kommt jeden Abend im Tagesabschluss."); return@Panel }
            Row(Modifier.fillMaxWidth()) {
                Body("", Modifier.weight(1.4f)); Muted("7 Tage", Modifier.weight(1f)); Muted("30 Tage", Modifier.weight(1f))
            }
            RATINGS.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Body("${r.emoji} ${r.label}", Modifier.weight(1.4f), size = 14.sp)
                    Body(DayRatings.avg(r.key, 7)?.let { "%.1f".format(it).replace('.', ',') } ?: "–", Modifier.weight(1f), bold = true, size = 14.sp)
                    Body(DayRatings.avg(r.key, 30)?.let { "%.1f".format(it).replace('.', ',') } ?: "–", Modifier.weight(1f), size = 14.sp)
                }
            }
            Muted("Bei Stress und Cheatfrei ist niedriger besser.", size = 11.sp)
        }
    }
    item {
        val st = Store.state
        val pts = st.ratings.values.sortedBy { it.day }.takeLast(30).mapNotNull { r -> r.scores["mood"]?.let { r.day to it.toDouble() } }
        val en = st.ratings.values.sortedBy { it.day }.takeLast(30).mapNotNull { r -> r.scores["energy"]?.let { r.day to it.toDouble() } }
        Panel {
            Heading("Stimmung & Energie (30 Tage)")
            LineChart(pts, second = en)
            Muted("Blau = Stimmung · Gold = Energie", size = 11.sp)
        }
    }
    item {
        val ins = DayRatings.insights()
        Panel {
            Heading("Was dir guttut")
            if (ins.isEmpty()) Muted("Nach etwa 8 bewerteten Tagen erscheinen hier Zusammenhänge, z. B. wie viel Zeit draußen deine Stimmung hebt.")
            ins.forEach { Body(it.text, Modifier.padding(vertical = 3.dp), size = 14.sp) }
        }
    }
    item {
        val st = Store.state
        Panel {
            Heading("Letzte Tage")
            st.ratings.values.sortedByDescending { it.day }.take(14).forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Body(fmtShort(r.day), Modifier.width(70.dp), size = 13.sp)
                    Muted(RATINGS.joinToString("  ") { "${it.emoji}${r.scores[it.key] ?: "–"}" }, size = 12.sp)
                }
                if (r.note.isNotBlank()) Muted("„${r.note}“", Modifier.padding(start = 70.dp), size = 11.sp)
            }
        }
    }
}

fun LazyListScope.watchStatsTab() {
    item {
        val st = Store.state
        val p = pal
        val t = Watch.today(st)
        Panel(accent = p.primary) {
            Heading("Heute laut Uhr")
            if (t == null) { Muted("Noch keine Uhr-Daten. Einstellungen → Health Connect → Smartwatch-Berechtigungen erteilen und synchronisieren."); return@Panel }
            Row(Modifier.fillMaxWidth()) {
                StatBox("Verbrannt", t.kcalTotal?.let { "${it.toInt()} kcal" } ?: "–", Modifier.weight(1f))
                StatBox("Aktiv", t.kcalActive?.let { "${it.toInt()} kcal" } ?: "–", Modifier.weight(1f))
                val b = Watch.balance(st)
                StatBox("Bilanz", b?.let { "${if (it >= 0) "+" else "−"}${kotlin.math.abs(it.toInt())}" } ?: "–", Modifier.weight(1f), if ((b ?: 0.0) >= 0) p.good else p.secondary)
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                StatBox("Ruhepuls", t.restingHr?.let { "${it.toInt()}" } ?: "–", Modifier.weight(1f))
                StatBox("HRV", t.hrv?.let { "${it.toInt()} ms" } ?: "–", Modifier.weight(1f))
                StatBox("SpO₂", t.spo2?.let { "${it.toInt()} %" } ?: "–", Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                StatBox("Strecke", t.distanceKm?.let { "${fmtKg(Math.round(it * 10) / 10.0)} km" } ?: "–", Modifier.weight(1f))
                StatBox("Training", t.exerciseMin?.let { "${it.toInt()} Min." } ?: "–", Modifier.weight(1f))
                StatBox("VO₂max", t.vo2max?.let { "${it.toInt()}" } ?: "–", Modifier.weight(1f))
            }
            if (t.sleepDeep != null) {
                Sep()
                Body("😴 Schlafphasen: Tief ${t.sleepDeep.toInt()} · REM ${(t.sleepRem ?: 0.0).toInt()} · Leicht ${(t.sleepLight ?: 0.0).toInt()} · Wach ${(t.sleepAwake ?: 0.0).toInt()} Min.", size = 13.sp)
            }
            if (t.respRate != null) Muted("Atemfrequenz ${"%.0f".format(t.respRate)}/Min.", size = 12.sp)
        }
    }
    item {
        val r = Watch.ratings()
        val p = pal
        Panel {
            Heading("Bewertung")
            if (r.isEmpty()) Muted("Nach ein paar Tagen mit Uhr vergleicht die App deine Werte mit deinem eigenen Schnitt.")
            r.forEach { x -> Body((when (x.good) { true -> "✅ "; false -> "⚠️ "; null -> "• " }) + x.text, Modifier.padding(vertical = 2.dp), size = 14.sp,
                color = when (x.good) { false -> p.secondary; else -> p.ink }) }
        }
    }
    item {
        val st = Store.state
        val b = Watch.latestBody(st)
        val bmi = Watch.bmi(st)
        Panel {
            Heading("Körper")
            if (bmi != null) Body("BMI ${"%.1f".format(bmi).replace('.', ',')} – ${Watch.bmiText(bmi)} (Größe ${st.settings.heightCm} cm)", size = 14.sp)
            if (b == null) Muted("Noch keine Körperanalyse. Auf der Galaxy Watch: Samsung Health → Körperzusammensetzung → messen.")
            else {
                Muted("Letzte Messung: ${fmtDateTime(b.at)}", size = 12.sp)
                b.fatPct?.let { Body("Körperfett: ${"%.1f".format(it).replace('.', ',')} %", size = 14.sp) }
                b.leanKg?.let { Body("Magermasse: ${fmtKg(Math.round(it * 10) / 10.0)} kg", size = 14.sp) }
                b.waterKg?.let { Body("Körperwasser: ${fmtKg(Math.round(it * 10) / 10.0)} kg", size = 14.sp) }
                b.boneKg?.let { Body("Knochenmasse: ${fmtKg(Math.round(it * 10) / 10.0)} kg", size = 14.sp) }
                b.bmr?.let { Body("Grundumsatz: ${it.toInt()} kcal/Tag", size = 14.sp) }
            }
            val fat = st.bodyComps.mapNotNull { c -> c.fatPct?.let { c.at to it } }
            if (fat.size >= 2) { Spacer(Modifier.height(6.dp)); LineChart(fat, unit = "%") }
        }
    }
    item {
        val st = Store.state
        val days = st.watchDays.values.sortedBy { it.day }.takeLast(30)
        val rhr = days.mapNotNull { d -> d.restingHr?.let { d.day to it } }
        val hrv = days.mapNotNull { d -> d.hrv?.let { d.day to it } }
        Panel {
            Heading("Ruhepuls & HRV (30 Tage)")
            LineChart(rhr, second = hrv)
            Muted("Blau = Ruhepuls · Gold = HRV (ms). Sinkender Ruhepuls und steigende HRV = bessere Fitness und Erholung.", size = 11.sp)
        }
    }
}

/** Einmalige Frage beim Start: Smartwatch vorhanden? */
@Composable
fun WatchAskDialog() {
    val p = pal
    androidx.compose.ui.window.Dialog(onDismissRequest = {}) {
        Panel(accent = p.primary) {
            Text("⌚", fontSize = 36.sp)
            Title("Hast du eine Smartwatch?", Modifier.padding(vertical = 4.dp), size = 22.sp)
            Body("Mit einer Uhr (z. B. Galaxy Watch) zeigt Life Save zusätzlich Puls, HRV, Sauerstoff, Schlafphasen, Körperfett und verbrannte Kalorien – und bewertet sie automatisch.", size = 14.sp)
            Spacer(Modifier.height(12.dp))
            Btn("Ja, einrichten", Modifier.fillMaxWidth()) {
                Store.setSettings { it.copy(watchOn = true, watchAsked = true, hcEnabled = true) }
                Nav.go("settings_x", "health")
            }
            Spacer(Modifier.height(8.dp))
            Btn("Nein / später", Modifier.fillMaxWidth(), BtnKind.GHOST) { Store.setSettings { it.copy(watchAsked = true) } }
            Muted("Lässt sich jederzeit in Einstellungen → Health Connect & Smartwatch ändern.", Modifier.padding(top = 4.dp), size = 12.sp)
        }
    }
}
