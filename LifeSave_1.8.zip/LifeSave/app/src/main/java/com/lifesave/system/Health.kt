package com.lifesave.system

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import com.lifesave.core.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant

/**
 * Health Connect (Samsung Health, Google Fit, Waagen …): liest Schritte, Schlaf und Gewicht.
 * Life Save schreibt nichts zurück.
 */
object Health {
    val BASE_PERMISSIONS = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class)
    )
    /** mit Smartwatch kommen Puls, Kalorien, Körperwerte usw. dazu */
    val PERMISSIONS: Set<String> get() = if (Store.state.settings.watchOn) BASE_PERMISSIONS + WatchSync.PERMISSIONS else BASE_PERMISSIONS

    var status by mutableStateOf(""); private set
    var granted by mutableStateOf<Set<String>>(emptySet()); private set
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun available(c: Context): Boolean = runCatching { HealthConnectClient.getSdkStatus(c) == HealthConnectClient.SDK_AVAILABLE }.getOrDefault(false)

    fun permissionContract() = PermissionController.createRequestPermissionResultContract()

    fun refreshGranted(c: Context) {
        if (!available(c)) return
        scope.launch {
            val g = runCatching { HealthConnectClient.getOrCreate(c).permissionController.getGrantedPermissions() }.getOrDefault(emptySet())
            withContext(Dispatchers.Main) { granted = g }
        }
    }

    /** höchstens alle 30 Minuten automatisch */
    fun autoSync(c: Context) {
        val s = Store.state
        if (!s.settings.hcEnabled || now() - s.lastHcSync < 30 * 60_000L) return
        sync(c)
    }

    fun sync(c: Context) {
        val st = Store.state.settings
        if (!st.hcEnabled) return
        if (!available(c)) { status = "Health Connect ist auf diesem Handy nicht verfügbar."; return }
        status = "Synchronisiere …"
        val app = c.applicationContext
        scope.launch {
            val res = runCatching {
                val client = HealthConnectClient.getOrCreate(app)
                val g = client.permissionController.getGrantedPermissions()
                val today = startOfDay(now())
                val steps = mutableMapOf<Long, Long>()
                if (st.hcSteps && HealthPermission.getReadPermission(StepsRecord::class) in g) {
                    for (i in 0..6) {
                        val d = startOfDay(addDays(today, -i))
                        val end = if (i == 0) now() else addDays(d, 1)
                        val r = client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), TimeRangeFilter.between(Instant.ofEpochMilli(d), Instant.ofEpochMilli(end))))
                        r[StepsRecord.COUNT_TOTAL]?.let { steps[d] = it }
                    }
                }
                val sleep = mutableMapOf<Long, Double>()
                if (st.hcSleep && HealthPermission.getReadPermission(SleepSessionRecord::class) in g) {
                    val r = client.readRecords(ReadRecordsRequest(SleepSessionRecord::class,
                        timeRangeFilter = TimeRangeFilter.between(Instant.ofEpochMilli(addDays(today, -8)), Instant.ofEpochMilli(now()))))
                    r.records.forEach { rec ->
                        val day = startOfDay(rec.endTime.toEpochMilli())
                        val h = (rec.endTime.toEpochMilli() - rec.startTime.toEpochMilli()) / 3_600_000.0
                        sleep[day] = (sleep[day] ?: 0.0) + h
                    }
                }
                val weights = mutableListOf<WeightEntry>()
                if (st.hcWeight && HealthPermission.getReadPermission(WeightRecord::class) in g) {
                    val r = client.readRecords(ReadRecordsRequest(WeightRecord::class,
                        timeRangeFilter = TimeRangeFilter.between(Instant.ofEpochMilli(addDays(today, -60)), Instant.ofEpochMilli(now()))))
                    r.records.forEach { rec -> weights += WeightEntry(kg = Math.round(rec.weight.inKilograms * 10) / 10.0, at = rec.time.toEpochMilli()) }
                }
                val watch = if (st.watchOn) WatchSync.read(client, g) else null
                Triple(steps, sleep, weights) to watch
            }
            withContext(Dispatchers.Main) {
                res.onSuccess { (base, watch) ->
                    val (steps, sleep, weights) = base
                    Store.update { s ->
                        val newW = weights.filter { w -> s.weights.none { kotlin.math.abs(it.at - w.at) < 10 * 60_000L } }
                        s.copy(
                            steps = s.steps + steps,
                            sleep = s.sleep + sleep.filterKeys { it !in s.sleep },  // eigene Einträge haben Vorrang
                            weights = s.weights + newW,
                            lastHcSync = now()
                        )
                    }
                    watch?.let { WatchSync.apply(it) }
                    status = "Synchronisiert: ${fmtTime(now())} Uhr"
                }.onFailure { status = "Fehler: ${it.message ?: "unbekannt"}" }
            }
        }
    }
}
