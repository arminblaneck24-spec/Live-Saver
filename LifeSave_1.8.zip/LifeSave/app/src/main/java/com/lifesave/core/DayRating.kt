package com.lifesave.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Tagesbewertung im Tagesabschluss.
 * Bewertet (1–10): Stimmung, Energie, Stress, Produktivität, Cheatfrei, Spaß.
 * Nur Zahlen (Indikatoren): Minuten draußen, Minuten Bewegung, Stunden mit Leuten, Bildschirmzeit, Schlaf.
 */
data class DayRating(
    val day: Long,
    val scores: Map<String, Int> = emptyMap(),     // Schlüssel aus RATING_KEYS
    val facts: Map<String, Double> = emptyMap(),   // Schlüssel aus FACT_KEYS
    val note: String = "",
    val at: Long = now()
)

data class RatingDef(val key: String, val label: String, val emoji: String, val low: String, val high: String, val higherIsBetter: Boolean = true)
data class FactDef(val key: String, val label: String, val emoji: String, val unit: String, val step: Double, val max: Double)

val RATINGS = listOf(
    RatingDef("mood", "Stimmung", "😊", "mies", "super"),
    RatingDef("energy", "Energie", "⚡", "platt", "voller Energie"),
    RatingDef("stress", "Stress", "😤", "entspannt", "extrem gestresst", higherIsBetter = false),
    RatingDef("productivity", "Produktivität", "🎯", "nichts geschafft", "alles geschafft"),
    RatingDef("cheat", "Cheatfrei", "🍩", "perfekt gehalten", "komplett drauf geschissen", higherIsBetter = false),
    RatingDef("fun", "Spaß", "🎉", "langweilig", "richtig viel Spaß")
)

val FACTS = listOf(
    FactDef("outside", "Draußen", "🌳", "Min.", 15.0, 720.0),
    FactDef("move", "Bewegung", "🏃", "Min.", 15.0, 480.0),
    FactDef("social", "Mit Leuten", "👥", "Std.", 0.5, 16.0),
    FactDef("screen", "Bildschirmzeit", "📱", "Std.", 0.5, 20.0),
    FactDef("sleep", "Schlaf", "😴", "Std.", 0.25, 14.0)
)

object DayRatings {
    const val XP = 15

    fun get(day: Long, s: AppState = Store.state) = s.ratings[day]

    fun save(r: DayRating) {
        val first = Store.state.ratings[r.day] == null
        Store.update { it.copy(ratings = it.ratings + (r.day to r)) }
        // gleiche XP, egal wie gut oder schlecht bewertet – nur fürs Bewerten
        if (first) Rewards.addXp(r.day, "Tagesbewertung", "review", XP)
    }

    /** Vorschläge für die Zahlen: Bewegung aus Training/Uhr, Schlaf und Bildschirmzeit automatisch */
    fun prefill(day: Long, s: AppState = Store.state, screenHours: Double?): Map<String, Double> {
        val m = mutableMapOf<String, Double>()
        val workoutMin = s.workouts.filter { startOfDay(it.start) == day }.sumOf { ((it.end ?: it.start) - it.start) / 60_000.0 }
        val cardioMin = s.cardio.filter { startOfDay(it.at) == day }.sumOf { it.minutes.toDouble() }
        val watchMin = s.watchDays[day]?.exerciseMin ?: 0.0
        val move = maxOf(workoutMin + cardioMin, watchMin)
        if (move > 0) m["move"] = (Math.round(move / 15.0) * 15.0)
        Vitals.sleep(s, day)?.let { m["sleep"] = Math.round(it * 4) / 4.0 }
        screenHours?.let { m["screen"] = Math.round(it * 2) / 2.0 }
        return m
    }

    // ------------------------------------------------------------ Auswertung
    fun avg(key: String, days: Int, s: AppState = Store.state): Double? {
        val from = addDays(startOfDay(now()), -days)
        val v = s.ratings.values.filter { it.day > from }.mapNotNull { it.scores[key] }
        return if (v.isEmpty()) null else v.average()
    }

    data class Insight(val text: String, val strength: Double)

    /**
     * Sucht, ab welcher Menge eines Indikators eine Bewertung spürbar besser/schlechter wird.
     * Braucht mindestens 4 Tage auf jeder Seite der Schwelle.
     */
    fun insights(s: AppState = Store.state): List<Insight> {
        val days = s.ratings.values.toList()
        if (days.size < 8) return emptyList()
        val out = mutableListOf<Insight>()
        for (f in FACTS) {
            val withFact = days.filter { it.facts[f.key] != null }
            if (withFact.size < 8) continue
            val values = withFact.map { it.facts[f.key]!! }.distinct().sorted()
            for (r in RATINGS) {
                var best: Triple<Double, Double, Int>? = null   // Schwelle, Unterschied, n
                for (t in values.drop(1)) {
                    val hi = withFact.filter { it.facts[f.key]!! >= t }.mapNotNull { it.scores[r.key] }
                    val lo = withFact.filter { it.facts[f.key]!! < t }.mapNotNull { it.scores[r.key] }
                    if (hi.size < 4 || lo.size < 4) continue
                    val diff = hi.average() - lo.average()
                    if (best == null || kotlin.math.abs(diff) > kotlin.math.abs(best.second)) best = Triple(t, diff, hi.size + lo.size)
                }
                val b = best ?: continue
                if (kotlin.math.abs(b.second) < 1.0) continue
                val good = if (r.higherIsBetter) b.second > 0 else b.second < 0
                val amount = "%.1f".format(kotlin.math.abs(b.second)).replace('.', ',')
                val th = if (f.unit == "Min.") "${b.first.toInt()} Min." else "${fmtNum1(b.first)} Std."
                val dir = if (b.second > 0) "höher" else "niedriger"
                val icon = if (good) "✅" else "⚠️"
                out += Insight("$icon Ab $th ${f.label.lowercase()} ist dein ${r.label}-Wert im Schnitt $amount Punkte $dir (${b.third} Tage).", kotlin.math.abs(b.second))
            }
        }
        return out.sortedByDescending { it.strength }.take(8)
    }

    private fun fmtNum1(d: Double) = if (d == Math.floor(d)) d.toInt().toString() else "%.1f".format(d).replace('.', ',')

    // ------------------------------------------------------------ Speichern
    fun toJson(m: Map<Long, DayRating>): JSONArray = JSONArray(m.values.map { r ->
        JSONObject().put("day", r.day).put("at", r.at).put("note", r.note)
            .put("s", JSONObject().apply { r.scores.forEach { (k, v) -> put(k, v) } })
            .put("f", JSONObject().apply { r.facts.forEach { (k, v) -> put(k, v) } })
    })

    fun fromJson(a: JSONArray?): Map<Long, DayRating> {
        if (a == null) return emptyMap()
        val out = mutableMapOf<Long, DayRating>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val s = o.optJSONObject("s"); val f = o.optJSONObject("f")
            val r = DayRating(
                day = o.optLong("day"),
                scores = s?.keys()?.asSequence()?.associateWith { s.optInt(it) } ?: emptyMap(),
                facts = f?.keys()?.asSequence()?.associateWith { f.optDouble(it) } ?: emptyMap(),
                note = o.optString("note"),
                at = o.optLong("at")
            )
            out[r.day] = r
        }
        return out
    }
}
