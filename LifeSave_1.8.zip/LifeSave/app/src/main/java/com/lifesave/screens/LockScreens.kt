package com.lifesave.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.system.Pw
import com.lifesave.training.*
import com.lifesave.ui.*

/** Gemeinsamer Rahmen der Sperrbildschirme: Telefon & Notfall-Passwort immer erreichbar */
@Composable
private fun LockFrame(title: String, subtitle: String, emoji: String, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    val p = pal
    val ctx = LocalContext.current
    BackHandler { }
    Column(Modifier.fillMaxSize().background(p.bg).systemBarsPadding().imePadding()) {
        Column(Modifier.fillMaxWidth().background(p.header).padding(18.dp)) {
            Text(emoji, fontSize = 40.sp)
            Title(title, color = p.onHeader, size = 30.sp)
            Muted(subtitle, color = p.onHeader.copy(alpha = 0.8f), size = 14.sp)
        }
        Box(Modifier.weight(1f)) {
            Screen {
                content()
                item {
                    var open by remember { mutableStateOf(false) }
                    var pw by remember { mutableStateOf("") }
                    var wrong by remember { mutableStateOf(false) }
                    Panel {
                        Row {
                            Btn("📞 Telefon", Modifier.weight(1f), BtnKind.GHOST, small = true) {
                                runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }
                            Spacer(Modifier.width(8.dp))
                            Btn("Notfall-Passwort", Modifier.weight(1f), BtnKind.GHOST, small = true) { open = !open }
                        }
                        if (open) {
                            Spacer(Modifier.height(8.dp))
                            Muted("Mit dem Passwort ist die Sperre 10 Minuten aufgehoben. Frag Claude nach dem aktuellen Passwort.")
                            Field(pw, { pw = it.uppercase().trim(); wrong = false }, "Passwort", caps = true)
                            if (wrong) Muted("Falsches oder abgelaufenes Passwort", color = p.secondary)
                            Btn("Entsperren", Modifier.fillMaxWidth().padding(top = 6.dp), small = true) {
                                if (Pw.check(pw)) Store.unlockAdmin() else wrong = true
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================= Wiegen =================
@Composable
fun WeighLockScreen() {
    val p = pal
    var kg by remember { mutableStateOf("") }
    val last = BodyLog.latest()
    val ok = (parseNum(kg) ?: 0.0) in 20.0..400.0
    LockFrame("Zeit zum Wiegen", "Trag dein Gewicht ein, dann ist dein Handy wieder frei.", "⚖") {
        item {
            Panel(accent = p.primary) {
                Field(kg, { kg = it }, "Gewicht in kg", decimal = true)
                last?.let { Muted("Letztes Mal: ${fmtKg(it.kg)} kg am ${fmtDate(it.at)}", Modifier.padding(top = 4.dp)) }
                Spacer(Modifier.height(10.dp))
                if (Locks.photoDay()) {
                    Muted("Heute ist Foto-Tag – optional deine Fortschrittsfotos (bleiben privat in der App):")
                    Spacer(Modifier.height(6.dp))
                    PhotoDayPanel()
                } else Muted("Tipp: nach dem Klo und vor dem Frühstück wiegen – dann sind die Werte vergleichbar.")
                Spacer(Modifier.height(12.dp))
                Btn("Speichern", Modifier.fillMaxWidth(), enabled = ok) { BodyLog.addWeight(parseNum(kg)!!) }
            }
        }
        item {
            Panel {
                Body("Gerade keine Waage in der Nähe?", bold = true)
                Muted("Dann fragt die App morgen früh wieder. Nachtragen kannst du jederzeit unter »Fortschritt → Körper«.")
                Btn("Gerade keine Waage", Modifier.fillMaxWidth().padding(top = 8.dp), BtnKind.GHOST) { Locks.snoozeWeigh() }
            }
        }
    }
}

// ================= Tagesabschluss =================
@Composable
fun ReviewLockScreen() {
    val st = Store.state
    val p = pal
    val today = startOfDay(now())
    val habits = st.habits.filter { Habits.dueToday(it) }
    // null = noch nicht beantwortet
    val marks = remember { mutableStateMapOf<Long, Boolean>() }
    val dueTasks = Tasks.open(st).filter { it.due != null && it.due < addDays(today, 1) }
    val taskDecision = remember { mutableStateMapOf<Long, String>() }
    val workoutsToday = st.workouts.filter { startOfDay(it.start) == today }
    val cardioToday = st.cardio.filter { startOfDay(it.at) == today }
    val planned = Training.nextSession(st)?.takeIf { it.today }
    val rating = rememberRatingDraft(today)
    val ratingOk = !st.settings.ratingOn || rating.complete
    val allAnswered = ratingOk && habits.all { marks.containsKey(it.id) || Habits.doneToday(it) } && dueTasks.all { taskDecision.containsKey(it.id) } &&
        (0..2).all { Nutrition.mealDone(today, it, st) }

    LockFrame("Tagesabschluss", fmtDay(now()) + " · beantworte alles, dann ist dein Handy wieder frei.", "🌙") {
        if (st.settings.ratingOn) item { DayRatingPanel(rating) }
        item {
            Panel(accent = p.gold) {
                Heading("Dein Tag")
                Row {
                    StatBox("XP heute", "+${Rewards.xpToday(st)}", Modifier.weight(1f), p.good); Spacer(Modifier.width(8.dp))
                    StatBox("Streak", "🔥 ${Rewards.streak(st)}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Erledigt", "${Tasks.doneToday(st).size}", Modifier.weight(1f))
                }
            }
        }
        item {
            Panel {
                Heading("Training heute")
                if (workoutsToday.isEmpty() && cardioToday.isEmpty()) {
                    Body(if (planned != null) "Geplant war: ${planned.day.name} – heute nicht gemacht." else "Heute kein Training.",
                        color = if (planned != null) p.secondary else p.ink)
                }
                workoutsToday.forEach { w -> Body("💪 ${w.name}: ${w.doneSets()} Sätze · ${fmtNum(w.volume())}") }
                cardioToday.forEach { c -> Body("🏃 ${c.type}: ${c.minutes} Min." + if (c.km > 0) " · ${fmtKg(c.km)} km" else "") }
            }
        }
        item {
            Panel(accent = if ((0..2).all { Nutrition.mealDone(today, it, st) }) p.good else p.secondary) {
                Heading("Ernährung heute")
                val t = Nutrition.totals(today, st)
                Muted("${(t["kcal"] ?: 0.0).toInt()} / ${Nutrition.goal("kcal", st).toInt()} kcal · ${(t["protein"] ?: 0.0).toInt()} / ${Nutrition.goal("protein", st).toInt()} g Eiweiß")
                (0..2).forEach { m ->
                    val mt = Nutrition.mealTotal(today, m, st)
                    val skipped = m in (st.mealSkips[today] ?: emptySet())
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Body("${MEAL_ICONS[m]} ${MEALS[m]}", Modifier.weight(1f))
                        when {
                            mt.isNotEmpty() -> Pill("✓ ${(mt["kcal"] ?: 0.0).toInt()} kcal", p.good)
                            skipped -> Btn("Ausgelassen ✓", small = true, kind = BtnKind.GHOST) { Nutrition.skipMeal(today, m, false) }
                            else -> Row {
                                Btn("Eintragen", small = true) { Locks.bypass(); Nav.root("nutrition") }
                                Spacer(Modifier.width(4.dp))
                                Btn("Ausgelassen", small = true, kind = BtnKind.GHOST) { Nutrition.skipMeal(today, m, true) }
                            }
                        }
                    }
                }
                Muted("„Eintragen“ gibt dir 15 Minuten zum Nachtragen, danach kommt der Tagesabschluss wieder.")
                NutritionGradeCard(today)
            }
        }
        item {
            Panel {
                Heading("Wasser & Schlaf")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Body("💧 ${Vitals.water(st)}/${st.settings.waterGoal} Gläser", Modifier.weight(1f))
                    Btn("−", small = true, kind = BtnKind.GHOST) { Vitals.addWater(-1) }
                    Spacer(Modifier.width(4.dp))
                    Btn("+", small = true) { Vitals.addWater(1) }
                }
                Body("😴 Letzte Nacht: " + (Vitals.sleep(st)?.let { Vitals.fmtHours(it) } ?: "nicht eingetragen"), Modifier.padding(top = 6.dp))
            }
        }
        if (habits.isNotEmpty()) {
            item { Heading("Gewohnheiten – geschafft?") }
            items(habits, key = { it.id }) { h ->
                val already = Habits.doneToday(h)
                val m = marks[h.id] ?: if (already) true else null
                Panel(accent = when (m) { true -> p.good; false -> p.secondary; else -> p.line }) {
                    Body(h.title, bold = true)
                    Muted("🔥 ${Habits.streak(h)} · " + if (h.target > 1) "${Habits.progress(h)}/${h.target} ${h.unit}" else Habits.modeText(h))
                    Row(Modifier.padding(top = 8.dp)) {
                        Btn("Ja ✓", Modifier.weight(1f), if (m == true) BtnKind.PRIMARY else BtnKind.GHOST, small = true) { marks[h.id] = true }
                        Spacer(Modifier.width(8.dp))
                        Btn("Nein", Modifier.weight(1f), if (m == false) BtnKind.DANGER else BtnKind.GHOST, small = true) { marks[h.id] = false }
                    }
                }
            }
        }
        if (dueTasks.isNotEmpty()) {
            item { Heading("Offene Aufgaben von heute") }
            items(dueTasks, key = { "t" + it.id }) { t ->
                val d = taskDecision[t.id]
                Panel(accent = when (d) { "done" -> p.good; "move" -> p.gold; "drop" -> p.inkSoft; else -> p.line }) {
                    Body(t.title, bold = true)
                    Muted(listOfNotNull(t.category.ifBlank { null }, t.due?.let { fmtDateTime(it) }).joinToString(" · "))
                    Row(Modifier.padding(top = 8.dp)) {
                        Btn("Erledigt", Modifier.weight(1f), if (d == "done") BtnKind.PRIMARY else BtnKind.GHOST, small = true) { taskDecision[t.id] = "done" }
                        Spacer(Modifier.width(6.dp))
                        Btn("Morgen", Modifier.weight(1f), if (d == "move") BtnKind.GOLD else BtnKind.GHOST, small = true) { taskDecision[t.id] = "move" }
                        if (!Tasks.isRepeating(t)) {
                            Spacer(Modifier.width(6.dp))
                            Btn("Streichen", Modifier.weight(1f), if (d == "drop") BtnKind.DANGER else BtnKind.GHOST, small = true) { taskDecision[t.id] = "drop" }
                        }
                    }
                }
            }
        }
        item {
            if (!allAnswered) Muted("Noch nicht alles beantwortet.", Modifier.fillMaxWidth(), color = p.secondary)
            Btn("Tag abschließen", Modifier.fillMaxWidth().padding(top = 4.dp), BtnKind.GOLD, enabled = allAnswered) {
                habits.forEach { h -> marks[h.id]?.let { Habits.setDone(h, it) } }
                dueTasks.forEach { t ->
                    when (taskDecision[t.id]) {
                        "done" -> Tasks.complete(t)
                        "move" -> Tasks.postpone(t)
                        "drop" -> Tasks.delete(t.id)
                    }
                }
                if (st.settings.ratingOn) DayRatings.save(rating.toRating())
                Locks.finishReview()
            }
        }
    }
}
