package com.lifesave.core

/**
 * Schulnote 1–6 für die Ernährung eines Tages, mit kurzer Begründung.
 * Bewertet nach festen Regeln (läuft offline): Kalorien, Eiweiß, Zucker, Ballaststoffe,
 * Mahlzeiten-Rhythmus, Wasser – und mit Smartwatch die Energiebilanz.
 */
object NutritionGrade {
    data class Grade(val note: Int, val reason: String, val points: Int)

    private class Item(val pts: Int, val max: Int, val good: String?, val bad: String?)

    fun of(day: Long, s: AppState = Store.state): Grade? {
        val logs = Nutrition.logs(day, s)
        if (logs.isEmpty()) return null
        val t = Nutrition.total(logs)
        val items = mutableListOf<Item>()

        // Kalorien gegen Ziel (mit Uhr: gegen tatsächlichen Verbrauch + gewünschten Überschuss/Defizit)
        val goal = Nutrition.goal("kcal", s)
        val kcal = t["kcal"] ?: 0.0
        val dev = if (goal > 0) (kcal - goal) / goal else 0.0
        val kcalPts = when { kotlin.math.abs(dev) <= 0.05 -> 30; kotlin.math.abs(dev) <= 0.10 -> 25; kotlin.math.abs(dev) <= 0.20 -> 15; kotlin.math.abs(dev) <= 0.35 -> 6; else -> 0 }
        val pctTxt = "${if (dev >= 0) "+" else "−"}${kotlin.math.abs(Math.round(dev * 100))} %"
        items += Item(kcalPts, 30,
            if (kcalPts >= 25) "Kalorienziel getroffen ($pctTxt)" else null,
            if (kcalPts < 25) (if (dev > 0) "zu viele Kalorien ($pctTxt)" else "zu wenig gegessen ($pctTxt)") else null)

        // Eiweiß
        val pr = (t["protein"] ?: 0.0) / Nutrition.goal("protein", s).coerceAtLeast(1.0)
        val prPts = when { pr >= 1.0 -> 25; pr >= 0.85 -> 20; pr >= 0.7 -> 12; pr >= 0.5 -> 5; else -> 0 }
        items += Item(prPts, 25, if (prPts >= 20) "Eiweiß super (${Math.round(pr * 100)} %)" else null, if (prPts < 20) "zu wenig Eiweiß (${Math.round(pr * 100)} %)" else null)

        // Zucker (Höchstwert)
        val su = (t["sugar"] ?: 0.0) / Nutrition.goal("sugar", s).coerceAtLeast(1.0)
        val suPts = when { su <= 0.7 -> 15; su <= 1.0 -> 11; su <= 1.3 -> 5; else -> 0 }
        items += Item(suPts, 15, if (suPts >= 15) "wenig Zucker" else null, if (suPts <= 5) "zu viel Zucker (${Math.round(su * 100)} % vom Maximum)" else null)

        // Ballaststoffe
        val fi = (t["fiber"] ?: 0.0) / Nutrition.goal("fiber", s).coerceAtLeast(1.0)
        val fiPts = when { fi >= 0.9 -> 10; fi >= 0.6 -> 6; fi >= 0.3 -> 3; else -> 0 }
        items += Item(fiPts, 10, if (fiPts >= 10) "genug Ballaststoffe" else null, if (fiPts <= 3) "kaum Ballaststoffe (Gemüse, Vollkorn)" else null)

        // Rhythmus: Frühstück, Mittag, Abend gegessen oder bewusst ausgelassen
        val meals = (0..2).count { m -> logs.any { it.meal == m } }
        val rhPts = when (meals) { 3 -> 10; 2 -> 6; else -> 2 }
        items += Item(rhPts, 10, if (meals == 3) "regelmäßig gegessen" else null, if (meals < 2) "unregelmäßig gegessen" else null)

        // Wasser
        val w = Vitals.water(s, day)
        val wPts = if (w >= s.settings.waterGoal) 5 else if (w >= s.settings.waterGoal / 2) 2 else 0
        items += Item(wPts, 5, if (wPts == 5) "genug getrunken" else null, if (wPts == 0) "zu wenig getrunken" else null)

        // Smartwatch: Bilanz-Hinweis (nur Begründung, keine Extra-Punkte)
        val wd = s.watchDays[day]
        val balanceNote = if (s.settings.watchOn && wd?.kcalTotal != null) {
            val b = kcal - wd.kcalTotal
            " Bilanz laut Uhr: ${if (b >= 0) "+" else "−"}${kotlin.math.abs(b.toInt())} kcal."
        } else ""

        val pts = items.sumOf { it.pts }
        val max = items.sumOf { it.max }
        val pct = pts * 100 / max
        val note = when { pct >= 90 -> 1; pct >= 75 -> 2; pct >= 60 -> 3; pct >= 45 -> 4; pct >= 30 -> 5; else -> 6 }
        val goods = items.sortedByDescending { it.pts.toDouble() / it.max }.mapNotNull { it.good }.take(2)
        val bads = items.sortedBy { it.pts.toDouble() / it.max }.mapNotNull { it.bad }.take(2)
        val reason = buildString {
            if (goods.isNotEmpty()) append(goods.joinToString(", ").replaceFirstChar { it.uppercase() }).append(". ")
            if (bads.isNotEmpty()) append("Abzug: ").append(bads.joinToString(", ")).append(".")
            if (goods.isEmpty() && bads.isEmpty()) append("Solider Tag.")
            append(balanceNote)
        }.trim()
        return Grade(note, reason, pct)
    }

    fun label(n: Int) = when (n) { 1 -> "sehr gut"; 2 -> "gut"; 3 -> "befriedigend"; 4 -> "ausreichend"; 5 -> "mangelhaft"; else -> "ungenügend" }
}
