package com.lifesave.system

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings
import com.lifesave.core.now
import com.lifesave.core.startOfDay

/** Bildschirmzeit von heute (Android „Nutzungsdatenzugriff“ muss einmal erlaubt werden). */
object ScreenTime {
    fun allowed(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    fun openSettings(c: Context) {
        runCatching { c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    /** Stunden im Vordergrund seit Mitternacht, null ohne Erlaubnis */
    fun todayHours(c: Context): Double? {
        if (!allowed(c)) return null
        return runCatching {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val start = startOfDay(now())
            val stats = usm.queryAndAggregateUsageStats(start, now())
            val ms = stats.values.filter { it.packageName != c.packageName }.sumOf { it.totalTimeInForeground }
            ms / 3_600_000.0
        }.getOrNull()
    }
}
