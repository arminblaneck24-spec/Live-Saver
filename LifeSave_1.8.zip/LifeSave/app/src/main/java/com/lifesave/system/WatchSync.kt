package com.lifesave.system

import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.aggregate.AggregateMetric
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import com.lifesave.core.*
import java.time.Instant
import kotlin.reflect.KClass

/**
 * Smartwatch-Werte aus Health Connect (Galaxy Watch über Samsung Health, Pixel Watch, Fitbit …).
 * Wird von [Health.sync] aufgerufen, wenn „Smartwatch“ in den Einstellungen an ist.
 */
object WatchSync {
    private val READS: List<KClass<out Record>> = listOf(
        TotalCaloriesBurnedRecord::class, ActiveCaloriesBurnedRecord::class, HeartRateRecord::class,
        RestingHeartRateRecord::class, HeartRateVariabilityRmssdRecord::class, OxygenSaturationRecord::class,
        RespiratoryRateRecord::class, Vo2MaxRecord::class, DistanceRecord::class, ExerciseSessionRecord::class,
        BloodPressureRecord::class, BodyFatRecord::class, LeanBodyMassRecord::class, BodyWaterMassRecord::class,
        BoneMassRecord::class, BasalMetabolicRateRecord::class, HeightRecord::class
    )
    val PERMISSIONS: Set<String> = READS.map { HealthPermission.getReadPermission(it) }.toSet()

    data class Result(val days: Map<Long, WatchDay>, val comps: List<BodyComp>, val cardio: List<CardioSession>, val heightCm: Int?)

    private fun range(from: Long, to: Long) = TimeRangeFilter.between(Instant.ofEpochMilli(from), Instant.ofEpochMilli(to))

    suspend fun read(client: HealthConnectClient, granted: Set<String>, days: Int = 7): Result {
        fun ok(k: KClass<out Record>) = HealthPermission.getReadPermission(k) in granted
        val today = startOfDay(now())
        val out = mutableMapOf<Long, WatchDay>()
        for (i in 0 until days) {
            val d = startOfDay(addDays(today, -i))
            val end = if (i == 0) now() else addDays(d, 1)
            val metrics = buildSet<AggregateMetric<*>> {
                if (ok(TotalCaloriesBurnedRecord::class)) add(TotalCaloriesBurnedRecord.ENERGY_TOTAL)
                if (ok(ActiveCaloriesBurnedRecord::class)) add(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)
                if (ok(HeartRateRecord::class)) { add(HeartRateRecord.BPM_AVG); add(HeartRateRecord.BPM_MAX) }
                if (ok(RestingHeartRateRecord::class)) add(RestingHeartRateRecord.BPM_AVG)
                if (ok(DistanceRecord::class)) add(DistanceRecord.DISTANCE_TOTAL)
            }
            val agg = if (metrics.isEmpty()) null else runCatching { client.aggregate(AggregateRequest(metrics, range(d, end))) }.getOrNull()
            var w = WatchDay(
                day = d,
                kcalTotal = agg?.get(TotalCaloriesBurnedRecord.ENERGY_TOTAL)?.inKilocalories,
                kcalActive = agg?.get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)?.inKilocalories,
                avgHr = agg?.get(HeartRateRecord.BPM_AVG)?.toDouble(),
                maxHr = agg?.get(HeartRateRecord.BPM_MAX)?.toDouble(),
                restingHr = agg?.get(RestingHeartRateRecord.BPM_AVG)?.toDouble(),
                distanceKm = agg?.get(DistanceRecord.DISTANCE_TOTAL)?.inKilometers
            )
            if (ok(HeartRateVariabilityRmssdRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssdRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                if (r.isNotEmpty()) w = w.copy(hrv = r.map { it.heartRateVariabilityMillis }.average())
            }
            if (ok(OxygenSaturationRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                if (r.isNotEmpty()) w = w.copy(spo2 = r.map { it.percentage.value }.average())
            }
            if (ok(RespiratoryRateRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(RespiratoryRateRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                if (r.isNotEmpty()) w = w.copy(respRate = r.map { it.rate }.average())
            }
            if (ok(Vo2MaxRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(Vo2MaxRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                if (r.isNotEmpty()) w = w.copy(vo2max = r.last().vo2MillilitersPerMinuteKilogram)
            }
            if (ok(BloodPressureRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(BloodPressureRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                r.lastOrNull()?.let { w = w.copy(bpSys = it.systolic.inMillimetersOfMercury, bpDia = it.diastolic.inMillimetersOfMercury) }
            }
            if (ok(ExerciseSessionRecord::class)) {
                val r = runCatching { client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, range(d, end))).records }.getOrDefault(emptyList())
                if (r.isNotEmpty()) w = w.copy(exerciseMin = r.sumOf { (it.endTime.toEpochMilli() - it.startTime.toEpochMilli()) / 60_000.0 })
            }
            out[d] = w
        }

        // Schlafphasen (Nacht gehört zum Tag des Aufwachens)
        if (ok(SleepSessionRecord::class) || HealthPermission.getReadPermission(SleepSessionRecord::class) in granted) {
            val r = runCatching { client.readRecords(ReadRecordsRequest(SleepSessionRecord::class, range(addDays(today, -days), now()))).records }.getOrDefault(emptyList())
            r.groupBy { startOfDay(it.endTime.toEpochMilli()) }.forEach { (day, sessions) ->
                val st = sessions.flatMap { it.stages }
                if (st.isEmpty()) return@forEach
                fun min(type: Int) = st.filter { it.stage == type }.sumOf { (it.endTime.toEpochMilli() - it.startTime.toEpochMilli()) / 60_000.0 }
                val base = out[day] ?: WatchDay(day)
                out[day] = base.copy(
                    sleepDeep = min(SleepSessionRecord.STAGE_TYPE_DEEP), sleepRem = min(SleepSessionRecord.STAGE_TYPE_REM),
                    sleepLight = min(SleepSessionRecord.STAGE_TYPE_LIGHT), sleepAwake = min(SleepSessionRecord.STAGE_TYPE_AWAKE)
                )
            }
        }

        // Körperzusammensetzung (letzte 90 Tage), Messungen zur gleichen Zeit zusammenfassen
        val from = addDays(today, -90)
        val comps = mutableMapOf<Long, BodyComp>()
        fun key(t: Long) = t / (10 * 60_000L)
        fun merge(t: Long, f: (BodyComp) -> BodyComp) { val k = key(t); comps[k] = f(comps[k] ?: BodyComp(at = t)) }
        if (ok(BodyFatRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(BodyFatRecord::class, range(from, now()))).records }.getOrDefault(emptyList())
            .forEach { r -> merge(r.time.toEpochMilli()) { it.copy(fatPct = r.percentage.value) } }
        if (ok(LeanBodyMassRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(LeanBodyMassRecord::class, range(from, now()))).records }.getOrDefault(emptyList())
            .forEach { r -> merge(r.time.toEpochMilli()) { it.copy(leanKg = r.mass.inKilograms) } }
        if (ok(BodyWaterMassRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(BodyWaterMassRecord::class, range(from, now()))).records }.getOrDefault(emptyList())
            .forEach { r -> merge(r.time.toEpochMilli()) { it.copy(waterKg = r.mass.inKilograms) } }
        if (ok(BoneMassRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(BoneMassRecord::class, range(from, now()))).records }.getOrDefault(emptyList())
            .forEach { r -> merge(r.time.toEpochMilli()) { it.copy(boneKg = r.mass.inKilograms) } }
        if (ok(BasalMetabolicRateRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(BasalMetabolicRateRecord::class, range(from, now()))).records }.getOrDefault(emptyList())
            .forEach { r -> merge(r.time.toEpochMilli()) { it.copy(bmr = r.basalMetabolicRate.inKilocaloriesPerDay) } }

        var height: Int? = null
        if (ok(HeightRecord::class)) runCatching { client.readRecords(ReadRecordsRequest(HeightRecord::class, range(addDays(today, -3650), now()))).records }.getOrDefault(emptyList())
            .lastOrNull()?.let { height = Math.round(it.height.inMeters * 100).toInt() }

        // Trainings der Uhr als Cardio (ohne Krafttraining – das trägst du in Life Save ein)
        val cardio = mutableListOf<CardioSession>()
        if (ok(ExerciseSessionRecord::class)) {
            val strength = setOf(ExerciseSessionRecord.EXERCISE_TYPE_STRENGTH_TRAINING, ExerciseSessionRecord.EXERCISE_TYPE_WEIGHTLIFTING,
                ExerciseSessionRecord.EXERCISE_TYPE_CALISTHENICS)
            runCatching { client.readRecords(ReadRecordsRequest(ExerciseSessionRecord::class, range(addDays(today, -days), now()))).records }.getOrDefault(emptyList())
                .filter { it.exerciseType !in strength }
                .forEach { r ->
                    val min = ((r.endTime.toEpochMilli() - r.startTime.toEpochMilli()) / 60_000L).toInt()
                    if (min >= 5) cardio += CardioSession(type = typeName(r.exerciseType, r.title), minutes = min, at = r.startTime.toEpochMilli(), note = "⌚ " + r.metadata.id)
                }
        }
        return Result(out, comps.values.sortedBy { it.at }, cardio, height)
    }

    private fun typeName(t: Int, title: String?): String = when (t) {
        ExerciseSessionRecord.EXERCISE_TYPE_RUNNING, ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL -> "Laufen"
        ExerciseSessionRecord.EXERCISE_TYPE_WALKING -> "Gehen"
        ExerciseSessionRecord.EXERCISE_TYPE_BIKING, ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY -> "Radfahren"
        ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_POOL, ExerciseSessionRecord.EXERCISE_TYPE_SWIMMING_OPEN_WATER -> "Schwimmen"
        ExerciseSessionRecord.EXERCISE_TYPE_HIKING -> "Wandern"
        ExerciseSessionRecord.EXERCISE_TYPE_ELLIPTICAL -> "Crosstrainer"
        ExerciseSessionRecord.EXERCISE_TYPE_ROWING_MACHINE -> "Rudern"
        ExerciseSessionRecord.EXERCISE_TYPE_STAIR_CLIMBING_MACHINE -> "Stepper"
        else -> title?.takeIf { it.isNotBlank() } ?: "Training (Uhr)"
    }

    /** Ergebnis übernehmen: eigene Einträge bleiben, Uhr-Trainings nur einmal (mit den gleichen XP wie manuell) */
    fun apply(r: Result) {
        val st = Store.state
        val known = st.cardio.map { it.note }.filter { it.startsWith("⌚ ") }.toSet()
        val newCardio = if (st.settings.watchAutoCardio) r.cardio.filter { it.note !in known } else emptyList()
        Store.update { s ->
            val comps = (s.bodyComps + r.comps).distinctBy { it.at / (10 * 60_000L) }.sortedBy { it.at }
            s.copy(
                watchDays = s.watchDays + r.days,
                bodyComps = comps,
                cardio = s.cardio + newCardio,
                settings = if (r.heightCm != null && r.heightCm in 120..230) s.settings.copy(heightCm = r.heightCm) else s.settings
            )
        }
        newCardio.forEach { c -> Rewards.addXp(c.id, "${c.type} (Uhr)", "cardio", (c.minutes / 2).coerceIn(5, 60)) }
    }
}
