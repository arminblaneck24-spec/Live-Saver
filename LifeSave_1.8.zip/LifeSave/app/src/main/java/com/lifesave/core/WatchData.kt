package com.lifesave.core

import org.json.JSONArray
import org.json.JSONObject

/** Tageswerte einer Smartwatch (über Health Connect). null = nicht vorhanden. */
data class WatchDay(
    val day: Long,
    val kcalTotal: Double? = null,     // gesamt verbraucht (inkl. Grundumsatz)
    val kcalActive: Double? = null,
    val restingHr: Double? = null,
    val avgHr: Double? = null,
    val maxHr: Double? = null,
    val hrv: Double? = null,           // RMSSD in ms
    val spo2: Double? = null,          // %
    val respRate: Double? = null,      // Atemzüge/Min.
    val vo2max: Double? = null,
    val distanceKm: Double? = null,
    val exerciseMin: Double? = null,
    val sleepDeep: Double? = null,     // Minuten
    val sleepRem: Double? = null,
    val sleepLight: Double? = null,
    val sleepAwake: Double? = null,
    val bpSys: Double? = null,
    val bpDia: Double? = null
)

/** Messung der Körperzusammensetzung (z. B. Galaxy Watch BIA). */
data class BodyComp(
    val at: Long,
    val fatPct: Double? = null,
    val leanKg: Double? = null,
    val waterKg: Double? = null,
    val boneKg: Double? = null,
    val bmr: Double? = null
)

data class Rating(val text: String, val good: Boolean?)   // good=null → neutral

object Watch {
    fun on(s: AppState = Store.state) = s.settings.watchOn

    fun today(s: AppState = Store.state) = s.watchDays[startOfDay(now())]

    private fun avgOf(s: AppState, days: Int, sel: (WatchDay) -> Double?): Double? {
        val from = addDays(startOfDay(now()), -days)
        val v = s.watchDays.values.filter { it.day > from && it.day < startOfDay(now()) }.mapNotNull(sel)
        return if (v.size < 3) null else v.average()
    }

    fun latestBody(s: AppState = Store.state) = s.bodyComps.maxByOrNull { it.at }

    fun bmi(s: AppState = Store.state): Double? {
        val kg = s.weights.maxByOrNull { it.at }?.kg ?: return null
        val m = s.settings.heightCm / 100.0
        return if (m <= 0) null else kg / (m * m)
    }

    fun bmiText(b: Double) = when {
        b < 18.5 -> "Untergewicht"
        b < 25 -> "Normalgewicht"
        b < 30 -> "Übergewicht"
        else -> "Adipositas"
    }

    /** Kurze automatische Bewertungen für heute im Vergleich zu deinem 30-Tage-Schnitt. */
    fun ratings(s: AppState = Store.state): List<Rating> {
        val t = today(s) ?: return emptyList()
        val out = mutableListOf<Rating>()
        val rhrAvg = avgOf(s, 30) { it.restingHr }
        if (t.restingHr != null && rhrAvg != null) {
            val d = t.restingHr - rhrAvg
            out += when {
                d >= 4 -> Rating("Ruhepuls ${t.restingHr.toInt()} – ${d.toInt()} über deinem Schnitt: Körper ist gestresst oder du wirst krank. Heute lieber locker.", false)
                d <= -3 -> Rating("Ruhepuls ${t.restingHr.toInt()} – unter deinem Schnitt: gut erholt.", true)
                else -> Rating("Ruhepuls ${t.restingHr.toInt()} – normal für dich.", null)
            }
        }
        val hrvAvg = avgOf(s, 30) { it.hrv }
        if (t.hrv != null && hrvAvg != null) {
            val r = t.hrv / hrvAvg
            out += when {
                r < 0.85 -> Rating("HRV ${t.hrv.toInt()} ms – deutlich unter deinem Schnitt: wenig erholt.", false)
                r > 1.1 -> Rating("HRV ${t.hrv.toInt()} ms – über deinem Schnitt: top erholt, guter Tag für hartes Training.", true)
                else -> Rating("HRV ${t.hrv.toInt()} ms – im normalen Bereich.", null)
            }
        }
        t.spo2?.let { out += if (it < 94) Rating("Sauerstoff ${it.toInt()} % – niedrig. Bleibt das so, ärztlich abklären lassen.", false) else Rating("Sauerstoff ${it.toInt()} % – gut.", true) }
        val deep = t.sleepDeep; val rem = t.sleepRem
        if (deep != null && rem != null) {
            out += if (deep >= 60 && rem >= 75) Rating("Schlaf: ${deep.toInt()} Min. Tiefschlaf, ${rem.toInt()} Min. REM – erholsam.", true)
            else Rating("Schlaf: ${deep.toInt()} Min. Tiefschlaf, ${rem.toInt()} Min. REM – eher wenig erholsam.", false)
        }
        if (t.bpSys != null && t.bpDia != null) {
            out += if (t.bpSys >= 140 || t.bpDia >= 90) Rating("Blutdruck ${t.bpSys.toInt()}/${t.bpDia.toInt()} – erhöht.", false)
            else Rating("Blutdruck ${t.bpSys.toInt()}/${t.bpDia.toInt()} – im Rahmen.", true)
        }
        val comps = s.bodyComps.sortedBy { it.at }.filter { it.fatPct != null }
        if (comps.size >= 2) {
            val last = comps.last(); val ref = comps.lastOrNull { it.at < last.at - 21 * 86_400_000L } ?: comps.first()
            if (ref != last) {
                val d = last.fatPct!! - ref.fatPct!!
                val txt = "%+.1f".format(d).replace('.', ',')
                out += Rating("Körperfett ${"%.1f".format(last.fatPct).replace('.', ',')} % ($txt % seit ${fmtDate(ref.at)})", if (kotlin.math.abs(d) < 0.3) null else d < 0)
            }
        }
        return out
    }

    /** Energiebilanz heute: gegessen − verbraucht (null ohne Uhr-Daten) */
    fun balance(s: AppState = Store.state): Double? {
        val burned = today(s)?.kcalTotal ?: return null
        val eaten = Nutrition.totals(startOfDay(now()), s)["kcal"] ?: 0.0
        return eaten - burned
    }

    // ------------------------------------------------------------ Speichern
    private fun JSONObject.putD(k: String, v: Double?) = apply { if (v != null) put(k, v) }
    private fun JSONObject.d(k: String): Double? = if (has(k) && !isNull(k)) optDouble(k) else null

    fun daysToJson(m: Map<Long, WatchDay>) = JSONArray(m.values.map { w ->
        JSONObject().put("day", w.day).putD("kt", w.kcalTotal).putD("ka", w.kcalActive).putD("rhr", w.restingHr).putD("ahr", w.avgHr)
            .putD("mhr", w.maxHr).putD("hrv", w.hrv).putD("o2", w.spo2).putD("rr", w.respRate).putD("vo2", w.vo2max).putD("km", w.distanceKm)
            .putD("ex", w.exerciseMin).putD("sd", w.sleepDeep).putD("sr", w.sleepRem).putD("sl", w.sleepLight).putD("sa", w.sleepAwake)
            .putD("bs", w.bpSys).putD("bd", w.bpDia)
    })

    fun daysFromJson(a: JSONArray?): Map<Long, WatchDay> {
        if (a == null) return emptyMap()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.associate { o ->
            o.optLong("day") to WatchDay(o.optLong("day"), o.d("kt"), o.d("ka"), o.d("rhr"), o.d("ahr"), o.d("mhr"), o.d("hrv"), o.d("o2"), o.d("rr"),
                o.d("vo2"), o.d("km"), o.d("ex"), o.d("sd"), o.d("sr"), o.d("sl"), o.d("sa"), o.d("bs"), o.d("bd"))
        }
    }

    fun compsToJson(l: List<BodyComp>) = JSONArray(l.map { b ->
        JSONObject().put("at", b.at).putD("fat", b.fatPct).putD("lean", b.leanKg).putD("water", b.waterKg).putD("bone", b.boneKg).putD("bmr", b.bmr)
    })

    fun compsFromJson(a: JSONArray?): List<BodyComp> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            BodyComp(o.optLong("at"), o.d("fat"), o.d("lean"), o.d("water"), o.d("bone"), o.d("bmr"))
        }
    }
}
