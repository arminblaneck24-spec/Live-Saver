plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.lifesave"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lifesave"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("lifesave.keystore")
            storePassword = "unlocktodo"
            keyAlias = "unlock"
            keyPassword = "unlocktodo"
        }
    }
    buildFeatures { compose = true }
    // Bilder der Übungsdatenbank sind schon komprimiert
    androidResources { noCompress += listOf("webp") }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.health.connect:connect-client:1.1.0-rc01")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
