package com.lifesave.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

val TITLES = mapOf(
    "workout" to "Workout", "workoutlog" to "Workout", "plan" to "Trainingsplan", "cardio" to "Cardio",
    "exercise" to "Übung", "exercise_new" to "Eigene Übung", "task" to "Aufgabe", "habit" to "Gewohnheit",
    "photos" to "Fortschrittsfotos", "photo" to "Foto", "compare" to "Vergleich", "settings_x" to "Einstellungen", "badges" to "Abzeichen"
)

/** Wurzel der Oberfläche: Sperren, Navigation, Feiern */
@Composable
fun LifeSaveApp() {
    val st = Store.state
    var tick by remember { mutableLongStateOf(now()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); tick = now() } }
    LifeTheme(paletteFor(st.settings)) {
        val p = pal
        Box(Modifier.fillMaxSize().background(p.bg)) {
            val lock = if (tick >= 0L) Locks.pending(st) else null
            when (lock) {
                "weigh" -> WeighLockScreen()
                "review" -> ReviewLockScreen()
                else -> Shell()
            }
            if (Store.celebrations.isNotEmpty()) CelebrationOverlay(Store.celebrations.first()) { Store.celebrations.removeAt(0) }
        }
    }
}

@Composable
fun Shell() {
    val p = pal
    val st = Store.state
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val route = Nav.current
    val topLevel = route.name in SECTIONS && route.arg.isEmpty()

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(enabled = !drawer.isOpen && Nav.stack.size > 1) { Nav.back() }
    BackHandler(enabled = !drawer.isOpen && Nav.stack.size == 1 && route.name != st.settings.startPage) { Nav.root(st.settings.startPage) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = p.panel, modifier = Modifier.width(290.dp)) {
                DrawerContent { name -> scope.launch { drawer.close() }; Nav.root(name) }
            }
        }
    ) {
        Column(Modifier.fillMaxSize().background(p.bg).systemBarsPadding().imePadding()) {
            // ---------- Kopfleiste ----------
            Row(Modifier.fillMaxWidth().background(p.header).padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (Nav.stack.size > 1) IconBtn("←", color = p.onHeader) { Nav.back() }
                else IconBtn("☰", color = p.onHeader) { scope.launch { drawer.open() } }
                val title = if (route.name == "exercises" && route.arg == "pick") "Übung wählen" else SECTIONS[route.name] ?: TITLES[route.name] ?: APP_NAME
                Title(title, Modifier.weight(1f).padding(start = 4.dp), color = p.onHeader, size = 22.sp)
                Pill("🔥 ${Rewards.streak(st)}", p.gold)
                Spacer(Modifier.width(4.dp))
                IconBtn("⚙", color = p.onHeader) { if (route.name != "settings") Nav.go("settings") }
            }
            // ---------- Hinweise ----------
            if (topLevel) {
                val due = Training.dueToday(st)
                if (due != null) TrainingBanner(due)
            }
            val active = st.active
            if (active != null && route.name != "workout") ActiveWorkoutBar(active)

            Box(Modifier.weight(1f)) { RouteContent(route) }

            // ---------- Leiste unten (einstellbar) ----------
            if (topLevel || Nav.stack.size == 1) BottomTabs(st.settings.tabs, route.name)
        }
    }
}

@Composable
fun RouteContent(r: Route) {
    when (r.name) {
        "dashboard" -> DashboardScreen()
        "training" -> TrainingScreen()
        "workout" -> WorkoutScreen()
        "workoutlog" -> WorkoutLogScreen(r.arg.toLongOrNull() ?: 0L)
        "plan" -> PlanEditor(r.arg)
        "cardio" -> CardioScreen()
        "exercises" -> ExercisesScreen(pick = r.arg == "pick")
        "exercise" -> ExerciseDetail(r.arg)
        "exercise_new" -> CustomExerciseEditor()
        "tasks" -> TasksScreen()
        "task" -> TaskEditor(r.arg.toLongOrNull())
        "habits" -> HabitsScreen()
        "habit" -> HabitEditor(r.arg.toLongOrNull())
        "body" -> BodyScreen()
        "photos" -> PhotosScreen()
        "photo" -> PhotoView(r.arg.toLongOrNull() ?: 0L)
        "compare" -> CompareScreen()
        "stats" -> StatsScreen()
        "badges" -> BadgesScreen()
        "nutrition" -> NutritionScreen()
        "settings" -> SettingsScreen()
        "settings_x" -> SettingsSection(r.arg)
        else -> DashboardScreen()
    }
}

@Composable
fun DrawerContent(onGo: (String) -> Unit) {
    val p = pal
    Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState())) {
        Column(Modifier.fillMaxWidth().background(p.header).padding(18.dp)) {
            Title(APP_NAME, color = p.onHeader, size = 28.sp)
            val li = Rewards.levelInfo(Rewards.totalXp())
            Muted("Level ${li.level} · ${Rewards.totalXp()} XP", color = p.onHeader.copy(alpha = 0.75f))
        }
        Spacer(Modifier.height(6.dp))
        SECTIONS.forEach { (k, label) ->
            val sel = Nav.stack.firstOrNull()?.name == k
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (sel) p.soft else Color.Transparent).clickable { onGo(k) }.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(SECTION_ICONS[k] ?: "•", Modifier.width(32.dp), fontSize = 18.sp, color = p.primary)
                Body(label, bold = sel, color = if (sel) p.primary else p.ink)
                if (k == "nutrition") { Spacer(Modifier.width(8.dp)); Pill("bald", p.gold) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Muted("Version $VERSION", Modifier.padding(horizontal = 20.dp))
    }
}

@Composable
fun BottomTabs(tabs: List<String>, current: String) {
    val p = pal
    Row(Modifier.fillMaxWidth().background(p.panel)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.line))
    }
    Row(Modifier.fillMaxWidth().background(p.panel).padding(vertical = 4.dp)) {
        tabs.filter { it in SECTIONS }.forEach { k ->
            val sel = Nav.stack.firstOrNull()?.name == k
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).clickable { Nav.root(k) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(SECTION_ICONS[k] ?: "•", fontSize = 19.sp, color = if (sel) p.primary else p.inkSoft)
                Text(SECTIONS[k] ?: k, fontSize = 11.sp, color = if (sel) p.primary else p.inkSoft,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
                Box(Modifier.padding(top = 3.dp).width(18.dp).height(3.dp).clip(RoundedCornerShape(50)).background(if (sel) p.primary else Color.Transparent))
            }
        }
    }
}

/** großer Hinweis, wenn heute Training ansteht */
@Composable
fun TrainingBanner(s: Session) {
    val p = pal
    Row(
        Modifier.fillMaxWidth().background(p.secondary).clickable { Training.start(s.plan, s.day); Nav.go("workout") }.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🏋", fontSize = 26.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Title("Heute ist Training!", color = Color.White, size = 20.sp)
            Text("${s.day.name} · ${s.day.exercises.size} Übungen", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
        }
        Text("STARTEN ›", color = Color.White, fontFamily = Barlow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun ActiveWorkoutBar(w: Workout) {
    val p = pal
    var t by remember { mutableLongStateOf(now()) }
    LaunchedEffect(w.id) { while (true) { delay(1000); t = now() } }
    Row(
        Modifier.fillMaxWidth().background(p.primary).clickable { Nav.go("workout") }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("● ", color = p.onPrimary)
        Body("${w.name} läuft · ${fmtDuration(t - w.start)}", Modifier.weight(1f), color = p.onPrimary, bold = true)
        Text("FORTSETZEN ›", color = p.onPrimary, fontFamily = Barlow, fontWeight = FontWeight.Bold)
    }
}

// ---------- Feier mit Konfetti ----------
@Composable
fun CelebrationOverlay(c: Celebration, onDone: () -> Unit) {
    val p = pal
    val anim = rememberInfiniteTransition(label = "konfetti")
    val t by anim.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "t")
    val pieces = remember(c) { List(70) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextInt(5)) } }
    val colors = listOf(p.primary, p.secondary, p.gold, p.good, Color(0xFF7E57C2))
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable { onDone() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            pieces.forEach { (x, off, ci) ->
                val y = ((t + off) % 1f) * size.height
                val xx = x * size.width + kotlin.math.sin((t + off) * 12f) * 18.dp.toPx()
                drawRect(colors[ci], Offset(xx, y), androidx.compose.ui.geometry.Size(7.dp.toPx(), 11.dp.toPx()))
            }
        }
        Panel(Modifier.padding(28.dp)) {
            Text(c.emoji, Modifier.fillMaxWidth(), fontSize = 54.sp, textAlign = TextAlign.Center)
            Title(c.title, Modifier.fillMaxWidth().padding(vertical = 6.dp), size = 26.sp)
            c.lines.forEach { Body(it, Modifier.padding(vertical = 2.dp)) }
            Spacer(Modifier.height(14.dp))
            Btn("Weiter", Modifier.fillMaxWidth(), BtnKind.GOLD) { onDone() }
        }
    }
}
