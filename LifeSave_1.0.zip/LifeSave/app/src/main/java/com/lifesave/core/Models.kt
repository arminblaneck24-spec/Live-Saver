package com.lifesave.core

import java.util.Calendar

const val APP_NAME = "Life Save"
const val VERSION = "1.0"

private var lastId = 0L
fun newId(): Long {
    val t = System.currentTimeMillis()
    lastId = if (t > lastId) t else lastId + 1
    return lastId
}

// ================= Aufgaben =================
data class Subtask(val title: String, val done: Boolean = false)

data class Task(
    val id: Long = newId(),
    val title: String,
    val note: String = "",
    val due: Long? = null,
    val priority: Int = 2,               // 1 niedrig, 2 mittel, 3 hoch
    val category: String = "",
    val subtasks: List<Subtask> = emptyList(),
    val repeatDays: Int = 0,             // alle X Tage (0 = aus)
    val weekdays: List<Int> = emptyList(), // feste Wochentage
    val xp: Int = 10,
    val doneAt: Long? = null,
    val archived: Boolean = false,
    val notified: Boolean = false
)

// ================= Gewohnheiten =================
const val HABIT_DAILY = 0
const val HABIT_WEEKDAYS = 1
const val HABIT_PER_WEEK = 2

data class Habit(
    val id: Long = newId(),
    val title: String,
    val target: Int = 1,                 // Tagesziel (Anzahl)
    val unit: String = "",
    val baseXp: Int = 10,
    val mode: Int = HABIT_DAILY,
    val weekdays: List<Int> = emptyList(),
    val perWeek: Int = 3,
    val progress: Int = 0,
    val progressDay: Long = 0L,
    val doneDays: List<Long> = emptyList()
)

// ================= XP-Verlauf (Grundlage für Level, Streak und das spätere Spiel) =================
data class XpEntry(val refId: Long, val title: String, val kind: String, val xp: Int, val at: Long)

// ================= Training =================
data class PlanExercise(val exId: String, val sets: Int = 3, val reps: Int = 10, val note: String = "")

data class PlanDay(
    val id: Long = newId(),
    val name: String,
    val exercises: List<PlanExercise> = emptyList(),
    val week: Int = 1,                   // nur Wochenplan: Woche im Zyklus (1..N)
    val weekdays: List<Int> = emptyList() // nur Wochenplan: an diesen Tagen
)

const val PLAN_SCHEDULE = 0   // Wochenplan, wiederholt sich alle N Wochen
const val PLAN_ROTATION = 1   // feste Reihenfolge, egal wann (A, B, A, B ...)

data class Plan(
    val id: Long = newId(),
    val name: String,
    val mode: Int = PLAN_ROTATION,
    val cycleWeeks: Int = 1,
    val startDate: Long = startOfWeek(now()),
    val days: List<PlanDay> = emptyList(),
    val nextIndex: Int = 0,              // Rotation: welcher Tag als Nächstes dran ist
    val trainDays: List<Int> = emptyList() // Rotation: an diesen Wochentagen wird erinnert
)

data class SetEntry(val weight: Double = 0.0, val reps: Int = 0, val done: Boolean = false)
data class WorkoutExercise(val exId: String, val sets: List<SetEntry>, val targetReps: Int = 0)

data class Workout(
    val id: Long = newId(),
    val name: String,
    val planId: Long? = null,
    val dayId: Long? = null,
    val start: Long = now(),
    val end: Long? = null,
    val exercises: List<WorkoutExercise> = emptyList(),
    val current: Int = 0
)

data class CardioSession(
    val id: Long = newId(), val type: String, val minutes: Int, val km: Double = 0.0,
    val at: Long = now(), val note: String = ""
)

data class RecordEntry(val exId: String, val kind: String, val value: Double, val at: Long, val workoutId: Long)

data class CustomExercise(
    val id: String, val name: String, val primary: List<String>, val secondary: List<String> = emptyList(),
    val equipment: String = "other", val note: String = ""
)

// ================= Körper =================
data class WeightEntry(val id: Long = newId(), val kg: Double, val at: Long = now())
data class PhotoEntry(val id: Long = newId(), val file: String, val at: Long = now(), val note: String = "")

// ================= Einstellungen =================
data class Tile(val id: String, val visible: Boolean = true)

val SECTIONS = linkedMapOf(
    "dashboard" to "Start",
    "training" to "Training",
    "exercises" to "Übungen",
    "tasks" to "Aufgaben",
    "habits" to "Gewohnheiten",
    "body" to "Körper",
    "stats" to "Statistik",
    "nutrition" to "Ernährung",
    "settings" to "Einstellungen"
)
val SECTION_ICONS = mapOf(
    "dashboard" to "⌂", "training" to "🏋", "exercises" to "📖", "tasks" to "✓", "habits" to "🔥",
    "body" to "⚖", "stats" to "📊", "nutrition" to "🥗", "settings" to "⚙"
)

val TILE_NAMES = linkedMapOf(
    "hero" to "Level & Streak",
    "training" to "Nächstes Training",
    "body" to "Mannequin",
    "tasks" to "Aufgaben heute",
    "habits" to "Gewohnheiten heute",
    "weight" to "Gewicht",
    "records" to "Rekorde & Abzeichen"
)
val DEFAULT_TILES = TILE_NAMES.keys.map { Tile(it) }

val WIDGET_BLOCKS = linkedMapOf(
    "header" to "Kopfzeile (Datum)",
    "streak" to "Streak & Level",
    "training" to "Training",
    "tasks" to "Aufgaben",
    "habits" to "Gewohnheiten",
    "weight" to "Gewicht",
    "body" to "Mannequin"
)
val WIDGET_TEMPLATES = linkedMapOf(
    "kompakt" to listOf("streak", "training"),
    "training" to listOf("training", "body", "streak"),
    "komplett" to listOf("header", "streak", "training", "tasks", "habits", "weight")
)

data class WidgetCfg(
    val template: String = "komplett",
    val blocks: List<Tile> = WIDGET_BLOCKS.keys.map { Tile(it, it in WIDGET_TEMPLATES["komplett"]!!) },
    val bg: String = "#0B1E33",
    val fg: String = "#FFFFFF",
    val accent: String = "#C9A227",
    val alpha: Int = 235,
    val radius: Int = 18
)

data class Settings(
    val startPage: String = "dashboard",
    val tabs: List<String> = listOf("dashboard", "training", "tasks", "body", "stats"),
    val tiles: List<Tile> = DEFAULT_TILES,
    val mannequinMode: Int = 0,          // 0 = zuletzt trainiert, 1 = Wochenvolumen
    val restSec: Int = 90,
    val themeId: String = "mel",
    val customColors: Map<String, String> = emptyMap(),
    val activePlanId: Long? = null,
    val widget: WidgetCfg = WidgetCfg(),
    // ---- nur mit Passwort änderbar ----
    val openMode: Int = 3,               // 0 jedes Entsperren, 1 alle X Min., 2 1× täglich, 3 nur wenn etwas offen ist, 4 aus
    val openInterval: Int = 60,
    val reviewHour: Int = 22,
    val weighDay: Int = Calendar.SATURDAY,
    val weighHour: Int = 11,
    val locksOn: Boolean = true,
    val protect: Boolean = true
)

data class AppState(
    val tasks: List<Task> = emptyList(),
    val categories: List<String> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val history: List<XpEntry> = emptyList(),
    val plans: List<Plan> = emptyList(),
    val workouts: List<Workout> = emptyList(),
    val active: Workout? = null,
    val cardio: List<CardioSession> = emptyList(),
    val records: List<RecordEntry> = emptyList(),
    val customEx: List<CustomExercise> = emptyList(),
    val exLinks: Map<String, String> = emptyMap(),
    val weights: List<WeightEntry> = emptyList(),
    val photos: List<PhotoEntry> = emptyList(),
    val badges: Map<String, Long> = emptyMap(),
    val settings: Settings = Settings(),
    val lastShown: Long = 0L,
    val reviewDay: Long = 0L,
    val weighSnoozeUntil: Long = 0L,
    val restUntil: Long = 0L
)
