package com.lifesave.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * Speicherformat. Jedes Feld wird mit Standardwert gelesen, damit neue Versionen
 * alte Dateien problemlos laden (neue Felder einfach hier ergänzen).
 */
object Json {
    const val FORMAT = 1

    // ---------- kleine Helfer ----------
    private fun JSONObject.objs(name: String): List<JSONObject> =
        optJSONArray(name)?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } } ?: emptyList()
    private fun JSONObject.ints(name: String): List<Int> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optInt(it) } } ?: emptyList()
    private fun JSONObject.longs(name: String): List<Long> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optLong(it) } } ?: emptyList()
    private fun JSONObject.strs(name: String): List<String> =
        optJSONArray(name)?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
    private fun JSONObject.optLongOrNull(name: String): Long? = if (has(name) && !isNull(name)) optLong(name) else null
    private fun JSONObject.strMap(name: String): Map<String, String> {
        val o = optJSONObject(name) ?: return emptyMap()
        return o.keys().asSequence().associateWith { o.optString(it) }
    }
    private fun JSONObject.longMap(name: String): Map<String, Long> {
        val o = optJSONObject(name) ?: return emptyMap()
        return o.keys().asSequence().associateWith { o.optLong(it) }
    }
    private fun arr(l: List<Any?>) = JSONArray(l)
    private fun <T> arrOf(l: List<T>, f: (T) -> JSONObject) = JSONArray(l.map(f))
    private fun mapObj(m: Map<String, Any>) = JSONObject().apply { m.forEach { (k, v) -> put(k, v) } }
    private fun JSONObject.putN(k: String, v: Long?) = apply { put(k, v ?: JSONObject.NULL) }

    // ---------- Tiles ----------
    private fun tile(t: Tile) = JSONObject().put("id", t.id).put("v", t.visible)
    private fun tileFrom(o: JSONObject) = Tile(o.optString("id"), o.optBoolean("v", true))
    /** gespeicherte Reihenfolge behalten, neu hinzugekommene Kacheln hinten anhängen */
    private fun mergeTiles(saved: List<Tile>, all: Collection<String>, defaultVisible: (String) -> Boolean): List<Tile> {
        val known = saved.filter { it.id in all }
        return known + all.filter { id -> known.none { it.id == id } }.map { Tile(it, defaultVisible(it)) }
    }

    // ================= Kodieren =================
    fun encode(s: AppState): String = JSONObject().apply {
        put("format", FORMAT)
        put("tasks", arrOf(s.tasks) { t ->
            JSONObject().put("id", t.id).put("title", t.title).put("note", t.note).putN("due", t.due)
                .put("priority", t.priority).put("category", t.category)
                .put("subtasks", arrOf(t.subtasks) { JSONObject().put("t", it.title).put("d", it.done) })
                .put("repeatDays", t.repeatDays).put("weekdays", arr(t.weekdays)).put("xp", t.xp)
                .putN("doneAt", t.doneAt).put("archived", t.archived).put("notified", t.notified)
        })
        put("categories", arr(s.categories))
        put("habits", arrOf(s.habits) { h ->
            JSONObject().put("id", h.id).put("title", h.title).put("target", h.target).put("unit", h.unit)
                .put("baseXp", h.baseXp).put("mode", h.mode).put("weekdays", arr(h.weekdays)).put("perWeek", h.perWeek)
                .put("progress", h.progress).put("progressDay", h.progressDay).put("doneDays", arr(h.doneDays))
        })
        put("history", arrOf(s.history) {
            JSONObject().put("r", it.refId).put("t", it.title).put("k", it.kind).put("x", it.xp).put("a", it.at)
        })
        put("plans", arrOf(s.plans) { p ->
            JSONObject().put("id", p.id).put("name", p.name).put("mode", p.mode).put("cycleWeeks", p.cycleWeeks)
                .put("startDate", p.startDate).put("nextIndex", p.nextIndex).put("trainDays", arr(p.trainDays))
                .put("days", arrOf(p.days) { d ->
                    JSONObject().put("id", d.id).put("name", d.name).put("week", d.week).put("weekdays", arr(d.weekdays))
                        .put("ex", arrOf(d.exercises) { e ->
                            JSONObject().put("id", e.exId).put("s", e.sets).put("r", e.reps).put("n", e.note)
                        })
                })
        })
        put("workouts", arrOf(s.workouts) { workout(it) })
        s.active?.let { put("active", workout(it)) }
        put("cardio", arrOf(s.cardio) {
            JSONObject().put("id", it.id).put("type", it.type).put("min", it.minutes).put("km", it.km).put("at", it.at).put("note", it.note)
        })
        put("records", arrOf(s.records) {
            JSONObject().put("e", it.exId).put("k", it.kind).put("v", it.value).put("a", it.at).put("w", it.workoutId)
        })
        put("customEx", arrOf(s.customEx) {
            JSONObject().put("id", it.id).put("name", it.name).put("p", arr(it.primary)).put("s", arr(it.secondary))
                .put("e", it.equipment).put("note", it.note)
        })
        put("exLinks", mapObj(s.exLinks))
        put("weights", arrOf(s.weights) { JSONObject().put("id", it.id).put("kg", it.kg).put("at", it.at) })
        put("photos", arrOf(s.photos) { JSONObject().put("id", it.id).put("file", it.file).put("at", it.at).put("note", it.note) })
        put("badges", mapObj(s.badges))
        val st = s.settings
        val w = st.widget
        put("settings", JSONObject()
            .put("startPage", st.startPage).put("tabs", arr(st.tabs))
            .put("tiles", arrOf(st.tiles) { tile(it) })
            .put("mannequinMode", st.mannequinMode).put("restSec", st.restSec)
            .put("themeId", st.themeId).put("customColors", mapObj(st.customColors))
            .putN("activePlanId", st.activePlanId)
            .put("widget", JSONObject().put("template", w.template).put("blocks", arrOf(w.blocks) { tile(it) })
                .put("bg", w.bg).put("fg", w.fg).put("accent", w.accent).put("alpha", w.alpha).put("radius", w.radius))
            .put("openMode", st.openMode).put("openInterval", st.openInterval).put("reviewHour", st.reviewHour)
            .put("weighDay", st.weighDay).put("weighHour", st.weighHour).put("locksOn", st.locksOn).put("protect", st.protect))
        put("lastShown", s.lastShown)
        put("reviewDay", s.reviewDay)
        put("weighSnoozeUntil", s.weighSnoozeUntil)
        put("restUntil", s.restUntil)
    }.toString()

    private fun workout(w: Workout) = JSONObject().put("id", w.id).put("name", w.name)
        .putN("planId", w.planId).putN("dayId", w.dayId).put("start", w.start).putN("end", w.end).put("cur", w.current)
        .put("ex", arrOf(w.exercises) { e ->
            JSONObject().put("id", e.exId).put("tr", e.targetReps).put("sets", arrOf(e.sets) {
                JSONObject().put("w", it.weight).put("r", it.reps).put("d", it.done)
            })
        })

    private fun workoutFrom(o: JSONObject) = Workout(
        id = o.optLong("id"), name = o.optString("name"),
        planId = o.optLongOrNull("planId"), dayId = o.optLongOrNull("dayId"),
        start = o.optLong("start"), end = o.optLongOrNull("end"), current = o.optInt("cur"),
        exercises = o.objs("ex").map { e ->
            WorkoutExercise(e.optString("id"), e.objs("sets").map { SetEntry(it.optDouble("w", 0.0), it.optInt("r"), it.optBoolean("d")) }, e.optInt("tr"))
        }
    )

    // ================= Dekodieren =================
    fun decode(text: String): AppState {
        val o = JSONObject(text)
        val so = o.optJSONObject("settings") ?: JSONObject()
        val d = Settings()
        val wo = so.optJSONObject("widget")
        val dw = WidgetCfg()
        val widget = if (wo == null) dw else WidgetCfg(
            template = wo.optString("template", dw.template),
            blocks = mergeTiles(wo.objs("blocks").map { tileFrom(it) }, WIDGET_BLOCKS.keys) { false },
            bg = wo.optString("bg", dw.bg), fg = wo.optString("fg", dw.fg), accent = wo.optString("accent", dw.accent),
            alpha = wo.optInt("alpha", dw.alpha), radius = wo.optInt("radius", dw.radius)
        )
        val settings = Settings(
            startPage = so.optString("startPage", d.startPage),
            tabs = so.strs("tabs").filter { it in SECTIONS }.ifEmpty { d.tabs },
            tiles = mergeTiles(so.objs("tiles").map { tileFrom(it) }, TILE_NAMES.keys) { true },
            mannequinMode = so.optInt("mannequinMode", d.mannequinMode),
            restSec = so.optInt("restSec", d.restSec),
            themeId = so.optString("themeId", d.themeId),
            customColors = so.strMap("customColors"),
            activePlanId = so.optLongOrNull("activePlanId"),
            widget = widget,
            openMode = so.optInt("openMode", d.openMode),
            openInterval = so.optInt("openInterval", d.openInterval),
            reviewHour = so.optInt("reviewHour", d.reviewHour),
            weighDay = so.optInt("weighDay", d.weighDay),
            weighHour = so.optInt("weighHour", d.weighHour),
            locksOn = so.optBoolean("locksOn", d.locksOn),
            protect = so.optBoolean("protect", d.protect)
        )
        return AppState(
            tasks = o.objs("tasks").map { t ->
                Task(
                    id = t.optLong("id"), title = t.optString("title"), note = t.optString("note"), due = t.optLongOrNull("due"),
                    priority = t.optInt("priority", 2), category = t.optString("category"),
                    subtasks = t.objs("subtasks").map { Subtask(it.optString("t"), it.optBoolean("d")) },
                    repeatDays = t.optInt("repeatDays"), weekdays = t.ints("weekdays"), xp = t.optInt("xp", 10),
                    doneAt = t.optLongOrNull("doneAt"), archived = t.optBoolean("archived"), notified = t.optBoolean("notified")
                )
            },
            categories = o.strs("categories"),
            habits = o.objs("habits").map { h ->
                Habit(
                    id = h.optLong("id"), title = h.optString("title"), target = h.optInt("target", 1), unit = h.optString("unit"),
                    baseXp = h.optInt("baseXp", 10), mode = h.optInt("mode"), weekdays = h.ints("weekdays"), perWeek = h.optInt("perWeek", 3),
                    progress = h.optInt("progress"), progressDay = h.optLong("progressDay"), doneDays = h.longs("doneDays")
                )
            },
            history = o.objs("history").map { XpEntry(it.optLong("r"), it.optString("t"), it.optString("k"), it.optInt("x"), it.optLong("a")) },
            plans = o.objs("plans").map { p ->
                Plan(
                    id = p.optLong("id"), name = p.optString("name"), mode = p.optInt("mode", PLAN_ROTATION),
                    cycleWeeks = p.optInt("cycleWeeks", 1).coerceAtLeast(1), startDate = p.optLong("startDate", startOfWeek(now())),
                    nextIndex = p.optInt("nextIndex"), trainDays = p.ints("trainDays"),
                    days = p.objs("days").map { dd ->
                        PlanDay(
                            id = dd.optLong("id"), name = dd.optString("name"), week = dd.optInt("week", 1), weekdays = dd.ints("weekdays"),
                            exercises = dd.objs("ex").map { PlanExercise(it.optString("id"), it.optInt("s", 3), it.optInt("r", 10), it.optString("n")) }
                        )
                    }
                )
            },
            workouts = o.objs("workouts").map { workoutFrom(it) },
            active = o.optJSONObject("active")?.let { workoutFrom(it) },
            cardio = o.objs("cardio").map {
                CardioSession(it.optLong("id"), it.optString("type"), it.optInt("min"), it.optDouble("km", 0.0), it.optLong("at"), it.optString("note"))
            },
            records = o.objs("records").map { RecordEntry(it.optString("e"), it.optString("k"), it.optDouble("v", 0.0), it.optLong("a"), it.optLong("w")) },
            customEx = o.objs("customEx").map {
                CustomExercise(it.optString("id"), it.optString("name"), it.strs("p"), it.strs("s"), it.optString("e", "other"), it.optString("note"))
            },
            exLinks = o.strMap("exLinks"),
            weights = o.objs("weights").map { WeightEntry(it.optLong("id"), it.optDouble("kg", 0.0), it.optLong("at")) },
            photos = o.objs("photos").map { PhotoEntry(it.optLong("id"), it.optString("file"), it.optLong("at"), it.optString("note")) },
            badges = o.longMap("badges"),
            settings = settings,
            lastShown = o.optLong("lastShown"),
            reviewDay = o.optLong("reviewDay"),
            weighSnoozeUntil = o.optLong("weighSnoozeUntil"),
            restUntil = o.optLong("restUntil")
        )
    }
}
