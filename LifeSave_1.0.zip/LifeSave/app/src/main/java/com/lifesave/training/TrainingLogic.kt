package com.lifesave.training

import com.lifesave.core.*

/** Ein anstehendes Training aus einem Plan */
data class Session(val plan: Plan, val day: PlanDay, val date: Long?, val today: Boolean)

object Training {

    // ================= Pläne =================
    fun activePlan(s: AppState = Store.state): Plan? =
        s.plans.find { it.id == s.settings.activePlanId } ?: s.plans.firstOrNull()

    /** Woche im Zyklus (1..N), in der t liegt */
    fun cycleWeek(p: Plan, t: Long): Int = Math.floorMod(weeksBetween(p.startDate, t), p.cycleWeeks.coerceAtLeast(1)) + 1

    fun doneOnDay(s: AppState, dayId: Long, day: Long): Boolean =
        s.workouts.any { it.dayId == dayId && startOfDay(it.start) == startOfDay(day) }

    fun trainedToday(s: AppState = Store.state): Boolean {
        val t = startOfDay(now())
        return s.workouts.any { startOfDay(it.start) == t } || s.cardio.any { startOfDay(it.at) == t }
    }

    fun next(p: Plan, s: AppState = Store.state): Session? {
        if (p.days.isEmpty()) return null
        val today = startOfDay(now())
        if (p.mode == PLAN_ROTATION) {
            val d = p.days[Math.floorMod(p.nextIndex, p.days.size)]
            val isDay = dow(today) in p.trainDays && s.workouts.none { it.planId == p.id && startOfDay(it.start) == today }
            return Session(p, d, null, isDay)
        }
        for (i in 0..(7 * p.cycleWeeks.coerceAtLeast(1))) {
            val t = startOfDay(addDays(today, i))
            val w = cycleWeek(p, t)
            val d = p.days.find { it.week == w && dow(t) in it.weekdays } ?: continue
            if (i == 0 && doneOnDay(s, d.id, t)) continue
            return Session(p, d, t, i == 0)
        }
        return null
    }

    fun nextSession(s: AppState = Store.state): Session? = activePlan(s)?.let { next(it, s) }

    /** heute steht Training an und es wurde noch nicht trainiert */
    fun dueToday(s: AppState = Store.state): Session? = nextSession(s)?.takeIf { it.today && s.active == null && !trainedToday(s) }

    fun upsertPlan(p: Plan) = Store.update { s ->
        val plans = if (s.plans.any { it.id == p.id }) s.plans.map { if (it.id == p.id) p else it } else s.plans + p
        s.copy(plans = plans, settings = if (s.settings.activePlanId == null) s.settings.copy(activePlanId = p.id) else s.settings)
    }

    fun deletePlan(id: Long) = Store.update { s ->
        s.copy(plans = s.plans.filterNot { it.id == id },
            settings = if (s.settings.activePlanId == id) s.settings.copy(activePlanId = null) else s.settings)
    }

    fun activate(id: Long) = Store.setSettings { it.copy(activePlanId = id) }

    // ================= Workout =================
    fun lastSets(exId: String, s: AppState = Store.state): List<SetEntry> =
        s.workouts.sortedByDescending { it.start }.firstNotNullOfOrNull { w ->
            w.exercises.find { it.exId == exId }?.sets?.filter { it.done }?.takeIf { it.isNotEmpty() }
        } ?: emptyList()

    fun start(plan: Plan?, day: PlanDay?) {
        if (Store.state.active != null) return
        val ex = day?.exercises?.map { pe ->
            WorkoutExercise(pe.exId, List(pe.sets.coerceAtLeast(1)) { SetEntry() }, pe.reps)
        } ?: emptyList()
        val w = Workout(name = day?.name ?: "Freies Training", planId = plan?.id, dayId = day?.id, exercises = ex)
        Store.update { it.copy(active = w) }
    }

    fun edit(f: (Workout) -> Workout) = Store.update { s -> s.active?.let { s.copy(active = f(it)) } ?: s }

    fun setSet(exIdx: Int, setIdx: Int, f: (SetEntry) -> SetEntry) = edit { w ->
        w.copy(exercises = w.exercises.mapIndexed { i, e ->
            if (i != exIdx) e else e.copy(sets = e.sets.mapIndexed { j, st -> if (j == setIdx) f(st) else st })
        })
    }

    fun toggleDone(exIdx: Int, setIdx: Int) {
        val st = Store.state.active?.exercises?.getOrNull(exIdx)?.sets?.getOrNull(setIdx) ?: return
        setSet(exIdx, setIdx) { it.copy(done = !it.done) }
        if (!st.done) startRest() else stopRest()
    }

    fun addSet(exIdx: Int) = edit { w ->
        w.copy(exercises = w.exercises.mapIndexed { i, e ->
            if (i != exIdx) e else e.copy(sets = e.sets + (e.sets.lastOrNull()?.copy(done = false) ?: SetEntry()))
        })
    }

    fun removeSet(exIdx: Int) = edit { w ->
        w.copy(exercises = w.exercises.mapIndexed { i, e -> if (i != exIdx || e.sets.size <= 1) e else e.copy(sets = e.sets.dropLast(1)) })
    }

    fun addExercise(exId: String) = edit { w ->
        val last = lastSets(exId)
        val n = last.size.coerceIn(3, 5)
        w.copy(exercises = w.exercises + WorkoutExercise(exId, List(n) { SetEntry() }), current = w.exercises.size)
    }

    fun removeExercise(idx: Int) = edit { w ->
        val l = w.exercises.filterIndexed { i, _ -> i != idx }
        w.copy(exercises = l, current = w.current.coerceAtMost((l.size - 1).coerceAtLeast(0)))
    }

    fun go(idx: Int) = edit { w -> w.copy(current = idx.coerceIn(0, (w.exercises.size - 1).coerceAtLeast(0))) }

    fun startRest() = Store.update { it.copy(restUntil = now() + it.settings.restSec * 1000L) }
    fun stopRest() = Store.update { it.copy(restUntil = 0L) }
    fun shiftRest(sec: Int) = Store.update { it.copy(restUntil = (it.restUntil + sec * 1000L).coerceAtLeast(now())) }

    fun cancel() = Store.update { it.copy(active = null, restUntil = 0L) }

    /** Workout abschließen: Rekorde prüfen, XP vergeben, Plan weiterschalten */
    fun finish(): Workout? {
        val s = Store.state
        val raw = s.active ?: return null
        // nicht abgehakte Sätze verwerfen, leere Übungen entfernen
        val w = raw.copy(end = now(), exercises = raw.exercises.map { e -> e.copy(sets = e.sets.filter { it.done }) }.filter { it.sets.isNotEmpty() })
        val newRecords = findRecords(w, s)
        Store.update { st ->
            val plans = st.plans.map { p ->
                if (p.id == w.planId && p.mode == PLAN_ROTATION && p.days.isNotEmpty()) {
                    val idx = p.days.indexOfFirst { it.id == w.dayId }
                    p.copy(nextIndex = if (idx >= 0) (idx + 1) % p.days.size else p.nextIndex)
                } else p
            }
            st.copy(active = null, restUntil = 0L, workouts = if (w.exercises.isEmpty()) st.workouts else st.workouts + w,
                records = st.records + newRecords, plans = plans)
        }
        if (w.exercises.isEmpty()) return null
        val xp = (30 + w.doneSets() * 2).coerceAtMost(120)
        Store.celebrate(Celebration(
            "Workout geschafft!",
            listOf(
                "${w.name} · ${fmtDuration((w.end ?: now()) - w.start)}",
                "${w.doneSets()} Sätze · ${fmtNum(w.volume())} bewegt",
                "+$xp XP"
            ) + newRecords.map { "🏆 ${ExerciseDb.name(it.exId)}: ${recordText(it)}" },
            "💪"
        ))
        Rewards.addXp(w.id, w.name, "workout", xp)
        return w
    }

    fun deleteWorkout(id: Long) = Store.update { s ->
        s.copy(workouts = s.workouts.filterNot { it.id == id }, records = s.records.filterNot { it.workoutId == id },
            history = s.history.filterNot { it.refId == id && it.kind == "workout" })
    }

    // ================= Rekorde =================
    const val R_WEIGHT = "weight"
    const val R_E1RM = "e1rm"
    const val R_VOLUME = "volume"
    const val R_REPS = "reps"

    fun e1rm(w: Double, r: Int) = if (r <= 0) 0.0 else if (r == 1) w else w * (1 + r / 30.0)

    fun recordText(r: RecordEntry) = when (r.kind) {
        R_WEIGHT -> "Höchstes Gewicht ${fmtKg(r.value)} kg"
        R_E1RM -> "Geschätztes 1RM ${fmtKg(Math.round(r.value * 10) / 10.0)} kg"
        R_VOLUME -> "Meistes Volumen ${fmtNum(r.value)}"
        else -> "Meiste Wiederholungen ${r.value.toInt()}"
    }

    data class ExBest(val weight: Double, val e1rm: Double, val volume: Double, val reps: Int)

    fun bestOf(e: WorkoutExercise): ExBest {
        val d = e.sets.filter { it.done }
        return ExBest(
            d.maxOfOrNull { it.weight } ?: 0.0,
            d.maxOfOrNull { e1rm(it.weight, it.reps) } ?: 0.0,
            d.sumOf { it.weight * it.reps },
            d.maxOfOrNull { it.reps } ?: 0
        )
    }

    fun bests(exId: String, s: AppState = Store.state): ExBest? {
        val l = s.workouts.flatMap { w -> w.exercises.filter { it.exId == exId } }.map { bestOf(it) }
        if (l.isEmpty()) return null
        return ExBest(l.maxOf { it.weight }, l.maxOf { it.e1rm }, l.maxOf { it.volume }, l.maxOf { it.reps })
    }

    private fun findRecords(w: Workout, s: AppState): List<RecordEntry> {
        val out = mutableListOf<RecordEntry>()
        w.exercises.groupBy { it.exId }.forEach { (exId, list) ->
            val prev = bests(exId, s) ?: return@forEach   // erstes Mal = noch kein Rekord, nur Basiswert
            val cur = list.map { bestOf(it) }
            val cw = cur.maxOf { it.weight }; val ce = cur.maxOf { it.e1rm }; val cv = cur.maxOf { it.volume }; val cr = cur.maxOf { it.reps }
            if (cw > prev.weight && cw > 0) out += RecordEntry(exId, R_WEIGHT, cw, now(), w.id)
            else if (ce > prev.e1rm + 0.01 && cw > 0) out += RecordEntry(exId, R_E1RM, ce, now(), w.id)
            if (cv > prev.volume && cv > 0) out += RecordEntry(exId, R_VOLUME, cv, now(), w.id)
            if (cw == 0.0 && cr > prev.reps) out += RecordEntry(exId, R_REPS, cr.toDouble(), now(), w.id)
        }
        return out
    }

    // ================= Muskeln =================
    /** zuletzt trainiert je Muskel */
    fun lastTrained(s: AppState = Store.state): Map<String, Long> {
        val m = mutableMapOf<String, Long>()
        s.workouts.forEach { w ->
            w.exercises.filter { e -> e.sets.any { it.done } }.forEach { e ->
                val ex = ExerciseDb.get(e.exId) ?: return@forEach
                (ex.primary + ex.secondary).forEach { mu -> if ((m[mu] ?: 0L) < w.start) m[mu] = w.start }
            }
        }
        return m
    }

    data class MuscleStat(val sets: Double, val volume: Double)

    /** Sätze (Hauptmuskel 1, Nebenmuskel 0,5) und kg-Volumen je Muskel ab [from] */
    fun muscleStats(from: Long, s: AppState = Store.state): Map<String, MuscleStat> {
        val sets = mutableMapOf<String, Double>(); val vol = mutableMapOf<String, Double>()
        s.workouts.filter { it.start >= from }.forEach { w ->
            w.exercises.forEach { e ->
                val ex = ExerciseDb.get(e.exId) ?: return@forEach
                val done = e.sets.filter { it.done }
                val n = done.size.toDouble(); val v = done.sumOf { it.weight * it.reps }
                ex.primary.forEach { sets[it] = (sets[it] ?: 0.0) + n; vol[it] = (vol[it] ?: 0.0) + v }
                ex.secondary.forEach { sets[it] = (sets[it] ?: 0.0) + n * 0.5; vol[it] = (vol[it] ?: 0.0) + v * 0.5 }
            }
        }
        return (sets.keys + vol.keys).associateWith { MuscleStat(sets[it] ?: 0.0, vol[it] ?: 0.0) }
    }

    /** Farbstärke 0..1 je Muskel fürs Mannequin: mode 0 = zuletzt trainiert (verblasst über 7 Tage), 1 = Wochenvolumen */
    fun intensity(mode: Int, s: AppState = Store.state): Map<String, Float> {
        if (mode == 1) {
            val st = muscleStats(addDays(startOfDay(now()), -6), s)
            val max = (st.values.maxOfOrNull { it.sets } ?: 0.0).coerceAtLeast(10.0)
            return st.mapValues { (it.value.sets / max).toFloat().coerceIn(0f, 1f) }
        }
        val n = now()
        return lastTrained(s).mapValues { (_, t) -> (1f - (n - t) / (7 * 86_400_000f)).coerceIn(0f, 1f) }
    }

    fun exerciseIntensity(e: Ex): Map<String, Float> = e.secondary.associateWith { 0.45f } + e.primary.associateWith { 1f }

    // ================= Cardio =================
    val CARDIO_TYPES = listOf("Laufen", "Radfahren", "Gehen", "Schwimmen", "Rudern", "Crosstrainer", "Stepper", "Seilspringen", "Sonstiges")

    fun addCardio(c: CardioSession) {
        Store.update { it.copy(cardio = it.cardio + c) }
        Rewards.addXp(c.id, c.type, "cardio", (c.minutes / 2).coerceIn(5, 60))
    }

    fun deleteCardio(id: Long) = Store.update { s ->
        s.copy(cardio = s.cardio.filterNot { it.id == id }, history = s.history.filterNot { it.refId == id && it.kind == "cardio" })
    }

    // ================= Vorlagen =================
    private fun day(name: String, vararg ex: String, week: Int = 1, days: List<Int> = emptyList()) =
        PlanDay(name = name, exercises = ex.map { PlanExercise(it) }, week = week, weekdays = days)

    val TEMPLATES: Map<String, () -> Plan> = linkedMapOf(
        "Ganzkörper (A/B)" to {
            Plan(name = "Ganzkörper", mode = PLAN_ROTATION, days = listOf(
                day("Ganzkörper A", "Barbell_Squat", "Barbell_Bench_Press_-_Medium_Grip", "Bent_Over_Barbell_Row", "Dumbbell_Shoulder_Press", "Plank"),
                day("Ganzkörper B", "Romanian_Deadlift", "Incline_Dumbbell_Press", "Wide-Grip_Lat_Pulldown", "Side_Lateral_Raise", "Cable_Crunch")
            ))
        },
        "Oberkörper / Unterkörper" to {
            Plan(name = "Ober-/Unterkörper", mode = PLAN_ROTATION, days = listOf(
                day("Oberkörper", "Barbell_Bench_Press_-_Medium_Grip", "Bent_Over_Barbell_Row", "Dumbbell_Shoulder_Press", "Wide-Grip_Lat_Pulldown", "Barbell_Curl", "Triceps_Pushdown"),
                day("Unterkörper", "Barbell_Squat", "Romanian_Deadlift", "Leg_Press", "Lying_Leg_Curls", "Standing_Calf_Raises", "Hanging_Leg_Raise")
            ))
        },
        "Push / Pull / Beine" to {
            Plan(name = "Push/Pull/Beine", mode = PLAN_ROTATION, days = listOf(
                day("Push", "Barbell_Bench_Press_-_Medium_Grip", "Incline_Dumbbell_Press", "Dumbbell_Shoulder_Press", "Side_Lateral_Raise", "Triceps_Pushdown_-_Rope_Attachment"),
                day("Pull", "Pullups", "Bent_Over_Barbell_Row", "Seated_Cable_Rows", "Face_Pull", "Hammer_Curls", "EZ-Bar_Curl"),
                day("Beine", "Barbell_Squat", "Romanian_Deadlift", "Leg_Extensions", "Lying_Leg_Curls", "Standing_Calf_Raises")
            ))
        },
        "Leer (Wochenplan)" to { Plan(name = "Mein Wochenplan", mode = PLAN_SCHEDULE, days = emptyList()) }
    )
}
