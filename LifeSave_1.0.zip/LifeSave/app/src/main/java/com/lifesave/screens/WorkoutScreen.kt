package com.lifesave.screens

import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*
import kotlinx.coroutines.delay

/**
 * Laufendes Workout: zeigt immer die aktuelle Übung. Gewichte und Wiederholungen trägst du selbst ein,
 * die Werte vom letzten Mal stehen klein daneben. Abhaken startet die Satzpause.
 */
@Composable
fun WorkoutScreen() {
    val st = Store.state
    val p = pal
    val ctx = LocalContext.current
    val w = st.active
    var t by remember { mutableLongStateOf(now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500); t = now()
            val r = Store.state.restUntil
            if (r != 0L && t >= r && Store.restAlerted != r) {
                Store.restAlerted = r
                runCatching { ctx.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)) }
                Training.stopRest()
            }
        }
    }
    var finishAsk by remember { mutableStateOf(false) }
    var cancelAsk by remember { mutableStateOf(false) }
    var copyVersion by remember { mutableIntStateOf(0) }

    if (w == null) {
        Screen {
            item {
                Panel {
                    Body("Gerade läuft kein Workout.", bold = true)
                    Spacer(Modifier.height(8.dp))
                    Btn("Freies Training starten", Modifier.fillMaxWidth()) { Training.start(null, null) }
                    Spacer(Modifier.height(8.dp))
                    Btn("Zum Training", Modifier.fillMaxWidth(), BtnKind.GHOST) { Nav.root("training") }
                }
            }
        }
        return
    }

    if (finishAsk) {
        val open = w.exercises.sumOf { e -> e.sets.count { !it.done } }
        ConfirmDialog("Workout beenden?",
            if (open > 0) "$open Sätze sind nicht abgehakt und werden nicht gespeichert." else "Super Arbeit! Workout speichern?",
            "Beenden", { finishAsk = false }) { Training.finish(); Nav.back() }
    }
    if (cancelAsk) ConfirmDialog("Workout verwerfen?", "Alle Einträge dieses Workouts gehen verloren.", "Verwerfen", { cancelAsk = false }) {
        Training.cancel(); Nav.back()
    }

    val cur = w.current.coerceIn(0, (w.exercises.size - 1).coerceAtLeast(0))
    val e = w.exercises.getOrNull(cur)
    val ex = e?.let { ExerciseDb.get(it.exId) }

    Column(Modifier.fillMaxSize()) {
        // ---------- Kopf ----------
        Row(Modifier.fillMaxWidth().background(p.panel).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Body(w.name, bold = true)
                Muted("⏱ ${fmtDuration(t - w.start)} · ${w.doneSets()} Sätze · ${fmtNum(w.volume())}")
            }
            Btn("Beenden", kind = BtnKind.DANGER, small = true) { finishAsk = true }
        }
        // ---------- Satzpause ----------
        if (st.restUntil > t) RestBar(st.restUntil - t)

        // ---------- Übungsleiste ----------
        val rowState = rememberLazyListState()
        LaunchedEffect(cur) { if (w.exercises.isNotEmpty()) rowState.animateScrollToItem(cur) }
        LazyRow(state = rowState, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)) {
            itemsIndexed(w.exercises) { i, we ->
                val done = we.sets.isNotEmpty() && we.sets.all { it.done }
                val sel = i == cur
                Box(
                    Modifier.padding(end = 6.dp).clip(RoundedCornerShape(50))
                        .background(if (sel) p.primary else if (done) p.good.copy(alpha = 0.18f) else p.panel)
                        .clickable { Training.go(i) }.padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text((if (done) "✓ " else "${i + 1}. ") + ExerciseDb.name(we.exId).take(22), fontSize = 13.sp,
                        color = if (sel) p.onPrimary else if (done) p.good else p.ink, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
            item {
                Box(Modifier.clip(RoundedCornerShape(50)).background(p.soft).clickable { Nav.pickExercise { Training.addExercise(it) } }
                    .padding(horizontal = 12.dp, vertical = 7.dp)) { Text("+ Übung", color = p.primary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
        }

        Box(Modifier.weight(1f)) {
            Screen {
                if (e == null) {
                    item {
                        Panel {
                            Body("Noch keine Übungen in diesem Workout.", bold = true)
                            Spacer(Modifier.height(8.dp))
                            Btn("+ Übung hinzufügen", Modifier.fillMaxWidth()) { Nav.pickExercise { Training.addExercise(it) } }
                        }
                    }
                } else {
                    item { CurrentExercise(w, cur, e, ex, copyVersion) { copyVersion++ } }
                    item {
                        Row {
                            Btn("‹ Zurück", Modifier.weight(1f), BtnKind.GHOST, enabled = cur > 0) { Training.go(cur - 1) }
                            Spacer(Modifier.width(8.dp))
                            if (cur < w.exercises.size - 1) Btn("Nächste ›", Modifier.weight(1f)) { Training.go(cur + 1) }
                            else Btn("Fertig ✓", Modifier.weight(1f), BtnKind.GOLD) { finishAsk = true }
                        }
                    }
                    item {
                        Row {
                            Btn("Übung entfernen", Modifier.weight(1f), BtnKind.GHOST, small = true) { Training.removeExercise(cur) }
                            Spacer(Modifier.width(8.dp))
                            Btn("Anleitung", Modifier.weight(1f), BtnKind.GHOST, small = true) { Nav.go("exercise", e.exId) }
                        }
                    }
                }
                item { Btn("Workout verwerfen", Modifier.fillMaxWidth(), BtnKind.GHOST, small = true) { cancelAsk = true } }
            }
        }
    }
}

@Composable
private fun RestBar(leftMs: Long) {
    val p = pal
    val total = Store.state.settings.restSec * 1000f
    Column(Modifier.fillMaxWidth().background(p.header).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Muted("SATZPAUSE", color = p.onHeader.copy(alpha = 0.7f))
                BigNumber(fmtDuration(leftMs + 999), p.onHeader, 34.sp)
            }
            Btn("−15", small = true, kind = BtnKind.SECONDARY) { Training.shiftRest(-15) }
            Spacer(Modifier.width(6.dp))
            Btn("+15", small = true, kind = BtnKind.SECONDARY) { Training.shiftRest(15) }
            Spacer(Modifier.width(6.dp))
            Btn("Weiter", small = true, kind = BtnKind.GOLD) { Training.stopRest() }
        }
        Spacer(Modifier.height(6.dp))
        Bar(leftMs / total, p.gold)
    }
}

@Composable
private fun CurrentExercise(w: Workout, idx: Int, e: WorkoutExercise, ex: Ex?, copyVersion: Int, onCopied: () -> Unit) {
    val p = pal
    val last = remember(e.exId, w.id) { Training.lastSets(e.exId) }
    val best = remember(e.exId, w.id) { Training.bests(e.exId) }
    Panel(accent = p.primary) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ExImage(ex?.images ?: emptyList(), Modifier.size(76.dp), animate = true)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Title(ex?.name ?: e.exId, size = 22.sp)
                Muted(ex?.primary?.joinToString(", ") { muscleDe(it) } ?: "")
                if (e.targetReps > 0) Pill("Ziel: ${e.sets.size} × ${e.targetReps}", p.primary)
            }
        }
        Spacer(Modifier.height(8.dp))
        if (last.isNotEmpty()) Muted("Letztes Mal: " + last.joinToString("  ·  ") { "${fmtKg(it.weight)}×${it.reps}" })
        else Muted("Erstes Mal bei dieser Übung")
        if (best != null && best.weight > 0) Muted("Bestwert: ${fmtKg(best.weight)} kg · 1RM ≈ ${fmtKg(Math.round(best.e1rm * 10) / 10.0)} kg")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Muted("SATZ", Modifier.width(40.dp), size = 11.sp)
            Muted("KG", Modifier.weight(1f).padding(start = 6.dp), size = 11.sp)
            Muted("WDH.", Modifier.weight(1f).padding(start = 6.dp), size = 11.sp)
            Spacer(Modifier.width(78.dp))
        }
        e.sets.forEachIndexed { si, s ->
            val prev = last.getOrNull(si) ?: last.lastOrNull()
            Row(
                Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (s.done) p.good.copy(alpha = 0.12f) else Color.Transparent).padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BigNumber("${si + 1}", if (s.done) p.good else p.inkSoft, 20.sp)
                Spacer(Modifier.width(22.dp))
                NumField(if (s.weight > 0) fmtKg(s.weight) else "", prev?.let { "kg · " + fmtKg(it.weight) } ?: "kg", Modifier.weight(1f).padding(end = 6.dp),
                    key = "${w.id}-$idx-$si-${e.exId}-$copyVersion") { v -> Training.setSet(idx, si) { it.copy(weight = parseNum(v) ?: 0.0) } }
                NumField(if (s.reps > 0) "${s.reps}" else "", prev?.let { "Wdh · ${it.reps}" } ?: (if (e.targetReps > 0) "Ziel ${e.targetReps}" else "Wdh."), Modifier.weight(1f),
                    decimal = false, key = "r${w.id}-$idx-$si-${e.exId}-$copyVersion") { v -> Training.setSet(idx, si) { it.copy(reps = v.toIntOrNull() ?: 0) } }
                IconBtn("↺", color = if (prev != null) p.primary else p.line, size = 36.dp) {
                    if (prev != null) { Training.setSet(idx, si) { it.copy(weight = prev.weight, reps = prev.reps) }; onCopied() }
                }
                Check(s.done, p.good, 38.dp) {
                    // leere Felder mit dem Zielwert füllen, damit der Satz zählt
                    if (!s.done && s.reps == 0 && e.targetReps > 0) Training.setSet(idx, si) { it.copy(reps = e.targetReps) }
                    Training.toggleDone(idx, si)
                    if (!s.done && s.reps == 0 && e.targetReps > 0) onCopied()
                }
            }
        }
        Row(Modifier.padding(top = 6.dp)) {
            Btn("+ Satz", small = true, kind = BtnKind.SECONDARY) { Training.addSet(idx) }
            Spacer(Modifier.width(8.dp))
            if (e.sets.size > 1) Btn("− Satz", small = true, kind = BtnKind.GHOST) { Training.removeSet(idx) }
            Spacer(Modifier.weight(1f))
            Muted("Pause: ${Store.state.settings.restSec}s", Modifier.align(Alignment.CenterVertically).clickable { Nav.go("settings_x", "general") })
        }
    }
}
