package com.lifesave.core

/**
 * Handy-Sperren: Wiegen (wöchentlich) und Tagesabschluss (abends).
 * Solange eine Sperre offen ist, leitet der Wächter-Dienst jede andere App auf Life Save um
 * (Telefon/Notruf/Uhr und die freigegebenen Apps bleiben frei). Alles ist in den Einstellungen frei einstellbar.
 */
object Locks {
    /** letzter Wiege-Termin (z. B. Samstag 11 Uhr), der schon erreicht ist */
    fun weighDueAt(s: AppState = Store.state, at: Long = now()): Long {
        if (s.settings.weighDaily) {
            val todayDue = atHour(startOfDay(at), s.settings.weighDailyHour)
            return if (at >= todayDue) todayDue else 0L
        }
        var d = startOfDay(at); var g = 0
        while (g < 8) {
            if (dow(d) == s.settings.weighDay && atHour(d, s.settings.weighHour) <= at) return atHour(d, s.settings.weighHour)
            d = startOfDay(addDays(d, -1)); g++
        }
        return 0L
    }

    fun weighedSince(s: AppState, t: Long) = s.weights.any { it.at >= startOfDay(t) }

    fun weighPending(s: AppState = Store.state): Boolean {
        if (!s.settings.locksOn || !s.settings.weighOn) return false
        val due = weighDueAt(s)
        if (due == 0L) return false
        val n = now()
        return n >= due && !weighedSince(s, due) && n >= s.weighSnoozeUntil
    }

    /** „Gerade keine Waage" → morgen zur selben Uhrzeit wieder */
    fun snoozeWeigh() = Store.update {
        it.copy(weighSnoozeUntil = atHour(addDays(startOfDay(now()), 1), if (it.settings.weighDaily) it.settings.weighDailyHour else it.settings.weighHour))
    }

    fun reviewPending(s: AppState = Store.state): Boolean =
        s.settings.locksOn && s.settings.reviewOn && hourNow() >= s.settings.reviewHour && s.reviewDay != startOfDay(now())

    fun finishReview() {
        Store.update { it.copy(reviewDay = startOfDay(now())) }
        Rewards.addXp(0L, "Tagesabschluss", "review", 10)
    }

    /** "weigh", "review" oder null */
    /** heute ist der wöchentliche Foto-Tag (Samstag bzw. eingestellter Wiege-Tag) */
    fun photoDay(s: AppState = Store.state) = dow(now()) == s.settings.weighDay

    /** „Jetzt eintragen" auf dem Tagesabschluss: 15 Minuten frei, um Essen nachzutragen */
    fun bypass(minutes: Int = 15) = Store.update { it.copy(lockBypassUntil = now() + minutes * 60_000L) }
    fun bypassActive(s: AppState = Store.state) = now() < s.lockBypassUntil

    fun pending(s: AppState = Store.state): String? = when {
        bypassActive(s) -> null
        // während eines laufenden Workouts (höchstens 3 Std.) wartet die Sperre
        s.active != null && now() - s.active.start < 3 * 3_600_000L -> null
        weighPending(s) -> "weigh"
        reviewPending(s) -> "review"
        else -> null
    }

    // ---------- Automatisch öffnen nach dem Entsperren ----------
    fun shouldOpen(s: AppState = Store.state, somethingOpen: Boolean): Boolean {
        val st = s.settings
        val n = now()
        return when (st.openMode) {
            0 -> true
            1 -> n - s.lastShown >= st.openInterval * 60_000L
            2 -> startOfDay(n) != startOfDay(s.lastShown)
            3 -> somethingOpen && n - s.lastShown >= 15 * 60_000L
            else -> false
        }
    }

    fun markShown() = Store.update { it.copy(lastShown = now()) }
}
