package com.lifesave.widget

import android.graphics.*
import com.lifesave.core.*
import com.lifesave.training.ExerciseDb
import com.lifesave.training.Training
import com.lifesave.ui.BodyMap
import java.util.Locale

/**
 * Zeichnet die einzelnen Widget-Typen als Bild. Farben, Deckkraft und Ecken kommen aus
 * Einstellungen → Widget und gelten für alle Widgets gleich.
 * Jeder Typ passt sich an die Größe an: schmal = nur das Wichtigste, groß = mehr Details.
 */
object KindRenderer {
    private fun col(s: String, f: Int) = runCatching { Color.parseColor(s) }.getOrDefault(f)
    private fun a(c: Int, alpha: Int) = (c and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
    private fun n(v: Double) = String.format(Locale.GERMANY, "%,d", Math.round(v))

    /** Zeichenfläche mit Farben und Hilfsfunktionen */
    private class D(val c: Canvas, val w: Float, val h: Float, val u: Float, cfg: WidgetCfg) {
        val fg = col(cfg.fg, Color.WHITE)
        val ac = col(cfg.accent, Color.parseColor("#C9A227"))
        val soft = a(fg, 0xA8)
        val track = a(fg, 0x2E)
        val good = Color.parseColor("#3FB950")
        val pad = 12 * u
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val wide: Boolean get() = w > h * 1.3f

        fun p(color: Int, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color; textSize = size * u; textAlign = align
                if (bold) typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

        fun clip(t: String, paint: Paint, maxW: Float): String {
            if (paint.measureText(t) <= maxW) return t
            var e = t
            while (e.isNotEmpty() && paint.measureText("$e…") > maxW) e = e.dropLast(1)
            return "$e…"
        }

        /** Überschrift oben links (+ optional Text rechts); liefert die y-Position darunter */
        fun title(t: String, right: String = ""): Float {
            val y = pad + 11 * u
            val tp = p(ac, 11f, true).apply { letterSpacing = 0.08f }
            val rp = p(soft, 11f, align = Paint.Align.RIGHT)
            val rw = if (right.isNotEmpty()) rp.measureText(right) + 8 * u else 0f
            c.drawText(clip(t, tp, w - 2 * pad - rw), pad, y, tp)
            if (right.isNotEmpty()) c.drawText(right, w - pad, y, rp)
            return y + 8 * u
        }

        fun ring(cx: Float, cy: Float, r: Float, frac: Float, color: Int, stroke: Float = r * 0.22f) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; strokeCap = Paint.Cap.ROUND }
            val rect = RectF(cx - r, cy - r, cx + r, cy + r)
            sp.color = track; c.drawArc(rect, 0f, 360f, false, sp)
            val f = frac.coerceIn(0f, 1f)
            if (f > 0.005f) { sp.color = color; c.drawArc(rect, -90f, 360f * f, false, sp) }
        }

        fun bar(x: Float, y: Float, bw: Float, bh: Float, frac: Float, color: Int) {
            fill.color = track; c.drawRoundRect(RectF(x, y, x + bw, y + bh), bh / 2, bh / 2, fill)
            val f = frac.coerceIn(0f, 1f)
            if (f > 0.01f) { fill.color = color; c.drawRoundRect(RectF(x, y, x + bw * f, y + bh), bh / 2, bh / 2, fill) }
        }

        fun center(t: String, size: Float = 13f) {
            val tp = p(soft, size, align = Paint.Align.CENTER)
            c.drawText(clip(t, tp, w - 2 * pad), w / 2, h / 2 + 8 * u, tp)
        }
    }

    fun render(kind: String, cfg: WidgetCfg, s: AppState, w: Int, h: Int, u: Float): Bitmap {
        if (kind == "komplett") return WidgetRenderer.render(cfg, s, w, h, u)
        val bmp = Bitmap.createBitmap(w.coerceAtLeast(10), h.coerceAtLeast(10), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = col(cfg.bg, Color.parseColor("#0B1E33"))
        val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = a(bg, cfg.alpha) }
        c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), cfg.radius * u, cfg.radius * u, bgP)
        val d = D(c, w.toFloat(), h.toFloat(), u, cfg)
        runCatching {
            when (kind) {
                "today" -> today(d, s)
                "plan" -> plan(d, s)
                "training" -> training(d, s)
                "week" -> week(d, s)
                "nutrition" -> nutrition(d, s)
                "habits" -> habits(d, s)
                "tasks" -> tasks(d, s)
                "water" -> water(d, s)
                "vitals" -> vitals(d, s)
                "weight" -> weight(d, s)
                "streak" -> streak(d, s)
                "body" -> body(d, s)
            }
        }
        return bmp
    }

    // ================= Heute: vier Ringe =================
    private fun today(d: D, s: AppState) {
        val y0 = d.title("📅 HEUTE", fmtShort(now()))
        val tt = Nutrition.totals(startOfDay(now()), s)
        val due = s.habits.filter { Habits.dueToday(it) }
        val rings = listOf(
            Triple("kcal", (tt["kcal"] ?: 0.0) / Nutrition.goal("kcal", s).coerceAtLeast(1.0), n(tt["kcal"] ?: 0.0)),
            Triple("Eiweiß", (tt["protein"] ?: 0.0) / Nutrition.goal("protein", s).coerceAtLeast(1.0), "${(tt["protein"] ?: 0.0).toInt()} g"),
            Triple("Wasser", Vitals.water(s).toDouble() / s.settings.waterGoal.coerceAtLeast(1), "${Vitals.water(s)}/${s.settings.waterGoal}"),
            Triple("Gewohnh.", if (due.isEmpty()) 1.0 else due.count { Habits.doneToday(it) }.toDouble() / due.size, "${due.count { Habits.doneToday(it) }}/${due.size}")
        )
        val colors = listOf(d.ac, Color.parseColor("#E5484D"), Color.parseColor("#3B9EFF"), d.good)
        val cols = if (d.w > d.h * 1.6f || d.h < 140 * d.u) 4 else 2
        val rows = 4 / cols
        val cellW = (d.w - 2 * d.pad) / cols
        val cellH = (d.h - y0 - d.pad) / rows
        val r = (minOf(cellW, cellH - 16 * d.u) / 2f * 0.78f).coerceAtLeast(8 * d.u)
        val vp = d.p(d.fg, (r / d.u * 0.42f).coerceIn(9f, 16f), true, Paint.Align.CENTER)
        val lp = d.p(d.soft, 10f, align = Paint.Align.CENTER)
        rings.forEachIndexed { i, (label, frac, value) ->
            val cx = d.pad + cellW * (i % cols) + cellW / 2
            val cy = y0 + cellH * (i / cols) + (cellH - 14 * d.u) / 2
            d.ring(cx, cy, r, frac.toFloat(), colors[i])
            d.c.drawText(d.clip(value, vp, r * 1.6f), cx, cy + vp.textSize * 0.35f, vp)
            d.c.drawText(label, cx, cy + r + 13 * d.u, lp)
        }
    }

    // ================= Tagesplan =================
    private fun plan(d: D, s: AppState) {
        val (cur, next) = Schedule.nowNext(s)
        var y = d.title("🗓 TAGESPLAN", fmtShort(now()))
        val maxW = d.w - 2 * d.pad
        val big = d.p(d.fg, 17f, true)
        if (cur != null) {
            y += 17 * d.u
            d.c.drawText("JETZT · bis ${fmtMin(cur.end)}", d.pad, y - 2 * d.u, d.p(d.ac, 10f, true))
            y += 15 * d.u
            d.c.drawText(d.clip(cur.title, big, maxW), d.pad, y, big)
            val m = minuteOf(now())
            y += 8 * d.u
            d.bar(d.pad, y, maxW, 5 * d.u, (m - cur.start).toFloat() / cur.dur.coerceAtLeast(1), runCatching { Color.parseColor(cur.color) }.getOrDefault(d.ac))
            y += 6 * d.u
        }
        // die nächsten Einträge des Tages
        val m = minuteOf(now())
        val rest = Schedule.items(startOfDay(now()), s).filter { !it.skipped && it.start >= m && it != cur }
        if (cur == null && rest.isEmpty()) { d.center(if (next == null) "Heute nichts mehr geplant" else ""); return }
        val row = d.p(d.fg, 12f); val time = d.p(d.soft, 11f)
        for (it in rest) {
            if (y + 17 * d.u > d.h - d.pad * 0.6f) break
            y += 17 * d.u
            d.fill.color = runCatching { Color.parseColor(it.color) }.getOrDefault(d.ac)
            d.c.drawRoundRect(RectF(d.pad, y - 10 * d.u, d.pad + 4 * d.u, y + 2 * d.u), 2 * d.u, 2 * d.u, d.fill)
            d.c.drawText(fmtMin(it.start), d.pad + 9 * d.u, y, time)
            val tx = d.pad + 48 * d.u
            d.c.drawText(d.clip(it.title, row, d.w - d.pad - tx), tx, y, row)
        }
    }

    // ================= Training =================
    private fun training(d: D, s: AppState) {
        val active = s.active
        val next = Training.nextSession(s)
        val doneToday = Training.trainedToday(s)
        val status = when {
            active != null -> "● LÄUFT"
            doneToday -> "✓ HEUTE ERLEDIGT"
            next?.today == true -> "HEUTE DRAN"
            next != null -> next.date?.let { WEEKDAY_LONG[dow(it)] } ?: "ALS NÄCHSTES"
            else -> ""
        }
        var y = d.title("🏋 TRAINING", status)
        val big = d.p(d.fg, 18f, true)
        val small = d.p(d.soft, 11f)
        val maxW = d.w - 2 * d.pad
        if (active != null) {
            y += 18 * d.u
            d.c.drawText(d.clip(active.name, big, maxW), d.pad, y, big)
            val total = active.exercises.sumOf { it.sets.size }
            y += 16 * d.u
            d.c.drawText("${active.doneSets()}/$total Sätze · ${fmtDuration(now() - active.start)}", d.pad, y, small)
            y += 8 * d.u
            d.bar(d.pad, y, maxW, 6 * d.u, active.doneSets().toFloat() / total.coerceAtLeast(1), d.ac)
            y += 10 * d.u
            val cur = active.exercises.firstOrNull { e -> e.sets.any { !it.done } }
            if (cur != null && y + 16 * d.u < d.h - d.pad) {
                y += 14 * d.u
                d.c.drawText(d.clip("Weiter: " + ExerciseDb.name(cur.exId), d.p(d.fg, 13f), maxW), d.pad, y, d.p(d.fg, 13f))
            }
            return
        }
        if (next == null) { d.center("Kein Plan – tippen zum Anlegen"); return }
        val ex = next.day.exercises
        y += 18 * d.u
        d.c.drawText(d.clip(next.day.name, big, maxW), d.pad, y, big)
        val sets = ex.sumOf { it.sets }
        y += 15 * d.u
        d.c.drawText("${ex.size} Übungen · $sets Sätze · ca. ${(sets * 2.7).toInt() + 5} Min", d.pad, y, small)
        y += 4 * d.u
        val row = d.p(d.fg, 12f)
        val reps = d.p(d.soft, 11f, align = Paint.Align.RIGHT)
        for (e in ex) {
            if (y + 17 * d.u > d.h - d.pad * 0.6f) break
            y += 16 * d.u
            val r = "${e.sets}×${e.lo}–${e.reps}"
            d.c.drawText(d.clip("• " + ExerciseDb.name(e.exId), row, maxW - reps.measureText(r) - 8 * d.u), d.pad, y, row)
            d.c.drawText(r, d.w - d.pad, y, reps)
        }
    }

    // ================= Wochenziel =================
    private fun week(d: D, s: AppState) {
        val goal = s.settings.weeklyGoal.coerceAtLeast(1)
        val cnt = Training.weekCount(s)
        val y0 = d.title("🎯 WOCHENZIEL", if (cnt >= goal) "✓ geschafft" else "")
        val areaH = d.h - y0 - d.pad
        val r = (minOf(areaH, if (d.wide) d.w * 0.4f else d.w - 2 * d.pad) / 2f * 0.82f).coerceAtLeast(10 * d.u)
        val cx = if (d.wide) d.pad + r + 4 * d.u else d.w / 2
        val cy = y0 + areaH / 2 + (if (d.wide) 0f else -10 * d.u)
        d.ring(cx, cy, r, cnt.toFloat() / goal, if (cnt >= goal) d.good else d.ac)
        val vp = d.p(d.fg, (r / d.u * 0.55f).coerceIn(12f, 26f), true, Paint.Align.CENTER)
        d.c.drawText("$cnt/$goal", cx, cy + vp.textSize * 0.35f, vp)
        if (!d.wide) return
        // Wochentage als Punkte
        val x0 = cx + r + 18 * d.u
        val dw = (d.w - d.pad - x0) / 7f
        val ws = startOfWeek(now())
        val today = startOfDay(now())
        val lp = d.p(d.soft, 10f, align = Paint.Align.CENTER)
        val dy = cy - 8 * d.u
        val dr = minOf(dw * 0.32f, 8 * d.u)
        WEEKDAYS.forEachIndexed { i, (_, label) ->
            val day = addDays(ws, i)
            val trained = s.workouts.any { startOfDay(it.start) == day } || s.cardio.any { startOfDay(it.at) == day }
            val x = x0 + dw * i + dw / 2
            d.fill.color = if (trained) d.ac else d.track
            d.c.drawCircle(x, dy, dr, d.fill)
            if (day == today) d.c.drawCircle(x, dy, dr + 2.5f * d.u, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d.u; color = d.fg })
            d.c.drawText(label, x, dy + dr + 13 * d.u, lp)
        }
        val ws2 = Training.weekStreak(s)
        val info = if (cnt >= goal) "🔥 $ws2 Wochen in Folge" else "Noch ${goal - cnt} Training${if (goal - cnt == 1) "" else "s"}" + if (ws2 > 0) " · 🔥 $ws2 Wo." else ""
        val ip = d.p(d.fg, 12f)
        d.c.drawText(d.clip(info, ip, d.w - d.pad - x0), x0, dy + dr + 32 * d.u, ip)
    }

    // ================= Ernährung =================
    private fun nutrition(d: D, s: AppState) {
        val tt = Nutrition.totals(startOfDay(now()), s)
        val kcal = tt["kcal"] ?: 0.0
        val goal = Nutrition.goal("kcal", s).coerceAtLeast(1.0)
        val rest = goal - kcal
        val y0 = d.title("🥗 ERNÄHRUNG", if (rest >= 0) "noch ${n(rest)} kcal" else "${n(-rest)} kcal drüber")
        val areaH = d.h - y0 - d.pad
        val r = (minOf(areaH, if (d.wide) d.w * 0.4f else d.w - 2 * d.pad) / 2f * 0.84f).coerceAtLeast(10 * d.u)
        val cx = if (d.wide) d.pad + r + 4 * d.u else d.w / 2
        val cy = y0 + areaH / 2
        d.ring(cx, cy, r, (kcal / goal).toFloat(), d.ac)
        val vp = d.p(d.fg, (r / d.u * 0.42f).coerceIn(11f, 22f), true, Paint.Align.CENTER)
        d.c.drawText(n(kcal), cx, cy + vp.textSize * 0.2f, vp)
        d.c.drawText("von ${n(goal)}", cx, cy + vp.textSize * 0.2f + 12 * d.u, d.p(d.soft, 9f, align = Paint.Align.CENTER))
        if (!d.wide) return
        val x0 = cx + r + 18 * d.u
        val bw = d.w - d.pad - x0
        val macros = listOf(
            Triple("Eiweiß", "protein", Color.parseColor("#E5484D")),
            Triple("Kohlenhydrate", "carbs", Color.parseColor("#3B9EFF")),
            Triple("Fett", "fat", Color.parseColor("#F5A524"))
        )
        val step = (areaH / 3f).coerceAtMost(30 * d.u)
        var y = cy - step * 1.5f + 10 * d.u
        val lp = d.p(d.fg, 11f)
        val vp2 = d.p(d.soft, 11f, align = Paint.Align.RIGHT)
        macros.forEach { (label, key, color) ->
            val v = tt[key] ?: 0.0; val g = Nutrition.goal(key, s).coerceAtLeast(1.0)
            d.c.drawText(label, x0, y, lp)
            d.c.drawText("${v.toInt()}/${g.toInt()} g", d.w - d.pad, y, vp2)
            d.bar(x0, y + 4 * d.u, bw, 6 * d.u, (v / g).toFloat(), color)
            y += step
        }
    }

    // ================= Gewohnheiten =================
    private fun habits(d: D, s: AppState) {
        val due = s.habits.filter { Habits.dueToday(it) }
        val done = due.count { Habits.doneToday(it) }
        var y = d.title("🔥 GEWOHNHEITEN", "$done/${due.size}")
        if (due.isEmpty()) { d.center("Heute keine Gewohnheiten"); return }
        val row = d.p(d.fg, 13f)
        val doneP = d.p(d.soft, 13f).apply { isStrikeThruText = true }
        val cnt = d.p(d.soft, 11f, align = Paint.Align.RIGHT)
        val r = 7 * d.u
        val sorted = due.sortedBy { Habits.doneToday(it) }
        for ((i, hb) in sorted.withIndex()) {
            if (y + 20 * d.u > d.h - d.pad * 0.5f) {
                val rest = sorted.size - i
                if (rest > 0) d.c.drawText("+ $rest weitere", d.w - d.pad, d.h - d.pad * 0.6f, cnt)
                break
            }
            y += 20 * d.u
            val ok = Habits.doneToday(hb)
            val cy = y - 4.5f * d.u
            if (ok) {
                d.fill.color = d.good; d.c.drawCircle(d.pad + r, cy, r, d.fill)
                d.c.drawText("✓", d.pad + r, cy + 4 * d.u, d.p(Color.WHITE, 10f, true, Paint.Align.CENTER))
            } else d.c.drawCircle(d.pad + r, cy, r - 0.8f * d.u, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * d.u; color = d.soft })
            val extra = if (hb.target > 1) "${Habits.progress(hb)}/${hb.target}" else ""
            val tx = d.pad + r * 2 + 8 * d.u
            d.c.drawText(d.clip(hb.title, if (ok) doneP else row, d.w - d.pad - tx - cnt.measureText(extra) - 6 * d.u), tx, y, if (ok) doneP else row)
            if (extra.isNotEmpty()) d.c.drawText(extra, d.w - d.pad, y, cnt)
        }
    }

    // ================= Aufgaben =================
    private fun tasks(d: D, s: AppState) {
        val open = Tasks.dueToday(s).sortedByDescending { it.priority }
        var y = d.title("✓ AUFGABEN", "${open.size} offen")
        if (open.isEmpty()) { d.center("Alles erledigt 🎉"); return }
        val row = d.p(d.fg, 13f)
        val time = d.p(d.soft, 11f, align = Paint.Align.RIGHT)
        val prio = mapOf(3 to Color.parseColor("#E5484D"), 2 to d.ac, 1 to d.soft)
        for ((i, t) in open.withIndex()) {
            if (y + 20 * d.u > d.h - d.pad * 0.5f) { d.c.drawText("+ ${open.size - i} weitere", d.w - d.pad, d.h - d.pad * 0.6f, time); break }
            y += 20 * d.u
            d.fill.color = prio[t.priority] ?: d.soft
            d.c.drawCircle(d.pad + 4 * d.u, y - 4.5f * d.u, 4 * d.u, d.fill)
            val tm = t.due?.let { if (startOfDay(it) == startOfDay(now())) fmtTime(it) else fmtShort(it) } ?: ""
            val tx = d.pad + 14 * d.u
            d.c.drawText(d.clip(t.title, row, d.w - d.pad - tx - time.measureText(tm) - 6 * d.u), tx, y, row)
            if (tm.isNotEmpty()) d.c.drawText(tm, d.w - d.pad, y, time)
        }
    }

    // ================= Wasser (+1 rechts) =================
    private fun water(d: D, s: AppState) {
        val cnt = Vitals.water(s); val goal = s.settings.waterGoal.coerceAtLeast(1)
        val y0 = d.title("💧 WASSER", "${cnt * 250} ml")
        val split = d.w * 0.75f
        val blue = Color.parseColor("#3B9EFF")
        // Gläser
        val n = maxOf(goal, cnt).coerceAtMost(16)
        val perRow = if (n > 8 && d.h > 120 * d.u) (n + 1) / 2 else n
        val rowsN = (n + perRow - 1) / perRow
        val big = d.p(d.fg, 20f, true)
        d.c.drawText("$cnt / $goal Gläser", d.pad, y0 + 20 * d.u, big)
        val gy0 = y0 + 30 * d.u
        val gw = ((split - 2 * d.pad) / perRow).coerceAtMost(22 * d.u)
        val gh = ((d.h - gy0 - d.pad) / rowsN - 4 * d.u).coerceIn(8 * d.u, 26 * d.u)
        for (i in 0 until n) {
            val x = d.pad + gw * (i % perRow)
            val y = gy0 + (gh + 4 * d.u) * (i / perRow)
            val rect = RectF(x + 2 * d.u, y, x + gw - 2 * d.u, y + gh)
            d.fill.color = if (i < cnt) blue else d.track
            d.c.drawRoundRect(rect, 3 * d.u, 3 * d.u, d.fill)
        }
        // Plus-Knopf
        val cx = split + (d.w - split) / 2
        val cy = d.h / 2 + 4 * d.u
        val r = minOf((d.w - split) / 2 - 8 * d.u, d.h / 2 - 22 * d.u).coerceAtLeast(12 * d.u)
        d.fill.color = d.ac
        d.c.drawCircle(cx, cy, r, d.fill)
        d.c.drawText("+", cx, cy + r * 0.38f, d.p(Color.parseColor("#12161C"), r / d.u * 1.1f, true, Paint.Align.CENTER))
        d.c.drawText("1 Glas", cx, (cy + r + 13 * d.u).coerceAtMost(d.h - 4 * d.u), d.p(d.soft, 10f, align = Paint.Align.CENTER))
    }

    // ================= Schlaf & Schritte =================
    private fun vitals(d: D, s: AppState) {
        var y = d.title("😴 SCHLAF & SCHRITTE")
        val sl = Vitals.sleep(s); val st = Vitals.steps(s)
        val rows = listOf(
            Triple("😴 Schlaf", sl?.let { Vitals.fmtHours(it) + " / " + Vitals.fmtHours(s.settings.sleepGoal) } ?: "nicht eingetragen",
                ((sl ?: 0.0) / s.settings.sleepGoal.coerceAtLeast(1.0)).toFloat() to Color.parseColor("#8E6CEF")),
            Triple("👟 Schritte", st?.let { n(it.toDouble()) + " / " + n(s.settings.stepGoal.toDouble()) } ?: "keine Daten",
                ((st ?: 0L).toFloat() / s.settings.stepGoal.coerceAtLeast(1)) to d.good),
            Triple("💧 Wasser", "${Vitals.water(s)} / ${s.settings.waterGoal} Gläser",
                (Vitals.water(s).toFloat() / s.settings.waterGoal.coerceAtLeast(1)) to Color.parseColor("#3B9EFF"))
        )
        val step = ((d.h - y - d.pad) / rows.size).coerceIn(22 * d.u, 36 * d.u)
        val lp = d.p(d.fg, 12f); val vp = d.p(d.soft, 11f, align = Paint.Align.RIGHT)
        rows.forEach { (label, value, fc) ->
            if (y + step > d.h + 4 * d.u) return
            y += step * 0.55f
            d.c.drawText(label, d.pad, y, lp)
            d.c.drawText(d.clip(value, vp, d.w * 0.55f), d.w - d.pad, y, vp)
            d.bar(d.pad, y + 5 * d.u, d.w - 2 * d.pad, 6 * d.u, fc.first, fc.second)
            y += step * 0.45f
        }
    }

    // ================= Gewicht =================
    private fun weight(d: D, s: AppState) {
        val l = BodyLog.latest(s)
        val y0 = d.title("⚖ GEWICHT", l?.let { fmtShort(it.at) } ?: "")
        if (l == null) { d.center("Noch kein Gewicht eingetragen"); return }
        val big = d.p(d.fg, 24f, true)
        d.c.drawText("${fmtKg(l.kg)} kg", d.pad, y0 + 24 * d.u, big)
        val ch = BodyLog.change(28, s)
        if (ch != null) {
            val t = (if (ch >= 0) "+" else "") + fmtKg(Math.round(ch * 10) / 10.0) + " kg in 4 Wochen"
            d.c.drawText(t, d.pad, y0 + 40 * d.u, d.p(d.soft, 11f))
        }
        // Verlauf der letzten 30 Tage
        val from = addDays(startOfDay(now()), -30)
        val pts = BodyLog.sorted(s).filter { it.at >= from }
        val top = y0 + 50 * d.u
        val bottom = d.h - d.pad
        val left = if (d.wide) d.w * 0.42f else d.pad
        val chartTop = if (d.wide) y0 + 6 * d.u else top
        if (pts.size < 2 || bottom - chartTop < 24 * d.u) return
        val mn = pts.minOf { it.kg } - 0.3; val mx = pts.maxOf { it.kg } + 0.3
        val t0 = pts.first().at.toDouble(); val t1 = pts.last().at.toDouble().coerceAtLeast(t0 + 1)
        fun px(t: Long) = (left + (d.w - d.pad - left) * ((t - t0) / (t1 - t0))).toFloat()
        fun py(kg: Double) = (bottom - (bottom - chartTop) * ((kg - mn) / (mx - mn))).toFloat()
        val path = Path()
        pts.forEachIndexed { i, e -> if (i == 0) path.moveTo(px(e.at), py(e.kg)) else path.lineTo(px(e.at), py(e.kg)) }
        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f * d.u; color = d.ac; strokeJoin = Paint.Join.ROUND }
        d.c.drawPath(path, lp)
        d.fill.color = d.ac
        d.c.drawCircle(px(pts.last().at), py(pts.last().kg), 3.5f * d.u, d.fill)
    }

    // ================= Streak & Level =================
    private fun streak(d: D, s: AppState) {
        val xp = Rewards.totalXp(s)
        val li = Rewards.levelInfo(xp)
        val y0 = d.title("⭐ STREAK & LEVEL")
        val big = d.p(d.fg, (minOf(d.h - y0 - 40 * d.u, 44 * d.u) / d.u).coerceIn(20f, 40f), true)
        val by = y0 + big.textSize
        d.c.drawText("🔥 ${Rewards.streak(s)}", d.pad, by, big)
        d.c.drawText("Tage in Folge", d.pad, by + 14 * d.u, d.p(d.soft, 11f))
        val lp = d.p(d.ac, 14f, true, Paint.Align.RIGHT)
        d.c.drawText("Level ${li.level}", d.w - d.pad, by - big.textSize * 0.3f, lp)
        val by2 = (d.h - d.pad - 6 * d.u).coerceAtLeast(by + 22 * d.u)
        d.bar(d.pad, by2, d.w - 2 * d.pad, 6 * d.u, li.into.toFloat() / li.needed.coerceAtLeast(1), d.ac)
        d.c.drawText("${li.needed - li.into} XP bis Level ${li.level + 1}", d.w - d.pad, by2 - 5 * d.u, d.p(d.soft, 10f, align = Paint.Align.RIGHT))
    }

    // ================= Mannequin =================
    private fun body(d: D, s: AppState) {
        val y0 = d.title("💪 MUSKELN", if (s.settings.mannequinMode == 0) "zuletzt" else "diese Woche")
        d.c.save(); d.c.translate(d.pad, y0)
        BodyMap.draw(d.c, d.w - 2 * d.pad, d.h - y0 - d.pad * 0.5f, Training.intensity(s.settings.mannequinMode, s),
            a(d.fg, 0x38), a(d.fg, 0xD0), d.ac, d.soft, showLabels = d.h > 150 * d.u)
        d.c.restore()
    }
}
