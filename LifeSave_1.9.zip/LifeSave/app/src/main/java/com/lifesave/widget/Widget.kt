package com.lifesave.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.RemoteViews
import com.lifesave.MainActivity
import com.lifesave.R
import com.lifesave.core.*
import com.lifesave.training.ExerciseDb
import com.lifesave.training.Training
import com.lifesave.ui.BodyMap

/**
 * Komplett-Widget: frei zusammenstellbare Bausteine (Einstellungen → Widget).
 * Alle weiteren Widgets stehen in [WIDGET_KINDS] (WidgetHost.kt).
 * Der Klassenname bleibt gleich, damit bereits platzierte Widgets erhalten bleiben.
 */
class LifeSaveWidget : KindWidget("komplett")

object WidgetRenderer {
    private fun col(s: String, fallback: Int) = runCatching { Color.parseColor(s) }.getOrDefault(fallback)

    /** u = Pixel pro dp */
    fun render(cfg: WidgetCfg, s: AppState, w: Int, h: Int, u: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w.coerceAtLeast(10), h.coerceAtLeast(10), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = col(cfg.bg, Color.parseColor("#0B1E33"))
        val fg = col(cfg.fg, Color.WHITE)
        val ac = col(cfg.accent, Color.parseColor("#C9A227"))
        val soft = (fg and 0x00FFFFFF) or (0xA0 shl 24)
        val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (bg and 0x00FFFFFF) or (cfg.alpha.coerceIn(0, 255) shl 24) }
        c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), cfg.radius * u, cfg.radius * u, bgP)

        val pad = 12 * u
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; textSize = 17 * u; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; textSize = 13 * u }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = soft; textSize = 11 * u }
        val acc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ac; textSize = 13 * u; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val bar = Paint(Paint.ANTI_ALIAS_FLAG)

        var y = pad
        val right = w - pad
        fun fits(need: Float) = y + need <= h - pad * 0.5f
        fun clip(t: String, p: Paint, maxW: Float): String {
            if (p.measureText(t) <= maxW) return t
            var e = t
            while (e.isNotEmpty() && p.measureText("$e…") > maxW) e = e.dropLast(1)
            return "$e…"
        }

        val blocks = cfg.blocks.filter { it.visible }.map { it.id }
        // Mannequin rechts daneben, falls aktiv und genug Breite
        val bodySide = "body" in blocks && w > h * 1.4f
        val textRight = if (bodySide) w - h * 0.85f else right
        if (bodySide) {
            c.save(); c.translate(textRight, pad * 0.5f)
            BodyMap.draw(c, right - textRight, h - pad, Training.intensity(s.settings.mannequinMode, s),
                (fg and 0x00FFFFFF) or (0x38 shl 24), (fg and 0x00FFFFFF) or (0xD0 shl 24), ac, soft, showLabels = false)
            c.restore()
        }
        val maxW = textRight - pad

        for (b in blocks) {
            when (b) {
                "header" -> if (fits(18 * u)) {
                    y += 13 * u
                    c.drawText(APP_NAME.uppercase(), pad, y, acc)
                    val d = fmtDay(now())
                    c.drawText(d, right - small.measureText(d), y, small)
                    y += 8 * u
                }
                "plan" -> if (fits(30 * u)) {
                    val (cur, next) = Schedule.nowNext(s)
                    y += 14 * u
                    c.drawText(if (cur != null) "JETZT · bis ${fmtMin(cur.end)}" else "TAGESPLAN", pad, y, acc)
                    y += 17 * u
                    c.drawText(clip(cur?.title ?: next?.let { "${fmtMin(it.start)} ${it.title}" } ?: "Nichts geplant", big, maxW), pad, y, big)
                    if (cur != null && next != null && fits(16 * u)) {
                        y += 16 * u
                        c.drawText(clip("Danach: ${fmtMin(next.start)} ${next.title}", txt, maxW), pad, y, txt)
                    }
                    y += 6 * u
                }
                "streak" -> if (fits(40 * u)) {
                    val li = Rewards.levelInfo(Rewards.totalXp(s))
                    y += 18 * u
                    c.drawText("🔥 ${Rewards.streak(s)} Tage", pad, y, big)
                    val lv = "Level ${li.level}"
                    c.drawText(lv, pad + maxW - acc.measureText(lv), y, acc)
                    y += 7 * u
                    bar.color = (fg and 0x00FFFFFF) or (0x33 shl 24)
                    c.drawRoundRect(RectF(pad, y, pad + maxW, y + 5 * u), 3 * u, 3 * u, bar)
                    bar.color = ac
                    c.drawRoundRect(RectF(pad, y, pad + maxW * (li.into.toFloat() / li.needed.coerceAtLeast(1)), y + 5 * u), 3 * u, 3 * u, bar)
                    y += 12 * u
                }
                "training" -> if (fits(36 * u)) {
                    val active = s.active
                    val next = Training.nextSession(s)
                    y += 14 * u
                    val head = when {
                        active != null -> "● WORKOUT LÄUFT"
                        next?.today == true && !Training.trainedToday(s) -> "HEUTE TRAINING"
                        Training.trainedToday(s) -> "✓ HEUTE TRAINIERT"
                        else -> "NÄCHSTES TRAINING"
                    }
                    c.drawText(head, pad, y, acc)
                    y += 17 * u
                    val name = active?.name ?: next?.let { n -> n.day.name + (n.date?.let { d -> if (n.today) "" else " · " + (WEEKDAY_LONG[dow(d)] ?: "") } ?: "") } ?: "Kein Plan angelegt"
                    c.drawText(clip(name, big, maxW), pad, y, big)
                    y += 6 * u
                }
                "tasks" -> if (fits(30 * u)) {
                    val open = Tasks.dueToday(s)
                    y += 14 * u
                    c.drawText("AUFGABEN · ${open.size} offen", pad, y, acc)
                    open.take(3).forEach { t ->
                        if (!fits(16 * u)) return@forEach
                        y += 16 * u
                        c.drawText(clip("○ " + t.title, txt, maxW), pad, y, txt)
                    }
                    if (open.isEmpty() && fits(16 * u)) { y += 16 * u; c.drawText("Alles erledigt 🎉", pad, y, txt) }
                    y += 6 * u
                }
                "habits" -> if (fits(30 * u)) {
                    val due = s.habits.filter { Habits.dueToday(it) }
                    val done = due.count { Habits.doneToday(it) }
                    y += 14 * u
                    c.drawText("GEWOHNHEITEN · $done/${due.size}", pad, y, acc)
                    y += 8 * u
                    var x = pad
                    val r = 6 * u
                    due.take(12).forEach { hb ->
                        bar.color = if (Habits.doneToday(hb)) ac else (fg and 0x00FFFFFF) or (0x40 shl 24)
                        c.drawCircle(x + r, y + r, r, bar)
                        x += r * 2.6f
                    }
                    y += r * 2 + 6 * u
                }
                "week" -> if (fits(24 * u)) {
                    val goal = s.settings.weeklyGoal.coerceAtLeast(1)
                    val cnt = Training.weekCount(s)
                    y += 16 * u
                    c.drawText(clip("🎯 Woche $cnt/$goal" + (if (cnt >= goal) " ✓" else "") + " · ${Training.weekStreak(s)} Wo. in Folge", txt, maxW), pad, y, txt)
                    y += 6 * u
                }
                "nutrition" -> if (fits(24 * u)) {
                    y += 16 * u
                    val tt = Nutrition.totals(startOfDay(now()), s)
                    c.drawText(clip("🥗 ${(tt["kcal"] ?: 0.0).toInt()}/${Nutrition.goal("kcal", s).toInt()} kcal · E ${(tt["protein"] ?: 0.0).toInt()}/${Nutrition.goal("protein", s).toInt()} g", txt, maxW), pad, y, txt)
                    y += 6 * u
                }
                "vitals" -> if (fits(24 * u)) {
                    y += 16 * u
                    val sl = Vitals.sleep(s)?.let { Vitals.fmtHours(it) } ?: "–"
                    val stp = Vitals.steps(s)?.toString() ?: "–"
                    c.drawText(clip("💧 ${Vitals.water(s)}/${s.settings.waterGoal}   😴 $sl   👟 $stp", txt, maxW), pad, y, txt)
                    y += 6 * u
                }
                "weight" -> if (fits(24 * u)) {
                    val l = BodyLog.latest(s)
                    y += 16 * u
                    if (l == null) c.drawText("⚖ Noch kein Gewicht", pad, y, txt)
                    else {
                        val ch = BodyLog.change(28, s)
                        val t = "⚖ ${fmtKg(l.kg)} kg" + (ch?.let { "  (" + (if (it >= 0) "+" else "") + fmtKg(Math.round(it * 10) / 10.0) + " kg / 4 Wo.)" } ?: "")
                        c.drawText(clip(t, txt, maxW), pad, y, txt)
                    }
                    y += 6 * u
                }
                "body" -> if (!bodySide && fits(60 * u)) {
                    val bh = minOf(h - y - pad, 110 * u)
                    c.save(); c.translate(pad, y)
                    BodyMap.draw(c, maxW, bh, Training.intensity(s.settings.mannequinMode, s),
                        (fg and 0x00FFFFFF) or (0x38 shl 24), (fg and 0x00FFFFFF) or (0xD0 shl 24), ac, soft, showLabels = false)
                    c.restore()
                    y += bh + 4 * u
                }
            }
        }
        return bmp
    }
}

