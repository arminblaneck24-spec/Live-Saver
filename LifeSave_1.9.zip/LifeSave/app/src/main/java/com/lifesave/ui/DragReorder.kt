package com.lifesave.ui

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.zIndex
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Lange drücken und ziehen, um Einträge einer LazyColumn umzusortieren – ohne Griff-Symbole.
 * [canMove] sagt, welche Listen-Indizes verschiebbar sind (z. B. nur die Kacheln, nicht die Überschrift).
 * [onMove] wird während des Ziehens bei jedem Platztausch aufgerufen, [onEnd] beim Loslassen (zum Speichern).
 */
class DragReorderState(
    val list: LazyListState,
    private val scope: CoroutineScope,
    private val canMove: (Int) -> Boolean,
    private val onMove: (Int, Int) -> Unit,
    private val onEnd: () -> Unit
) {
    var dragging by mutableStateOf<Int?>(null); private set
    private var delta by mutableFloatStateOf(0f)
    private var initialOffset by mutableIntStateOf(0)

    private val draggingInfo: LazyListItemInfo? get() = list.layoutInfo.visibleItemsInfo.firstOrNull { it.index == dragging }

    /** Verschiebung des gezogenen Eintrags gegenüber seiner Listenposition */
    val offset: Float get() = draggingInfo?.let { initialOffset + delta - it.offset } ?: 0f

    fun start(at: Offset) {
        val y = at.y.toInt() - list.layoutInfo.beforeContentPadding
        list.layoutInfo.visibleItemsInfo.firstOrNull { y in it.offset..(it.offset + it.size) && canMove(it.index) }?.let {
            dragging = it.index; initialOffset = it.offset; delta = 0f
        }
    }

    fun drag(dy: Float) {
        val cur = draggingInfo ?: return
        delta += dy
        val top = cur.offset + offset
        val mid = top + cur.size / 2f
        val target = list.layoutInfo.visibleItemsInfo.firstOrNull { mid.toInt() in it.offset..(it.offset + it.size) && it.index != cur.index && canMove(it.index) }
        if (target != null) {
            onMove(cur.index, target.index)
            dragging = target.index
        } else {
            // am Rand automatisch weiterscrollen
            val view = list.layoutInfo.viewportEndOffset
            val over = when {
                top < 0 -> top
                top + cur.size > view -> top + cur.size - view
                else -> 0f
            }
            if (over != 0f) scope.launch { list.scrollBy(over * 0.5f) }
        }
    }

    fun end() {
        if (dragging != null) onEnd()
        dragging = null; delta = 0f; initialOffset = 0
    }
}

@Composable
fun rememberDragReorder(list: LazyListState, canMove: (Int) -> Boolean, onMove: (Int, Int) -> Unit, onEnd: () -> Unit): DragReorderState {
    val scope = rememberCoroutineScope()
    val cm by rememberUpdatedState(canMove); val om by rememberUpdatedState(onMove); val oe by rememberUpdatedState(onEnd)
    return remember(list) { DragReorderState(list, scope, { cm(it) }, { a, b -> om(a, b) }, { oe() }) }
}

/** an die LazyColumn hängen */
fun Modifier.dragReorder(state: DragReorderState, haptic: () -> Unit = {}): Modifier = pointerInput(state) {
    detectDragGesturesAfterLongPress(
        onDragStart = { state.start(it); if (state.dragging != null) haptic() },
        onDrag = { change, amount -> change.consume(); state.drag(amount.y) },
        onDragEnd = { state.end() },
        onDragCancel = { state.end() }
    )
}

/** an jeden verschiebbaren Eintrag hängen: hebt den gezogenen Eintrag an */
fun Modifier.dragItem(state: DragReorderState, index: Int): Modifier {
    val active = state.dragging == index
    return if (!active) this else this.zIndex(1f).graphicsLayer { translationY = state.offset; shadowElevation = 16f }.scale(1.02f)
}

@Composable
fun hapticLongPress(): () -> Unit {
    val h = LocalHapticFeedback.current
    return { h.performHapticFeedback(HapticFeedbackType.LongPress) }
}
