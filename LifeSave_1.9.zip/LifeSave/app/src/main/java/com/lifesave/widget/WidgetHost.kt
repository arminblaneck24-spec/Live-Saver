package com.lifesave.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.lifesave.MainActivity
import com.lifesave.R
import com.lifesave.core.Store
import com.lifesave.core.Vitals
import com.lifesave.training.ExerciseDb

/**
 * Ein Widget-Typ.
 * @param route  Bereich, der beim Antippen geöffnet wird (siehe MainActivity.openRoute)
 * @param action Aktion für den rechten Tippbereich (z. B. +1 Glas Wasser), sonst null
 *
 * Neues Widget hinzufügen:
 *  1. hier eintragen  2. Klasse unten anlegen  3. res/xml/widget_<id>.xml + Eintrag im Manifest
 *  4. Zeichnen in KindRenderer.render ergänzen
 */
data class WidgetKind(
    val id: String, val label: String, val desc: String, val route: String,
    val cls: Class<out AppWidgetProvider>, val action: String? = null
)

const val ACTION_WATER = "com.lifesave.widget.WATER_ADD"

val WIDGET_KINDS = listOf(
    WidgetKind("today", "Heute", "Ringe für Kalorien, Eiweiß, Wasser und Gewohnheiten", "dashboard", TodayWidget::class.java),
    WidgetKind("plan", "Tagesplan", "Was jetzt dran ist und die nächsten Blöcke", "plan", PlanWidget::class.java),
    WidgetKind("training", "Training", "Nächstes Training mit Übungen – oder laufendes Workout", "training", TrainingWidget::class.java),
    WidgetKind("week", "Wochenziel", "Trainings dieser Woche und Wochen-Serie", "training", WeekWidget::class.java),
    WidgetKind("nutrition", "Ernährung", "Kalorien-Ring und Makros von heute", "nutrition", NutritionWidget::class.java),
    WidgetKind("habits", "Gewohnheiten", "Heutige Gewohnheiten zum Abhaken", "habits", HabitsWidget::class.java),
    WidgetKind("tasks", "Aufgaben", "Offene Aufgaben von heute", "tasks", TasksWidget::class.java),
    WidgetKind("water", "Wasser", "Gläser zählen – rechts tippen für +1 Glas", "dashboard", WaterWidget::class.java, ACTION_WATER),
    WidgetKind("vitals", "Schlaf & Schritte", "Schlaf, Schritte und Wasser im Vergleich zum Ziel", "dashboard", VitalsWidget::class.java),
    WidgetKind("weight", "Gewicht", "Aktuelles Gewicht mit Verlauf der letzten 30 Tage", "weight", WeightWidget::class.java),
    WidgetKind("streak", "Streak & Level", "Tage in Folge, Level und XP", "progress", StreakWidget::class.java),
    WidgetKind("body", "Mannequin", "Welche Muskeln zuletzt trainiert wurden", "body", BodyWidget::class.java),
    WidgetKind("komplett", "Komplett (eigenes)", "Frei zusammenstellbar unter Einstellungen → Widget", "", LifeSaveWidget::class.java)
)

fun kindOf(id: String) = WIDGET_KINDS.firstOrNull { it.id == id }

/** Gemeinsame Basis aller Widgets – jede Unterklasse nennt nur ihren Typ */
open class KindWidget(private val kind: String) : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        Store.init(c); ExerciseDb.init(c)
        ids.forEach { WidgetUpdater.updateOne(c, m, it, kind) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, options: Bundle) {
        Store.init(c); ExerciseDb.init(c)
        WidgetUpdater.updateOne(c, m, id, kind)
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION_WATER) {
            Store.init(c)
            Vitals.addWater(1)
            Store.flush()
            WidgetUpdater.update(c)
        }
    }
}

class TodayWidget : KindWidget("today")
class PlanWidget : KindWidget("plan")
class TrainingWidget : KindWidget("training")
class WeekWidget : KindWidget("week")
class NutritionWidget : KindWidget("nutrition")
class HabitsWidget : KindWidget("habits")
class TasksWidget : KindWidget("tasks")
class WaterWidget : KindWidget("water")
class VitalsWidget : KindWidget("vitals")
class WeightWidget : KindWidget("weight")
class StreakWidget : KindWidget("streak")
class BodyWidget : KindWidget("body")

object WidgetUpdater {
    private var attached = false
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var pending: Runnable? = null

    fun attach(c: Context) {
        if (attached) return
        attached = true
        val app = c.applicationContext
        Store.onChanged = { schedule(app) }
    }

    /** Änderungen sammeln und höchstens alle 1,5 Sek. neu zeichnen (z. B. beim Tippen) */
    fun schedule(c: Context) {
        pending?.let { handler.removeCallbacks(it) }
        val r = Runnable { pending = null; update(c) }
        pending = r
        handler.postDelayed(r, 1500)
    }

    /** alle platzierten Widgets aller Typen neu zeichnen */
    fun update(c: Context) {
        runCatching {
            val m = AppWidgetManager.getInstance(c)
            WIDGET_KINDS.forEach { k ->
                runCatching { m.getAppWidgetIds(ComponentName(c, k.cls)).forEach { updateOne(c, m, it, k.id) } }
            }
        }
    }

    fun updateOne(c: Context, m: AppWidgetManager, id: Int, kind: String) {
        runCatching {
            val k = kindOf(kind) ?: return
            val o = m.getAppWidgetOptions(id)
            val d = c.resources.displayMetrics.density
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0).takeIf { it > 0 } ?: 250
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0).takeIf { it > 0 } ?: 110
            // Bildgröße begrenzen (Speicherlimit für Widgets)
            val scale = minOf(d, 900f / wDp, 900f / hDp)
            val bmp = KindRenderer.render(kind, Store.state.settings.widget, Store.state, (wDp * scale).toInt(), (hDp * scale).toInt(), scale)
            val rv = RemoteViews(c.packageName, if (k.action != null) R.layout.widget_split else R.layout.widget)
            rv.setImageViewBitmap(R.id.widget_img, bmp)
            val open = PendingIntent.getActivity(
                c, 100 + WIDGET_KINDS.indexOf(k),
                Intent(c, MainActivity::class.java).putExtra("route", k.route).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            if (k.action != null) {
                rv.setOnClickPendingIntent(R.id.widget_left, open)
                val act = PendingIntent.getBroadcast(c, 200 + WIDGET_KINDS.indexOf(k),
                    Intent(c, k.cls).setAction(k.action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                rv.setOnClickPendingIntent(R.id.widget_right, act)
            } else rv.setOnClickPendingIntent(R.id.widget_root, open)
            m.updateAppWidget(id, rv)
        }
    }

    /** Widget direkt auf den Startbildschirm legen (Android 8+, wenn der Launcher es kann) */
    fun requestPin(c: Context, kind: String = "komplett"): Boolean = runCatching {
        val m = AppWidgetManager.getInstance(c)
        if (!m.isRequestPinAppWidgetSupported) return false
        m.requestPinAppWidget(ComponentName(c, (kindOf(kind) ?: WIDGET_KINDS.last()).cls), null, null)
    }.getOrDefault(false)
}
