package com.lifesave.training

import com.lifesave.core.*

/**
 * Cardio-Arten mit beanspruchten Muskeln und MET-Wert (Energieverbrauch).
 * MET-Werte grob nach dem „Compendium of Physical Activities“, Muskelgruppen nach gängigen
 * Trainingsquellen. kcal ≈ MET × Körpergewicht (kg) × Stunden.
 * Muskelnamen wie in der Übungsdatenbank (z. B. "quadriceps", "lats").
 *
 * Neue Art: einfach unten in [CARDIO] ergänzen.
 */
data class CardioType(
    val name: String, val icon: String, val met: Double,
    val primary: List<String>, val secondary: List<String> = emptyList(),
    val distance: Boolean = true     // km sinnvoll?
)

object Cardio {
    val CARDIO = listOf(
        CardioType("Laufen", "🏃", 9.0, listOf("quadriceps", "hamstrings", "calves", "glutes"), listOf("abdominals", "adductors", "abductors")),
        CardioType("Gehen", "🚶", 3.5, listOf("calves", "quadriceps"), listOf("glutes", "hamstrings")),
        CardioType("Wandern", "🥾", 6.0, listOf("quadriceps", "glutes", "calves", "hamstrings"), listOf("lower back", "abdominals")),
        CardioType("Radfahren", "🚴", 7.5, listOf("quadriceps", "glutes", "calves", "hamstrings"), listOf("abdominals")),
        CardioType("Ergometer", "🚲", 7.0, listOf("quadriceps", "glutes", "calves", "hamstrings"), listOf("abdominals")),
        CardioType("Schwimmen", "🏊", 7.0, listOf("lats", "shoulders", "chest", "triceps"),
            listOf("middle back", "abdominals", "lower back", "glutes", "quadriceps", "hamstrings", "biceps", "forearms", "calves")),
        CardioType("Rudern", "🚣", 7.0, listOf("lats", "middle back", "quadriceps", "glutes"),
            listOf("hamstrings", "biceps", "shoulders", "abdominals", "lower back", "forearms", "calves")),
        CardioType("Crosstrainer", "🌀", 5.0, listOf("quadriceps", "glutes", "hamstrings"), listOf("calves", "chest", "shoulders", "triceps", "biceps")),
        CardioType("Stepper", "🪜", 9.0, listOf("glutes", "quadriceps"), listOf("hamstrings", "calves"), distance = false),
        CardioType("Seilspringen", "🪢", 11.0, listOf("calves", "quadriceps"), listOf("shoulders", "forearms", "abdominals", "glutes"), distance = false),
        CardioType("Fußball", "⚽", 7.0, listOf("quadriceps", "hamstrings", "calves", "glutes"), listOf("abdominals", "adductors", "abductors")),
        CardioType("Basketball", "🏀", 6.5, listOf("quadriceps", "calves", "glutes"), listOf("shoulders", "abdominals", "hamstrings"), distance = false),
        CardioType("Tennis", "🎾", 7.3, listOf("shoulders", "forearms", "quadriceps"), listOf("calves", "abdominals", "glutes", "chest"), distance = false),
        CardioType("Boxen", "🥊", 7.8, listOf("shoulders", "chest", "triceps", "abdominals"), listOf("calves", "lats", "forearms"), distance = false),
        CardioType("Klettern", "🧗", 8.0, listOf("forearms", "lats", "biceps"), listOf("shoulders", "middle back", "abdominals", "calves"), distance = false),
        CardioType("Inlineskaten", "🛼", 7.5, listOf("quadriceps", "glutes", "abductors", "adductors"), listOf("hamstrings", "calves", "abdominals")),
        CardioType("Skifahren", "⛷", 6.0, listOf("quadriceps", "glutes"), listOf("hamstrings", "calves", "abdominals", "adductors")),
        CardioType("Tanzen", "💃", 5.0, listOf("calves", "quadriceps", "glutes"), listOf("abdominals"), distance = false),
        CardioType("Yoga", "🧘", 2.5, listOf("abdominals"), listOf("shoulders", "hamstrings", "lower back", "glutes"), distance = false),
        CardioType("Sonstiges", "⏱", 5.0, emptyList(), distance = false)
    )

    val INTENSITIES = listOf("Locker", "Mittel", "Hart")
    private val INTENSITY_FACTOR = listOf(0.75, 1.0, 1.3)

    fun type(name: String): CardioType = CARDIO.firstOrNull { it.name == name } ?: when (name) {
        "Joggen" -> CARDIO[0]
        else -> CARDIO.last()
    }

    /** zählt als Workout fürs Wochenziel (ab 20 Minuten) */
    fun countsAsWorkout(c: CardioSession) = c.minutes >= 20

    /** geschätzter Verbrauch in kcal */
    fun kcal(type: String, minutes: Int, intensity: Int, s: AppState = Store.state): Int {
        val kg = BodyLog.latest(s)?.kg ?: 75.0
        val met = type(type).met * INTENSITY_FACTOR.getOrElse(intensity) { 1.0 }
        return (met * kg * minutes / 60.0).toInt()
    }

    fun kcalOf(c: CardioSession, s: AppState = Store.state) = if (c.kcal > 0) c.kcal else kcal(c.type, c.minutes, c.intensity, s)

    /**
     * Belastung je Muskel als „Satz-Äquivalent“: 10 Min. ≈ 1 Satz für Hauptmuskeln (max. 6),
     * halb so viel für Nebenmuskeln; harte Einheiten zählen mehr.
     */
    fun muscleSets(c: CardioSession): Map<String, Double> {
        val t = type(c.type)
        val base = (c.minutes / 10.0 * INTENSITY_FACTOR.getOrElse(c.intensity) { 1.0 }).coerceAtMost(6.0)
        return t.secondary.associateWith { base * 0.5 } + t.primary.associateWith { base }
    }

    /** Vorschau fürs Mannequin beim Eintragen */
    fun preview(name: String): Map<String, Float> {
        val t = type(name)
        return t.secondary.associateWith { 0.45f } + t.primary.associateWith { 1f }
    }
}
