package com.lifesave.system

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import com.lifesave.core.Locks
import com.lifesave.core.Store
import com.lifesave.training.ExerciseDb

fun guardOn(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return s.contains(ctx.packageName + "/")
}

/**
 * Wächter (Bedienungshilfe):
 *  Solange Wiegen oder Tagesabschluss offen sind, wird jede andere App auf Life Save umgeleitet.
 *  Telefon, Notruf, Uhr, Tastatur, Health Connect und die in den Einstellungen freigegebenen Apps
 *  (Standard: Claude und Bildschirmzeit) bleiben immer frei. Kein Passwort, kein Einstellungsschutz mehr.
 */
class GuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastRedirect = 0L
    private var keyboards: Set<String> = emptySet()

    private val tick = object : Runnable {
        override fun run() {
            runCatching { onTick() }
            handler.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(this)
        ExerciseDb.init(this)
        keyboards = runCatching {
            getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
        }.getOrDefault(emptySet())
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private val ALWAYS_FREE = setOf(
        "com.android.systemui", "android",
        "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer", "com.android.phone",
        "com.samsung.android.incallui", "com.android.incallui", "com.android.server.telecom", "com.android.contacts",
        "com.samsung.android.app.contacts", "com.android.emergency", "com.samsung.android.emergency", "com.google.android.apps.safetyhub",
        "com.android.deskclock", "com.google.android.deskclock", "com.sec.android.app.clockpackage",
        // Kamera für das Fortschrittsfoto beim Wiegen
        "com.sec.android.app.camera", "com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2",
        // Google-Dienste (Barcode-Scanner, Health Connect)
        "com.google.android.gms", "com.google.android.apps.healthdata", "com.google.android.healthconnect.controller",
        "com.android.healthconnect.controller", "com.samsung.android.shealthpermissionmanager",
        "com.google.android.documentsui", "com.android.documentsui", "com.google.android.providers.media.module", "com.android.providers.media"
    )

    private fun free(pkg: String) = pkg == packageName || pkg in ALWAYS_FREE || pkg in Store.state.settings.lockApps ||
        pkg in keyboards || pkg.contains("inputmethod") || pkg.contains("keyboard") || pkg.contains("packageinstaller")

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) checkLock(pkg)
    }

    private fun checkLock(pkg: String) {
        if (free(pkg)) return
        if (Locks.pending() == null) return
        redirect()
    }

    private fun onTick() {
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        if (getSystemService(KeyguardManager::class.java).isKeyguardLocked) return
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (System.currentTimeMillis() < Updater.installUntil) return
        checkLock(pkg)
    }

    private fun redirect() {
        val n = System.currentTimeMillis()
        if (n - lastRedirect < 900) return
        lastRedirect = n
        openApp(this)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        Store.flush()
        super.onDestroy()
    }
}
