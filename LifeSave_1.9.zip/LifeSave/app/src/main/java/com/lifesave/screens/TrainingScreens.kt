package com.lifesave.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifesave.core.*
import com.lifesave.training.*
import com.lifesave.ui.*

// ================= Übersicht =================
@Composable
fun TrainingScreen() {
    val st = Store.state
    val p = pal
    var templates by remember { mutableStateOf(false) }
    val active = Training.activePlan(st)
    Screen {
        item { TrainingTile(st) }
        item {
            Row {
                Btn("Freies Training", Modifier.weight(1f), BtnKind.SECONDARY) { Training.start(null, null); Nav.go("workout") }
                Spacer(Modifier.width(8.dp))
                Btn("Cardio eintragen", Modifier.weight(1f), BtnKind.SECONDARY) { Nav.go("cardio") }
            }
        }
        item { Heading("Trainingspläne") }
        if (st.plans.isEmpty()) item { Empty("Noch keine Pläne. Starte mit einer Vorlage oder einem leeren Plan.") }
        items(st.plans, key = { it.id }) { pl ->
            val isActive = pl.id == active?.id
            Panel(accent = if (isActive) p.primary else null, onClick = { Nav.go("plan", pl.id.toString()) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Body(pl.name, bold = true)
                        Muted(planText(pl))
                    }
                    if (isActive) Pill("aktiv", p.primary) else Btn("Aktivieren", small = true, kind = BtnKind.GHOST) { Training.activate(pl.id) }
                }
                Training.next(pl, st)?.let { s ->
                    Muted("Als Nächstes: ${s.day.name}" + (s.date?.let { d -> if (s.today) " (heute)" else " · ${WEEKDAY_LONG[dow(d)]}" } ?: ""))
                }
            }
        }
        item {
            Row {
                Btn("+ Neuer Plan", Modifier.weight(1f)) {
                    val np = Plan(name = "Neuer Plan"); Training.upsertPlan(np); Nav.go("plan", np.id.toString())
                }
                Spacer(Modifier.width(8.dp))
                Btn("Vorlagen", Modifier.weight(1f), BtnKind.GHOST) { templates = !templates }
            }
        }
        item { PlanImport() }
        if (templates) items(Training.TEMPLATES.keys.toList()) { name ->
            Panel(onClick = {
                val pl = Training.TEMPLATES[name]!!.invoke()
                Training.upsertPlan(pl); templates = false
                Nav.go("plan", pl.id.toString())
            }) {
                Body(name, bold = true)
                Muted("Übernehmen und anpassen")
            }
        }
        item { Heading("Verlauf") }
        val hist = (st.workouts.map { it.start to it } ).sortedByDescending { it.first }.take(30)
        val cardio = st.cardio.sortedByDescending { it.at }.take(10)
        if (hist.isEmpty() && cardio.isEmpty()) item { Empty("Noch keine Workouts") }
        items(hist, key = { "w" + it.second.id }) { (_, w) ->
            Panel(onClick = { Nav.go("workoutlog", w.id.toString()) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Body(w.name, bold = true)
                        Muted("${fmtDateTime(w.start)} · ${fmtDuration((w.end ?: w.start) - w.start)}")
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Body(fmtNum(w.volume()), bold = true)
                        Muted("${w.doneSets()} Sätze")
                    }
                }
            }
        }
        if (cardio.isNotEmpty()) {
            item { Heading("Cardio") }
            items(cardio, key = { "c" + it.id }) { c -> CardioRow(c) }
        }
    }
}

fun planText(pl: Plan): String = when (pl.mode) {
    PLAN_SCHEDULE -> "Wochenplan · " + (if (pl.cycleWeeks == 1) "jede Woche" else "wiederholt alle ${pl.cycleWeeks} Wochen") + " · ${pl.days.size} Einheiten"
    else -> "Reihenfolge · " + pl.days.joinToString(" → ") { it.name }.ifBlank { "leer" }
}

// ================= Plan importieren (JSON, z. B. von Claude) =================
@Composable
fun PlanImport() {
    val ctx = LocalContext.current
    val p = pal
    var open by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    fun run(t: String) {
        msg = runCatching { Training.importPlans(t) }.fold(
            { l -> if (l.isEmpty()) "Kein Plan in der Datei gefunden." else { if (l.size == 1 && Store.state.plans.size == 1) Training.activate(l[0].id); "✓ ${l.joinToString { it.name }} importiert" } },
            { "Ungültige Datei – bitte die JSON-Datei von Claude verwenden." })
        if (msg.startsWith("✓")) { text = ""; open = false }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() } }
            .onSuccess { run(it) }.onFailure { msg = "Datei konnte nicht gelesen werden." }
    }
    Btn("Plan importieren (JSON)", Modifier.fillMaxWidth(), BtnKind.GHOST) { open = !open }
    if (msg.isNotBlank()) Muted(msg, Modifier.padding(top = 4.dp), color = if (msg.startsWith("✓")) p.good else p.secondary)
    if (open) Panel(Modifier.padding(top = 6.dp)) {
        Muted("Pläne von Claude als .json-Datei auswählen oder den Text einfügen. Deine bisherigen Pläne und Daten bleiben erhalten.")
        Spacer(Modifier.height(8.dp))
        Btn("Datei auswählen", Modifier.fillMaxWidth(), small = true) { launcher.launch(arrayOf("application/json", "text/plain", "*/*")) }
        Spacer(Modifier.height(8.dp))
        Field(text, { text = it }, "…oder JSON hier einfügen", singleLine = false, minLines = 3)
        Btn("Text importieren", Modifier.fillMaxWidth().padding(top = 6.dp), BtnKind.SECONDARY, small = true, enabled = text.isNotBlank()) { run(text) }
    }
}

// ================= Plan bearbeiten =================
@Composable
fun PlanEditor(arg: String) {
    val p = pal
    val st = Store.state
    val planId = arg.toLongOrNull() ?: 0L
    val pl = st.plans.find { it.id == planId } ?: run { Empty("Plan nicht gefunden"); return }
    var confirmDelete by remember { mutableStateOf(false) }
    fun save(f: (Plan) -> Plan) = Training.upsertPlan(f(Store.state.plans.find { it.id == planId } ?: pl))
    fun saveDay(dayId: Long, f: (PlanDay) -> PlanDay) = save { x -> x.copy(days = x.days.map { if (it.id == dayId) f(it) else it }) }

    if (confirmDelete) ConfirmDialog("Plan löschen?", "»${pl.name}« wird gelöscht. Dein Trainingsverlauf bleibt erhalten.", "Löschen",
        { confirmDelete = false }) { Training.deletePlan(planId); Nav.back() }

    Screen {
        item {
            Panel {
                var name by remember(planId) { mutableStateOf(pl.name) }
                Field(name, { name = it; save { x -> x.copy(name = it) } }, "Name des Plans")
                Spacer(Modifier.height(10.dp))
                Heading("Wie wiederholt sich der Plan?")
                ChipRow {
                    Pick("Feste Reihenfolge", pl.mode == PLAN_ROTATION) { save { it.copy(mode = PLAN_ROTATION) } }
                    Pick("Wochenplan", pl.mode == PLAN_SCHEDULE) { save { it.copy(mode = PLAN_SCHEDULE) } }
                }
                if (pl.mode == PLAN_ROTATION) {
                    Muted("Die Einheiten kommen immer nacheinander dran, egal an welchem Tag (z. B. Oberkörper → Unterkörper → Oberkörper …).")
                    Spacer(Modifier.height(6.dp))
                    Heading("An diesen Tagen erinnern")
                    ChipRow {
                        WEEKDAYS.forEach { (d, l) ->
                            Pick(l, d in pl.trainDays) { save { x -> x.copy(trainDays = if (d in x.trainDays) x.trainDays - d else x.trainDays + d) } }
                        }
                    }
                    Muted("An diesen Tagen zeigt die App groß an, dass Training dran ist.")
                } else {
                    Muted("Jede Einheit hat feste Wochentage. Bei mehreren Wochen wechselt der Plan wochenweise und beginnt danach von vorn.")
                    Spacer(Modifier.height(6.dp))
                    NumInput("Wiederholt sich alle", pl.cycleWeeks.toDouble(), "Wochen", min = 1.0, max = 12.0) { v -> save { it.copy(cycleWeeks = v.toInt()) } }
                    if (pl.cycleWeeks > 1) Muted("Diese Woche ist Woche ${Training.cycleWeek(pl, now())} von ${pl.cycleWeeks}.", Modifier.padding(top = 4.dp))
                    if (pl.cycleWeeks > 1) Btn("Diese Woche = Woche 1", Modifier.padding(top = 6.dp), BtnKind.GHOST, small = true) {
                        save { it.copy(startDate = startOfWeek(now())) }
                    }
                }
            }
        }
        items(pl.days, key = { it.id }) { d ->
            val idx = pl.days.indexOf(d)
            Panel(accent = p.primary) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    var dn by remember(d.id) { mutableStateOf(d.name) }
                    Field(dn, { dn = it; saveDay(d.id) { x -> x.copy(name = it) } }, "Einheit ${idx + 1}", Modifier.weight(1f))
                    IconBtn("▲", color = if (idx > 0) p.primary else p.line) { if (idx > 0) save { it.copy(days = it.days.moved(idx, idx - 1)) } }
                    IconBtn("▼", color = if (idx < pl.days.size - 1) p.primary else p.line) { save { it.copy(days = it.days.moved(idx, idx + 1)) } }
                }
                if (pl.mode == PLAN_SCHEDULE) {
                    if (pl.cycleWeeks > 1) {
                        Muted("Woche")
                        ChipRow { (1..pl.cycleWeeks).forEach { w -> Pick("$w", d.week == w) { saveDay(d.id) { it.copy(week = w) } } } }
                    }
                    Muted("Tage")
                    ChipRow {
                        WEEKDAYS.forEach { (wd, l) ->
                            Pick(l, wd in d.weekdays) { saveDay(d.id) { x -> x.copy(weekdays = if (wd in x.weekdays) x.weekdays - wd else x.weekdays + wd) } }
                        }
                    }
                }
                Sep()
                if (d.exercises.isEmpty()) Muted("Noch keine Übungen")
                d.exercises.forEachIndexed { i, e ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        val ex = ExerciseDb.get(e.exId)
                        ExImage(ex?.images ?: emptyList(), Modifier.size(44.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Body(ex?.name ?: e.exId, bold = true, maxLines = 2, size = 14.sp)
                            fun upd(f: (PlanExercise) -> PlanExercise) = saveDay(d.id) { x -> x.copy(exercises = x.exercises.mapIndexed { j, y -> if (j == i) f(y) else y }) }
                            // Sätze und Wiederholungsbereich direkt eintippen
                            Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                NumField("${e.sets}", "3", Modifier.width(58.dp), decimal = false) { t -> t.toIntOrNull()?.takeIf { it in 1..20 }?.let { v -> upd { it.copy(sets = v) } } }
                                Muted(" Sätze  ")
                                NumField("${e.lo}", "8", Modifier.width(58.dp), decimal = false) { t -> t.toIntOrNull()?.takeIf { it in 1..100 }?.let { v -> upd { it.copy(repMin = v, reps = maxOf(it.reps, v)) } } }
                                Muted(" – ")
                                NumField("${e.reps}", "12", Modifier.width(58.dp), decimal = false) { t -> t.toIntOrNull()?.takeIf { it in 1..100 }?.let { v -> upd { it.copy(reps = v, repMin = minOf(it.lo, v)) } } }
                                Muted(" Wdh.")
                            }
                        }
                        Column {
                            IconBtn("▲", color = if (i > 0) p.primary else p.line, size = 30.dp) { saveDay(d.id) { x -> x.copy(exercises = x.exercises.moved(i, i - 1)) } }
                            IconBtn("✕", color = p.secondary, size = 30.dp) { saveDay(d.id) { x -> x.copy(exercises = x.exercises.filterIndexed { j, _ -> j != i }) } }
                        }
                    }
                }
                Row(Modifier.padding(top = 6.dp)) {
                    Btn("+ Übung", Modifier.weight(1f), BtnKind.SECONDARY, small = true) {
                        Nav.pickExercise { id -> saveDay(d.id) { x -> x.copy(exercises = x.exercises + PlanExercise(id)) } }
                    }
                    Spacer(Modifier.width(8.dp))
                    Btn("Starten", Modifier.weight(1f), small = true, enabled = d.exercises.isNotEmpty()) {
                        Training.start(Store.state.plans.find { it.id == planId }, d); Nav.go("workout")
                    }
                    Spacer(Modifier.width(8.dp))
                    Btn("Löschen", small = true, kind = BtnKind.GHOST) { save { x -> x.copy(days = x.days.filterNot { it.id == d.id }) } }
                }
            }
        }
        item {
            Btn("+ Einheit hinzufügen", Modifier.fillMaxWidth()) {
                save { x -> x.copy(days = x.days + PlanDay(name = "Einheit ${('A' + x.days.size)}", weekdays = emptyList(), week = 1)) }
            }
        }
        item {
            Row {
                if (st.settings.activePlanId != planId) {
                    Btn("Als aktiven Plan nutzen", Modifier.weight(1f), BtnKind.SECONDARY) { Training.activate(planId) }
                    Spacer(Modifier.width(8.dp))
                }
                Btn("Plan löschen", Modifier.weight(1f), BtnKind.GHOST) { confirmDelete = true }
            }
        }
    }
}

// ================= Abgeschlossenes Workout =================
@Composable
fun WorkoutLogScreen(id: Long) {
    val st = Store.state
    val p = pal
    val w = st.workouts.find { it.id == id } ?: run { Empty("Workout nicht gefunden"); return }
    var del by remember { mutableStateOf(false) }
    if (del) ConfirmDialog("Workout löschen?", "Sätze, Rekorde und XP dieses Workouts werden entfernt.", "Löschen", { del = false }) {
        Training.deleteWorkout(id); Nav.back()
    }
    Screen {
        item {
            Panel(accent = p.primary) {
                Title(w.name)
                Muted(fmtDateTime(w.start) + " · " + fmtDuration((w.end ?: w.start) - w.start))
                Spacer(Modifier.height(8.dp))
                Row {
                    StatBox("Volumen", fmtNum(w.volume()), Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Sätze", "${w.doneSets()}", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                    StatBox("Übungen", "${w.exercises.size}", Modifier.weight(1f))
                }
            }
        }
        items(w.exercises) { e ->
            val ex = ExerciseDb.get(e.exId)
            Panel(onClick = { Nav.go("exercise", e.exId) }) {
                Body(ex?.name ?: e.exId, bold = true)
                e.sets.forEachIndexed { i, s ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Muted("Satz ${i + 1}", Modifier.width(64.dp))
                        Body("${fmtKg(s.weight)} kg × ${s.reps}", Modifier.weight(1f))
                        Muted(fmtNum(s.weight * s.reps))
                    }
                }
                st.records.filter { it.workoutId == w.id && it.exId == e.exId }.forEach { Pill("🏆 " + Training.recordText(it), p.gold) }
            }
        }
        item { Btn("Workout löschen", Modifier.fillMaxWidth(), BtnKind.GHOST) { del = true } }
    }
}

// ================= Cardio =================
@Composable
fun CardioScreen() {
    val p = pal
    var type by remember { mutableStateOf(Cardio.CARDIO[0].name) }
    var min by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var intensity by remember { mutableIntStateOf(1) }
    var dayOffset by remember { mutableIntStateOf(0) }   // 0 heute, 1 gestern
    val st = Store.state
    val ct = Cardio.type(type)
    val minutes = min.toIntOrNull() ?: 0
    Screen {
        item {
            Panel(accent = p.primary) {
                Heading("Was hast du gemacht?")
                // Raster aus Kacheln statt langer Chip-Zeile
                Cardio.CARDIO.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { t ->
                            val sel = t.name == type
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                    .background(if (sel) p.primary.copy(alpha = 0.15f) else p.soft)
                                    .clickable { type = t.name }.padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(t.icon, fontSize = 20.sp)
                                Text(t.name, fontSize = 11.sp, color = if (sel) p.primary else p.ink, maxLines = 1,
                                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        item {
            Panel {
                Heading("${ct.icon} ${ct.name}")
                NumInput("Dauer", minutes.toDouble(), "Min.", min = 0.0, max = 1440.0) { v -> min = v.toInt().toString() }
                if (ct.distance) NumInput("Strecke (optional)", parseNum(km) ?: 0.0, "km", decimal = true, max = 500.0) { v -> km = fmtKg(v) }
                Spacer(Modifier.height(4.dp))
                Muted("Anstrengung")
                Segmented(Cardio.INTENSITIES, intensity) { intensity = it }
                Spacer(Modifier.height(6.dp))
                Segmented(listOf("Heute", "Gestern"), dayOffset) { dayOffset = it }
                Spacer(Modifier.height(6.dp))
                Field(note, { note = it }, "Notiz (optional)")
                Spacer(Modifier.height(10.dp))
                if (minutes > 0) {
                    Row {
                        StatBox("Verbrauch", "≈ ${Cardio.kcal(type, minutes, intensity, st)} kcal", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                        StatBox("Wochenziel", if (minutes >= 20) "zählt ✓" else "ab 20 Min.", Modifier.weight(1f), if (minutes >= 20) p.good else p.inkSoft)
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Btn("Speichern", Modifier.fillMaxWidth(), enabled = minutes > 0) {
                    val at = if (dayOffset == 0) now() else addDays(now(), -1)
                    Training.addCardio(CardioSession(type = type, minutes = minutes, km = if (ct.distance) parseNum(km) ?: 0.0 else 0.0,
                        note = note.trim(), intensity = intensity, at = at))
                    min = ""; km = ""; note = ""
                }
            }
        }
        if (ct.primary.isNotEmpty()) item {
            Panel {
                Heading("Beanspruchte Muskeln")
                Mannequin(Cardio.preview(type))
                Muted("Hauptsächlich: " + ct.primary.joinToString { MUSCLES[it] ?: it } +
                    if (ct.secondary.isNotEmpty()) "\nMit dabei: " + ct.secondary.joinToString { MUSCLES[it] ?: it } else "")
                Muted("Cardio zählt wie ein Workout: Mannequin, Wochenziel, Streak und Diagramme.", Modifier.padding(top = 4.dp))
            }
        }
        item {
            val week = st.cardio.filter { it.at >= startOfWeek(now()) }
            Row {
                StatBox("Diese Woche", "${week.sumOf { it.minutes }} Min.", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                StatBox("Verbrauch Woche", "${week.sumOf { Cardio.kcalOf(it, st) }} kcal", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
                StatBox("Gesamt", "${st.cardio.size}×", Modifier.weight(1f))
            }
        }
        items(st.cardio.sortedByDescending { it.at }, key = { it.id }) { CardioRow(it) }
    }
}

@Composable
fun CardioRow(c: CardioSession) {
    var del by remember { mutableStateOf(false) }
    if (del) ConfirmDialog("Eintrag löschen?", "${c.type} vom ${fmtDate(c.at)}", "Löschen", { del = false }) { Training.deleteCardio(c.id) }
    Panel(onClick = { del = true }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Body("${Cardio.type(c.type).icon} ${c.type}", bold = true)
                Muted(fmtDateTime(c.at) + " · ${Cardio.INTENSITIES.getOrElse(c.intensity) { "" }} · ≈ ${Cardio.kcalOf(c)} kcal" + if (c.note.isNotBlank()) " · ${c.note}" else "")
            }
            Column(horizontalAlignment = Alignment.End) {
                Body("${c.minutes} Min.", bold = true)
                if (c.km > 0) Muted("${fmtKg(c.km)} km")
            }
        }
    }
}
