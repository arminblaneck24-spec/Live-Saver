package com.lifesave.system

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process
import android.provider.Settings
import com.lifesave.core.now
import com.lifesave.core.startOfDay

/** Andere Apps starten (Claude, Bildschirmzeit) und die Bildschirmzeit von heute lesen */
object Apps {
    const val CLAUDE = "com.anthropic.claude"
    val SCREEN_TIME = listOf("com.google.android.apps.wellbeing", "com.samsung.android.forest")

    data class AppInfo(val pkg: String, val label: String)

    fun launch(c: Context, pkg: String): Boolean = runCatching {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    }.getOrDefault(false)

    fun installed(c: Context, pkg: String) = runCatching { c.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

    fun label(c: Context, pkg: String): String = runCatching {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    /** Bildschirmzeit-App des Herstellers öffnen; sonst die Android-Übersicht */
    fun openScreenTime(c: Context): Boolean {
        SCREEN_TIME.forEach { if (launch(c, it)) return true }
        return runCatching {
            c.startActivity(Intent("android.settings.DIGITAL_WELLBEING").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        }.getOrDefault(false)
    }

    /** alle Apps mit Startsymbol (für die Liste „während der Sperre erlaubt") */
    fun launcherApps(c: Context): List<AppInfo> = runCatching {
        val pm = c.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }.getOrDefault(emptyList())

    // ---------- Bildschirmzeit ----------
    fun hasUsageAccess(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(AppOpsManager::class.java)
        @Suppress("DEPRECATION")
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    fun usageAccessIntent() = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Bildschirmzeit heute in Millisekunden (null ohne Berechtigung) und die meistgenutzten Apps */
    fun screenTimeToday(c: Context): Pair<Long, List<Pair<String, Long>>>? {
        if (!hasUsageAccess(c)) return null
        return runCatching {
            val um = c.getSystemService(UsageStatsManager::class.java)
            val stats = um.queryAndAggregateUsageStats(startOfDay(now()), now())
            val launcher = launcherApps(c).associate { it.pkg to it.label }
            val list = stats.values.filter { it.totalTimeInForeground > 60_000 && it.packageName in launcher }
                .map { (launcher[it.packageName] ?: it.packageName) to it.totalTimeInForeground }
                .sortedByDescending { it.second }
            list.sumOf { it.second } to list.take(5)
        }.getOrNull()
    }
}
